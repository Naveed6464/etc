/*global require*/
'use strict';

define(['angular', 'angularResource', 'angularUIRoute', 'angularUIGrid',
    'angularUIBootstrap', 'ngupload',
    'services/services', 'directives/directives', //'filters/filters',
    'controllers/controllers'
], function (angular) {
    return angular.module('myApp', [
        'ngResource',
        'ngTouch',
        'ngAnimate',
        'LocalStorageModule',
        'angular-loading-bar',
        'ui.router',
        'ui.bootstrap',
        'ui.grid',
        'ui.grid.selection',
        'ngUpload',
        'saladinAuth',
        'services',
        'directives',
        //'filters',
        'controllers'
    ]);
});