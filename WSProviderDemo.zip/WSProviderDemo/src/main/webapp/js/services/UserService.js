/*global require*/
'use strict';

define(function() {

    var service = ['$resource', 'REST_HOST', function UserService($resource, REST_HOST) {
            return $resource(REST_HOST + 'rest/user/:id', {id: '@id'});
        }
    ];

    return service;
});



