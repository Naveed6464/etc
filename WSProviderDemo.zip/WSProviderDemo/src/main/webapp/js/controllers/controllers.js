/*global require*/
'use strict';

define([
    'angular',
    'controllers/LoginController',
    'controllers/HomeController',
    'controllers/GenerateController',
    'controllers/SendController',
    'controllers/ReportController',
    'controllers/SettingsController',
    'controllers/NotSendController',
    'controllers/ResetPwdController',
    'controllers/ViewStatementController'
], function (angular, LoginController, HomeController, GenerateController, SendController, ReportController,
        SettingsController, NotSendController, ResetPwdController, ViewStatementController) {

    var controllers = angular.module('controllers', []);


    var controllersList = {
        LoginController: LoginController,
        HomeController: HomeController,
        GenerateController: GenerateController,
        SendController: SendController,
        ReportController: ReportController,
        SettingsController: SettingsController,
        NotSendController: NotSendController,
        ResetPwdController: ResetPwdController,
        ViewStatementController: ViewStatementController
    };

    angular.forEach(controllersList, function (controller, name) {
        controllers.controller(name, controller);
    });
});