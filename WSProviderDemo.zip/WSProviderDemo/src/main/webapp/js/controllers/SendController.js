/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$state', '$stateParams', '$http', 'Batches', function SendController($scope, $state, $stateParams, $http, Batches) {
            $scope.batches = Batches;
            $scope.gridOptions = {
                data: "batches",
                multiSelect: true,
                enableRowSelection: true,
                enableSelectAll: true,
                showGridFooter: true,
                //selectionRowHeaderWidth: 35,
                //rowHeight: 35
                columnDefs: [
                    /*{field: 'id', displayName: 'Id'},
                     {field: 'accountNo', displayName: 'Account No'},
                     {field: 'email', displayName: 'Email'},
                     {field: 'status', displayName: 'Status'}*/
                    {field: 'id', displayName: 'Batch ID'},
                    {field: 'fileName', displayName: 'Batch Filename'},                    
                    {field: 'status', displayName: 'Status'},
                    {field: 'username', displayName: 'User'}
                ]
            };

            $scope.gridOptions.onRegisterApi = function (gridApi) {
                $scope.gridApi = gridApi;
            };

            $scope.sendemail = function () {

                $http.post('sendemail.do', $scope.gridApi.selection.getSelectedRows()).
                        success(function (data, status, headers, config) {
                            alert("Email Successfully Delivered.");
                            $state.go("home.report");
                        }).
                        error(function (data, status, headers, config) {
                            alert(data.message);
                            $state.go("home.report");
                        });
            };
        }
    ];

    return controller;
});