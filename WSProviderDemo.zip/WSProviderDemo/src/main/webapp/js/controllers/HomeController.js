/*global require*/
'use strict';

define(function () {


    /*define(['controllers/controllers'], function(controllers) {     
     controllers.controller('HelloController', ['$scope', function HelloController($scope) {
     $scope.greeting = {text: 'Hello'};
     }
     ]);*/

    var controller = ['$rootScope', '$scope', '$state', function HomeController($rootScope, $scope, $state) {

            $scope.fileSelected = false;
            $scope.username = $rootScope.currentUser.username;

            $scope.onFileSet = function (files) {
                $scope.fileSelected = true;
            };

            /*$scope.onFileSelected = function (files) {
             $scope.fileSelected = true;                
             };*/

            $scope.uploadComplete = function (content) {
                //console.log(content);
                if (content.message === "Exist") {
                    alert("The Uploaded File already exists.");
                } else if (content.message === "StatementNotDefined") {
                    alert("Incorrect Filename, Statement does not found.");
                } else {
                    $state.go("home.generate");
                }
            };
        }
    ];

    return controller;
});