/*global require*/
'use strict';

define(function () {


    var controller = ['$rootScope', '$scope', '$http', '$state', 'REST_HOST', function ResetPwdController(
                $rootScope, $scope, $http, $state, REST_HOST) {

            $scope.user = {username: '', password: '', confirmPassword: ''};

            $scope.reset = function () {
                console.log($scope.user);
                if ($scope.user.password === '' || $scope.user.confirmPassword === '') {
                    $scope.errorMsg = "Password should not be empty!";
                    alert("Password should not be empty!");
                } else if ($scope.user.password !== $scope.user.confirmPassword) {
                    $scope.errorMsg = "Password does not match!";
                    alert("Password does not match!");
                } else {
                    $http.post(REST_HOST + 'reset', $scope.user).success(function (data, status, headers, config) {
                        $scope.user.password = '';
                        $state.go("login");
                    }).error(function (data, status, headers, config) {
                        $scope.errorMsg = "Invalid Username or passwrod!";
                    });
                }
            };
        }
    ];

    return controller;
});



