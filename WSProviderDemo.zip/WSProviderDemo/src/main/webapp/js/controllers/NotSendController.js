/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$state', '$stateParams', '$http', 'reports', function NotSendController($scope, $state, $stateParams, $http, reports) {
            $scope.reports = reports;
            $scope.gridOptions = {
                data: "reports",
                multiSelect: true,
                enableRowSelection: true,
                enableSelectAll: true,
                showGridFooter: true,
                //selectionRowHeaderWidth: 35,
                //rowHeight: 35
                columnDefs: [
                    {field: 'id', displayName: 'Id'},
                    {field: 'accountNo', displayName: 'Account No'},
                    {field: 'email', displayName: 'Email'},
                    {field: 'status', displayName: 'Status'},
                    {field: 'batchId', displayName: 'Batch ID'},
                    {field: 'fileName', displayName: 'Batch Filename'},
                    {field: 'username', displayName: 'Username'}
                ]
            };

            $scope.gridOptions.onRegisterApi = function (gridApi) {
                $scope.gridApi = gridApi;
            };

            $scope.sendemail = function () {

                $http.post('sendemail.do', $scope.gridApi.selection.getSelectedRows()).
                        success(function (data, status, headers, config) {
                            alert("Email Successfully Send");
                            $state.go("home.report");
                        }).
                        error(function (data, status, headers, config) {
                            alert("Error while submitting....");
                        });
            };
            
            $scope.deleteReport = function () {
                //$http.get('generate.do', {
                //  params: {fileName: $scope.fileName}
                $http.post('deleteReport.do', $scope.gridApi.selection.getSelectedRows()).success(function (data, status, headers, config) {
                    //$state.go("home.generate");
                    $http.get('getnotsendreport.do').success(function (data, status, headers, config) {
                        $scope.reports = data;
                    });
                });
            };
        }
    ];

    return controller;
});