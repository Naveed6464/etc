/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$http', '$state', 'Setting', function SettingsController($scope, $http, $state, Setting) {
            $scope.settings = Setting;
            $scope.submit = function () {
                $http.post('postsettings.do', $scope.settings).
                        success(function (data, status, headers, config) {
                            alert("Settings saved Successfully");
                            $state.go("home.upload");
                        }).
                        error(function (data, status, headers, config) {
                            alert("Error while submitting....");
                        });
            };
        }
    ];

    return controller;
});