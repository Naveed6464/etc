/*global require*/
'use strict';

define(['app'], function (app) {

    return app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
            $urlRouterProvider.otherwise("login");

            $stateProvider
                    .state('login', {
                        url: '/login',
                        templateUrl: 'views/login.html',
                        controller: 'LoginController',
                        saladin: {
                            authenticate: false
                        }
                    })
                    .state('reset', {
                        url: '/reset',
                        templateUrl: 'views/resetpassword.html',
                        controller: 'ResetPwdController',
                        saladin: {
                            authenticate: false
                        }
                    })
                    .state('home', {
                        url: '/home',
                        templateUrl: 'views/home.html',
                        saladin: {
                            authenticate: true
                        }
                    }).state('home.upload', {
                url: '/upload',
                controller: 'HomeController',
                templateUrl: 'views/upload.html',
                saladin: {
                    authenticate: true
                }
            }).state('home.generate', {
                url: '/generate',
                controller: 'GenerateController',
                templateUrl: 'views/generate.html',
                saladin: {
                    authenticate: true
                },
                "resolve": {
                    "Batches": ['$http', function ($http) {
                            return $http.get('getuploads.do')
                                    .then(function success(response) {
                                        return response.data;
                                    });
                        }
                    ]
                }
            }).state('home.send', {
                url: '/send',
                controller: 'SendController',
                templateUrl: 'views/send.html',
                saladin: {
                    authenticate: true
                },
                "resolve": {
                    "Batches": ['$http', function ($http) {
                            return $http.get('getgenerated.do')
                                    .then(function success(response) {
                                        return response.data;
                                    });
                        }
                    ]
                }
            }).state('home.notsend', {
                url: '/notsend',
                controller: 'NotSendController',
                templateUrl: 'views/notsend.html',
                saladin: {
                    authenticate: true
                },
                "resolve": {
                    "reports": ['$http', function ($http) {
                            return $http.get('getnotsendreport.do')
                                    .then(
                                            function success(response) {
                                                return response.data;
                                            },
                                            function error(reason) {
                                                return false;
                                            }
                                    );
                        }
                    ]
                }
            }).state('home.report', {
                url: '/report',
                controller: 'ReportController',
                templateUrl: 'views/report.html',
                saladin: {
                    authenticate: true
                },
                "resolve": {
                    "delivered": ['$http', function ($http) {
                            return $http.get('report.do', {params: {report: 'delivered'}}).then(function success(response) {
                                return response.data;
                            });
                        }],
                    "failed": ['$http', function ($http) {
                            return $http.get('report.do', {params: {report: 'failed'}}).then(function success(response) {
                                return response.data;
                            });
                        }],
                    "partial": ['$http', function ($http) {
                            return $http.get('report.do', {params: {report: 'partial'}}).then(function success(response) {
                                return response.data;
                            });
                        }]
                    
                }
            }).state('home.viewstatement', {
                url: '/viewstatement',
                controller: 'ViewStatementController',
                templateUrl: 'views/viewstatement.html',
                saladin: {
                    authenticate: true
                }
            });
        }
    ]);
});