/*global require*/
'use strict';

define([
    'angular'
], function(angular) {

    var filters = angular.module('filters', []);

    var filtersList = {
    };

    angular.forEach(filtersList, function(filter, name) {
        filters.factory(name, filter);
    });
});