/*global require*/
'use strict';

define(['app'], function (app) {

    return app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
            $urlRouterProvider.otherwise("login");

            $stateProvider
                    .state('login', {
                        url: '/login',
                        templateUrl: 'views/login.html',
                        controller: 'LoginController',
                        saladin: {
                            authenticate: false
                        }
                    })
                    .state('home', {
                        url: '/home',
                        templateUrl: 'views/home.html',
                        saladin: {
                            authenticate: true
                        }
                    }).state('home.upload', {
                url: '/upload',
                controller: 'UploadController',
                templateUrl: 'views/upload.html',
                saladin: {
                    authenticate: true
                },
                "resolve": {
                    "Settings": ['$http', 'REST_HOST', function ($http, REST_HOST) {
                            return $http.get(REST_HOST + 'getsettings.do')
                                    .then(
                                            function success(response) {
                                                return response.data;
                                            },
                                            function error(reason) {
                                                return false;
                                            }
                                    );
                        }
                    ]
                }
            }).state('home.settings', {
                url: '/settings',
                controller: 'SettingsController',
                templateUrl: 'views/settings.html',
                saladin: {
                    authenticate: true
                },
                "resolve": {
                    "Setting": ['$http', 'REST_HOST', function ($http, REST_HOST) {
                            return $http.get(REST_HOST + 'getsettings.do')
                                    .then(
                                            function success(response) {
                                                return response.data;
                                            },
                                            function error(reason) {
                                                return false;
                                            }
                                    );
                        }
                    ]
                }
            }).state('user', {
                url: '/user',
                controller: 'UserController',
                templateUrl: 'views/user/app.html',
                saladin: {
                    authenticate: true
                }
            }).state('user.main', {
                url: '/main',
                controller: 'UserMainController',
                templateUrl: 'views/user/main.html',
                saladin: {
                    authenticate: true
                },
                resolve: {
                    'Users': ['$http', 'REST_HOST', function ($http, REST_HOST) {
                            //return CRUDViewService.myPageResolve('project');
                            return $http.get(REST_HOST + 'user').then(
                                    function success(response) {
                                        return response.data;
                                    });
                        }]
                }
            }).state('user.new', {
                url: '/new/:id',
                controller: 'UserCRUDController',
                templateUrl: 'views/user/new.html',
                saladin: {
                    authenticate: true
                }
            }).state('user.edit', {
                url: '/edit/:id',
                controller: 'UserCRUDController',
                templateUrl: 'views/user/edit.html',
                saladin: {
                    authenticate: true
                }
            }).state('user.view', {
                url: '/view/:id',
                controller: 'UserCRUDController',
                templateUrl: 'views/user/view.html',
                saladin: {
                    authenticate: true
                }
            }).state('statement', {
                url: '/statement',
                controller: 'StatementController',
                templateUrl: 'views/statement/app.html',
                saladin: {
                    authenticate: true
                }
            }).state('statement.main', {
                url: '/main',
                controller: 'StatementMainController',
                templateUrl: 'views/statement/main.html',
                saladin: {
                    authenticate: true
                },
                resolve: {
                    'Statements': ['$http', 'REST_HOST', function ($http, REST_HOST) {
                            return $http.get(REST_HOST + 'statement').then(
                                    function success(response) {
                                        return response.data;
                                    });
                        }]
                }
            }).state('statement.new', {
                url: '/new/:id',
                controller: 'StatementCRUDController',
                templateUrl: 'views/statement/new.html',
                saladin: {
                    authenticate: true
                }
            }).state('statement.edit', {
                url: '/edit/:id',
                controller: 'StatementCRUDController',
                templateUrl: 'views/statement/edit.html',
                saladin: {
                    authenticate: true
                }
            }).state('statement.view', {
                url: '/view/:id',
                controller: 'StatementCRUDController',
                templateUrl: 'views/statement/view.html',
                saladin: {
                    authenticate: true
                }
            }).state('customer', {
                url: '/customer',
                controller: 'CustomerController',
                templateUrl: 'views/statement/app.html',
                saladin: {
                    authenticate: true
                }
            }).state('customer.main', {
                url: '/main',
                controller: 'CustomerMainController',
                templateUrl: 'views/customer/main.html',
                saladin: {
                    authenticate: true
                },
                resolve: {
                    'Customer': ['$http', 'REST_HOST', function ($http, REST_HOST) {
                            return $http.get(REST_HOST + 'customer').then(
                                    function success(response) {
                                        return response.data;
                                    });
                        }]
                }
            }).state('customer.new', {
                url: '/new/:id',
                controller: 'CustomerCRUDController',
                templateUrl: 'views/customer/new.html',
                saladin: {
                    authenticate: true
                }
            }).state('customer.edit', {
                url: '/edit/:id',
                controller: 'CustomerCRUDController',
                templateUrl: 'views/customer/edit.html',
                saladin: {
                    authenticate: true
                }
            }).state('customer.view', {
                url: '/view/:id',
                controller: 'CustomerCRUDController',
                templateUrl: 'views/customer/view.html',
                saladin: {
                    authenticate: true
                }
            }).state('mapping', {
                url: '/mapping',
                controller: 'MappingCtrl',
                templateUrl: 'views/mapping/app.html',
                saladin: {
                    authenticate: true
                }
            }).state('mapping.main', {
                url: '/main',
                controller: 'MappingMainCtrl',
                templateUrl: 'views/mapping/main.html',
                saladin: {
                    authenticate: true
                },
                resolve: {
                    'Statements': ['$http', 'REST_HOST', function ($http, REST_HOST) {
                            return $http.get(REST_HOST + 'mapping').then(
                                    function success(response) {
                                        return response.data;
                                    });
                        }]
                }
            }).state('mapping.new', {
                url: '/new/:id',
                controller: 'MappingCRUDCtrl',
                templateUrl: 'views/mapping/new.html',
                saladin: {
                    authenticate: true
                }
            }).state('mapping.edit', {
                url: '/edit/:id',
                controller: 'MappingCRUDCtrl',
                templateUrl: 'views/mapping/edit.html',
                saladin: {
                    authenticate: true
                }
            }).state('mapping.view', {
                url: '/view/:id',
                controller: 'MappingCRUDCtrl',
                templateUrl: 'views/mapping/view.html',
                saladin: {
                    authenticate: true
                }
            });
        }
    ]);
});