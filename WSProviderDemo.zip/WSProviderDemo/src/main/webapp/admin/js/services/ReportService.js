/*global require*/
'use strict';

define(function() {

    var service = ['$http', '$q', '$route', 'REST_HOST', function ReportService($http, $q, $route, REST_HOST) {
            var reportsModel = [];
            var reportService = {};

            //var reportsDailyURL = REST_HOST + 'report/'; //Because of Spring DATA JPA            
            var reportsDailyURL = REST_HOST ;

            reportService.myPageResolve = function() {
                var defer = $q.defer();
                var uid = $route.current.params.uid;
                var name = $route.current.params.name;
                $http.get(reportsDailyURL + name + "/" + uid).success(function(data) {
                    reportsModel = data;
                    defer.resolve();
                });
                return defer.promise;
            };

            reportService.getFormModel = function() {
                return reportsModel;
            };

            reportService.getReportsTblColmns = function() {
                var tblColumns = [
                    {"sTitle": "Testcase ID"},
                    {"sTitle": "Scenario"},
                    {"sTitle": "Module"},
                    {"sTitle": "Project"},
                    {
                        "sTitle": "Date", "sDefaultContent": "",
                        "fnRender": function(oObj) {
                            return new Date(oObj.aData["date"]).toUTCString();
                        }
                    },
                    {"sTitle": "User"},
                    {"sTitle": "Txn ID"},
                    {"sTitle": "Type"},
                    {"sTitle": "Status"}
                ];
                return tblColumns;
            };

            reportService.getReportsColumnDefs = function() {
                var columnDefs = [
                    {"mDataProp": "testCase.id", "aTargets": [0]},
                    {"mDataProp": "testCase.scenario.name", "aTargets": [1]},
                    {"mDataProp": "testCase.scenario.module.name", "aTargets": [2]},
                    {"mDataProp": "testCase.scenario.module.project.name", "aTargets": [3]},
                    {"mDataProp": "date", "aTargets": [4]},
                    {"mDataProp": "user.userName", "aTargets": [5]},
                    {"mDataProp": "txnID", "aTargets": [6]},
                    {"mDataProp": "type", "aTargets": [7]},
                    {"mDataProp": "status", "aTargets": [8]}
                ];
                return columnDefs;
            };

            reportService.getOverrideOptions = function() {
                // not mandatory, you can use defaults in directive        
                var overrideOptions = {
                    "bStateSave": true,
                    "iCookieDuration": 2419200, /* 1 month */
                    "bPaginate": true,
                    "bLengthChange": true,
                    "bFilter": true,
                    "bInfo": true,
                    "bDestroy": true
                };
                return overrideOptions;
            };
            return reportService;
        }
    ];

    return service;
});