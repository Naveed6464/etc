/*global require*/
'use strict';

define(function () {


    /*define(['controllers/controllers'], function(controllers) {     
     controllers.controller('HelloController', ['$scope', function HelloController($scope) {
     $scope.greeting = {text: 'Hello'};
     }
     ]);*/

    var controller = ['$scope', '$state', function HomeController($scope, $state) {
            
            $scope.fileSelected = false;
            
            $scope.onFileSet = function (files) {
                $scope.fileSelected = true;                
            };

            /*$scope.onFileSelected = function (files) {
                $scope.fileSelected = true;                
            };*/

            $scope.uploadComplete = function (content) {
                $state.go("home.generate", {fileName: content});
            };
        }
    ];

    return controller;
});