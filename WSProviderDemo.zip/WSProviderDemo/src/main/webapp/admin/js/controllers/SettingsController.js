/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$http', '$state', 'Setting', 'REST_HOST', function SettingsController($scope, $http, $state, Setting, REST_HOST) {
            $scope.settings = Setting;
            $scope.submit = function () {
                $http.post(REST_HOST + 'postsettings.do', $scope.settings).
                        success(function (data, status, headers, config) {
                            alert("Settings saved Successfully");
                            $state.go("home.upload");
                        }).
                        error(function (data, status, headers, config) {
                            alert("Error while submitting....");
                        });
            };
        }
    ];

    return controller;
});