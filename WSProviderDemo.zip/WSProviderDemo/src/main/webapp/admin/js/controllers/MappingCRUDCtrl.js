/*global require*/
'use strict';

define(['angular'], function (angular) {

    var controller = ['$scope', '$state', '$stateParams', '$http', 'REST_HOST',
        function MappingCRUDCtrl($scope, $state, $stateParams, $http, REST_HOST) {

            //$scope.app = App;
            $scope.app = {
                "name": "mapping", "title": "File Mapping", "img": "icon-48-stats.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "fileType", "label": "File Type", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "Delimiter", "label": "Delimiter", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2},
                    {"model": "PreProcessRTN", "label": "Pre Process RTN", "position": 2, "reportPosition": 2, "visible": true, "visibleInReports": true, "widgetType": "multi", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 3},
                    {"model": "recordType", "label": "RecordType", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "asociated", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 4,
                        "multiFields": [
                            {"model": "fieldName", "label": "Field Name", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 10},
                            {"model": "operation", "label": "Operation", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 5},
                            {"model": "conversion", "label": "Conversion", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 11},
                            {"model": "position", "label": "Position", "position": 5, "reportPosition": 5, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 6},
                            {"model": "startPosition", "label": "startPosition", "position": 6, "reportPosition": 6, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 7},
                            {"model": "length", "label": "Length", "position": 7, "reportPosition": 7, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 8}
                        ]}

                ],
                "id": 1};
            $scope.isFormNew = true;
            $scope.isFormEdit = true;
            var Entity = {};

            if (!$stateParams.id || $stateParams.id === 'new') {
                $scope.entity = Entity;
            } else {
                $scope.isFormNew = false;
                $scope.entity = Entity;
                $http.get(REST_HOST + $scope.app.name + '/' + $stateParams.id).then(
                        function success(response) {
                            $scope.entity = response.data;
                        });
            }

            $scope.entity.PreProcessRTN = [''];
            $scope.entity.recordType = [{}];
            $scope.gotoToMain = function () {
                $state.go("mapping.main");
            };
        }
    ];
    return controller;
});