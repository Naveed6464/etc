/*global require*/
'use strict';

define([
    'angular',
    'controllers/LoginController',
    'controllers/UploadController',
    'controllers/SettingsController',
    'controllers/UserController',
    'controllers/UserCRUDController',
    'controllers/UserMainController',
    'controllers/StatementController',
    'controllers/StatementCRUDController',
    'controllers/StatementMainController',
    'controllers/CustomerController',
    'controllers/CustomerCRUDController',
    'controllers/CustomerMainController',
    'controllers/MappingCtrl',
    'controllers/MappingMainCtrl',
    'controllers/MappingCRUDCtrl'
], function (angular, LoginController, UploadController, SettingsController, UserController, UserCRUDController, UserMainController,
        StatementController, StatementCRUDController, StatementMainController, CustomerController, CustomerCRUDController, CustomerMainController,
        MappingCtrl, MappingMainCtrl, MappingCRUDCtrl) {

    var controllers = angular.module('controllers', []);

    var controllersList = {
        LoginController: LoginController,
        UploadController: UploadController,
        SettingsController: SettingsController,
        UserController: UserController,
        UserCRUDController: UserCRUDController,
        UserMainController: UserMainController,
        StatementController: StatementController,
        StatementCRUDController: StatementCRUDController,
        StatementMainController: StatementMainController,
        CustomerController: CustomerController,
        CustomerCRUDController: CustomerCRUDController,
        CustomerMainController: CustomerMainController,
        MappingCtrl: MappingCtrl,
        MappingMainCtrl: MappingMainCtrl,
        MappingCRUDCtrl: MappingCRUDCtrl
    };

    angular.forEach(controllersList, function (controller, name) {
        controllers.controller(name, controller);
    });
});