/*global require*/
'use strict';

define(['angular'], function (angular) {

    var controller = ['$scope', '$state', '$stateParams', '$http', 'REST_HOST',
        function UserCRUDController($scope, $state, $stateParams, $http, REST_HOST) {

            //$scope.app = App;
            $scope.app = {
                "name": "user", "title": "User", "img": "icon-48-user.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "firstName", "label": "First Name", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "lastName", "label": "Last Name", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2},
                    {"model": "username", "label": "Userame", "position": 2, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 3},
                    {"model": "password", "label": "Password", "position": 3, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "password", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 4},
                    {"model": "role", "label": "Role", "position": 3, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "select", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 5, "list": [{"id": "user", "name": "User"}, {"id": "admin", "name": "Admin"}]}
                ],
                "id": 1};
            $scope.isFormNew = true;
            $scope.isFormEdit = true;
            var Entity = {};
            if (!$stateParams.id || $stateParams.id === 'new') {
                $scope.entity = Entity;
            } else {
                $scope.isFormNew = false;
                $scope.entity = Entity;
                $http.get(REST_HOST + $scope.app.name + '/' + $stateParams.id).then(
                        function success(response) {
                            $scope.entity = response.data;
                        });
            }

            $scope.gotoToMain = function () {
                $state.go("user.main");
            };
        }
    ];
    return controller;
});