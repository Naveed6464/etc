/*global require*/
'use strict';

define(['angular'], function (angular) {

    var controller = ['$scope', '$state', '$http', 'Users', 'NgTableParams', 'REST_HOST', function UserMainController(
                $scope, $state, $http, Users, NgTableParams, REST_HOST) {
            $scope.entityName = "user";
            //$scope.app = App;
            $scope.app = {
                "name": "user", "title": "User", "img": "icon-48-user.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "firstName", "label": "First Name", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "lastName", "label": "Last Name", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2}
                ],
                "id": 1};
            var columnDefs = [];
            for (var i in $scope.app.fields) {
                columnDefs[i] = {"field": $scope.app.fields[i].model, "name": $scope.app.fields[i].label};
            }
            columnDefs[$scope.app.fields.length] = {
                "name": "Action", //class=\"ui-grid-cell-contents\"
                enableSorting: false,
                enableColumnMenu: false,
                cellTemplate: "<div><a class='btn btn-default btn-sm' ui-sref=\"" + 'application.edit'
                        + "({id: row.entity.id})"
                        + "\"><i class='glyphicon glyphicon-edit'></i></a>  "
                        + "<a class='btn btn-default btn-sm' ui-sref=\"" + 'application.view'
                        + "({id: row.entity.id})"
                        + "\"><i class='glyphicon glyphicon-th-list'></i></a></div>"
            };
            $scope.gridOptions = {};
            $scope.gridOptions.columnDefs = columnDefs;
            $scope.data = Users;
            /*$http.get(REST_HOST + $scope.app.name).success(function (data) {
             $scope.gridOptions.data = data;
             $scope.data = data;                
             });*/


            $scope.tableParams = new NgTableParams({
                page: 1, // show first page
                count: 10 // count per page
            }, {
                total: $scope.data.length, // length of data
                getData: function ($defer, params) {
                    $defer.resolve($scope.data.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });

            $scope.gotoToNew = function () {
                $state.go($scope.entityName + '.new');
            };
        }
    ];
    return controller;
});