/*global require*/
'use strict';

define(['angular'], function (angular) {

    var controller = ['$scope', '$state', '$http', 'REST_HOST', function StatementController($scope, $state, $http, REST_HOST) {
            $scope.entityName = "statement";
            //$scope.app = App;
            $scope.app = {
                "name": "statement", "title": "Statement-Type", "img": "icon-48-user.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "firstName", "label": "First Name", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "lastName", "label": "Last Name", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2}
                ],
                "id": 1};

            $scope.gotoToNew = function () {
                $state.go($scope.entityName + '.new');
            };
        }
    ];
    return controller;
});