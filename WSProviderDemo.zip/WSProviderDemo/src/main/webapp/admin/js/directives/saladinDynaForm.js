/*global require*/
'use strict';

define(['angular'], function (angular) {

    return ['$rootScope', function ($rootScope) {
            return {
                restrict: 'A',
                scope: {
                    app: '=',
                    entity: '=',
                    isFormNew: '=',
                    isFormEdit: '=',
                    entityName: '='
                },
                templateUrl: 'views/templates/saladinDynaForm.html',
                replace: true,
                controller: ['$scope', '$http', 'REST_HOST', '$stateParams', '$state', function ($scope, $http, REST_HOST, $stateParams, $state) {
                        $scope.save = function () {
                            if ($scope.isFormNew) {
                                $http.post(REST_HOST + $scope.app.name, $scope.entity)
                                        .success(function (response) {
                                            $scope.gotoToMain();
                                        });
                            } else {
                                $http.put(REST_HOST + $scope.app.name + "/" + $stateParams.id, $scope.entity)
                                        .success(function (response) {
                                            $scope.gotoToMain();
                                        });
                            }
                        };
                        $scope.remove = function () {
                            /*$scope.entity.$remove(function (entity) {
                             $scope.gotoToMain();
                             });*/
                            $http.delete(REST_HOST + $scope.app.name + "/" + $stateParams.id, $scope.entity)
                                    .success(function (response) {
                                        $scope.gotoToMain();
                                    });
                        };

                        $scope.gotoToMain = function () {
                            $state.go($scope.app.name + ".main");
                        };

                        $scope.add = function (model) {
                            $scope.entity[model].push('');
                            $scope.apply();
                        };
                        $scope.remove = function (model, index) {
                            $scope.entity[model].splice(index, 1);
                        };

                        $scope.addAso = function (model) {
                            $scope.entity[model].push({});
                            $scope.apply();
                        };
                        $scope.removeAso = function (model, index) {
                            $scope.entity[model].splice(index, 1);
                        };

                    }],
                link: function (scope, element, attrs) {
                }
            };
        }];
});