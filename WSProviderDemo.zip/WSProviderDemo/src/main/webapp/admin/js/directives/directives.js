/*global require*/
'use strict';

define([
    'angular',
    'directives/onFileSelected',
    'directives/saladinDynaForm',
    'directives/saladinFormView'
], function (angular, onFileSelected, saladinDynaForm, saladinFormView) {

    var directives = angular.module('directives', []);

    var directivesList = {
        onFileSelected: onFileSelected,
        saladinDynaForm: saladinDynaForm,
        saladinFormView: saladinFormView
    };

    angular.forEach(directivesList, function (directive, name) {
        directives.directive(name, directive);
    });
});