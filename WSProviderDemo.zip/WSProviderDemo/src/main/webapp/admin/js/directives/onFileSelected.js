/*global require*/
'use strict';

define(function () {

    return ['$rootScope', function ($rootScope) {
            return {
                restrict: 'A',
                scope: {
                    onFileSelected: '&',
                    fileSelected: '='
                },
                link: function (scope, element, attrs) {
                    element.bind("change", function () {
                        scope.fileSelected = true;
                        //alert("onfileselected " + scope.selected);
                        ////match the selected files to the name 'selectedFileList', and
                        //execute the code in the data-dbinf-on-files-selected attribute
                        scope.onFileSelected({selectedFileList: element[0].files});
                    });
                }
            };
        }];
});