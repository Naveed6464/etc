/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.util.Date;

/**
 *
 * @author naveed
 */
public class JsonUtils {

    private static final JsonDeserializer<Date> deserializer = new JsonDeserializer<Date>() {

        @Override
        public Date deserialize(JsonElement json, Type type, JsonDeserializationContext jdc) throws JsonParseException {
            return new Date(json.getAsJsonPrimitive().getAsLong());
        }

    };
    private static final Gson gson = new GsonBuilder()
            //.setDateFormat(DateFormat.FULL)
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ") //("yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "EEE, dd MMM yyyy HH:mm:ss zzz", "yyyy-MM-dd")
            .registerTypeAdapter(Date.class, deserializer)
            .excludeFieldsWithoutExposeAnnotation()
            .create();

    public static String convertToJson(Object obj) {
        return gson.toJson(obj);
    }

    public static String convertToJson(Object obj, Class cls) {        
        return gson.toJson(obj, cls);
    }

    public static <T> T convertToObject(String json, Class<T> cls) {
        return gson.fromJson(json, cls);
    }

    private static Gson simpleJson = new GsonBuilder()
            //.setDateFormat(DateFormat.FULL)
            .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ") //("yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "EEE, dd MMM yyyy HH:mm:ss zzz", "yyyy-MM-dd")
            .registerTypeAdapter(Date.class, deserializer).create();

    public static <T> T fromJson(String json, Class<T> cls) {
        return simpleJson.fromJson(json, cls);
    }
}
