/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.config;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.servlet.GuiceServletContextListener;
import com.google.inject.servlet.ServletModule;
import com.naveed.ws.service.WebServiceServlet;
import com.naveed.ws.web.servlet.AdminLoginServlet;
import com.naveed.ws.web.servlet.LoginServlet;
import com.naveed.ws.web.servlet.LogoutServlet;
import com.naveed.ws.web.servlet.ResetPwdHandler;
import com.naveed.ws.web.servlet.UsersCRUDServlet;
import com.naveed.ws.web.servlet.UsersServlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import org.apache.shiro.guice.aop.ShiroAopModule;
import org.apache.shiro.guice.web.GuiceShiroFilter;
import org.apache.shiro.guice.web.ShiroWebModule;

/**
 *
 * @author naveed
 */
public class WebConfig extends GuiceServletContextListener {//implements WebApplicationInitializer

    private ServletContext servletContext;

    @Override
    public void contextInitialized(final ServletContextEvent servletContextEvent) {
        this.servletContext = servletContextEvent.getServletContext();
        super.contextInitialized(servletContextEvent);
    }

    @Override
    protected Injector getInjector() {
        return Guice.createInjector(new ServletModule() {

            @Override
            protected void configureServlets() {
                //filter("/*").through(GuiceShiroFilter.class);
                //serve("/api/*").with(DelegateServlet.class);
                //serve("/stuff/forbidden/*").with(HelloServlet.class);                
                serve("/login").with(LoginServlet.class);
                serve("/reset").with(ResetPwdHandler.class);
                serve("/logout").with(LogoutServlet.class);
                serve("/adminlogin").with(AdminLoginServlet.class);
                //serve("/uploadjasper.do").with(JasperUploadHandler.class);
                serve("/user").with(UsersServlet.class);
                serve("/user/*").with(UsersCRUDServlet.class);
                serve("/test").with(WebServiceServlet.class);
                //serve("/user/").with(GetUserServlet.class);
            }

        }//,
        //   new SecurityModule(servletContext), ShiroWebModule.guiceFilterModule(), new ShiroAopModule()
        );
    }
}
