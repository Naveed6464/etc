/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.servlet;

import com.naveed.ws.domain.entities.User;
import com.naveed.ws.domain.services.UserService;
import java.io.IOException;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
@Singleton
public class UsersCRUDServlet extends BaseServlet {

    @Inject
    UserService userService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURL().toString();
        String path = url.substring(url.lastIndexOf("/") + 1, url.length());
        if (path.equals("user")) {
            writeRestResponse(userService.findAll(), resp);
        } else {
            Long id = Long.parseLong(path);
            writeRestResponse(userService.find(id), resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = jsonRequest(req, User.class);
        userService.save(user);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = jsonRequest(req, User.class);
        userService.update(user);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = req.getRequestURL().toString();
        String path = url.substring(url.lastIndexOf("/") + 1, url.length());
        //User user = jsonRequest(req, User.class);
        Long id = Long.parseLong(path);
        userService.delete(id);
    }

}
