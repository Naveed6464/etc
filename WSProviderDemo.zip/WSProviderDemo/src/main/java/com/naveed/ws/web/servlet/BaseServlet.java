/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.servlet;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.gson.JsonObject;
import com.naveed.ws.domain.entities.Log;
import com.naveed.ws.domain.services.LogService;
import com.naveed.ws.web.util.JsonUtils;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Administrator
 */
public class BaseServlet extends HttpServlet {

    Logger log = LoggerFactory.getLogger(BaseServlet.class);
    String MIME_TEXT_PLAIN = "text/plain";
    String MIME_TEXT_HTML = "text/html";
    private final String MIME_APPLICATION_JSON = "application/json;charset=UTF-8";

    protected final String MESSAGE = "message";
    protected final String CODE = "code";
    protected final String TOKEN = "token";
    protected final int HTTP_STATUS_OK = 200;
    protected final int HTTP_STATUS_NOT_FOUND = 404;
    protected final int HTTP_STATUS_FORBIDDEN = 403;
    protected final int HTTP_STATUS_INTERNAL_SERVER_ERROR = 500;

    @Inject
    LogService logService;

    /**
     * Login and make sure you then have a new session. This helps prevent
     * session fixation attacks.
     *     
* @param token
     * @param subject
     */
    protected static void loginWithNewSession(AuthenticationToken token, Subject subject) {
        Session originalSession = subject.getSession();
        Map<Object, Object> attributes = Maps.newLinkedHashMap();
        Collection<Object> keys = originalSession.getAttributeKeys();
        for (Object key : keys) {
            Object value = originalSession.getAttribute(key);
            if (value != null) {
                attributes.put(key, value);
            }
        }
        originalSession.stop();
        subject.login(token);
        Session newSession = subject.getSession();
        for (Object key : attributes.keySet()) {
            newSession.setAttribute(key, attributes.get(key));
        }
    }

    protected boolean isCurrentUserAdmin() {
        Subject subject = SecurityUtils.getSubject();
        return subject.hasRole("admin");
    }

    protected void issue(String mimeType, int returnCode, String output, HttpServletResponse response) {
        try {
            response.setContentType(mimeType);
            response.setStatus(returnCode);
            response.getWriter().println(output);
        } catch (IOException ex) {
            log.error("Error Writing output " + ex);
        }
    }

    protected void issueJson(HttpServletResponse response, int status, String... args) {
        Preconditions.checkArgument(args.length % 2 == 0, "There must be an even number of strings");
        //JSONObject obj = new JSONObject();
        JsonObject json = new JsonObject();
        for (int i = 0; i < args.length; i += 2) {
            json.addProperty(args[i], args[i + 1]);
            //obj.put(args[i], args[i + 1]);
        }
        issueJson(response, status, json);
    }

    protected void issueJson(HttpServletResponse response, int status, JsonObject json) {
        issue(MIME_APPLICATION_JSON, status, json.toString(), response);
    }

    protected void writeResponse(boolean isRestResponse, Object methodReturnValue, HttpServletResponse response) throws IOException {
        if (isRestResponse) {
            writeRestResponse(methodReturnValue, response);
        } else {
            response.getWriter().write(methodReturnValue.toString());
        }
    }

    protected void writeRestResponse(Object methodReturnValue, HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=UTF-8");//application/xml response.setCharacterEncoding("UTF-8");       
        response.getWriter().write(JsonUtils.convertToJson(methodReturnValue));
    }

    protected List<Object> resolveMethodParameters(List<String> pathValues, Class<?>[] parameters, HttpServletRequest request, Class<?> entityClass) throws IOException {
        List<Object> args = new ArrayList<>();
        for (int i = 0; i < parameters.length; i++) {
            //log.info("Parameter Type " + parameters[i].getTypeName() + " " + parameters[i].getSimpleName());
            switch (parameters[i].getSimpleName()) {
                case "boolean":
                case "Boolean":
                    args.add(Boolean.parseBoolean(pathValues.get(i)));
                    break;
                case "char":
                case "Character":
                    args.add(pathValues.get(i).charAt(0));
                    break;
                case "byte":
                case "Byte":
                    args.add(Byte.parseByte(pathValues.get(i)));
                    break;
                case "short":
                case "Short":
                    args.add(Short.parseShort(pathValues.get(i)));
                    break;
                case "int":
                case "Integer":
                    args.add(Integer.parseInt(pathValues.get(i)));
                    break;
                case "long":
                case "Long":
                    args.add(Long.parseLong(pathValues.get(i)));
                    break;
                case "float":
                case "Float":
                    args.add(Float.parseFloat(pathValues.get(i)));
                    break;
                case "double":
                case "Double":
                    args.add(Double.parseDouble(pathValues.get(i)));
                    break;
                case "String":
                    args.add(pathValues.get(i));
                    break;
                case "Serializable":
                    args.add(Long.parseLong(pathValues.get(i)));
                    break;
                case "Object":
                    if (entityClass != null) {
                        log.info("Rest Request Object " + entityClass.getName());
                        args.add(JsonUtils.convertToObject(getRestRequest(request), entityClass));
                    } else {
                        log.info("Custom Rest Request Object :: " + parameters[i].getName());
                        args.add(JsonUtils.convertToObject(getRestRequest(request), parameters[i]));
                        //args.add((Object) pathValues.get(i));
                    }
                    break;
                default:
                    args.add(pathValues.get(i));
                    break;
            }
            //args.add(parameters[i].cast(pathValues.get(i)));
        }
        return args;
    }

    protected List<Object> restRequestResolveParameters(HttpServletRequest request, Class<?>[] parameters, Class<?> entityClass) throws IOException {
        List<Object> args = new ArrayList<>();
        for (Class<?> parameter : parameters) {
            if (entityClass != null) {
                args.add(JsonUtils.convertToObject(getRestRequest(request), entityClass));
            } else {
                args.add(JsonUtils.convertToObject(getRestRequest(request), parameter.getClass()));
            }
        }
        return args;
    }

    protected String getRestRequest(HttpServletRequest request) throws IOException {
        StringBuilder builder = new StringBuilder();
        String str;
        while ((str = request.getReader().readLine()) != null) {
            builder.append(str);
        }
        //log.info("REST REQUEST MSG ::" + builder);
        return builder.toString();
    }

    protected <T> T jsonRequest(HttpServletRequest request, Class<T> cls) throws IOException {
        StringBuilder builder = new StringBuilder();
        String str;
        while ((str = request.getReader().readLine()) != null) {
            builder.append(str);
        }
        return JsonUtils.fromJson(builder.toString(), cls);
    }

    protected void login(HttpServletRequest request, HttpServletResponse response) throws IOException {
        login(request, response, jsonRequest(request, LoginUser.class));
    }

    protected void login(HttpServletRequest request, HttpServletResponse response, LoginUser loginUser) {
        if (loginUser != null) {
            //String password = WebUtils.getCleanParam(request, user.getUsername());
            //String username = WebUtils.getCleanParam(request, user.getPassword());
            boolean rememberMe = loginUser.isRememberMe();
            String host = request.getRemoteHost();
            UsernamePasswordToken token = new UsernamePasswordToken(loginUser.getUsername(), loginUser.getPassword(), rememberMe, host);
            try {
                Subject subject = SecurityUtils.getSubject();
                //loginWithNewSession(token, subject);
                subject.login(token);
                loginLog(loginUser.getUsername(), request);                
                issueJson(response, HTTP_STATUS_OK, MESSAGE, "ok", TOKEN, generateKey(loginUser.getUsername()));
            } catch (AuthenticationException e) {
                issueJson(response, HTTP_STATUS_NOT_FOUND, MESSAGE, "cannot authorize " + loginUser.getUsername() + ": " + e.getMessage());
            }
        } else {
            issueJson(response, HTTP_STATUS_NOT_FOUND, MESSAGE, "cannot able authorize, user not found.");
        }
    }

    public void logout() {
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
    }

    public static byte[] key = new byte[64];
    public static boolean keyInitialize = false;

    public static byte[] getKey() {
        if (!keyInitialize) {
            new SecureRandom().nextBytes(key);
            keyInitialize = true;
        }
        return key;
    }

    private String generateKey(String username) {
        return Jwts.builder().setSubject(username).signWith(SignatureAlgorithm.HS256, key).compact();
    }

    public String getUserId(HttpServletRequest request) {
        String authorization = request.getHeader("Authorization");
        //Iterable<String> split = Splitter.on(' ').trimResults().omitEmptyStrings().split(authorization);
        String compact = authorization.replace("Bearer ", "");
        String subject = Jwts.parser().setSigningKey(key).parseClaimsJws(compact).getBody().getSubject();
        return subject;
    }

    public void loginLog(String username, HttpServletRequest request) {
        String ip = request.getRemoteAddr();
        Log logdb = new Log("info", "User has been logged in", username, ip, "Login");
        logService.save(logdb);
        log.info(logdb.toString());
    }

    public void log(String msg, String action, HttpServletRequest request) {
        log("info", msg, action, request);
    }

    public void log(String level, String msg, String action, HttpServletRequest request) {
        String username = getUserId(request);
        String ip = request.getRemoteAddr();
        Log logdb = new Log(level, msg, username, ip, action);
        logService.save(logdb);
        if (level.equals("info")) {
            log.info(logdb.toString());
        } else if (level.equals("error")) {
            log.error(logdb.toString());
        }
    }

}
