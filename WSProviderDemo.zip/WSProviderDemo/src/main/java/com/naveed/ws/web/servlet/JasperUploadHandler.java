/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.servlet;

import com.google.gson.Gson;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author nmrehman
 *
 */
@Singleton
public class JasperUploadHandler extends HttpServlet {

    Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> fileNames = new ArrayList<>();
        String resp = "";
        if (ServletFileUpload.isMultipartContent(request)) {
            try {
                String uploadDir = getServletContext().getInitParameter("UPLOAD_JASPER_DIRECTORY");
                System.out.println("JASPER UPLOAD DIR >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   " + uploadDir);
                if (!new File(uploadDir).exists()) {
                    System.out.println("Creating Directories! ");
                    new File(uploadDir).mkdirs();
                }
                List<FileItem> multiparts = new ServletFileUpload(
                        new DiskFileItemFactory()).parseRequest(request);

                for (FileItem item : multiparts) {
                    if (!item.isFormField()) {
                        String fileName = new File(item.getName()).getName();
                        if (fileName.contains("\\")) {
                            fileName = fileName.substring(fileName.lastIndexOf("\\") + 1, fileName.length());
                        }
                        fileNames.add(fileName);
                        File file = new File(uploadDir + File.separator + fileName);
                        item.write(file);                        
                    }
                }
                request.setAttribute("message", "File Uploaded Successfully");
            } catch (Exception ex) {
                resp = "File Upload Failed due to " + ex;
            }
        } else {
            resp = "Sorry this Servlet only handles file upload request";
        }

        if (!fileNames.isEmpty()) {
            response.setContentType("application/json");
            response.getWriter().write(gson.toJson(fileNames));
        } else {
            response.getWriter().write("Error");
        }
    }

}
