/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.domain.services;

import com.naveed.ws.domain.entities.User;
import com.naveed.ws.web.auth.SecurityUtil;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author Administrator
 */
public class UserService {

    EntityManagerFactory emf = null;
    private EntityManager em;

    public UserService() {
        emf = Persistence.createEntityManagerFactory("auth");
    }

    public EntityManager getEntityManager() {
        if (em == null) {
            em = emf.createEntityManager();
        }
        return em;
    }

    public User save(User entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entity.setSalt(SecurityUtil.getSalt());
            String password = entity.getPassword();
            entity.setPassword(SecurityUtil.hashPassword(password, entity.getSalt()));

            entityManager.getTransaction().begin();
            entityManager.persist(entity);
            entityManager.flush();
        } finally {
            entityManager.getTransaction().commit();
        }
        return entity;
    }

    public User updatePassword(User entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entity.setSalt(SecurityUtil.getSalt());
            String password = entity.getPassword();
            entity.setPassword(SecurityUtil.hashPassword(password, entity.getSalt()));

            User merge = entityManager.merge(entity);
            entityManager.flush();
            return merge;
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public User find(Long id) {
        return (User) getEntityManager().find(User.class, id);
    }

    public List<User> findAll() {
        return getEntityManager().createQuery("SELECT e FROM User " + " e").getResultList();
    }

    public User update(User entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            User merge = entityManager.merge(entity);
            entityManager.flush();
            return merge;
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public void delete(Long id) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            User entity = entityManager.find(User.class, id);
            entityManager.remove(entity);
            entityManager.flush();
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public User findByUsername(String username) {
        Query query = getEntityManager().createQuery("Select u from User u WHERE u.username = :username");
        query.setParameter("username", username);
        return (User) query.getResultList().get(0);
    }

}
