/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.domain.entities;

import com.google.gson.annotations.Expose;
import java.io.Serializable;
import lombok.Data;

/**
 *
 * @author naveed
 */
@Data
public class Option implements Serializable{

    @Expose String id;
    @Expose String name;        
    
    public Option() {
    }

    public Option(String id, String name) {
        this.id = id;
        this.name = name;
    }
}