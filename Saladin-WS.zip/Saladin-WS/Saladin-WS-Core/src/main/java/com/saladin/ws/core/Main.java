/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.saladin.ws.core;

/**
 *
 * @author nmrehman
 */
public class Main {

    public static void main(String[] args) {
        String customizedClassName = args[0];
        String url = args[1];
        String serviceMethodName = args[2];
        String requestParams = args[3];
        GenericWS genericWs = new GenericWS();
        String response = genericWs.invoke(customizedClassName, url, serviceMethodName, requestParams);
        System.out.println(response);
    }

}
