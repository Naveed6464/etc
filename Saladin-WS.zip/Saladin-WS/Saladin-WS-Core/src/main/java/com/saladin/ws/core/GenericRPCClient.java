/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.saladin.ws.core;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 * @param <T>
 */
public abstract class GenericRPCClient<T> implements IWSClient {

    final static Logger log = LoggerFactory.getLogger(GenericRPCClient.class);

    String clientAddress;
    String serviceMethodName;

    Gson gson = new Gson();

    protected Class<T> serviceClass = (Class<T>) ReflectionUtil.getTypeArguments(GenericRPCClient.class, this.getClass()).get(0);

    public void initialize(String address) {
        this.clientAddress = address;
    }

    public void setServiceMethodName(String serviceMethodName) {
        this.serviceMethodName = serviceMethodName;
    }

    public String getServiceMethodName() {
        return serviceMethodName;
    }

    public Gson getGSON() {
        return gson;
    }

    public String toJson(Object src) {
        return gson.toJson(src);
    }

    public <T> T fromJson(String json, Class<T> clz) {
        return gson.fromJson(json, clz);
    }

    public URL getURL() {
        try {
            return new URL(clientAddress);
        } catch (MalformedURLException ex) {
            log.error("MalformedURLException : " + ex);
        }
        return null;
    }

    public T create() {
        try {
            return serviceClass.newInstance();
        } catch (InstantiationException | IllegalAccessException ex) {
            log.error("Exception While Instantiating Web Service");
        }
        return null;
    }

    public <T> T populatedFields(Map<String, String> fields, Class<T> clz) {
        Object object = null;
        try {
            object = clz.newInstance();
            for (Map.Entry<String, String> entry : fields.entrySet()) {
                BeanUtils.setProperty(object, entry.getKey(), entry.getValue());
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException ex) {
            log.info("Exception While Populating Fields.");
        }
        return (T) object;
    }

    public <T> T populateFields(String strFields, Class<T> clz) {
        Map<String, String> fields = new HashMap<>();
        Iterable<String> split = Splitter.on(',').trimResults().omitEmptyStrings().split(strFields);
        for (String str : split) {
            fields.put(str.substring(0, str.indexOf(":")), str.substring(str.indexOf(":") + 1));
        }
        return populatedFields(fields, clz);
    }

    public List<String> split(String str, String on) {
        return Lists.newArrayList(Splitter.on(on).trimResults().omitEmptyStrings().split(str));
    }

    public abstract String invoke(String serviceMethodName);

    public abstract void initRequestParams(String requestParams);
}
