/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.saladin.ws.core;

/**
 *
 * @author nmrehman
 */
public interface IWSClient {

    public void initialize(String address);

    public void setServiceMethodName(String serviceMethodName);

    public void initRequestParams(String requestParams);

    public String invoke(String serviceMethodName);
}
