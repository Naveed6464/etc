##############################################################################
##
##  Remittance-RT start up script for UN*X
##
##############################################################################
# Add default JVM options here. You can also use JAVA_OPTS and REMITTANCE_RT_OPTS to pass JVM options to this script.
DEFAULT_JVM_OPTS=""

APP_NAME="Remittance-RT"
APP_BASE_NAME=`basename "$0"`

# Attempt to set APP_HOME
# Resolve links: $0 may be a link
export PATH=/usr/java7_64/bin:$PATH
JAVA_HOME=/usr/java7_64/bin
APP_HOME=/t24dev/bnk/bnk.run/java/Remittance-RT

#echo APP_HOME

CLASSPATH=$APP_HOME/lib/Remittance-RT-1.0.jar:$APP_HOME/lib/guice-4.0.jar:$APP_HOME/lib/guava-19.0.jar:$APP_HOME/lib/logback-classic-1.1.2.jar:$APP_HOME/lib/gson-2.6.2.jar:$APP_HOME/lib/cxf-rt-frontend-jaxws-3.1.6.jar:$APP_HOME/lib/cxf-rt-transports-http-3.1.6.jar:$APP_HOME/lib/cxf-rt-transports-http-jetty-3.1.6.jar:$APP_HOME/lib/commons-beanutils-1.9.2.jar:$APP_HOME/lib/axis-1.4.jar:$APP_HOME/lib/Remittance-T24FT-1.0.jar:$APP_HOME/lib/Remittance-Himalaya-1.0.jar:$APP_HOME/lib/javax.inject-1.jar:$APP_HOME/lib/aopalliance-1.0.jar:$APP_HOME/lib/logback-core-1.1.2.jar:$APP_HOME/lib/xml-resolver-1.2.jar:$APP_HOME/lib/asm-5.0.4.jar:$APP_HOME/lib/cxf-core-3.1.6.jar:$APP_HOME/lib/cxf-rt-bindings-soap-3.1.6.jar:$APP_HOME/lib/cxf-rt-bindings-xml-3.1.6.jar:$APP_HOME/lib/cxf-rt-frontend-simple-3.1.6.jar:$APP_HOME/lib/cxf-rt-ws-addr-3.1.6.jar:$APP_HOME/lib/jetty-server-9.2.15.v20160210.jar:$APP_HOME/lib/jetty-util-9.2.15.v20160210.jar:$APP_HOME/lib/jetty-io-9.2.15.v20160210.jar:$APP_HOME/lib/jetty-security-9.2.15.v20160210.jar:$APP_HOME/lib/jetty-continuation-9.2.15.v20160210.jar:$APP_HOME/lib/jetty-http-9.2.15.v20160210.jar:$APP_HOME/lib/commons-logging-1.1.1.jar:$APP_HOME/lib/commons-collections-3.2.1.jar:$APP_HOME/lib/axis-jaxrpc-1.4.jar:$APP_HOME/lib/axis-saaj-1.4.jar:$APP_HOME/lib/axis-wsdl4j-1.5.1.jar:$APP_HOME/lib/commons-discovery-0.2.jar:$APP_HOME/lib/Remittance-Core-1.0.jar:$APP_HOME/lib/woodstox-core-asl-4.4.1.jar:$APP_HOME/lib/xmlschema-core-2.2.1.jar:$APP_HOME/lib/cxf-rt-wsdl-3.1.6.jar:$APP_HOME/lib/cxf-rt-databinding-jaxb-3.1.6.jar:$APP_HOME/lib/cxf-rt-ws-policy-3.1.6.jar:$APP_HOME/lib/javax.servlet-api-3.1.0.jar:$APP_HOME/lib/axis-jaxrpc-1.4.jar:$APP_HOME/lib/axis-saaj-1.4.jar:$APP_HOME/lib/stax2-api-3.1.4.jar:$APP_HOME/lib/wsdl4j-1.6.3.jar:$APP_HOME/lib/jaxb-impl-2.2.11.jar:$APP_HOME/lib/jaxb-core-2.2.11.jar:$APP_HOME/lib/neethi-3.0.3.jar:$APP_HOME/lib/slf4j-api-1.7.19.jar

exec java -classpath "$CLASSPATH" com.inma.rmt.ws.core.Main $1 $2 $3 $4
