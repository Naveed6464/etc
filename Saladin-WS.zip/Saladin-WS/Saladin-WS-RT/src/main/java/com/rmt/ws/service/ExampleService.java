package com.rmt.ws.service;

import com.saladin.ws.core.GenericWSClient;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author nmrehman
 */
public class ExampleService extends GenericWSClient {

    @Override
    public void initRequestParams(String requestParams) {

    }

    @Override
    public String invoke(String serviceMethodName) {
        return toJson(new Service("TestService", "Success"));
    }

}
