package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRsType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRqType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRsType;
import com.ncr.cxp.branch.integration.schema.CustomerIdEnum;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.ReverseDepositRqType;
import com.ncr.cxp.branch.integration.schema.ReverseDepositRsType;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.impl.converter.StubBISDepositMessageConverter;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import com.ncr.itm.middleware.ws.util.Ensure;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Implementation of BIS Deposit Service Interface
 *
 * @author ap185225
 */
@Service
public class BISDepositService extends StubBISBaseServiceImpl {

    private static final String ACCOUNT_KEY_TYPE_OR_CUSTOMER_ID_TYPE = "AccountKeyType or CustomerIdType";
    private final StubBISDepositMessageConverter converter;

    /**
     * Constructs a new instance of the class.
     *
     * @param sessionManager
     * @param converter
     */
    @Autowired
    public BISDepositService(SessionManager sessionManager, StubBISDepositMessageConverter converter) {
        super(sessionManager);
        this.converter = converter;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISDeposit#authoriseDeposit(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.AuthoriseDepositRq)
     */
    //@Override
    public BISResult<AuthoriseDepositRsType> authoriseDeposit(final RqHeader header, final AuthoriseDepositRqType request) {
        //ProductionLogger.info(this, "authoriseDeposit - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<AuthoriseDepositRsType>() {
            @Override
            public BISResult<AuthoriseDepositRsType> execute() {
                return doAuthoriseDeposit(header, request);
            }
        }, new AuthoriseDepositRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<AuthoriseDepositRsType> doAuthoriseDeposit(RqHeader header, AuthoriseDepositRqType request) {
        String token = header.getAuthentication().getSessionToken();
        Ensure.notNull(request, "AuthoriseDepositRq");
        Ensure.notNull(request.getDepositInfo(), "DepositInfoType");
        ensureAccountKey(request, token);
        ensureTransactionType(request, token);

        Ensure.notNull(request.getDepositInfo().getAmount(), "AmountType");
        Ensure.isTrue(request.getDepositInfo().getAmount().getValue().compareTo(BigDecimal.ZERO) > 0,
                "AmountType");
        Ensure.isTrue(
                ((request.getDepositInfo().getDepositItems().getCashInItem().size() > 0) || (request.getDepositInfo().getDepositItems().getChequeRqItem().size() > 0)),
                "DepositItems");
        ErrorType error = null;
        AuthoriseDepositRsType response = new AuthoriseDepositRsType();

        try {
            response = converter.createAuthorizeDepositResponse(request, token, getCustomerId(token),
                    getCustomerIdType(token));
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), token, error, response);
    }

    private void ensureAccountKey(AuthoriseDepositRqType request, String token) {
        // account can be null for cash check, scan item subtypes (non-member transaction)
        Ensure.isTrue(
                (((request.getDepositInfo().getAccount() != null) // && CustomerIdEnum.HOSTCUSTOMERID.name().equals( getCustomerIdType( token ))
                ))
                // || ( ( request.getDepositInfo().getAccount() == null )
                // && CustomerIdEnum.ANONYMOUS.name().equals( getCustomerIdType( token ) ) ),
                || CustomerIdEnum.ANONYMOUS.name().equals(getCustomerIdType(token)), // ),
                ACCOUNT_KEY_TYPE_OR_CUSTOMER_ID_TYPE);

        if (CustomerIdEnum.ANONYMOUS.name().equals(getCustomerIdType(token))) {
            Ensure.isTrue(
                    (request.getDepositInfo().getAccount() == null),
                    ACCOUNT_KEY_TYPE_OR_CUSTOMER_ID_TYPE);
        } else {
            Ensure.isTrue(
                    (request.getDepositInfo().getAccount() != null),
                    ACCOUNT_KEY_TYPE_OR_CUSTOMER_ID_TYPE);
        }
    }

    private void ensureTransactionType(AuthoriseDepositRqType request, String token) {
        if (CustomerIdEnum.ANONYMOUS.name().equals(getCustomerIdType(token))) {
            Ensure.isTrue(
                    (SUB_TYPE_CASHCHEQUE.equalsIgnoreCase(request.getDepositInfo().getTransactionType())
                    || SUB_TYPE_SCAN_ITEM.equalsIgnoreCase(request.getDepositInfo().getTransactionType())),
                    "TransactionType");
        } else {
            Ensure.isTrue(
                    (request.getDepositInfo().getTransactionType() == null)
                    || (SUB_TYPE_CASHCHEQUE.equalsIgnoreCase(request.getDepositInfo().getTransactionType())
                    || SUB_TYPE_SCAN_ITEM.equalsIgnoreCase(request.getDepositInfo().getTransactionType())),
                    "TransactionType");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISDeposit#completeDeposit(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.CompleteDepositRq)
     */
    //@Override
    public BISResult<CompleteDepositRsType> completeDeposit(final RqHeader header, final CompleteDepositRqType request) {
        //ProductionLogger.info(this, "completeDeposit - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<CompleteDepositRsType>() {
            @Override
            public BISResult<CompleteDepositRsType> execute() {
                return doCompleteDeposit(header, request);
            }
        }, new CompleteDepositRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private BISResult<CompleteDepositRsType> doCompleteDeposit(RqHeader header, CompleteDepositRqType request) {
        Ensure.notNull(request.getTransactionId(), "transactionId");
        Ensure.isTrue(
                (request.getDepositCompletionInfo().getTransactionCompletionResult().getGoodCompletion() != null)
                || ((request.getDepositCompletionInfo().getTransactionCompletionResult().getCompletionIssues() != null)
                && ((request.getDepositCompletionInfo().getTransactionCompletionResult().getCompletionIssues().getCancellationReason() != null)
                || (request.getDepositCompletionInfo().getTransactionCompletionResult().getCompletionIssues().getReversalReason() != null))),
                "TransactionCompletionResult");
        ErrorType error = null;
        CompleteDepositRsType response = new CompleteDepositRsType();

        try {
            response = converter.createCompleteDepositResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISDeposit#reverseDeposit(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.ReverseDepositRq)
     */
    //@Override
    public BISResult<ReverseDepositRsType> reverseDeposit(final RqHeader header, final ReverseDepositRqType request) {
        //ProductionLogger.info(this, "reverseDeposit - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<ReverseDepositRsType>() {
            @Override
            public BISResult<ReverseDepositRsType> execute() {
                return doReverseDeposit(header, request);
            }
        }, new ReverseDepositRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private BISResult<ReverseDepositRsType> doReverseDeposit(RqHeader header, ReverseDepositRqType request) {
        Ensure.notNull(request, "reverseDeposit");
        Ensure.notNull(request.getTransactionId(), "transactionId");
        ErrorType error = null;
        ReverseDepositRsType response = new ReverseDepositRsType();

        try {
            response = converter.createReverseDepositResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

}
