package com.ncr.itm.middleware.ws.impl.converter;

/**
 * @author pm250114
 */
public class BISIntegrationException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -6661486564711674769L;

    /**
     * @param message
     */
    public BISIntegrationException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public BISIntegrationException(Throwable cause) {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public BISIntegrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
