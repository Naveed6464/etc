package com.ncr.itm.middleware.ws.impl.model;

import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.stereotype.Component;

/**
 * @author ap185225
 *
 */
@Component
public class StubFeeDataImpl implements StubFeeData {

    private final Map<StubTransactionSubType, StubTransactionFee> transactionFeeMap; // unmodifiableMap

    public StubFeeDataImpl() {
        this.transactionFeeMap = null;
    }

    /**
     * @param transactionFeeMap
     * @throws JAXBException
     */
    public StubFeeDataImpl(InputStream transactionFeeResource)
            throws JAXBException {
        transactionFeeMap = Collections.unmodifiableMap(parseTransactionFeeData(transactionFeeResource));
    }

    @Override
    public Map<StubTransactionSubType, StubTransactionFee> getTransactionFeeMap() {
        return transactionFeeMap;
    }

    private static Map<StubTransactionSubType, StubTransactionFee> parseTransactionFeeData(
            InputStream transactionFeeResource)
            throws JAXBException {
        Map<StubTransactionSubType, StubTransactionFee> feeMap;
        JAXBContext jaxbContext = JAXBContext.newInstance(StubTransactionFeeList.class);
        Unmarshaller unMarshaller = jaxbContext.createUnmarshaller();
        List<StubTransactionFee> feeList = ((StubTransactionFeeList) unMarshaller.unmarshal(transactionFeeResource)).getTransactionFees();

        if (feeList == null) {
            // no transaction fees specified in fee table
            feeMap = new HashMap<>(0);
        } else {
            feeMap = new HashMap<>(feeList.size() * 2);
            for (StubTransactionFee fee : feeList) {
                feeMap.put(fee.getTransactionSubType(), fee);
            }
        }

        return feeMap;
    }

    // *** TODO *** TEMPORARY ***
    @SuppressWarnings("unused")
    private static void readObject(String[] args) // main, renamed to prevent sonar flag
            throws JAXBException, IOException {
        String transactionFeeFilename = "C:\\ncrdev\\apache-tomcat-7.0.53\\conf\\my-StubTransactionFees.xml";

        InputStream is = new FileInputStream(transactionFeeFilename);
        // InputStream customerResource = StubDataImpl.class.getResourceAsStream( "/" + customerFileName ); // NOSONAR

        Map<StubTransactionSubType, StubTransactionFee> feeMap = parseTransactionFeeData(is);
        is.close();
        System.out.println("feeMap = " + feeMap); // NOSONAR
    }
}
