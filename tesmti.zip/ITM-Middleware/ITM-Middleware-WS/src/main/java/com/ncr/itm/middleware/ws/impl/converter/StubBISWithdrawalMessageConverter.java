package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.BalanceType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.FeeType;
import com.ncr.cxp.branch.integration.schema.OverrideInfoType;
import com.ncr.cxp.branch.integration.schema.ReverseWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.ReverseWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.TransactionStatusType;
import com.ncr.cxp.branch.integration.schema.WithdrawalCompletionInfoType;
import com.ncr.cxp.branch.integration.schema.WithdrawalDetailsType;
import com.ncr.cxp.branch.integration.schema.WithdrawalInfoType;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubFeeData;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionCache;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Message converter for the BIS Withdrawal Service
 *
 * @author ap185225
 */
@Component
public class StubBISWithdrawalMessageConverter extends StubBaseTransactionConverter {

    /**
     * @param stubData
     * @param stubFeeData
     * @param transactionCache
     */
    @Autowired
    public StubBISWithdrawalMessageConverter(StubData stubData, StubFeeData stubFeeData,
            StubTransactionCache transactionCache) {
        super(stubData, stubFeeData, transactionCache);
    }

    /**
     * Creates a {@link AuthoriseWithdrawalRs} based on the supplied
     * {@link StubData}
     *
     * @param request
     * @param token
     * @param customerId
     * @param customerIdType
     * @return {@link AuthoriseWithdrawalRs}
     * @throws StubNotFoundException
     * @throws StubAccountClosedException
     */
    public AuthoriseWithdrawalRsType createAuthorizeWithdrawalResponse(AuthoriseWithdrawalRqType request, String token,
            String customerId, String customerIdType)
            throws StubNotFoundException, StubAccountClosedException {
        AuthoriseWithdrawalRsType response = new AuthoriseWithdrawalRsType();
        WithdrawalDetailsType withdrawalDetailsType = new WithdrawalDetailsType();
        response.setWithdrawalDetails(withdrawalDetailsType);
        WithdrawalInfoType withdrawalInfoType = request.getWithdrawalInfo();
        String transactionId = request.getTransactionId();

        StubWithdrawalHelper withdrawalHelper = new StubWithdrawalHelper(withdrawalInfoType, withdrawalDetailsType,
                customerIdType);
        StubBISAuthorizeConverter authorizeConverter = new StubBISAuthorizeConverter(
                this,
                withdrawalHelper,
                token,
                customerId);

        // *** TODO *** VALIDATE VALID OPERATIONS *** VALIDATE IF WE CAN PERFORM TRANSACTION FOR accountKey.getType()
        try {
            // formal authorization process
            response.setTransactionStatus(authorizeConverter.processAuthorize(transactionId));
            response.setTransactionId(authorizeConverter.getStubTransactionId());
        } catch (Exception e) {
            //ProductionLogger.warn(this, e.getMessage(), e);
            throw e;
        }

        return response;
    }

    /**
     * Creates a {@link CompleteWithdrawalRs} based on the supplied
     * {@link StubData}
     *
     * @param request
     * @return {@link CompleteWithdrawalRs}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    public CompleteWithdrawalRsType createCompleteWithdrawalResponse(CompleteWithdrawalRqType request)
            throws StubNotFoundException, StubAccountClosedException {
        CompleteWithdrawalRsType response = new CompleteWithdrawalRsType();
        String transactionId = request.getTransactionId();
        WithdrawalCompletionInfoType withdrawalCompletionInfo = request.getWithdrawalCompletionInfo();
        // optional
        // List<CashMixType> cashOutDetails = withdrawalCompletionInfo.getCashOutDetails(); // NOSONAR

        TransactionStatusType transactionStatusType = completeTransaction(transactionId,
                StubTransactionType.WITHDRAWAL, withdrawalCompletionInfo.getTransactionCompletionResult());

        response.setTransactionStatus(transactionStatusType);
        response.setTransactionId(request.getTransactionId());

        return response;
    }

    /**
     * Creates a {@link ReverseWithdrawalRs} based on the supplied
     * {@link StubData}
     *
     * @param request
     * @return {@link ReverseWithdrawalRs}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    public ReverseWithdrawalRsType createReverseWithdrawalResponse(ReverseWithdrawalRqType request)
            throws StubNotFoundException, StubAccountClosedException {
        ReverseWithdrawalRsType response = new ReverseWithdrawalRsType();
        String transactionId = request.getTransactionId();

        TransactionStatusType transactionStatusType = reverseTransaction(transactionId, StubTransactionType.WITHDRAWAL);
        response.setTransactionStatus(transactionStatusType);
        response.setTransactionId(request.getTransactionId());

        return response;
    }

    /**
     * @author ap185225
     *
     */
    private final class StubWithdrawalHelper extends StubTransactionHelperImpl {

        private final WithdrawalInfoType withdrawalInfoType;
        private final WithdrawalDetailsType withdrawalDetailsType;

        /**
         * @param withdrawalInfoType
         * @param withdrawalDetailsType
         * @param customerIdType
         */
        private StubWithdrawalHelper(WithdrawalInfoType withdrawalInfoType,
                WithdrawalDetailsType withdrawalDetailsType, String customerIdType) {
            super(customerIdType);
            this.withdrawalInfoType = withdrawalInfoType;
            this.withdrawalDetailsType = withdrawalDetailsType;
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getWithdrawalAmount()
         */
        @Override
        public BigDecimal getAmount() {
            return withdrawalInfoType.getAmount().getValue();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getOverrideInfo()
         */
        @Override
        public OverrideInfoType getOverrideInfo() {
            return withdrawalInfoType.getOverrideInfo();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getResponseBalances()
         */
        @Override
        public List<BalanceType> getResponseBalances() {
            // TE doesn't needed balances for cashCheque
            // however, unit tests do use it
            return withdrawalDetailsType.getBalance();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getRequestFees()
         */
        @Override
        public List<FeeType> getRequestFees() {
            return withdrawalInfoType.getFee();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getResponseFees()
         */
        @Override
        public List<FeeType> getResponseFees() {
            return withdrawalDetailsType.getFee();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getSourceAccountKeyType()
         */
        @Override
        public String getSourceAccountNumber() {
            if (withdrawalInfoType.getAccount().getType() == null) {
                throw new IllegalArgumentException("missing account type");
            }

            return withdrawalInfoType.getAccount().getNumber();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getTransactionSubType()
         */
        @Override
        public StubTransactionSubType getTransactionSubType() {
            return convertTransactionSubType(withdrawalInfoType.getTransactionType());
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getTransactionType()
         */
        @Override
        public StubTransactionType getTransactionType() {
            return StubTransactionType.WITHDRAWAL;
        }

    }
}
