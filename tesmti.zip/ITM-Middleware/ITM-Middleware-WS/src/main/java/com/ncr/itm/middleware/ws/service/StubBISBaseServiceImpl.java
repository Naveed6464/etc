/**
 *
 */
package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AccountInqRs;
import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRsType;
import com.ncr.cxp.branch.integration.schema.AuthoriseTransferRsType;
import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRsType;
import com.ncr.cxp.branch.integration.schema.CompleteTransferRsType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.CustomerInqRs;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRs;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.cxp.branch.integration.schema.StartSessionRs;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRs;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.entities.RsHeader;
import java.util.Map;
import java.util.UUID;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.bind.JAXBException;

import org.springframework.util.StringUtils;

/**
 * @author naveed
 *
 */
public abstract class StubBISBaseServiceImpl extends BISBaseServiceImpl {

    /**
     * Key to identify the Teller or Terminal Id Type session context value
     */
    static final String CONTEXT_KEY_ID_TYPE = "CONTEXT_KEY_ID_TYPE";
    static final String SESSION_KEY_STATE_UUID = "SESSION_KEY_STATE_UUID";

    private static final String BIS_SESSION_NOT_IN_PROGRESS = "BIS_SESSION_NOT_IN_PROGRESS";
    private static final String MESSAGE_VALID_SESSION_TOKEN_WAS_NOT_PROVIDED = "please log out and log in again";
    private static final String MESSAGE_NO_CUSTOMER_SESSION_FOR_SUPPLIED_TOKEN = "no customer session for supplied token";

    // strings duplicated in StubBaseTransactionConverter
    static final String SUB_TYPE_CASHCHEQUE = "CASHCHEQUE";
    static final String SUB_TYPE_PRINT_CHEQUE = "PRINTCHEQUE";
    static final String SUB_TYPE_SCAN_ITEM = "SCANITEM";

    private final SessionManager sessionManager;
    private boolean useSessionState;

    /**
     * @param sessionManager
     */
    StubBISBaseServiceImpl(SessionManager sessionManager) {
        super(sessionManager);
        this.sessionManager = sessionManager;

        try {
            // controlled by value of <Environment name="bis-ait-stub-service-context.sessionstate" ...> in
            // <tomcat dir>\conf\context.xml
            InitialContext initialContext = new javax.naming.InitialContext();
            useSessionState = ((Boolean) initialContext.lookup("java:comp/env/bis-ait-stub-service-context.sessionstate")).booleanValue();
        } catch (NamingException e) // NOSONAR
        {
            // defaults to false
        }
    }

    /**
     * Builds BISResult with the supplied data.
     *
     * @param msgSeqId message sequence id.
     * @param token session token
     * @param error error object
     * @param response the response object
     * @return BISResult
     */
    @Override
    protected <T> BISResult<T> buildResult(String msgSeqId, String token, ErrorType error, T response) {
        RsHeader rsHeader = new RsHeader();

        rsHeader.setError(error);
        rsHeader.setMsgSeqId(msgSeqId);
        rsHeader.setSessionToken(token);

        if ((useSessionState) && (token != null) && (error == null)) {
            // needed to ensure AIT is functioning correctly
            Map<String, String> sessionState = sessionManager.getSessionState(token);
            sessionState.put(SESSION_KEY_STATE_UUID, UUID.randomUUID().toString());
            sessionManager.putSessionState(token, sessionState);
            addSessionState(rsHeader, sessionState);
        }

        return new BISResult<T>(rsHeader, response);
    }

    /**
     * @param header
     * @return
     */
    void ensureValidMsgSeqId(RqHeader header) {
        // needed to ensure AIT is functioning correctly
        if (!StringUtils.hasLength(header.getMsgSeqId())) {
            throw new IllegalArgumentException("missing msgSeqId");
        }
    }

    void ensureValidSessionState(RqHeader header) {
        if (useSessionState) {
            String token = header.getAuthentication().getSessionToken();
            Map<String, String> sessionState = null;

            // needed to ensure AIT is functioning correctly
            if (token != null) {
                sessionState = sessionManager.getSessionState(token);
                // keep session state in case of exception or error
            }

            if (!getSessionState(header).equals(sessionState)) {
                throw new IllegalArgumentException("missing or invalid SessionState");
            }
        }
    }

    /**
     * @param header
     * @return
     */
    private String ensureValidSessionToken(RqHeader header) {
        String token = getSessionTokenFromRequest(header);
        if (!getSessionManager().isValid(token)) {
            return null;
        }
        return token;
    }

    /**
     * Performs common actions needed for a BIS command and executes the specfic
     * action.
     *
     * @param header
     * @param command
     * @param defaultResponse
     * @return
     * @throws JAXBException
     */
    protected <T> BISResult<T> executeWithCustomerSessionValidation(RqHeader header, BISCommand<T> command,
            T defaultResponse) {
        BISResult<T> result = null;
        try {
            ensureValidMsgSeqId(header); // needed to ensure AIT is functioning correctly
            ensureValidSessionState(header); // needed to ensure AIT is functioning correctly
            String token = ensureValidSessionToken(header);
            token = validateTokenForUserAndResponse(defaultResponse, token);

            if (token != null) {
                if (getSessionManager().isCustomerSessionActive(getSessionTokenFromRequest(header))) {
                    result = command.execute();
                } else {
                    //ProductionLogger.warn(this, MESSAGE_NO_CUSTOMER_SESSION_FOR_SUPPLIED_TOKEN);
                    result = buildResult(
                            header.getMsgSeqId(),
                            null,
                            createErrorType(BIS_SESSION_NOT_IN_PROGRESS, BIS_SESSION_NOT_IN_PROGRESS,
                                    SeverityEnum.CRITICAL), defaultResponse);
                }
            } else {
                //ProductionLogger.warn(this, MESSAGE_VALID_SESSION_TOKEN_WAS_NOT_PROVIDED);
                result = buildResult(
                        header.getMsgSeqId(),
                        null,
                        createErrorType(BIS_INVALID_TOKEN, MESSAGE_VALID_SESSION_TOKEN_WAS_NOT_PROVIDED,
                                SeverityEnum.CRITICAL),
                        defaultResponse);
            }
        } catch (IllegalArgumentException e) {
            result = buildResult(
                    header.getMsgSeqId(),
                    null,
                    createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR),
                    defaultResponse);
        }

        return result;
    }

    /**
     * Checks if the session token supplied in header is valid and executes the
     * specified command. If the session token is not valid then this method
     * returns BISResult with BIS_INVALID_TOKEN error.
     *
     * @param header
     * @param command
     * @param defaultResponse
     * @return BISResult, the command execution result.
     * @throws JAXBException
     */
    @Override
    protected <T> BISResult<T> executeWithSessionTokenValidation(RqHeader header, BISCommand<T> command,
            T defaultResponse) {
        BISResult<T> result = null;
        try {
            ensureValidMsgSeqId(header); // needed to ensure AIT is functioning correctly
            ensureValidSessionState(header); // needed to ensure AIT is functioning correctly
            String token = ensureValidSessionToken(header);
            token = validateTokenForUserAndResponse(defaultResponse, token);

            if (StringUtils.hasText(token)) // CONTEXT_KEY_ID
            {
                result = command.execute();
            } else {
                //ProductionLogger.warn(this, MESSAGE_VALID_SESSION_TOKEN_WAS_NOT_PROVIDED);
                result = buildResult(
                        header.getMsgSeqId(),
                        token,
                        createErrorType(BIS_INVALID_TOKEN, MESSAGE_VALID_SESSION_TOKEN_WAS_NOT_PROVIDED,
                                SeverityEnum.CRITICAL),
                        defaultResponse);
            }
        } catch (IllegalArgumentException e) {
            result = buildResult(
                    header.getMsgSeqId(),
                    null,
                    createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR),
                    defaultResponse);
        }

        return result;
    }

    String getCustomerId(String token) {
        // get customerId from session manager
        return sessionManager.obtainSessionContextData(token).get(SessionManager.CONTEXT_KEY_CUSTOMER_ID);
    }

    String getCustomerIdType(String token) {
        // get customerId from session manager
        return sessionManager.obtainSessionContextData(token).get(CONTEXT_KEY_ID_TYPE);
    }

    /**
     * @return the useSessionState
     */
    public boolean isUseSessionState() {
        return useSessionState;
    }

    /**
     * @param useSessionState the useSessionState to set
     */
    public void setUseSessionState(boolean useSessionState) {
        this.useSessionState = useSessionState;
    }

    /**
     * @param defaultResponse
     * @param token
     * @return
     */
    private <T> String validateTokenForUserAndResponse(T defaultResponse, String token) {
        String newToken = token;
        boolean rejectCommand = false;
        String userId = "";

        if (token != null) {
            userId = sessionManager.obtainSessionContextData(token).get(SessionManager.CONTEXT_KEY_ID);
        }

        rejectCommand = validateTokenForCustomerService(defaultResponse, userId)
                || validateTokenForTransactions(defaultResponse, userId);

        if (rejectCommand) {
            // invalidate token
            getSessionManager().endSession(token);
            newToken = null;
        }

        return newToken;
    }

    /**
     * @param defaultResponse
     * @param userId
     * @return
     */
    private <T> boolean validateTokenForCustomerService(T defaultResponse, String userId) {
        boolean rejectCommand = false;

        // special userIds that invalidate the session token and return BIS_INVALID_TOKEN error
        // for testing token expiration at various points in Teller Enterprise
        // userId can be null in test case code
        if ((defaultResponse instanceof CustomerSearchRs) && ("15a".equals(userId))) {
            rejectCommand = true;
        } else if ((defaultResponse instanceof CustomerInqRs) && ("15b".equals(userId))) {
            rejectCommand = true;
        } else if ((defaultResponse instanceof AccountInqRs) && ("15c".equals(userId))) {
            rejectCommand = true;
        } else if ((defaultResponse instanceof StartSessionRs) && ("15g".equals(userId))) {
            rejectCommand = true;
        } else if ((defaultResponse instanceof TransactionHistoryRs) && ("15d".equals(userId))) {
            rejectCommand = true;
        }

        return rejectCommand;
    }

    /**
     * @param defaultResponse
     * @param userId
     * @return
     */
    private <T> boolean validateTokenForTransactions(T defaultResponse, String userId) {
        boolean rejectCommand = false;

        // special userIds that invalidate the session token and return BIS_INVALID_TOKEN error
        // for testing token expiration at various points in Teller Enterprise
        // userId can be null in test case code
        if (((defaultResponse instanceof AuthoriseDepositRsType)
                || (defaultResponse instanceof AuthoriseTransferRsType)
                || (defaultResponse instanceof AuthoriseWithdrawalRsType))
                && ("15e".equals(userId))) {
            rejectCommand = true;
        } else if (((defaultResponse instanceof CompleteDepositRsType)
                || (defaultResponse instanceof CompleteTransferRsType)
                || (defaultResponse instanceof CompleteWithdrawalRsType))
                && ("15f".equals(userId))) {
            rejectCommand = true;
        }

        return rejectCommand;
    }

}
