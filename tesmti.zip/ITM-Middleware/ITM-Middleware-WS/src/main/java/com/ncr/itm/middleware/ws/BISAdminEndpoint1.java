/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

/**
 *
 * @author naveed
 */
//@Endpoint
public class BISAdminEndpoint1  {
/*
    private HeaderProcessor headerProcessor;
    private final List<ServiceInqRs.ServiceAvailability> service;

    @Autowired
    public BISAdminEndpoint1(HeaderProcessor headerProcessor) {
        super(new SessionManagerImpl());
        this.headerProcessor = headerProcessor;
        this.service = new ArrayList(7);

        this.service.add(createServiceAvailability("admin"));
        this.service.add(createServiceAvailability("configuration"));
        this.service.add(createServiceAvailability("customer"));
        this.service.add(createServiceAvailability("deposit"));
        this.service.add(createServiceAvailability("transfer"));
        this.service.add(createServiceAvailability("withdrawal"));
    }

    private ServiceInqRs.ServiceAvailability createServiceAvailability(String serviceName) {
        ServiceInqRs.ServiceAvailability serviceAvailability = new ServiceInqRs.ServiceAvailability();

        serviceAvailability.setServiceName(serviceName);
        serviceAvailability.setServiceAvailable(true);

        return serviceAvailability;
    }

    public HeaderProcessor getHeaderProcessor() {
        return this.headerProcessor;
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ConnectRq")
    @ResponsePayload
    public ConnectRs connect(@RequestPayload ConnectRq connectRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "connect - Entry");        
        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<ConnectRs> response = buildResult(header.getMsgSeqId(), null, null, new ConnectRs());
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());
        return (ConnectRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ServiceInqRq")
    @ResponsePayload
    public ServiceInqRs serviceInq(@RequestPayload ServiceInqRq serviceInqRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "serviceInq - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        ensureValidMsgSeqId(header);
        ServiceInqRs response = new ServiceInqRs();
        response.getServiceAvailability().addAll(this.service);
        ServiceInqRs.ServiceState serviceState = new ServiceInqRs.ServiceState();
        response.getServiceState().add(serviceState);
        serviceState.setServiceId("CbiSampleCoreService");
        serviceState.setServiceStatus(ServiceStatusEnum.SIGNED_ON);

        BISResult<ServiceInqRs> result = buildResult(header.getMsgSeqId(), null, null, response);
        getHeaderProcessor().addResponseHeader(messageContext, result.getHeader());
        return (ServiceInqRs) result.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "SignonRq")
    @ResponsePayload
    public SignonRs signOn(@RequestPayload SignonRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "signOn - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        SignonRs response = new SignonRs();
        ErrorType error = null;
        String token = null;
        SignonTypeEnum signonType = request.getSignonInfo().getSignonType();
        try {
            ensureValidMsgSeqId(header);
            //Ensure.notNull(request.getSignonInfo().getSignonType(), "SignonTypeEnum");
            //Ensure.isNull(header.getSessionState(), "SessionState should be null for signon");
            String pwd;
            String id;
            if ((signonType == SignonTypeEnum.TELLER)
                    && (header.getAuthentication().getTellerCredentials() != null)) {
                id = header.getAuthentication().getTellerCredentials().getUserId();
                pwd = header.getAuthentication().getTellerCredentials().getPassword();
            } else if (header.getAuthentication().getTerminalCredentials() != null) {
                id = header.getAuthentication().getTerminalCredentials().getDeviceId();
                pwd = header.getAuthentication().getTerminalCredentials().getDeviceCredentialDetails();
            } else {
                throw new IllegalArgumentException("Authentication credentials");
            }

            if ((StringUtils.hasText(id)) && (StringUtils.hasText(pwd))
                    && (id.startsWith("")) && (pwd.equals("123456"))) {
                if (getSessionManager().isValid(signonType.name(), id)) {
                    error = createErrorType("BIS_ALREADY_SIGNED_ON", "already signed on", SeverityEnum.WARNING);
                } else {
                    token = getSessionManager().startSession(signonType.name(), id);
                    getSessionManager().storeSessionContextValue(getSessionTokenFromRequest(header), "CbiSampleCoreService",
                            ServiceStatusEnum.SIGNED_ON.toString());
                }
            } else {
                //ProductionLogger.warn(this, "signon - Invalid credentials");
                error = createErrorType("BIS_ACCESS_DENIED", "Invalid credentials", SeverityEnum.ERROR);

                //delaySignon(pwd);
            }
            SignonRs.Profile profile = new SignonRs.Profile();
            response.setProfile(profile);
            List<AdditionalInfoType> profileItems = profile.getProfileItem();
            AdditionalInfoType additionalInfoType = new AdditionalInfoType();
            additionalInfoType.setKey("someKey");
            additionalInfoType.setValue("someValue");
            profileItems.add(additionalInfoType);
        } catch (IllegalArgumentException e) {
            error = createErrorType("BIS_BAD_REQUEST", e.getMessage(), SeverityEnum.ERROR);
        }

        BISResult<SignonRs> result = buildResult(header.getMsgSeqId(), token, error, response);;

        getHeaderProcessor().addResponseHeader(messageContext, result.getHeader());
        return (SignonRs) result.getResponse();
    }

    
    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "SignoffRq")
    @ResponsePayload
    public SignoffRs signOff(@RequestPayload SignoffRq signOffRq, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        ProductionLogger.info(this, "signOff - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<SignoffRs> response;
        BISResult<SignoffRs> response;
        if (this.service == null) {
            SignoffRs errorResponse = new SignoffRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.signoff(header);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        ProductionLogger.info(this, "signOff - Exit");
        return (SignoffRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "OpenBranchRq")
    @ResponsePayload
    public OpenBranchRs openBranch(@RequestPayload OpenBranchRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        ProductionLogger.info(this, "openBranch - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<OpenBranchRs> response;
        BISResult<OpenBranchRs> response;
        if (this.service == null) {
            OpenBranchRs errorResponse = new OpenBranchRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.openBranch(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        ProductionLogger.info(this, "openBranch - Exit");
        return (OpenBranchRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CloseBranchRq")
    @ResponsePayload
    public CloseBranchRs closeBranch(@RequestPayload CloseBranchRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        ProductionLogger.info(this, "closeBranch - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CloseBranchRs> response;
        BISResult<CloseBranchRs> response;
        if (this.service == null) {
            CloseBranchRs errorResponse = new CloseBranchRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.closeBranch(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        ProductionLogger.info(this, "closeBranch - Exit");
        return (CloseBranchRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CashAdjustmentRq")
    @ResponsePayload
    public CashAdjustmentRs cashAdjustment(@RequestPayload CashAdjustmentRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        ProductionLogger.info(this, "cashAdjustment - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CashAdjustmentRs> response;
        BISResult<CashAdjustmentRs> response;
        if (this.service == null) {
            CashAdjustmentRs errorResponse = new CashAdjustmentRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.cashAdjustment(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        ProductionLogger.info(this, "cashAdjustment - Exit");
        return (CashAdjustmentRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "VerifySessionRq")
    @ResponsePayload
    public VerifySessionRs verifySession(@RequestPayload VerifySessionRq verifySessionRq, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        ProductionLogger.info(this, "verifySession - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<VerifySessionRs> response;
        BISResult<VerifySessionRs> response;
        if (this.service == null) {
            VerifySessionRs errorResponse = new VerifySessionRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.verifySession(header, verifySessionRq);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        ProductionLogger.info(this, "verifySession - Exit");
        return (VerifySessionRs) response.getResponse();

    }*/
}
