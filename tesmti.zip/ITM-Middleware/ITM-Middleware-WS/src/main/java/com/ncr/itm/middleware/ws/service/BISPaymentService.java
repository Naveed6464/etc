/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AuthorisePaymentRqType;
import com.ncr.cxp.branch.integration.schema.AuthorisePaymentRsType;
import com.ncr.cxp.branch.integration.schema.CompletePaymentRqType;
import com.ncr.cxp.branch.integration.schema.CompletePaymentRsType;
import com.ncr.cxp.branch.integration.schema.ReversePaymentRqType;
import com.ncr.cxp.branch.integration.schema.ReversePaymentRsType;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;

/**
 *
 * @author naveed
 */
public class BISPaymentService extends StubBISBaseServiceImpl {

    public BISPaymentService(SessionManager sessionManager) {
        super(sessionManager);
    }

    public BISResult<AuthorisePaymentRsType> authorisePayment(RqHeader header, AuthorisePaymentRqType authorisePaymentRequest) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public BISResult<CompletePaymentRsType> completePayment(RqHeader header, CompletePaymentRqType completePaymentRequest) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public BISResult<ReversePaymentRsType> reversePayment(RqHeader header, ReversePaymentRqType reversePaymentRequest) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
