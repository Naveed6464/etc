package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.CompleteTransactionsRq;
import com.ncr.cxp.branch.integration.schema.CompleteTransactionsRs;
import com.ncr.cxp.branch.integration.schema.ReverseTransactionsRq;
import com.ncr.cxp.branch.integration.schema.ReverseTransactionsRs;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISBatchService;
import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

/**
 * SOAP Endpoint for the BIS Batch Service
 *
 * @author ap185225
 */
@Endpoint
public class StubBISBatchEndpoint extends BaseEndpoint {

    private final BISBatchService batchService;

    /**
     * Creates a new BISBatchEndpoint
     *
     * @param batchService
     * @param headerProcessor
     */
    @Autowired
    public StubBISBatchEndpoint(BISBatchService batchService, HeaderProcessor headerProcessor) {
        super(headerProcessor);
        this.batchService = batchService;
    }

    /**
     * Requests completion of a batch transaction
     *
     * @param completeBatchRequest - the request information
     * @param soapHeader - the soap header in the request
     * @param messageContext - the message context of the request, required to
     * add the response soap header
     * @return the completeBatchResponse information
     * @throws JAXBException
     * @throws NotImplementedException
     * @throws InvalidSessionTokenException
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "CompleteBatchRq")
    @ResponsePayload
    public CompleteTransactionsRs complete(@RequestPayload final CompleteTransactionsRq completeBatchRequest,
            SoapHeader soapHeader, MessageContext messageContext) throws JAXBException {
        //ProductionLogger.info(this, "complete - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CompleteTransactionsRs> response = batchService.completeTransaction(header,
                completeBatchRequest);
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "complete - Exit");
        return response.getResponse();
    }

    /**
     * Requests reversal of a previously committed batch transaction
     *
     * @param reverseBatchRequest - the request information
     * @param soapHeader - the soap header in the request
     * @param messageContext - the message context of the request, required to
     * add the response soap header
     * @return the reverseBatchResponse information
     * @throws JAXBException
     * @throws NotImplementedException
     * @throws InvalidSessionTokenException
     */
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "ReverseBatchRq")
    @ResponsePayload
    public ReverseTransactionsRs reverse(@RequestPayload final ReverseTransactionsRq reverseBatchRequest,
            SoapHeader soapHeader, MessageContext messageContext) throws JAXBException {
        //ProductionLogger.info(this, "reverse - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<ReverseTransactionsRs> response = batchService.reverseTransaction(header,
                reverseBatchRequest);
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "reverse - Exit");
        return response.getResponse();
    }
}
