/**
 *
 */
package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.BalanceType;
import com.ncr.cxp.branch.integration.schema.CashInItemType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRqType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRsType;
import com.ncr.cxp.branch.integration.schema.CustomerIdEnum;
import com.ncr.cxp.branch.integration.schema.DepositRsItemsType;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author ap185225
 *
 */
public abstract class StubTransactionHelperImpl implements StubTransactionHelper {

    private final boolean nonMember;

    /**
     * @param nonMember
     */
    public StubTransactionHelperImpl(String customerIdType) {
        this.nonMember = CustomerIdEnum.ANONYMOUS.name().equals(customerIdType);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getCashBack()
     */
    @Override
    public BigDecimal getCashBack() {
        return BigDecimal.ZERO;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getCashRsItems()
     */
    @Override
    public List<CashInItemType> getCashInItems() {
        throw new UnsupportedOperationException();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getCashRsItems()
     */
    @Override
    public List<DepositRsItemsType.CashInItem> getCashRsItems() {
        throw new UnsupportedOperationException();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getChequeRqItems()
     */
    @Override
    public List<ChequeItemRqType> getChequeRqItems() {
        throw new UnsupportedOperationException();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getChequeRsItems()
     */
    @Override
    public List<ChequeItemRsType> getChequeRsItems() {
        throw new UnsupportedOperationException();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getDestinationAccountNumber()
     */
    @Override
    public String getDestinationAccountNumber() {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getResponseToBalances()
     */
    @Override
    public List<BalanceType> getResponseToBalances() {
        throw new UnsupportedOperationException();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#isNonMember()
     */
    @Override
    public boolean isNonMember() {
        return nonMember;
    }

}
