package com.ncr.itm.middleware.ws.impl.model;

/**
 * @author ap185225
 * 
 */
public class StubJointCustomer
{
    private final String birthdate;
    private final String homePhone;
    private final StubName name;
    private final String ssn;

    /**
     * Creates StubJointCustomer
     * 
     * @param fullName
     * @param birthdate
     * @param homePhone
     * @param ssn
     */
    public StubJointCustomer( String fullName, String birthdate, String homePhone, String ssn )
    {
        this.name = new StubName( fullName );
        this.birthdate = birthdate;
        this.homePhone = homePhone;
        this.ssn = ssn;
    }

    /**
     * @return the birthdate
     */
    public String getBirthdate()
    {
        return birthdate;
    }

    /**
     * @return the name
     */
    public StubName name()
    {
        return name;
    }

    /**
     * @return the ssn
     */
    public String getSsn()
    {
        return ssn;
    }

    /**
     * @return the homePhone
     */
    public String getHomePhone()
    {
        return homePhone;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "StubJointCustomer [birthdate=" + birthdate + ", homePhone=" + homePhone + ", name=" + name + ", ssn="
                + ssn + "]";
    }

}
