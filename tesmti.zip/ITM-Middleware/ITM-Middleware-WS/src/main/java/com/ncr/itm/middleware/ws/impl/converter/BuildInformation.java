/**
 *
 */
package com.ncr.itm.middleware.ws.impl.converter;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author ap185225
 *
 */
public class BuildInformation {

    private static final int INITIAL_CAPACITY = 20;
    private static final String NEW_LINE = System.getProperty("line.separator");

    private String implementationTitle;
    private String implementationVersion;
    private String svnRevision;

    /**
     *
     */
    @Autowired
    public BuildInformation(ServletContext context) {
        try (InputStream inputStream = context.getResourceAsStream("/META-INF/MANIFEST.MF")) {
            Manifest manifest = new Manifest(inputStream);
            Attributes attributes = manifest.getMainAttributes();

            implementationTitle = attributes.getValue("Implementation-Title");
            implementationVersion = attributes.getValue("Implementation-Version");
            svnRevision = attributes.getValue("ci-svn-commit");
        } catch (IOException e) {
            //ProductionLogger.warn( this, "exception reading manifest", e );
        }

        logBuildInformation();
    }

    public final void logBuildInformation() {
        Map<String, String> serviceMap = getServiceVersionMap();
        StringBuilder str = new StringBuilder(600);
        str.append(NEW_LINE);
        str.append("    NCR Branch Integration Server Build Information" + NEW_LINE);
        str.append("    Implementation Title: " + implementationTitle + NEW_LINE);
        str.append("    Implementation Version: " + implementationVersion + NEW_LINE);
        str.append("    Build: " + svnRevision + NEW_LINE);

        Set<Entry<String, String>> entrySet = serviceMap.entrySet();
        for (Entry<String, String> entry : entrySet) {
            str.append("    " + entry.getKey() + " service version: " + entry.getValue() + NEW_LINE);
        }

        //ProductionLogger.info(this, str.toString());
    }

    public static Map<String, String> getServiceVersionMap() {
        // update if additional services are implemented
        Map<String, String> serviceMap = new HashMap<>(INITIAL_CAPACITY);
        /*serviceMap.put(BISAdmin.SERVICE_NAME, BISAdmin.SERVICE_VERSION);
        serviceMap.put(BISConfiguration.SERVICE_NAME, BISConfiguration.SERVICE_VERSION);
        serviceMap.put(BISCustomer.SERVICE_NAME, BISCustomer.SERVICE_VERSION);
        serviceMap.put(BISDeposit.SERVICE_NAME, BISDeposit.SERVICE_VERSION);
        serviceMap.put(BISElectronic.SERVICE_NAME, BISElectronic.SERVICE_VERSION);
        serviceMap.put(BISPayment.SERVICE_NAME, BISPayment.SERVICE_VERSION);
        serviceMap.put(BISTransfer.SERVICE_NAME, BISTransfer.SERVICE_VERSION);
        serviceMap.put(BISWithdrawal.SERVICE_NAME, BISWithdrawal.SERVICE_VERSION);*/

        return serviceMap;
    }

}
