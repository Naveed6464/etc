/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.AuthoriseElectronicTxRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseElectronicTxRsType;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISElectronicService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

/**
 *
 * @author naveed
 */
@Endpoint
public class BISElectronicEndpoint extends BaseEndpoint {

    private BISElectronicService electronicService;

    public BISElectronicService getElectronicService() {
        return this.electronicService;
    }

    @Autowired(required = false)
    public void setElectronicService(BISElectronicService electronicService) {
        this.electronicService = electronicService;
    }

    @Autowired
    public BISElectronicEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "AuthoriseElectronicTxRq")
    @ResponsePayload
    public AuthoriseElectronicTxRsType authorise(@RequestPayload AuthoriseElectronicTxRqType authoriseElectronicTxRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "authorise - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<AuthoriseElectronicTxRsType> response;
        if (this.electronicService == null) {
            AuthoriseElectronicTxRsType electronicResponse = new AuthoriseElectronicTxRsType();
            response = createNotImplementedResponse(electronicResponse, header);
        } else {
            response = this.electronicService.authoriseElectronicTx(header, authoriseElectronicTxRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "authorise - Exit");
        return (AuthoriseElectronicTxRsType) response.getResponse();
    }
}
