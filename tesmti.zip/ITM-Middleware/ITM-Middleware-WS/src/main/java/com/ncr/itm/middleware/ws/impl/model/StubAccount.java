package com.ncr.itm.middleware.ws.impl.model;

import com.ncr.itm.middleware.ws.impl.model.StubDataImpl.AccountType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionState;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author ap185225
 *
 */
public final class StubAccount {

    private static final String ACCOUNT_IS_OPEN = "--------";
    private static final String DATE_FORMAT_PATTERN = "MMddyyyy";

    // NOTE: DO NOT CHANGE; Teller Enterprise looks for these values of AVAILABLE and CURRENT
    public static final String AVAILABLE = "Available";
    public static final String CURRENT = "Current";

    private final String accountId;
    private final String accountNumber;
    private final StubDataImpl.AccountType accountType;
    private BigDecimal availableBalance;
    private final String cardNumber;
    private final String closeDate;
    private BigDecimal currentBalance;
    private final String customerId;
    private final String dueDate;
    private final String interestRate;
    private final BigDecimal interestYearToDate;
    private final String irsCode;
    private String lastTransDate;
    private final String loanCode;
    private final BigDecimal loanPaymentHold;
    private final String maturityDate;
    private final String micrAccountNumber;
    private final BigDecimal minimumAdvance;
    private final String nickname;
    private final String openDate;
    private final BigDecimal pastDuePayment;
    private final BigDecimal paymentDue;
    private final BigDecimal payoffPayment;
    private final String product;
    private final BigDecimal regularPayment;
    private final String services;
    private final String shareCode;
    private final String symitarAccountType;
    private final List<StubTransactionDetail> transactionDetails;

    /**
     * Creates StubAccount from parameters
     *
     * @param accountId
     * @param accountNumber
     * @param accountType
     * @param availableBalance
     * @param cardNumber
     * @param closeDate
     * @param currentBalance
     * @param customerId
     * @param dueDate
     * @param interestRate
     * @param interestYearToDate
     * @param irsCode
     * @param lastTransDate
     * @param loanCode
     * @param loanPaymentHold
     * @param maturityDate
     * @param micrAccountNumber
     * @param minimumAdvance
     * @param nickname
     * @param pastDuePayment
     * @param paymentDue
     * @param payoffPayment
     * @param product
     * @param regularPayment
     * @param services
     * @param shareCode
     * @param symitarAccountType
     * @param transactionDetails
     */
    public StubAccount(String accountId, String accountNumber, AccountType accountType, BigDecimal availableBalance,
            String cardNumber, String closeDate, BigDecimal currentBalance, String customerId, String dueDate,
            String interestRate, BigDecimal interestYearToDate, String irsCode, String lastTransDate, String loanCode,
            BigDecimal loanPaymentHold, String maturityDate, String micrAccountNumber, BigDecimal minimumAdvance,
            String nickname, BigDecimal pastDuePayment, BigDecimal paymentDue, BigDecimal payoffPayment,
            String product, BigDecimal regularPayment, String services, String shareCode, String symitarAccountType,
            List<StubTransactionDetail> transactionDetails) {
        this.accountId = accountId;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.availableBalance = availableBalance;
        this.cardNumber = cardNumber;
        this.closeDate = closeDate;
        this.currentBalance = currentBalance;
        this.customerId = customerId;
        this.dueDate = dueDate;
        this.interestRate = interestRate;
        this.interestYearToDate = interestYearToDate;
        this.irsCode = irsCode;
        this.lastTransDate = lastTransDate;
        this.loanCode = loanCode;
        this.loanPaymentHold = loanPaymentHold;
        this.maturityDate = maturityDate;
        this.micrAccountNumber = micrAccountNumber;
        this.minimumAdvance = minimumAdvance;
        this.nickname = nickname;
        // *** TODO *** USE WHAT FOR OPEN DATE? ***
        this.openDate = lastTransDate;
        this.pastDuePayment = pastDuePayment;
        this.paymentDue = paymentDue;
        this.payoffPayment = payoffPayment;
        this.product = product;
        this.regularPayment = regularPayment;
        this.services = services;
        this.shareCode = shareCode;
        this.symitarAccountType = symitarAccountType;
        this.transactionDetails = transactionDetails;
    }

    /**
     * Copy constructor
     *
     * @param account
     */
    public StubAccount(StubAccount account) {
        this(account.accountId,
                account.accountNumber,
                account.accountType,
                account.availableBalance,
                account.cardNumber,
                account.closeDate,
                account.currentBalance,
                account.customerId,
                account.dueDate,
                account.interestRate,
                account.interestYearToDate,
                account.irsCode,
                account.lastTransDate,
                account.loanCode,
                account.loanPaymentHold,
                account.maturityDate,
                account.micrAccountNumber,
                account.minimumAdvance,
                account.nickname,
                account.pastDuePayment,
                account.paymentDue,
                account.payoffPayment,
                account.product,
                account.regularPayment,
                account.services,
                account.shareCode,
                account.symitarAccountType,
                new ArrayList<>(account.transactionDetails));
    }

    /**
     * @return the accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * @return the accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * @return the accountType
     */
    public StubDataImpl.AccountType getAccountType() {
        return accountType;
    }

    /**
     * @return the cardNumber
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * @return the closeDate
     */
    public String getCloseDate() {
        return closeDate;
    }

    /**
     * @return the customerId
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * @return the dueDate
     */
    public String getDueDate() {
        return dueDate;
    }

    /**
     * @return the interestRate
     */
    public String getInterestRate() {
        return interestRate;
    }

    /**
     * @return the interestYearToDate
     */
    public BigDecimal getInterestYearToDate() {
        return interestYearToDate;
    }

    /**
     * @return the irsCode
     */
    public String getIrsCode() {
        return irsCode;
    }

    /**
     * @return the lastTransDate
     */
    public synchronized String getLastTransDate() {
        return lastTransDate;
    }

    /**
     * @return the loanCode
     */
    public String getLoanCode() {
        return loanCode;
    }

    /**
     * @return the loanPaymentHold
     */
    public BigDecimal getLoanPaymentHold() {
        return loanPaymentHold;
    }

    /**
     * @return the maturityDate
     */
    public String getMaturityDate() {
        return maturityDate;
    }

    /**
     * @return the micrAccountNumber
     */
    public String getMicrAccountNumber() {
        return micrAccountNumber;
    }

    /**
     * @return the minimumAdvance
     */
    public BigDecimal getMinimumAdvance() {
        return minimumAdvance;
    }

    /**
     * @return the nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * @return the openDate
     */
    public String getOpenDate() {
        return openDate;
    }

    /**
     * @return the pastDuePayment
     */
    public BigDecimal getPastDuePayment() {
        return pastDuePayment;
    }

    /**
     * @return the paymentDue
     */
    public BigDecimal getPaymentDue() {
        return paymentDue;
    }

    /**
     * @return the payoffPayment
     */
    public BigDecimal getPayoffPayment() {
        return payoffPayment;
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @return the regularPayment
     */
    public BigDecimal getRegularPayment() {
        return regularPayment;
    }

    /**
     * @return the services
     */
    public String getServices() {
        return services;
    }

    /**
     * @return the shareCode
     */
    public String getShareCode() {
        return shareCode;
    }

    /**
     * @return the symitarAccountType
     */
    public String getSymitarAccountType() {
        return symitarAccountType;
    }

    /**
     * @return account balances
     */
    public synchronized Map<String, BigDecimal> getBalances() {
        Map<String, BigDecimal> balances = new HashMap<>(2);

        balances.put(AVAILABLE, availableBalance);
        balances.put(CURRENT, currentBalance);

        return balances;
    }

    /**
     * @return the transactionDetails
     */
    public List<StubTransactionDetail> getTransactionDetails() {
        return transactionDetails;
    }

    /**
     * If proposed transaction results in available balance >= 0, then if fees
     * exist return CUSTOMER_VALIDATION, otherwise update available balance, and
     * return account balances
     *
     * this method may not be not used for CashCheque
     *
     * StubTransactionState on entry: NOT_STARTED
     *
     * StubTransactionState on exit: AUTHORIZED, CUSTOMER_VALIDATION,
     * INSUFFICIENT_FUNDS, DENIED_FOR_TESTING (TE testing, "magic" number),
     * EXCEPTION_FOR_TESTING (TE testing, "magic" number),
     * BIS_NOT_FOUND_FOR_TESTING (TE testing, "magic" number)
     *
     * @param stubTransaction
     * @return account balances if transaction is can be authorized, else return
     * null
     */
    synchronized Map<String, BigDecimal> authorizeTransaction(StubTransaction stubTransaction) {
        assert ((stubTransaction.getState() == StubTransactionState.NOT_STARTED) // NOSONAR
                || ((stubTransaction.getType() == StubTransactionType.TRANSFER) // NOSONAR
                && (stubTransaction.getState() == StubTransactionState.AUTHORIZED))) : stubTransaction.getState().toString(); // NOSONAR

        Map<String, BigDecimal> balances = null;
        StubTransactionState state = updateAvailableBalance(stubTransaction);

        assert ((state == StubTransactionState.AUTHORIZED) // NOSONAR
                || (state == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                || (state == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                || (state == StubTransactionState.INSUFFICIENT_FUNDS) // NOSONAR
                || StubTransaction.isStateAddedForTesting(state)) : state.toString(); // NOSONAR
        stubTransaction.setState(state);

        if (state == StubTransactionState.AUTHORIZED) {
            balances = getBalances();
        }

        return balances;
    }

    /**
     * @param stubTransaction
     * @return
     */
    private BigDecimal calculateTransactionAvailable(StubTransaction stubTransaction) {
        BigDecimal transactionTotal;

        if ((stubTransaction.getType() == StubTransactionType.TRANSFER)
                && (accountNumber.equals(stubTransaction.getDestinationAccountNumber()))) {
            // deposit to destination account; fee was added to adjustment amount to withdraw from source account
            // remove it for the deposit end of the transaction
            transactionTotal = stubTransaction.getAdjustmentAmount().negate().subtract(stubTransaction.getFeeAmount());
        } else {
            transactionTotal = stubTransaction.getAdjustmentAmount();
        }

        return transactionTotal;
    }

    /**
     * @param stubTransaction
     * @return
     */
    private BigDecimal calculateTransactionTotal(StubTransaction stubTransaction) {
        // transactionAvailable does not include hold amount
        BigDecimal transactionTotal = calculateTransactionAvailable(stubTransaction).add(
                stubTransaction.getHoldAmount());

        return transactionTotal;
    }

    /**
     * Transaction was canceled, restore available balance to pre-transaction
     * value
     *
     * @param stubTransaction
     * @return account balances
     */
    synchronized Map<String, BigDecimal> cancelTransaction(StubTransaction stubTransaction) {
        if (stubTransaction.getState() != StubTransactionState.AUTHORIZED) {
            throw new IllegalStateException("cannot cancel transaction that has not been authorized");
        }

        BigDecimal transactionAvailable = calculateTransactionAvailable(stubTransaction);

        // restore balance
        availableBalance = availableBalance.subtract(transactionAvailable);
        lastTransDate = new SimpleDateFormat(DATE_FORMAT_PATTERN).format(new Date()); // "MMddyyyy"

        return getBalances();
    }

    /**
     * Update current balance now that transaction has been completed
     *
     * @param stubTransaction
     */
    synchronized void completeTransaction(StubTransaction stubTransaction) {
        BigDecimal transactionTotal = calculateTransactionTotal(stubTransaction);

        currentBalance = currentBalance.add(transactionTotal);
        lastTransDate = new SimpleDateFormat(DATE_FORMAT_PATTERN).format(new Date()); // "MMddyyyy"
    }

    /**
     * Return true if account is closed
     *
     * @return true if account is closed
     */
    public boolean isClosed() {
        return (!closeDate.equals(ACCOUNT_IS_OPEN));
    }

    /**
     * Transaction was reversed, restore available balance to pre-transaction
     * value
     *
     * @param stubTransaction
     */
    synchronized void reverseTransaction(StubTransaction stubTransaction) {
        if (stubTransaction.getState() != StubTransactionState.COMPLETED) {
            throw new IllegalStateException("cannot reverse transaction that has not been completed");
        }
        BigDecimal transactionAvailable = calculateTransactionAvailable(stubTransaction);
        BigDecimal transactionTotal = calculateTransactionTotal(stubTransaction);

        // update balances
        currentBalance = currentBalance.subtract(transactionTotal);
        availableBalance = availableBalance.subtract(transactionAvailable);
        lastTransDate = new SimpleDateFormat(DATE_FORMAT_PATTERN).format(new Date()); // "MMddyyyy"
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StubAccount [accountId=" + accountId + ", accountNumber=" + accountNumber + ", accountType="
                + accountType + ", availableBalance=" + availableBalance + ", cardNumber=" + cardNumber
                + ", closeDate=" + closeDate + ", currentBalance=" + currentBalance + ", customerId=" + customerId
                + ", dueDate=" + dueDate + ", interestRate=" + interestRate + ", interestYearToDate="
                + interestYearToDate + ", irsCode=" + irsCode + ", lastTransDate=" + lastTransDate + ", loanCode="
                + loanCode + ", loanPaymentHold=" + loanPaymentHold + ", maturityDate=" + maturityDate
                + ", micrAccountNumber=" + micrAccountNumber + ", minimumAdvance=" + minimumAdvance + ", nickname="
                + nickname + ", openDate=" + openDate + ", pastDuePayment=" + pastDuePayment + ", paymentDue="
                + paymentDue + ", payoffPayment=" + payoffPayment + ", product=" + product + ", regularPayment="
                + regularPayment + ", services=" + services + ", shareCode=" + shareCode + ", symitarAccountType="
                + symitarAccountType + "]";
    }

    /**
     * @param stubTransaction
     * @return
     */
    private StubTransactionState updateAvailableBalance(StubTransaction stubTransaction) {
        BigDecimal transactionAvailable = calculateTransactionAvailable(stubTransaction);
        StubTransactionState state;

        if (availableBalance.add(transactionAvailable).compareTo(BigDecimal.ZERO) >= 0) {
            // parallel code in StubDataImpl.authorizeAccount() for non-member transactions
            // scan item transactions may add fees of 0.00
            if (stubTransaction.isNewFeeAdded()) // && ( stubTransaction.getFeeAmount().compareTo( BigDecimal.ZERO ) > 0 ) )
            {
                state = StubTransactionState.CUSTOMER_VALIDATION;
            } else if (((stubTransaction.getRequestAmount().compareTo(StubTransaction.TELLER_OVERRIDE_AMOUNT) == 0)
                    || (stubTransaction.getRequestAmount().compareTo(
                            StubTransaction.TELLER_OVERRIDE_VALIDATE_REASON_ON_COMPLETE_AMOUNT) == 0)
                    || (stubTransaction.getAdjustmentAmount().compareTo(
                            StubTransaction.TELLER_OVERRIDE_ADJUSTED_AMOUNT) == 0)
                    || (stubTransaction.getAdjustmentAmount().compareTo(
                            StubTransaction.TELLER_OVERRIDE_VALIDATE_REASON_ON_COMPLETE_ADJUSTED_AMOUNT) == 0))
                    && (!stubTransaction.hasOverrideReason())) {
                state = StubTransactionState.TELLER_OVERRIDE;
            } else {
                availableBalance = availableBalance.add(transactionAvailable);
                lastTransDate = new SimpleDateFormat(DATE_FORMAT_PATTERN).format(new Date()); // "MMddyyyy"
                state = StubTransactionState.AUTHORIZED;
            }
        } else {
            state = StubTransactionState.INSUFFICIENT_FUNDS;
        }

        return state;
    }

}
