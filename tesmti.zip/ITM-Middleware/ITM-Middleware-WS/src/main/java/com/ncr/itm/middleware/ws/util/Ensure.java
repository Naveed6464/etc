package com.ncr.itm.middleware.ws.util;

/**
 * Assert class for standard assertions
 */
public final class Ensure {

    /**
     * Private constructor
     */
    private Ensure() {

    }

    /**
     * Check condition is true else throw an {@link IllegalArgumentException}
     * with the given message
     *
     * @param condition
     * @param message
     */
    public static void isTrue(boolean condition, String message) {
        if (!condition) {
            throw new IllegalArgumentException(message);
        }
    }

    /**
     * Check condition is false else throw an {@link IllegalArgumentException}
     * with the given message
     *
     * @param condition
     * @param message
     */
    public static void isFalse(boolean condition, String message) {
        if (condition) {
            throw new IllegalArgumentException(message);
        }
    }

    /**
     * Check the object is not null else throw an
     * {@link IllegalArgumentException} with the given message
     *
     * @param object
     * @param message
     */
    public static void notNull(Object object, String message) {
        if (object == null) {
            throw new IllegalArgumentException(message);
        }
    }

    /**
     * Check the object is null else throw an {@link IllegalArgumentException}
     * with the given message
     *
     * @param object
     * @param message
     */
    public static void isNull(Object object, String message) {
        if (object != null) {
            throw new IllegalArgumentException(message);
        }
    }

    /**
     * Check the array is not null, empty and has elements but does not contain
     * nulls else throw an {@link IllegalArgumentException} with the given
     * message
     *
     * @param array
     * @param message
     */
    public static void hasElements(Object[] array, String message) {
        if (array == null || array.length == 0) {
            throw new IllegalArgumentException(message);
        }
        for (Object el : array) {
            if (el == null) {
                throw new IllegalArgumentException(message + ": element is null");
            }
        }
    }

    /**
     * Check the text is not null, empty string or only whitespace else throw an
     * {@link IllegalArgumentException} with the given message
     *
     * @param text
     * @param message
     */
    public static void hasText(String text, String message) {
        if (text == null || text.trim().length() == 0) {
            throw new IllegalArgumentException(message);
        }
    }

    /**
     * Checks the length of the supplied text is no longer than the supplied
     * length. Otherwise throws an {@link IllegalArgumentException } with the
     * given message.
     *
     * @param text
     * @param length
     * @param message
     * @throws IllegalArgumentException if the supplied text has a longer length
     * than the supplied length value.
     */
    public static void isNoLongerThan(String text, int length, String message) {
        if (text.length() > length) {
            throw new IllegalArgumentException(message);
        }
    }
}
