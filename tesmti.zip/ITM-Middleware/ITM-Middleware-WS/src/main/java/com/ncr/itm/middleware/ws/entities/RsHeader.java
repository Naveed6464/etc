/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.entities;

import com.ncr.cxp.branch.integration.schema.AdditionalInfoType;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author naveed
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RsHeaderType", propOrder = {"msgSeqId", "sessionToken", "sessionState", "error"})
@XmlRootElement(name = "RsHeader")
public class RsHeader {

    @XmlElement(name = "MsgSeqId", required = true)
    protected String msgSeqId;
    @XmlElement(name = "SessionToken")
    protected String sessionToken;
    @XmlElement(name = "SessionState")
    protected SessionState sessionState;
    @XmlElement(name = "Error")
    protected ErrorType error;

    public String getMsgSeqId() {
        return this.msgSeqId;
    }

    public void setMsgSeqId(String value) {
        this.msgSeqId = value;
    }

    public String getSessionToken() {
        return this.sessionToken;
    }

    public void setSessionToken(String value) {
        this.sessionToken = value;
    }

    public SessionState getSessionState() {
        return this.sessionState;
    }

    public void setSessionState(SessionState value) {
        this.sessionState = value;
    }

    public ErrorType getError() {
        return this.error;
    }

    public void setError(ErrorType value) {
        this.error = value;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {"stateInformations"})
    public static class SessionState {

        @XmlElement(name = "StateInformation", required = true)
        protected List<AdditionalInfoType> stateInformations;

        public List<AdditionalInfoType> getStateInformations() {
            if (this.stateInformations == null) {
                this.stateInformations = new ArrayList();
            }
            return this.stateInformations;
        }
    }
}
