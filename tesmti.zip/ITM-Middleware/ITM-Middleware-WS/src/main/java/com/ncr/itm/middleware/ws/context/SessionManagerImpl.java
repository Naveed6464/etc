/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.context;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author naveed
 */
public class SessionManagerImpl
        implements SessionManager {

    private static final String CONTEXT_KEY_TYPE = "CONTEXT_KEY_TYPE";
    private static final String CONTEXT_KEY_TOKEN = "CONTEXT_KEY_TOKEN";
    private static final List<String> RESTRICTED_CONTEXT_KEYS = Arrays.asList(new String[]{"CONTEXT_KEY_TYPE", "CONTEXT_KEY_TOKEN", "CONTEXT_KEY_ID", "CONTEXT_KEY_CUSTOMER_ID"});
    private final Map<String, SessionState> sessions;
    private final Map<String, String> tokens;
    private final Map<String, Map<String, String>> sessionState;

    public SessionManagerImpl() {
        this.sessions = new ConcurrentHashMap();

        this.tokens = new ConcurrentHashMap();

        this.sessionState = new ConcurrentHashMap();
    }

    private final class SessionState {

        private final Map<String, String> contextData = new ConcurrentHashMap();

        private SessionState(String type, String id, String token) {
            this.contextData.put("CONTEXT_KEY_TYPE", type);
            this.contextData.put("CONTEXT_KEY_ID", id);
            this.contextData.put("CONTEXT_KEY_TOKEN", token);
        }

        private Map<String, String> getContextData() {
            return this.contextData;
        }

        private String getType() {
            return (String) this.contextData.get("CONTEXT_KEY_TYPE");
        }

        private String getId() {
            return (String) this.contextData.get("CONTEXT_KEY_ID");
        }

        private String getToken() {
            return (String) this.contextData.get("CONTEXT_KEY_TOKEN");
        }

        private String getCustomerId() {
            return (String) this.contextData.get("CONTEXT_KEY_CUSTOMER_ID");
        }

        private void setCustomerId(String customerId) {
            this.contextData.put("CONTEXT_KEY_CUSTOMER_ID", customerId);
        }

        private void removeCustomerId() {
            this.contextData.remove("CONTEXT_KEY_CUSTOMER_ID");
        }
    }

    public String startSession(String type, String id) {
        if (isValid(type, id)) {
            return null;
        }
        SessionState session = new SessionState(type, id, UUID.randomUUID().toString());
        String token = session.getToken();
        this.tokens.put(type + id, token);
        this.sessions.put(token, session);
        return token;
    }

    public String startSession(String type, String id, String token) {
        if ((isValid(token)) || (isValid(type, id))) {
            return null;
        }
        SessionState session = new SessionState(type, id, token);
        this.tokens.put(type + id, token);
        this.sessions.put(token, session);
        return token;
    }

    public void endSession(String token) {
        if (isValid(token)) {
            String idKey = ((SessionState) this.sessions.get(token)).getType() + ((SessionState) this.sessions.get(token)).getId();
            this.tokens.remove(idKey);
            this.sessions.remove(token);
        }
    }

    public void endSession(String type, String id) {
        if (isValid(type, id)) {
            String token = (String) this.tokens.get(type + id);
            this.tokens.remove(type + id);
            this.sessions.remove(token);
        }
    }

    public String getToken(String type, String id) {
        return (String) this.tokens.get(type + id);
    }

    public boolean isValid(String token) {
        return this.sessions.containsKey(token);
    }

    public boolean isValid(String type, String id) {
        return this.tokens.containsKey(type + id);
    }

    public boolean startCustomerSession(String token, String customerSessionId) {
        boolean returnValue = false;
        SessionState session = (SessionState) this.sessions.get(token);
        if ((session != null) && (session.getCustomerId() == null)) {
            returnValue = true;
            session.setCustomerId(customerSessionId);
        }
        return returnValue;
    }

    public void endCustomerSession(String token) {
        SessionState session = (SessionState) this.sessions.get(token);
        if (session != null) {
            session.removeCustomerId();
        }
    }

    public boolean isCustomerSessionActive(String token) {
        boolean result = false;
        SessionState session = (SessionState) this.sessions.get(token);
        if (session != null) {
            result = session.getCustomerId() != null;
        }
        return result;
    }

    public Map<String, String> obtainSessionContextData(String token) {
        Map<String, String> result = null;
        if (token != null) {
            SessionState session = (SessionState) this.sessions.get(token);
            if (session != null) {
                result = new HashMap(session.getContextData());
            }
        }
        return result;
    }

    public void storeSessionContextValue(String token, String contextValueKey, String contextValue) {
        ensureIsNotRestrictedContextKey(contextValueKey);

        SessionState session = (SessionState) this.sessions.get(token);
        if (session != null) {
            session.getContextData().put(contextValueKey, contextValue);
        }
    }

    public String removeSessionContextValue(String token, String contextValueKey) {
        ensureIsNotRestrictedContextKey(contextValueKey);

        String result = null;
        SessionState session = (SessionState) this.sessions.get(token);
        if (session != null) {
            result = (String) session.getContextData().remove(contextValueKey);
        }
        return result;
    }

    public void reset() {
        this.sessions.clear();
        this.tokens.clear();
    }

    private void ensureIsNotRestrictedContextKey(String contextValueKey) {
        if (RESTRICTED_CONTEXT_KEYS.contains(contextValueKey)) {
            throw new IllegalArgumentException(contextValueKey + " is a restricted context key.");
        }
    }

    public void putSessionState(String token, Map<String, String> currentState) {
        Map<String, String> state = new HashMap();
        state.putAll(currentState);
        this.sessionState.put(token, state);
    }

    public Map<String, String> getSessionState(String token) {
        Map<String, String> currentState = new HashMap();
        if (this.sessionState.get(token) != null) {
            currentState.putAll((Map) this.sessionState.get(token));
        }
        return currentState;
    }

    public void deleteSessionState(String token) {
        this.sessionState.remove(token);
    }
}
