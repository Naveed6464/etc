package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubFeeData;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StubBISTransactionConverter extends StubBaseTransactionConverter {

    /**
     * @param stubData
     * @param stubFeeData
     * @param transactionCache
     */
    @Autowired
    public StubBISTransactionConverter(StubData stubData, StubFeeData stubFeeData,
            StubTransactionCache transactionCache) {
        super(stubData, stubFeeData, transactionCache);
    }

}
