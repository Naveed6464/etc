package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AuthoriseTransferRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseTransferRsType;
import com.ncr.cxp.branch.integration.schema.CompleteTransferRqType;
import com.ncr.cxp.branch.integration.schema.CompleteTransferRsType;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.ReverseTransferRqType;
import com.ncr.cxp.branch.integration.schema.ReverseTransferRsType;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.impl.converter.StubBISTransferMessageConverter;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import com.ncr.itm.middleware.ws.util.Ensure;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Implementation of BIS Transfer Service Interface
 *
 * @author ap185225
 */
@Service
public class BISTransferService extends StubBISBaseServiceImpl {

    private final StubBISTransferMessageConverter converter;

    /**
     * Constructs a new instance of the class.
     *
     * @param sessionManager
     * @param converter
     */
    @Autowired
    public BISTransferService(SessionManager sessionManager, StubBISTransferMessageConverter converter) {
        super(sessionManager);
        this.converter = converter;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISTransfer#authoriseTransfer(com.ncr.cxp.localassist.integration
     * .dto.RqHeader, com.ncr.cxp.localassist.integration.dto.AuthoriseTransferRq)
     */
    //@Override
    public BISResult<AuthoriseTransferRsType> authoriseTransfer(final RqHeader header, final AuthoriseTransferRqType request) {
        //ProductionLogger.info(this, "authoriseTransfer - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<AuthoriseTransferRsType>() {
            @Override
            public BISResult<AuthoriseTransferRsType> execute() {
                return doAuthoriseTransfer(header, request);
            }
        }, new AuthoriseTransferRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<AuthoriseTransferRsType> doAuthoriseTransfer(RqHeader header, AuthoriseTransferRqType request) {
        String token = header.getAuthentication().getSessionToken();
        Ensure.notNull(request, "AuthoriseTransferRq");
        Ensure.notNull(request.getTransferInfo(), "TransferInfoType");
        // Ensure.isTrue( CustomerIdEnum.HOSTCUSTOMERID.name().equals( getCustomerIdType( token ) ),
        // "CustomerIdEnum" )
        Ensure.isTrue((request.getTransferInfo().getTransactionType() == null), "TransactionType");
        Ensure.notNull(request.getTransferInfo().getFromAccount(), "From AccountKeyType");
        Ensure.notNull(request.getTransferInfo().getToAccount(), "To AccountKeyType");
        Ensure.notNull(request.getTransferInfo().getAmount(), "AmountType");
        Ensure.isTrue(request.getTransferInfo().getAmount().getValue().compareTo(BigDecimal.ZERO) > 0,
                "AmountType");
        ErrorType error = null;

        AuthoriseTransferRsType response = new AuthoriseTransferRsType();

        try {
            response = converter.createAuthorizeTransferResponse(request, token, getCustomerId(token),
                    getCustomerIdType(token));
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), token, error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISTransfer#completeTransfer(com.ncr.cxp.localassist.integration.
     * dto.RqHeader, com.ncr.cxp.localassist.integration.dto.CompleteTransferRq)
     */
    //@Override
    public BISResult<CompleteTransferRsType> completeTransfer(final RqHeader header, final CompleteTransferRqType request) {
        //ProductionLogger.info(this, "completeTransfer - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<CompleteTransferRsType>() {
            @Override
            public BISResult<CompleteTransferRsType> execute() {
                return doCompleteTransfer(header, request);
            }
        }, new CompleteTransferRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<CompleteTransferRsType> doCompleteTransfer(RqHeader header, CompleteTransferRqType request) {
        Ensure.notNull(request, "CompleteTransferRq");
        Ensure.notNull(request.getTransactionId(), "transactionId");
        Ensure.notNull(request.getTransferCompletionInfo().getTransactionCompletionResult(), "TransactionCompletionResult");
        Ensure.isTrue(
                (request.getTransferCompletionInfo().getTransactionCompletionResult().getGoodCompletion() != null)
                || ((request.getTransferCompletionInfo().getTransactionCompletionResult().getCompletionIssues() != null)
                && ((request.getTransferCompletionInfo().getTransactionCompletionResult().getCompletionIssues().getCancellationReason() != null)
                || (request.getTransferCompletionInfo().getTransactionCompletionResult().getCompletionIssues().getReversalReason() != null))),
                "TransactionCompletionResult");

        ErrorType error = null;
        CompleteTransferRsType response = new CompleteTransferRsType();

        try {
            response = converter.createCompleteTransferResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISTransfer#reverseTransfer(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.ReverseTransferRq)
     */
    //@Override
    public BISResult<ReverseTransferRsType> reverseTransfer(final RqHeader header, final ReverseTransferRqType request) {
        //ProductionLogger.info(this, "reverseTransfer - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<ReverseTransferRsType>() {
            @Override
            public BISResult<ReverseTransferRsType> execute() {
                return doReverseTransfer(header, request);
            }
        }, new ReverseTransferRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<ReverseTransferRsType> doReverseTransfer(RqHeader header, ReverseTransferRqType request) {
        Ensure.notNull(request, "ReverseTransferRq");
        Ensure.notNull(request.getTransactionId(), "transactionId");
        ErrorType error = null;
        ReverseTransferRsType response = new ReverseTransferRsType();

        try {
            response = converter.createReverseTransferResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }
}
