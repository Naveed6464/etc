package com.ncr.itm.middleware.ws.impl.model;

import java.math.BigDecimal;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * @author ap185225
 * 
 */
@XmlAccessorType( XmlAccessType.FIELD )
@XmlType( name = "", propOrder = {
        "transactionSubType",
        "amount",
        "nonMemberAmount",
        "glAccount",
        "waivedCodes",
        "description",
        "editable"
} )
@XmlRootElement( name = "transactionFee" )
public class StubTransactionFee
{
    @XmlElement( name = "amount" )
    private BigDecimal amount;

    @XmlAttribute( name = "description" )
    private String description;

    @XmlAttribute( name = "editable" )
    private boolean editable;

    @XmlElement( name = "transactionSubType" )
    private StubTransaction.StubTransactionSubType transactionSubType;

    @XmlElement( name = "glAccount" )
    private String glAccount;

    @XmlElement( name = "nonMemberAmount" )
    private BigDecimal nonMemberAmount;

    @XmlElement( name = "relationshipCode" )
    @XmlElementWrapper( name = "waivedCodes" )
    private Set<String> waivedCodes;

    /**
     * 
     */
    @SuppressWarnings( "unused" )
    private StubTransactionFee()
    {
        // needed for JAXB
    }

    /**
     * for unit testing
     * 
     * @param amount
     * @param description
     * @param editable
     * @param transactionSubType
     * @param glAccount
     * @param nonMemberAmount
     * @param waivedCodes
     */
    public StubTransactionFee( BigDecimal amount, String description, boolean editable,
            StubTransaction.StubTransactionSubType transactionSubType, String glAccount, BigDecimal nonMemberAmount, Set<String> waivedCodes )
    {
        this.amount = amount;
        this.description = description;
        this.editable = editable;
        this.transactionSubType = transactionSubType;
        this.glAccount = glAccount;
        this.nonMemberAmount = nonMemberAmount;
        this.waivedCodes = waivedCodes;
    }

    /**
     * @return the amount
     */
    public BigDecimal getAmount()
    {
        return amount;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @return the transactionSubType
     */
    public StubTransaction.StubTransactionSubType getTransactionSubType()
    {
        return transactionSubType;
    }

    /**
     * @return the glAccount
     */
    public String getGlAccount()
    {
        return glAccount;
    }

    /**
     * @return the nonMemberAmount
     */
    public BigDecimal getNonMemberAmount()
    {
        return nonMemberAmount;
    }

    /**
     * @return the waivedCodes
     */
    public Set<String> getWaivedCodes()
    {
        return waivedCodes;
    }

    /**
     * @return the editable
     */
    public boolean isEditable()
    {
        return editable;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "StubTransactionFee [amount=" + amount + ", editable=" + editable + ", transactionSubType="
                + transactionSubType
                + ", glAccount=" + glAccount + ", nonMemberAmount=" + nonMemberAmount + ", waivedCodes=" + waivedCodes
                + ", description=" + description + "]";
    }

}
