package com.ncr.itm.middleware.ws.impl.model.exceptions;

/**
 * @author pm250114
 */
public class StubAccountClosedException extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = -7094706218260455833L;

    /**
     * @param message
     */
    public StubAccountClosedException( String message )
    {
        super( message );
    }

}
