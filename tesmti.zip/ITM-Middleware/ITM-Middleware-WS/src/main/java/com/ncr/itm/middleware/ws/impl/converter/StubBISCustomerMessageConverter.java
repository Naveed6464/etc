package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.AccountInqRq;
import com.ncr.cxp.branch.integration.schema.AccountInqRs;
import com.ncr.cxp.branch.integration.schema.AccountInqRs.Account;
import com.ncr.cxp.branch.integration.schema.AccountKeyType;
import com.ncr.cxp.branch.integration.schema.AccountKeyType.ValidOperations;
import com.ncr.cxp.branch.integration.schema.AccountOperationEnum;
import com.ncr.cxp.branch.integration.schema.AccountType;
import com.ncr.cxp.branch.integration.schema.AccountType.JointOwner;
import com.ncr.cxp.branch.integration.schema.AdditionalInfoType;
import com.ncr.cxp.branch.integration.schema.AmountType;
import com.ncr.cxp.branch.integration.schema.BalanceType;
import com.ncr.cxp.branch.integration.schema.CustomerDetailsType;
import com.ncr.cxp.branch.integration.schema.CustomerInfoType;
import com.ncr.cxp.branch.integration.schema.CustomerInfoType.AccountList;
import com.ncr.cxp.branch.integration.schema.CustomerInfoType.ContactPhone;
import com.ncr.cxp.branch.integration.schema.CustomerInfoType.Name;
import com.ncr.cxp.branch.integration.schema.CustomerInfoType.Portfolios;
import com.ncr.cxp.branch.integration.schema.CustomerInqRq;
import com.ncr.cxp.branch.integration.schema.CustomerInqRs;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRq;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRq.SearchCriteria;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRs;
import com.ncr.cxp.branch.integration.schema.NoteType;
import com.ncr.cxp.branch.integration.schema.StartSessionRq;
import com.ncr.cxp.branch.integration.schema.StartSessionRs;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRq;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRs;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRs.TransactionDetails;
import com.ncr.itm.middleware.ws.impl.model.StubAccount;
import com.ncr.itm.middleware.ws.impl.model.StubCustomer;
import com.ncr.itm.middleware.ws.impl.model.StubCustomerNote;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubDataImpl;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionDetail;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Message converter for the BIS Customer Service
 *
 * @author ap185225
 */
@Component
public class StubBISCustomerMessageConverter extends StubBISMessageConverter {

    private static final String DELAYED_RESPONSE_FOR_TESTING = "delayed response for testing";
    private static final String SOAP_FAULT_CUSTOMER_ID = "98";
    // private static final String ABE_LINCOLN = "16"
    private static final String DELAY_ALL = "100";
    private static final String DELAY_SEARCH = "101";
    private static final String DELAY_CUSTOMER_INQUIRY = "102";
    private static final String DELAY_ACCOUNT_INQUIRY = "103";
    private static final String DELAY_START_SESSION = "104";
    private static final String ERROR_START_SESSION = "105";
    private static final String HOME_PHONE = "home";
    private static final String CLOSED = "closed";
    private static final String EMPTY_STRING = "";
    private static final String MANY_ACCOUNTS_CUSTOMER_ID = "106";
    private static final String NO_ACCOUNTS_CUSTOMER_ID = "107";
    private static final String OPEN = "open";
    private static final String PAST_DUE = "past due";
    private static final int SECONDS_DELAY = 10 * 1000; // 10 seconds

    private boolean addPortfolios;

    /**
     * @param stubData
     */
    @Autowired
    public StubBISCustomerMessageConverter(StubData stubData) {
        super(stubData);

        try {
            // controlled by value of <Environment name="bis-ait-stub-service-context.portfolios" ...> in
            // <tomcat dir>\conf\context.xml
            InitialContext initialContext = new javax.naming.InitialContext();
            addPortfolios = ((Boolean) initialContext.lookup("java:comp/env/bis-ait-stub-service-context.portfolios")).booleanValue();
        } catch (NamingException e) // NOSONAR
        {
            // defaults to false
        }
    }

    /**
     * Creates a {@link AccountInqRs} based on the supplied {@link StubData}
     *
     * @param request
     * @return {@link AccountInqRs}
     * @throws StubNotFoundException
     */
    public AccountInqRs createAccountInqResponse(AccountInqRq request)
            throws StubNotFoundException {
        AccountInqRs response = new AccountInqRs();
        List<AccountKeyType> accountKeies = request.getAccountKey();

        // process each requested account
        for (AccountKeyType accountKey : accountKeies) {
            // look for account with specified account number
            if (accountKey.getType() == null) {
                throw new IllegalArgumentException("missing account type");
            }
            StubAccount account;
            try {
                account = stubData.getAccount(accountKey.getNumber());
                if (account != null) {
                    response.getAccount().add(convertAccount(account));
                }
            } catch (StubNotFoundException e) // NOSONAR
            {
                //ProductionLogger.warn(this, StubDataImpl.ACCOUNT_NOT_FOUND);
            }
        }

        try {
            if (accountKeies.get(0).getNumber().startsWith(DELAY_ALL + "-")
                    || accountKeies.get(0).getNumber().startsWith(DELAY_ACCOUNT_INQUIRY + "-")) {
                //ProductionLogger.info(this, DELAYED_RESPONSE_FOR_TESTING);
                Thread.sleep(SECONDS_DELAY);
            }
        } catch (InterruptedException e) // NOSONAR
        {
            // ignore
        }

        return response;
    }

    /**
     * Creates a {@link CustomerInqRs} based on the supplied {@link StubData}
     *
     * @param request
     * @return {@link CustomerInqRs}
     */
    public CustomerInqRs createCustomerInqResponse(CustomerInqRq request) {
        String customerId = request.getCustomerId().getIdInfo();
        CustomerInqRs response = null;

        // for Interactive Teller testing
        if (customerId.equals(SOAP_FAULT_CUSTOMER_ID)) {
            throw new IllegalStateException("soap fault customer selected");
        }

        // look for customer with specified customerId
        StubCustomer customer = stubData.getCustomer(customerId);
        if (customer != null) {
            response = new CustomerInqRs();
            response.setCustomerInfo(convertCustomerInfo(customer, request.getPortfolioId(), false));
            response.setCustomerDetails(convertCustomerDetails(customer));
        }

        try {
            if (DELAY_ALL.equals(customerId)
                    || DELAY_CUSTOMER_INQUIRY.equals(customerId)) {
                //ProductionLogger.info(this, DELAYED_RESPONSE_FOR_TESTING);
                Thread.sleep(SECONDS_DELAY);
            }
        } catch (InterruptedException e) // NOSONAR
        {
            // ignore
        }

        return response;
    }

    /**
     * Creates a {@link CustomerSearchRs} based on the supplied {@link StubData}
     *
     * @param request
     * @return {@link CustomerSearchRs}
     */
    public CustomerSearchRs createCustomerSearchResponse(CustomerSearchRq request) {
        CustomerSearchRs response = new CustomerSearchRs();
        List<SearchCriteria> searchCriteriaList = request.getSearchCriteria();
        List<StubCustomer> customers = null;
        Boolean matchAny = request.isMatchAny();
        Map<String, CustomerInfoType> customerMap = new HashMap<>();

        // do search for each specified search criteria, default: intersection of all criteria
        for (SearchCriteria searchCriteria : searchCriteriaList) {
            customers = doSearch(searchCriteria, customers);

            if ((matchAny == null) || (!matchAny.booleanValue())) {
                // intersection; if we have a results list from a previous search, use it as the source list in
                // successive searches before adding to response
                continue;
            } else {
                // union, add results to map aggregating results
                addCustomersToSearchResults(customers, customerMap);
                // signal to use all customers as source list in next search criteria
                customers = null;
            }
        }

        if ((matchAny == null) || (!matchAny.booleanValue())) {
            // intersection, now add results to map aggregating results
            addCustomersToSearchResults(customers, customerMap);
        }

        // copy customers aggregated in map to response; then sort by customerId
        response.getCustomer().addAll(customerMap.values());
        sortCustomers(response.getCustomer());
        addSearchDelay(searchCriteriaList);

        return response;
    }

    /**
     * Creates a {@link StartSessionRs} based on the supplied {@link StubData}
     *
     * @param request
     * @return {@link StartSessionRs}
     */
    public StartSessionRs createStartSessionResponse(StartSessionRq request) {
        String customerId = request.getCustomerId().getIdInfo();
        StartSessionRs response = new StartSessionRs();

        try {
            if (DELAY_ALL.equals(customerId) || DELAY_START_SESSION.equals(customerId)) {
                //ProductionLogger.info(this, DELAYED_RESPONSE_FOR_TESTING);
                Thread.sleep(SECONDS_DELAY);
            } else if (ERROR_START_SESSION.equals(customerId)) {
                response = null;
            }
        } catch (InterruptedException e) // NOSONAR
        {
            // ignore
        }

        return response;
    }

    /**
     * @param request
     * @return
     * @throws StubNotFoundException
     */
    public TransactionHistoryRs createTransactionHistory(TransactionHistoryRq request)
            throws StubNotFoundException {
        StubAccount account = stubData.getAccount(request.getAccountKey().getNumber());
        TransactionHistoryRs transactionHistoryRs = new TransactionHistoryRs();
        List<StubTransactionDetail> transactionDetails = account.getTransactionDetails();
        GregorianCalendar fromCalendar = request.getRange().getDateRange().getFromDate().toGregorianCalendar();
        GregorianCalendar toCalendar;

        if (request.getRange().getDateRange().getToDate() != null) {
            toCalendar = request.getRange().getDateRange().getToDate().toGregorianCalendar();
        } else {
            toCalendar = new GregorianCalendar();
        }

        // include all transactions occurring on dates within range (inclusive)
        fromCalendar.set(Calendar.HOUR_OF_DAY, 0);
        fromCalendar.set(Calendar.MINUTE, 0);
        fromCalendar.set(Calendar.SECOND, 0);
        fromCalendar.set(Calendar.MILLISECOND, 0);
        toCalendar.add(Calendar.DATE, 1);
        toCalendar.set(Calendar.HOUR_OF_DAY, 0);
        toCalendar.set(Calendar.MINUTE, 0);
        toCalendar.set(Calendar.SECOND, 0);
        toCalendar.set(Calendar.MILLISECOND, 0);

        if (transactionDetails.size() > 0) {
            List<TransactionDetails> transactionDetailList = transactionHistoryRs.getTransactionDetails();

            for (StubTransactionDetail transactionDetail : transactionDetails) {
                // filter by date range
                if ((transactionDetail.getPostedDate().compareTo(fromCalendar) >= 0)
                        && (transactionDetail.getPostedDate().compareTo(toCalendar) < 0)) {
                    TransactionDetails details = createTransactionDetails(account.getAccountType(), transactionDetail);
                    transactionDetailList.add(details);
                }
            }
        }

        return transactionHistoryRs;
    }

    /**
     * @param customerId
     * @return
     */
    public boolean isCustomerIdValid(String customerId) {
        return (stubData.getCustomer(customerId) != null);
    }

    /**
     * @param customerInfoType
     * @param customer
     * @param portfolioId
     */
    private void addAccounts(CustomerInfoType customerInfoType, StubCustomer customer, String portfolioId) {

        // add account info
        AccountList accountList = new AccountList();
        List<StubAccount> accounts = customer.getAccounts();
        int loopCount = 1;
        for (StubAccount stubAccount : accounts) {
            // all accounts added if not using portfolios or customer ID is odd number
            if ((portfolioId == null) || ((Integer.parseInt(customer.getId()) % 2) == 1)
                    || (customer.getId().equalsIgnoreCase(MANY_ACCOUNTS_CUSTOMER_ID))) {
                accountList.getAccount().add(convertAccountKeyType(stubAccount));
            } else // only add one account per portfolio, so each portfolio looks different for TE
            {
                if (Integer.parseInt(portfolioId.substring(0, 1)) == loopCount++) {
                    accountList.getAccount().add(convertAccountKeyType(stubAccount));
                    break;
                }
            }
        }
        if (!accountList.getAccount().isEmpty()) {
            customerInfoType.setAccountList(accountList);
        }
    }

    /**
     * add customers that matched search criteria to map aggregating customers
     * from all search criteria avoid duplicating customers found in multiple
     * search criteria
     *
     * @param addCustomers customers that matched search criteria
     * @param customerMap map aggregating customers from all search criteria
     */
    private void addCustomersToSearchResults(List<StubCustomer> addCustomers, Map<String, CustomerInfoType> customerMap) {
        // add to map aggregating results
        if ((addCustomers != null) && (!addCustomers.isEmpty())) {
            for (StubCustomer customer : addCustomers) {
                if (!customerMap.containsKey(customer.getId())) {
                    CustomerInfoType customerInfoType = convertCustomerInfo(customer, null, addPortfolios);
                    customerMap.put(customer.getId(), customerInfoType);
                }
            }
        }
    }

    /**
     * @param stubAccount
     * @param accountType
     */
    private void addNoteWarningToAccountType(StubAccount stubAccount, AccountType accountType) {
        StubCustomer customer = stubData.getCustomer(stubAccount.getCustomerId());
        List<StubCustomerNote> customerNotes = customer.getCustomerNotes();
        for (StubCustomerNote customerNote : customerNotes) {
            String type = customerNote.getType();
            if ("1".equals(type)) {
                accountType.getNote().add(convertAccountNote(customerNote));
            } else if ("2".equals(type)) {
                accountType.getWarning().add(convertAccountrWarning(customerNote));
            } else {
                throw new IllegalStateException("Invalid customer note type: " + type);
            }
        }
    }

    /**
     * @param customerInfoType
     * @param customer
     */
    private void addPortfolios(CustomerInfoType customerInfoType, StubCustomer customer) {
        // special case for Teller Enterprise development and testing
        // add list of portfolioIds instead of accounts
        Portfolios portfolios = new Portfolios();
        List<String> portfolioIds = portfolios.getPortfolioId();

        int prefix = 1;
        for (StubAccount stubAccount : customer.getAccounts()) {
            portfolioIds.add(String.valueOf(prefix++) + customer.getId() + stubAccount.getAccountId());
        }

        // add portfolios to customer without accounts
        if (NO_ACCOUNTS_CUSTOMER_ID.equalsIgnoreCase(customer.getId())) {
            portfolioIds.add(String.valueOf(1) + customer.getId() + "00");
            portfolioIds.add(String.valueOf(2) + customer.getId() + "01");
        }

        if (portfolioIds.size() > 0) {
            customerInfoType.setPortfolios(portfolios);
        }
    }

    /**
     * @param searchCriteriaList
     */
    private void addSearchDelay(List<SearchCriteria> searchCriteriaList) {
        try {
            if ((searchCriteriaList.size() > 0) && (DELAY_ALL.equals(searchCriteriaList.get(0).getAccountNumber()) || DELAY_SEARCH.equals(searchCriteriaList.get(0).getAccountNumber()))) {
                //ProductionLogger.info(this, DELAYED_RESPONSE_FOR_TESTING);
                Thread.sleep(SECONDS_DELAY);
            }
        } catch (InterruptedException e) // NOSONAR
        {
            // ignore
        }
    }

    /**
     * convert StubAccount into Account
     *
     * @param stubAccount
     * @return converted Account
     */
    private Account convertAccount(StubAccount stubAccount) {
        // convert account data
        Account account = new Account();
        AccountType accountType = new AccountType();
        accountType.setAccountKey(convertAccountKeyType(stubAccount));
        account.setAccountInfo(accountType);

        // set account status
        if (stubAccount.isClosed()) {
            accountType.setAccountStatus(CLOSED);
        } else if ((stubAccount.getPastDuePayment() != null)
                && (stubAccount.getPastDuePayment().compareTo(BigDecimal.ZERO) > 0)) {
            accountType.setAccountStatus(PAST_DUE);
        } else {
            accountType.setAccountStatus(OPEN);
        }

        accountType.setOpenDate(convertDate(stubAccount.getOpenDate()));
        accountType.setNickname(stubAccount.getNickname());
        // *** TODO *** SHARE CODE, LOAN CODE ??? ***
        // accountType.setProductCode( stubAccount.getSymitarAccountType() ); // NOSONAR
        accountType.setProductName(stubAccount.getProduct());
        accountType.setProductType(stubAccount.getAccountType().getBankProductType());

        // we decided not to use this in the stub
        // *** TODO *** NEED TO CREATE SEPARATE RECORDS FOR JOINT OWNERS IN DATA FILE AND UPDATE CODE TO SUPPORT IT ***
        // StubCustomer customer = stubData.getCustomer( stubAccount.getCustomerId() ); // NOSONAR
        // List<StubJointCustomer> jointCustomers = customer.getJointCustomers(); // NOSONAR
        // for( StubJointCustomer stubJointCustomer : jointCustomers ) // NOSONAR
        // add next two presidents as joint owners, for use in Teller Enterprise
        List<JointOwner> jointOwners = accountType.getJointOwner();
        int customerId = Integer.parseInt(stubAccount.getCustomerId());
        createJointOwner(jointOwners, customerId + 1);
        createJointOwner(jointOwners, customerId + 2);

        // create some joint owners to add more rows of data
        if (stubAccount.getCustomerId().equalsIgnoreCase(MANY_ACCOUNTS_CUSTOMER_ID)) {
            createJointOwner(jointOwners, 1);
            createJointOwner(jointOwners, 2);
            createJointOwner(jointOwners, 3); // NOSONAR
            createJointOwner(jointOwners, 4); // NOSONAR
            createJointOwner(jointOwners, 5); // NOSONAR
            createJointOwner(jointOwners, 6); // NOSONAR
        }

        // convert balance data
        // small window for race condition; we think this is ok for stub
        Map<String, BigDecimal> balances = stubAccount.getBalances();
        String lastTransDate = stubAccount.getLastTransDate();
        Set<Entry<String, BigDecimal>> entrySet = balances.entrySet();
        for (Entry<String, BigDecimal> entry : entrySet) {
            accountType.getBalance().add(
                    convertBalance(entry.getKey(), StubBISMessageConverter.STUB_CURRENCY, entry.getValue(),
                            lastTransDate));
        }

        // account Notes, Warnings
        addNoteWarningToAccountType(stubAccount, accountType);

        return account;
    }

    /**
     * @param jointOwners
     * @param jointCusomerId
     */
    private void createJointOwner(List<JointOwner> jointOwners, int jointCusomerId) {
        String jointId = String.valueOf(jointCusomerId);

        if (isCustomerIdValid(jointId)) {
            JointOwner jointOwner = new JointOwner();

            jointOwners.add(jointOwner);
            jointOwner.setCustomerId(jointId);
            jointOwner.setRelationship("relationship value");
            if ((jointCusomerId % 2) == 1) {
                StubCustomer jointCustomer = stubData.getCustomer(jointId);
                jointOwner.setName(jointCustomer.getName().getFullName());
            }
        }
    }

    /**
     * convert StubAccount into AccountKeyType
     *
     * @param stubAccount
     * @return converted AccountKeyType
     */
    private AccountKeyType convertAccountKeyType(StubAccount stubAccount) {
        AccountKeyType accountKeyType = new AccountKeyType();

        accountKeyType.setNumber(stubAccount.getAccountNumber());
        accountKeyType.setType(stubAccount.getAccountType().name());

        // accountKeyType.setCompany( value ); // NOSONAR
        // accountKeyType.setRouting( value ); // NOSONAR
        ValidOperations validOps = new ValidOperations();
        accountKeyType.setValidOperations(validOps);

        // closed accounts cannot be used for transactions
        if (!stubAccount.isClosed()) {
            // stubAccount.getServices(); // ???
            validOps.getAccountOperation().add(AccountOperationEnum.CASHCHEQUE);
            validOps.getAccountOperation().add(AccountOperationEnum.DEPOSIT);
            validOps.getAccountOperation().add(AccountOperationEnum.VIEW);
            validOps.getAccountOperation().add(AccountOperationEnum.WITHDRAW);
            // validOps.getAccountOperations().add( AccountOperationEnum.PAYFROM); // NOSONAR
            // validOps.getAccountOperations().add( AccountOperationEnum.PAYTO); // NOSONAR
            // validOps.getAccountOperations().add( AccountOperationEnum.TRANSFERFROM); // NOSONAR
            // validOps.getAccountOperations().add( AccountOperationEnum.TRANSFERTO); // NOSONAR
        }
        // accountType.setAccessAuthority( value ); // NOSONAR

        return accountKeyType;
    }

    /**
     * convert StubCustomer into CustomerDetailsType
     *
     * @param customer
     * @return converted CustomerDetailsType
     */
    private CustomerDetailsType convertCustomerDetails(StubCustomer customer) {
        CustomerDetailsType customerDetailsType = new CustomerDetailsType();
        customerDetailsType.setCustomerType(customer.getRelationshipCode());
        customerDetailsType.setPrivacy(EMPTY_STRING);

        // customer Notes, Warnings
        List<StubCustomerNote> customerNotes = customer.getCustomerNotes();
        for (StubCustomerNote customerNote : customerNotes) {
            String type = customerNote.getType();
            if ("1".equals(type)) {
                customerDetailsType.getNote().add(convertCustomerNote(customerNote));
            } else if ("2".equals(type)) {
                customerDetailsType.getWarning().add(convertCustomerWarning(customerNote));
            } else {
                throw new IllegalStateException("Invalid customer note type: " + type);
            }
        }

        return customerDetailsType;
    }

    private NoteType convertCustomerNote(StubCustomerNote customerNote) {
        //Ensure.isTrue("1".equals(customerNote.getType()), "not note type");
        NoteType note = new NoteType();
        note.setText(customerNote.getComment());
        note.setDate(convertShortDate(customerNote.getEffectiveDate()));
        note.setTitle(customerNote.getHeader());

        return note;
    }

    private CustomerDetailsType.Warning convertCustomerWarning(
            StubCustomerNote customerNote) {
        //Ensure.isTrue("2".equals(customerNote.getType()), "not warning type");
        CustomerDetailsType.Warning warning = new CustomerDetailsType.Warning();
        warning.setText(customerNote.getComment());
        AdditionalInfoType additionalInfo = new AdditionalInfoType();
        warning.getWarningsInfo().add(additionalInfo);
        additionalInfo.setKey("date");
        additionalInfo.setValue(convertShortDate(customerNote.getEffectiveDate()).toString());
        additionalInfo = new AdditionalInfoType();
        warning.getWarningsInfo().add(additionalInfo);
        additionalInfo.setKey("title");
        additionalInfo.setValue(customerNote.getHeader());

        return warning;
    }

    private NoteType convertAccountNote(StubCustomerNote customerNote) {
        //Ensure.isTrue("1".equals(customerNote.getType()), "not note type");
        NoteType note = new NoteType();
        note.setText(customerNote.getComment());
        note.setDate(convertShortDate(customerNote.getEffectiveDate()));
        note.setTitle(customerNote.getHeader());

        if (customerNote.getOtherData() != null) {
            AdditionalInfoType additionalInfo = new AdditionalInfoType();
            note.getNotesInfo().add(additionalInfo);
            additionalInfo.setKey("otherData");
            additionalInfo.setValue(customerNote.getOtherData());
        }

        return note;
    }

    private AccountType.Warning convertAccountrWarning(StubCustomerNote customerNote) {
        //Ensure.isTrue("2".equals(customerNote.getType()), "not warning type");
        AccountType.Warning warning = new AccountType.Warning();
        warning.setText(customerNote.getComment());
        AdditionalInfoType additionalInfo = new AdditionalInfoType();
        warning.getWarningsInfo().add(additionalInfo);
        additionalInfo.setKey("date");
        // *** TODO *** CORRECT FORMAT? *** OR USE customerNote.getEffectiveDate() WITHOUT CONVERSION? ***
        // *** AS IS, FORMAT MATCHES THAT USED FOR NOTE ***
        additionalInfo.setValue(convertShortDate(customerNote.getEffectiveDate()).toString());
        additionalInfo = new AdditionalInfoType();
        warning.getWarningsInfo().add(additionalInfo);
        additionalInfo.setKey("title");
        additionalInfo.setValue(customerNote.getHeader());

        return warning;
    }

    /**
     * create Address from data contained in StubCustomer
     *
     * @param customer
     * @return Address
     */
    private CustomerInfoType.Address convertAddress(StubCustomer customer) {
        CustomerInfoType.Address address = new CustomerInfoType.Address();
        address.getAddressLine().add(customer.getStreet());
        address.getAddressLine().add(EMPTY_STRING);
        address.getAddressLine().add(EMPTY_STRING);
        address.getAddressLine().add(customer.getCity());
        address.getAddressLine().add(customer.getState());
        address.getAddressLine().add(customer.getZipcode());
        address.getAddressLine().add("USA");

        return address;
    }

    /**
     * convert StubCustomer into CustomerInfoType
     *
     * @param customer
     * @param portfolioId
     * @param portfolioFlag
     * @return converted CustomerInfoType
     */
    private CustomerInfoType convertCustomerInfo(StubCustomer customer, String portfolioId, boolean portfolioFlag) {
        CustomerInfoType customerInfoType = new CustomerInfoType();
        Name name = new Name();
        name.setFirstName(customer.getName().getFirstName());
        name.setLastName(customer.getName().getLastName());

        customerInfoType.setCustomerId(customer.getId());
        customerInfoType.setName(name);
        customerInfoType.setAddress(convertAddress(customer));
        ContactPhone contactPhone = new ContactPhone();
        customerInfoType.getContactPhone().add(contactPhone);
        // *** TODO *** WHAT VALUES DO WE USE FOR PHONE TYPES? ***
        contactPhone.setPhoneType(HOME_PHONE);
        contactPhone.setPhoneNumber(customer.getHomePhone());
        if (StringUtils.hasLength(customer.getBirthdate())) {
            customerInfoType.setDateOfBirth(convertDate(customer.getBirthdate()));
        }

        CustomerInfoType.NationalId nationalId = new CustomerInfoType.NationalId();
        nationalId.setNationalIdType("tax id");
        nationalId.setNationalIdValue(customer.getSsn());
        customerInfoType.setNationalId(nationalId);

        if (portfolioFlag) {
            addPortfolios(customerInfoType, customer);
        } else {
            addAccounts(customerInfoType, customer, portfolioId);
        }

        return customerInfoType;
    }

    /**
     * @param accountType
     * @param stubTransactionDetail
     * @return
     */
    private TransactionDetails createTransactionDetails(StubDataImpl.AccountType accountType,
            StubTransactionDetail stubTransactionDetail) {
        TransactionDetails transactionDetails = new TransactionDetails();

        transactionDetails.setDate(datatypeFactory.newXMLGregorianCalendar(stubTransactionDetail.getEffectiveDate()));
        transactionDetails.setPostedDate(datatypeFactory.newXMLGregorianCalendar(stubTransactionDetail.getPostedDate()));
        transactionDetails.setTransactionType(stubTransactionDetail.getTransactionType());
        AmountType amountType = new AmountType();
        transactionDetails.setTransactionAmount(amountType);
        // required field
        transactionDetails.setDescription(EMPTY_STRING);

        amountType.setCurrency(StubBISMessageConverter.STUB_CURRENCY);
        amountType.setValue(stubTransactionDetail.getTransactionAmount());

        BalanceType balanceType = new BalanceType();
        AmountType amount = new AmountType();
        amount.setCurrency(StubBISMessageConverter.STUB_CURRENCY);
        amount.setValue(stubTransactionDetail.getBalance());
        balanceType.setType(StubAccount.CURRENT);
        balanceType.setAmount(amount);
        balanceType.setAsOfDate(datatypeFactory.newXMLGregorianCalendar(stubTransactionDetail.getPostedDate()));

        AdditionalInfoType additionalInfo1 = new AdditionalInfoType();
        additionalInfo1.setKey(stubTransactionDetail.getKey1());
        additionalInfo1.setValue(stubTransactionDetail.getValue1());
        AdditionalInfoType additionalInfo2 = new AdditionalInfoType();
        additionalInfo2.setKey(stubTransactionDetail.getKey2());
        additionalInfo2.setValue(stubTransactionDetail.getValue2());

        switch (accountType) {
            case ShareDraft:
                transactionDetails.getBalance().add(balanceType);
                break;

            case Share:
                transactionDetails.setDescription(stubTransactionDetail.getDescription());
                break;

            case Loan:
                transactionDetails.getTransactionData().add(additionalInfo1);
                transactionDetails.getTransactionData().add(additionalInfo2);
                break;

            case LineOfCredit:
                break;

            case CreditCard:
                transactionDetails.setDescription(stubTransactionDetail.getDescription());
                transactionDetails.getBalance().add(balanceType);
                transactionDetails.getTransactionData().add(additionalInfo1);
                transactionDetails.getTransactionData().add(additionalInfo2);
                break;

            case External:
                break;

            default:
                break;
        }

        return transactionDetails;
    }

    /**
     * find customers that match search criteria only one search criteria is
     * allowed per call
     *
     * @param searchCriteria
     * @param customers
     * @return list of customers matching search criteria
     */
    private List<StubCustomer> doSearch(SearchCriteria searchCriteria, List<StubCustomer> customers) {
        List<StubCustomer> foundCustomers = customers;

        // use specified search criteria
        if (searchCriteria.getCustomerName() != null) {
            foundCustomers = stubData.searchCustomersByName(foundCustomers, searchCriteria.getCustomerName());
        } else if (searchCriteria.getCustomerId() != null) {
            // assume: searchCriteria.getCustomerId().getIdType() == HOSTCUSTOMERID
            foundCustomers = stubData.searchCustomersByCustomerId(foundCustomers,
                    searchCriteria.getCustomerId().getIdInfo());
        } else if (searchCriteria.getAccountNumber() != null) {
            foundCustomers = stubData.searchCustomersByAccountNumber(foundCustomers,
                    searchCriteria.getAccountNumber());
        } else if (searchCriteria.getNationalId() != null) {
            foundCustomers = stubData.searchCustomersBySsn(foundCustomers, searchCriteria.getNationalId());
        } else if (searchCriteria.getPhoneNumber() != null) {
            foundCustomers = stubData.searchCustomersByPhoneNumber(foundCustomers,
                    searchCriteria.getPhoneNumber());
        } else if (searchCriteria.getCardNumber() != null) {
            foundCustomers = stubData.searchCustomersByCardNumber(foundCustomers, searchCriteria.getCardNumber());
        } else {
            //ProductionLogger.warn(this, "no known search criteria was provided");
            throw new IllegalArgumentException("no known search criteria was provided");
        }

        return foundCustomers;
    }

    /**
     * @param addPortfolios the addPortfolios to set
     */
    public void setAddPortfolios(boolean addPortfolios) {
        this.addPortfolios = addPortfolios;
    }

    /**
     * @param customerList
     */
    private void sortCustomers(List<CustomerInfoType> customerList) {
        // compare customerId of two customers; used to sort customer list
        Comparator<CustomerInfoType> comparator = new Comparator<CustomerInfoType>() {
            @Override
            public int compare(CustomerInfoType c1, CustomerInfoType c2) {
                int compareResult = 0;
                int id1 = Integer.parseInt(c1.getCustomerId());
                int id2 = Integer.parseInt(c2.getCustomerId());

                if (id1 < id2) {
                    compareResult = -1;
                } else if (id1 > id2) {
                    compareResult = 1;
                }

                return compareResult;
            }
        };

        Collections.sort(customerList, comparator);
    }

}
