/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.entities;

import com.ncr.cxp.branch.integration.schema.AdditionalInfoType;
import com.ncr.cxp.branch.integration.schema.TellerCredentialsType;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 *
 * @author naveed
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RqHeaderType", propOrder = {"timeStamp", "msgSeqId", "authentication", "overrideAuthentication", "customHeader", "sessionState"})
@XmlRootElement(name = "RqHeader")
public class RqHeader {

    @XmlElement(name = "TimeStamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar timeStamp;
    @XmlElement(name = "MsgSeqId", required = true)
    protected String msgSeqId;
    @XmlElement(name = "Authentication", required = true)
    protected Authentication authentication;
    @XmlElement(name = "OverrideAuthentication")
    protected OverrideAuthentication overrideAuthentication;
    @XmlElement(name = "CustomHeader")
    protected CustomHeader customHeader;
    @XmlElement(name = "SessionState")
    protected SessionState sessionState;

    public XMLGregorianCalendar getTimeStamp() {
        return this.timeStamp;
    }

    public void setTimeStamp(XMLGregorianCalendar value) {
        this.timeStamp = value;
    }

    public String getMsgSeqId() {
        return this.msgSeqId;
    }

    public void setMsgSeqId(String value) {
        this.msgSeqId = value;
    }

    public Authentication getAuthentication() {
        return this.authentication;
    }

    public void setAuthentication(Authentication value) {
        this.authentication = value;
    }

    public OverrideAuthentication getOverrideAuthentication() {
        return this.overrideAuthentication;
    }

    public void setOverrideAuthentication(OverrideAuthentication value) {
        this.overrideAuthentication = value;
    }

    public CustomHeader getCustomHeader() {
        return this.customHeader;
    }

    public void setCustomHeader(CustomHeader value) {
        this.customHeader = value;
    }

    public SessionState getSessionState() {
        return this.sessionState;
    }

    public void setSessionState(SessionState value) {
        this.sessionState = value;
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {"systemCredentials", "terminalCredentials", "tellerCredentials", "sessionToken"})
    public static class Authentication {

        @XmlElement(name = "SystemCredentials")
        protected SystemCredentials systemCredentials;
        @XmlElement(name = "TerminalCredentials")
        protected TerminalCredentials terminalCredentials;
        @XmlElement(name = "TellerCredentials")
        protected TellerCredentialsType tellerCredentials;
        @XmlElement(name = "SessionToken")
        protected String sessionToken;

        public SystemCredentials getSystemCredentials() {
            return this.systemCredentials;
        }

        public void setSystemCredentials(SystemCredentials value) {
            this.systemCredentials = value;
        }

        public TerminalCredentials getTerminalCredentials() {
            return this.terminalCredentials;
        }

        public void setTerminalCredentials(TerminalCredentials value) {
            this.terminalCredentials = value;
        }

        public TellerCredentialsType getTellerCredentials() {
            return this.tellerCredentials;
        }

        public void setTellerCredentials(TellerCredentialsType value) {
            this.tellerCredentials = value;
        }

        public String getSessionToken() {
            return this.sessionToken;
        }

        public void setSessionToken(String value) {
            this.sessionToken = value;
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {"systemName", "systemCredentialDetails"})
        public static class SystemCredentials {

            @XmlElement(name = "SystemName", required = true)
            protected String systemName;
            @XmlElement(name = "SystemCredentialDetails", required = true)
            protected String systemCredentialDetails;

            public String getSystemName() {
                return this.systemName;
            }

            public void setSystemName(String value) {
                this.systemName = value;
            }

            public String getSystemCredentialDetails() {
                return this.systemCredentialDetails;
            }

            public void setSystemCredentialDetails(String value) {
                this.systemCredentialDetails = value;
            }
        }

        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {"deviceId", "deviceCredentialDetails"})
        public static class TerminalCredentials {

            @XmlElement(name = "DeviceId", required = true)
            protected String deviceId;
            @XmlElement(name = "DeviceCredentialDetails", required = true)
            protected String deviceCredentialDetails;

            public String getDeviceId() {
                return this.deviceId;
            }

            public void setDeviceId(String value) {
                this.deviceId = value;
            }

            public String getDeviceCredentialDetails() {
                return this.deviceCredentialDetails;
            }

            public void setDeviceCredentialDetails(String value) {
                this.deviceCredentialDetails = value;
            }
        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {"additionalInfos"})
    public static class CustomHeader {

        @XmlElement(name = "AdditionalInfo", required = true)
        protected List<AdditionalInfoType> additionalInfos;

        public List<AdditionalInfoType> getAdditionalInfos() {
            if (this.additionalInfos == null) {
                this.additionalInfos = new ArrayList();
            }
            return this.additionalInfos;
        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {"userId", "password"})
    public static class OverrideAuthentication {

        @XmlElement(name = "UserId", required = true)
        protected String userId;
        @XmlElement(name = "Password")
        protected String password;

        public String getUserId() {
            return this.userId;
        }

        public void setUserId(String value) {
            this.userId = value;
        }

        public String getPassword() {
            return this.password;
        }

        public void setPassword(String value) {
            this.password = value;
        }
    }

    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {"stateInformations"})
    public static class SessionState {

        @XmlElement(name = "StateInformation", required = true)
        protected List<AdditionalInfoType> stateInformations;

        public List<AdditionalInfoType> getStateInformations() {
            if (this.stateInformations == null) {
                this.stateInformations = new ArrayList();
            }
            return this.stateInformations;
        }
    }
}
