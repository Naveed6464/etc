package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.CompleteTransactionsRq;
import com.ncr.cxp.branch.integration.schema.CompleteTransactionsRs;
import com.ncr.cxp.branch.integration.schema.ReverseTransactionsRq;
import com.ncr.cxp.branch.integration.schema.ReverseTransactionsRs;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Implementation of BIS Batch Service Interface
 *
 * @author ap185225
 */
@Service
public class BISBatchService extends StubBISBaseServiceImpl {
    // private final StubBISTransactionConverter converter; // NOSONAR

    /**
     * Constructs a new instance of the class.
     *
     * @param sessionManager
     * @param converter
     */
    @Autowired
    public BISBatchService(SessionManager sessionManager/* , StubBISTransactionConverter converter */) {
        super(sessionManager);
        // this.converter = converter; // NOSONAR
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISBatch#completeTransaction(com.ncr.cxp.localassist.integration.
     * dto.RqHeader, com.ncr.cxp.localassist.integration.dto.CompleteTransactionsRq)
     */
    //@Override
    public BISResult<CompleteTransactionsRs> completeTransaction(final RqHeader header, CompleteTransactionsRq request) {
        //ProductionLogger.warn(this, "completeBatch - no implementation in product, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<CompleteTransactionsRs>() {
            @Override
            public BISResult<CompleteTransactionsRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new CompleteTransactionsRs());
            }
        }, new CompleteTransactionsRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISBatch#reverseTransaction(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.ReverseTransactionsRq)
     */
    //@Override
    public BISResult<ReverseTransactionsRs> reverseTransaction(final RqHeader header, ReverseTransactionsRq request) {
        //ProductionLogger.warn(this, "reverseBatch - no implementation in product, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<ReverseTransactionsRs>() {
            @Override
            public BISResult<ReverseTransactionsRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new ReverseTransactionsRs());
            }
        }, new ReverseTransactionsRs());
    }

}
