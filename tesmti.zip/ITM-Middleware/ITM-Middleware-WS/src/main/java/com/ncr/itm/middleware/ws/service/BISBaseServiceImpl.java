/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AdditionalInfoType;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.entities.RsHeader;
import java.util.HashMap;
import java.util.Map;
import org.springframework.util.StringUtils;

/**
 *
 * @author naveed
 */
public class BISBaseServiceImpl {

    protected static final String BIS_SYSTEM_ERROR = "BIS_SYSTEM_ERROR";
    protected static final String BIS_INVALID_TOKEN = "BIS_INVALID_TOKEN";
    protected static final String BIS_SYSTEM_UNAVAILABLE = "BIS_SYSTEM_UNAVAILABLE";
    protected static final String BIS_UNKNOWN_ERROR = "BIS_UNKNOWN_ERROR";
    protected static final String BIS_NOT_CONNECTED = "BIS_NOT_CONNECTED";
    protected static final String BIS_BAD_REQUEST = "BIS_BAD_REQUEST";
    protected static final String BIS_ACCESS_DENIED = "BIS_ACCESS_DENIED";
    protected static final String BIS_INVALID_CUSTOMER_CREDENTIALS = "BIS_INVALID_CUSTOMER_CREDENTIALS";
    protected static final String BIS_SESSION_IN_PROGRESS = "BIS_SESSION_IN_PROGRESS";
    protected static final String BIS_NOT_IMPLEMENTED = "BIS_NOT_IMPLEMENTED";
    protected static final String BIS_NOT_FOUND = "BIS_NOT_FOUND";
    protected static final String BIS_INVALID_BRANCHID = "BIS_INVALID_BRANCHID";
    protected static final String BIS_ALREADY_SIGNED_ON = "BIS_ALREADY_SIGNED_ON";
    protected static final String BIS_ALREADY_SIGNED_OFF = "BIS_ALREADY_SIGNED_OFF";
    protected static final String BIS_SEQUENCE_ERROR = "BIS_SEQUENCE_ERROR";
    protected static final String BIS_NO_CUSTOMER_SESSION = "BIS_NO_CUSTOMER_SESSION";
    protected static final String BIS_NO_CHANGE = "BIS_NO_CHANGE";
    protected static final String NOT_IMPLEMENTED = "Not implemented";
    protected static final String TERMINALSESSION = "TERMINAL";
    protected static final String TELLERSESSION = "TELLER";
    protected static final String SYSTEMSESSION = "SYSTEM";
    private final SessionManager sessionManager;

    protected BISBaseServiceImpl(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    public SessionManager getSessionManager() {
        return this.sessionManager;
    }

    protected String getSessionTokenFromRequest(RqHeader header) {
        String token = header.getAuthentication().getSessionToken();
        if (token == null) {
            String sessionType = null;
            String id = null;
            RqHeader.Authentication auth = header.getAuthentication();
            if (auth.getTerminalCredentials() != null) {
                sessionType = "TERMINAL";
                id = auth.getTerminalCredentials().getDeviceId();
            } else if (auth.getTellerCredentials() != null) {
                sessionType = "TELLER";
                id = auth.getTellerCredentials().getUserId();
            }
            token = getSessionManager().getToken(sessionType, id);
        }
        return token;
    }

    protected <T> BISResult<T> buildNotImplementedResult(String msgSeqId, String token, T response) {
        return buildResult(msgSeqId, token, createErrorType("BIS_NOT_IMPLEMENTED", "Not implemented", SeverityEnum.ERROR), response);
    }

    protected <T> BISResult<T> buildResult(String msgSeqId, String token, ErrorType error, T response) {
        RsHeader rsHeader = new RsHeader();

        rsHeader.setError(error);
        rsHeader.setMsgSeqId(msgSeqId);
        rsHeader.setSessionToken(token);

        return new BISResult(rsHeader, response);
    }

    protected <T> BISResult<T> executeWithSessionTokenValidation(RqHeader header, BISCommand<T> command, T defaultResponse) {
        BISResult<T> result = null;

        String token = ensureValidSessionToken(header);
        if (StringUtils.hasText(token)) {
            result = command.execute();
        } else {
            result = buildResult(header.getMsgSeqId(), token, createErrorType("BIS_INVALID_TOKEN", "BIS_INVALID_TOKEN", SeverityEnum.CRITICAL), defaultResponse);
        }
        return result;
    }

    protected <T> BISResult<T> executeAndCreateSessionTokenIfNecessary(RqHeader header, BISCommand<T> command, T defaultResponse) {
        String token = getSessionTokenFromRequest(header);
        Credentials credentials = getCredentials(header);
        if ((credentials != null) && (StringUtils.hasText(credentials.getId()))) {
            if (!getSessionManager().isValid(credentials.getConnectType(), credentials.getId())) {
                getSessionManager().startSession(credentials.getConnectType(), credentials.getId());
            }
            return command.execute();
        }
        if (StringUtils.hasText(token)) {
            return executeWithSessionTokenValidation(header, command, defaultResponse);
        }
        return buildResult(header.getMsgSeqId(), null, createErrorType("BIS_BAD_REQUEST", "No teller/terminal credentials", SeverityEnum.ERROR), defaultResponse);
    }

    protected ErrorType createErrorType(String errorCode, String errorMessage, SeverityEnum severity) {
        ErrorType error = new ErrorType();
        error.setErrorCode(errorCode);
        error.setErrorMessage(errorMessage);
        error.setSeverity(severity);
        return error;
    }

    protected Map<String, String> getSessionState(RqHeader header) {
        Map<String, String> sessionState = new HashMap();
        if (header.getSessionState() != null) {
            for (AdditionalInfoType stateFromHeader : header.getSessionState().getStateInformations()) {
                sessionState.put(stateFromHeader.getKey(), stateFromHeader.getValue());
            }
        }
        return sessionState;
    }

    protected void addSessionState(RsHeader header, Map<String, String> sessionState) {
        if ((sessionState != null) && (!sessionState.isEmpty())) {
            RsHeader.SessionState state = new RsHeader.SessionState();
            for (String key : sessionState.keySet()) {
                AdditionalInfoType info = new AdditionalInfoType();
                info.setKey(key);
                info.setValue((String) sessionState.get(key));
                state.getStateInformations().add(info);
            }
            header.setSessionState(state);
        }
    }

    private String ensureValidSessionToken(RqHeader header) {
        String token = getSessionTokenFromRequest(header);
        if ((StringUtils.hasText(token)) && (!getSessionManager().isValid(token))) {
            return null;
        }
        return token;
    }

    private Credentials getCredentials(RqHeader header) {
        Credentials credentials = null;
        if (header.getAuthentication().getTerminalCredentials() != null) {
            credentials = new Credentials("TERMINAL", header.getAuthentication().getTerminalCredentials().getDeviceId());
        } else if (header.getAuthentication().getTellerCredentials() != null) {
            credentials = new Credentials("TELLER", header.getAuthentication().getTellerCredentials().getUserId());
        } else if (header.getAuthentication().getSystemCredentials() != null) {
            credentials = new Credentials("SYSTEM", header.getAuthentication().getSystemCredentials().getSystemName());
        }
        return credentials;
    }

    private static class Credentials {

        private final String connectType;
        private final String id;

        public Credentials(String connectType, String id) {
            this.connectType = connectType;
            this.id = id;
        }

        public String getConnectType() {
            return this.connectType;
        }

        public String getId() {
            return this.id;
        }
    }

    protected static abstract interface BISCommand<TResponse> {

        public abstract BISResult<TResponse> execute();
    }
}
