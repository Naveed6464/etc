/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRsType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRqType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRsType;
import com.ncr.cxp.branch.integration.schema.ReverseDepositRqType;
import com.ncr.cxp.branch.integration.schema.ReverseDepositRsType;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISDepositService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

/**
 *
 * @author naveed
 */
@Endpoint
public class BISDepositEndpoint
        extends BaseEndpoint {

    private BISDepositService depositService;

    public BISDepositService getDepositService() {
        return this.depositService;
    }

    @Autowired(required = false)
    public void setDepositService(BISDepositService depositService) {
        this.depositService = depositService;
    }

    @Autowired
    public BISDepositEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "AuthoriseDepositRq")
    @ResponsePayload
    public AuthoriseDepositRsType authorise(@RequestPayload AuthoriseDepositRqType authoriseDepositRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "authorise - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<AuthoriseDepositRsType> response;
        if (this.depositService == null) {
            AuthoriseDepositRsType depositResponse = new AuthoriseDepositRsType();
            response = createNotImplementedResponse(depositResponse, header);
        } else {
            response = this.depositService.authoriseDeposit(header, authoriseDepositRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "authorise - Exit");
        return (AuthoriseDepositRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CompleteDepositRq")
    @ResponsePayload
    public CompleteDepositRsType complete(@RequestPayload CompleteDepositRqType completeDepositRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "complete - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<CompleteDepositRsType> response;
        if (this.depositService == null) {
            CompleteDepositRsType depositResponse = new CompleteDepositRsType();
            response = createNotImplementedResponse(depositResponse, header);
        } else {
            response = this.depositService.completeDeposit(header, completeDepositRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "complete - Exit");
        return (CompleteDepositRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ReverseDepositRq")
    @ResponsePayload
    public ReverseDepositRsType reverse(@RequestPayload ReverseDepositRqType reverseDepositRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "reverse - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<ReverseDepositRsType> response;
        if (this.depositService == null) {
            ReverseDepositRsType depositResponse = new ReverseDepositRsType();
            response = createNotImplementedResponse(depositResponse, header);
        } else {
            response = this.depositService.reverseDeposit(header, reverseDepositRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "reverse - Exit");
        return (ReverseDepositRsType) response.getResponse();
    }
}
