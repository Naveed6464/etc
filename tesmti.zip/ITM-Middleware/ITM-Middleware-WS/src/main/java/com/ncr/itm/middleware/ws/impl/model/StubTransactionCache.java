package com.ncr.itm.middleware.ws.impl.model;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * @author ap185225
 *
 */
@Component
public class StubTransactionCache {

    // this is only reset on restart
    private final Map<String, StubTransaction> transactions = new ConcurrentHashMap<>();

    /**
     * @param transactionId
     * @return
     */
    public StubTransaction get(String transactionId) {
        return transactions.get(transactionId);
    }

    /**
     * @param transactionId
     * @param stubTransaction
     * @return
     */
    public StubTransaction put(String transactionId, StubTransaction stubTransaction) {
        return transactions.put(transactionId, stubTransaction);
    }

    /**
     * @param transactionId
     * @return
     */
    public StubTransaction remove(String transactionId) {
        return transactions.remove(transactionId);
    }

    /**
     * @param token
     */
    public void cleanup(String token) {
        if (token != null) {
            for (StubTransaction transaction : transactions.values()) {
                if (transaction.getToken().equals(token)
                        && (transaction.getState() != StubTransaction.StubTransactionState.COMPLETED)) {
                    //ProductionLogger.warn( this,"removing non-completed transaction: " + transaction.getTransactionId() );
                    transactions.remove(transaction.getTransactionId());
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StubTransactionCache [TRANSACTIONS=" + transactions + "]";
    }

}
