/**
 *
 */
package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.CashInItemType;
import com.ncr.cxp.branch.integration.schema.ChequeAuthResultType;
import com.ncr.cxp.branch.integration.schema.ChequeAuthResultType.OverrideOptions;
import com.ncr.cxp.branch.integration.schema.ChequeHoldTypeEnum;
import com.ncr.cxp.branch.integration.schema.ChequeInfoType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRqType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRsType;
import com.ncr.cxp.branch.integration.schema.ChequeRecommendEnum;
import com.ncr.cxp.branch.integration.schema.ChequeValidationStateEnum;
import com.ncr.cxp.branch.integration.schema.DepositRsItemsType.CashInItem;
import com.ncr.cxp.branch.integration.schema.FeeType;
import com.ncr.cxp.branch.integration.schema.HoldResultType;
import com.ncr.cxp.branch.integration.schema.HoldResultType.Availability;
import com.ncr.cxp.branch.integration.schema.MessageType;
import com.ncr.cxp.branch.integration.schema.TransactionStateEnum;
import com.ncr.cxp.branch.integration.schema.TransactionStatusType;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionState;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionCache;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionFee;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class StubBISAuthorizeConverter {

    private static final String DELAYED_RESPONSE_FOR_TESTING = "delayed response for testing";

    // these are used to facilitate Teller Enterprise and Unit testing
    // more constants defined in com.ncr.cxp.ait.stub.model.StubTransaction
    private static final BigDecimal DEPOSIT_STANDARD_HOLD_AMOUNT = new BigDecimal("1500.00");

    private final StubBaseTransactionConverter converterTarget; // access to transaction converter (including its base
    // class)
    private final StubTransactionHelper transactionHelper; // access to transaction components of request and response
    private BigDecimal cashTally = BigDecimal.ZERO;
    private boolean checkItemFailed = false;
    private BigDecimal checkTally = BigDecimal.ZERO;
    private final String customerId;
    private final List<FeeType> feeTypeList = new ArrayList<>();
    private BigDecimal holdTally = BigDecimal.ZERO;
    private boolean newFeeAdded = false;
    private StubTransaction originalTransaction = null;
    private final StubData stubData; // data model
    private final StubTransactionCache transactionCache;
    private String stubTransactionId;
    private final StubTransactionSubType transactionSubType;
    private final String token;
    private final Random random = new Random();

    /**
     * @param converterTarget access to transaction converter (including its
     * base class)
     * @param transactionHelper access to transaction components of request and
     * response
     * @param token
     * @param customerId
     */
    StubBISAuthorizeConverter(
            StubBaseTransactionConverter converterTarget,
            StubTransactionHelper transactionHelper,
            String token,
            String customerId) {
        this.converterTarget = converterTarget;
        this.transactionHelper = transactionHelper;
        this.stubData = converterTarget.getStubData();
        this.transactionCache = converterTarget.getTransactionCache();
        this.transactionSubType = transactionHelper.getTransactionSubType();
        this.token = token;
        this.customerId = customerId;
    }

    /**
     * @param transactionId
     * @param chequeItemRq
     * @param chequeAuthResult
     */
    private void addCheckHold(String transactionId, ChequeItemRqType chequeItemRq,
            ChequeAuthResultType chequeAuthResult) {
        ChequeInfoType chequeInfo = chequeItemRq.getChequeInfo();

        // *** TODO *** NOT IMPLEMENTED BY TELLER ENTERPRISE AT THIS TIME ***
        // decisions made by the teller after the authorization response to be sent in subsequent (re) authorization
        // request
        // ChequeDecisionsType chequeDecisions = chequeItemRq.getChequeDecisions(); // NOSONAR
        // com.ncr.cxp.localassist.integration.dto.ChequeDecisionsType.Hold holdDecision =
        // chequeDecisions.getHold(); // NOSONAR
        // Boolean nextDay = chequeDecisions.isNextDay(); // NOSONAR
        // Boolean return1 = chequeDecisions.isReturn(); // NOSONAR
        // ChequeHoldTypeEnum holdType = holdDecision.getHoldType(); // NOSONAR
        // String extendedHoldReason = holdDecision.getExtendedHoldReason(); // NOSONAR
        // *** FOR TE AND UNIT TESTING ***
        // add standard hold on any check > DEPOSIT_STANDARD_HOLD_AMOUNT
        // no holds for cashcheque subtype
        if ((transactionSubType != StubTransactionSubType.CASH_CHEQUE)
                && (chequeInfo.getAmount().getValue().compareTo(DEPOSIT_STANDARD_HOLD_AMOUNT) > 0)) {
            final Integer holdDays = Integer.valueOf(3);

            HoldResultType holdResultType = new HoldResultType();
            chequeAuthResult.getHold().add(holdResultType);
            holdResultType.setHoldAmount(chequeInfo.getAmount());
            holdResultType.setHoldType(ChequeHoldTypeEnum.REGULAR); // EXTENDED
            Availability availability = new Availability();
            holdResultType.setAvailability(availability);
            availability.setDaysHeld(holdDays);
            //ProductionLogger.info(this,"adding hold id: " + chequeItemRq.getChequeId() + " amount: "+ holdResultType.getHoldAmount().getValue()+ "; type: " + holdResultType.getHoldType() + "; days: "+ holdResultType.getAvailability().getDaysHeld()+ StubBaseTransactionConverter.TRANSACTION_ID + transactionId);
        }
    }

    /**
     * @param transactionId
     */
    private void addFeeType(String transactionId) {
        FeeType feeType = createFeeType(transactionId);

        if (feeType != null) {
            feeTypeList.add(feeType);
            transactionHelper.getResponseFees().add(feeType); // add fees to response
            if (!feeType.isWaived().booleanValue()) {
                // this will trigger setting state to CUSTOMER_VALIDATION
                newFeeAdded = true;
            }
        }
    }

    /**
     * Does not change StubTransactionState
     *
     * @param stubTransaction
     * @param balanceList
     * @return {@link TransactionStatusType}
     */
    private void addResponseBalances(StubTransaction stubTransaction, List<Map<String, BigDecimal>> balanceList) {
        // for testing Interactive Teller; if amount == NULL_BALANCE_AMOUNT, do not add balances to response
        if (stubTransaction.getRequestAmount().compareTo(StubTransaction.NULL_BALANCE_AMOUNT) == 0) {
            //ProductionLogger.info(this,"balances will not be returned for this transaction due to transaction amount to support testing");
        } else {
            Map<String, BigDecimal> sourcebalances = balanceList.get(0); // source account
            Map<String, BigDecimal> destinationBalances = (balanceList.size() > 1) ? balanceList.get(1) : null; // destination

            // update account
            // account number may be null for non-member transactions (CashCheque transactions, etc.)
            String lastTransDate = stubData.getLastTransDate(stubTransaction.getSourceAccountNumber());

            // package source account balance information
            Set<Entry<String, BigDecimal>> entrySet = sourcebalances.entrySet();
            for (Entry<String, BigDecimal> entry : entrySet) {
                // optional account balances in response after an authorized transaction
                transactionHelper.getResponseBalances().add(
                        converterTarget.convertBalance(entry.getKey(), StubBISMessageConverter.STUB_CURRENCY,
                                entry.getValue(), lastTransDate));
            }

            // package destination account balance information; transfer transactions
            if (destinationBalances != null) {
                // optional account balances in response after an authorized transaction
                lastTransDate = stubData.getLastTransDate(stubTransaction.getDestinationAccountNumber());
                entrySet = destinationBalances.entrySet();
                for (Entry<String, BigDecimal> entry : entrySet) {
                    // optional account balances in response after an authorized transaction
                    transactionHelper.getResponseToBalances().add(
                            converterTarget.convertBalance(entry.getKey(), StubBISMessageConverter.STUB_CURRENCY,
                                    entry.getValue(), lastTransDate));
                }
            }
        }
    }

    /**
     * @param stubTransaction
     * @return
     * @throws StubNotFoundException
     * @throws StubAccountClosedException
     */
    private List<Map<String, BigDecimal>> authorizeTransaction(StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        List<Map<String, BigDecimal>> balanceList;

        // NOTE: This was added to test denied transactions in Teller Enterprise
        if (stubTransaction.isDeniedForTesting()) {
            // denied for testing
            // must have at least one entry in list; may be null
            balanceList = new ArrayList<Map<String, BigDecimal>>(2);
            balanceList.add(null);
            assert stubTransaction.isStateAddedForTesting() : stubTransaction.getState();
        } else {
            // small window for race condition: update/get balance and lastTransDate; probably ok for stub
            balanceList = stubData.authorizeTransaction(stubTransaction);
        }
        assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.INSUFFICIENT_FUNDS) // NOSONAR
                || stubTransaction.isStateAddedForTesting()) : stubTransaction.getState().toString(); // NOSONAR

        return balanceList;
    }

    /**
     * @param transactionId
     * @param addFees
     * @return
     */
    private void convertCashItemList(String transactionId, boolean addFees) {
        // this excludes withdrawal and transfer transactions
        if (transactionHelper.getCashInItems() != null) {
            for (CashInItemType cashInItem : transactionHelper.getCashInItems()) {
                CashInItem convertedCashItem = convertCashItem(cashInItem);
                transactionHelper.getCashRsItems().add(convertedCashItem);

                if (convertedCashItem.getItemStatus().getTransactionState() == TransactionStateEnum.AUTHORISED) {
                    cashTally = cashTally.add(cashInItem.getAmount().getValue());
                    if (addFees) {
                        // request is not a re-authorize that includes approved fees
                        // add any applicable fees, for each check
                        addFeeType(transactionId);
                    }
                }
            }
        }
    }

    /**
     * @param cashInItemType
     * @return
     */
    private CashInItem convertCashItem(CashInItemType cashInItemType) {
        CashInItem cashInItem = new CashInItem();
        cashInItem.setAmount(cashInItemType.getAmount());
        cashInItem.setItemStatus(StubBaseTransactionConverter.convertTransactionStatusType(
                TransactionStateEnum.AUTHORISED, null, null));

        return cashInItem;
    }

    /**
     * @param transactionId
     * @param chequeItemRq
     * @return
     */
    private ChequeItemRsType convertChequeItem(String transactionId, ChequeItemRqType chequeItemRq) {
        ChequeItemRsType chequeItemRs = new ChequeItemRsType();
        chequeItemRs.setChequeId(chequeItemRq.getChequeId());
        // optional, updated account information for this cheque
        // chequeItemRs.setChequeAccount( account ); // NOSONAR

        // ChequeInfoType
        // ChequeInfoType chequeInfo = chequeItemRq.getChequeInfo(); // NOSONAR
        // optional, not used by stub
        // chequeInfo.getCourtesyAmount() // amount identified by image analysis from the courtesy amount field
        // chequeInfo.getLegalAmount() // amount identified by image analysis from the legal amount field
        // chequeInfo.getCustomerEnteredAmount() // amount entered by customer
        // chequeInfo.getTellerEnteredAmount() // amount entered by teller
        // chequeInfo.getDate() // date of check as identified by image analysis
        // chequeInfo.getPayee() // payee of check as identified by image analysis
        // chequeInfo.isSignaturePresent(); // true if image analysis has found a signature; if null, image analysis
        // // could not conclusively identify if a signature is present
        // check image and codeline information
        // ChequeImagesType chequeImages = chequeItemRq.getChequeImages(); // NOSONAR
        // chequeImages.getCodeLine()
        // chequeImages.getCodeLineParsed()
        // chequeImages.getConfidenceLevels()
        // chequeImages.getImages()
        ChequeAuthResultType chequeAuthResult = createChequeAuthResultType(transactionId, chequeItemRq);
        chequeItemRs.setChequeAuthResult(chequeAuthResult);

        return chequeItemRs;
    }

    /**
     * @param transactionId
     * @return
     */
    private void convertChequeItemList(String transactionId) {
        // this excludes withdrawal and transfer transactions
        if (transactionHelper.getChequeRqItems() != null) {
            for (ChequeItemRqType chequeItemRq : transactionHelper.getChequeRqItems()) {
                ChequeItemRsType convertedCheckItem = convertChequeItem(transactionId, chequeItemRq);
                transactionHelper.getChequeRsItems().add(convertedCheckItem);

                checkTally = checkTally.add(convertedCheckItem.getChequeAuthResult().getAmount().getValue());
                holdTally = holdTally.add(tallyHolds(convertedCheckItem));
            }
        }
    }

    /**
     * @param transactionId
     * @param chequeItemRq
     * @return
     */
    private ChequeAuthResultType createChequeAuthResultType(String transactionId, ChequeItemRqType chequeItemRq) {
        ChequeAuthResultType chequeAuthResult = new ChequeAuthResultType();
        ChequeInfoType chequeInfo = chequeItemRq.getChequeInfo();
        BigDecimal checkAmount;
        OverrideOptions overrideOptions;
        TransactionStatusType transactionStatusType;

        if (chequeInfo.getValidationState() != ChequeValidationStateEnum.VALID) {
            checkAmount = BigDecimal.ZERO;
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.DENIED, StubBaseTransactionConverter.BIS_CONDITION_ITEM_DENIED, null);
            overrideOptions = createOverrideOptions(ChequeRecommendEnum.RETURN);
            checkItemFailed = true;
        } else {
            // *** THIS CODE ALWAYS SETS STATUS TO AUTHORISED, EVEN IF HOLD EXISTS ***
            checkAmount = chequeInfo.getAmount().getValue();
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.AUTHORISED, null, null);
            overrideOptions = createOverrideOptions(ChequeRecommendEnum.KEEP);

            List<FeeType> fees = chequeItemRq.getChequeInfo().getFee();
            if (fees.size() > 0) {
                // this should only happen on re-authorize requests
                // copy approved fees for each check
                chequeAuthResult.getFee().addAll(fees);
                feeTypeList.addAll(fees);
            } else {
                // add applicable fees for each check
                FeeType feeType = createFeeType(transactionId);
                if (feeType != null) {
                    chequeAuthResult.getFee().add(feeType);
                    feeTypeList.add(feeType);
                    if (!feeType.isWaived().booleanValue()) {
                        // this will trigger setting state to CUSTOMER_VALIDATION
                        newFeeAdded = true;
                    }
                }
            }

            addCheckHold(transactionId, chequeItemRq, chequeAuthResult);

            // optional
            // chequeAuthResult.setEndorsement( value ); // NOSONAR
            // chequeAuthResult.setSortGroup( "OnUs" ) // "OffUs"
        }

        chequeAuthResult.setAmount(StubBISMessageConverter.convertAmount(StubBISMessageConverter.STUB_CURRENCY,
                checkAmount));
        chequeAuthResult.setOverrideOptions(overrideOptions);
        chequeAuthResult.setItemStatus(transactionStatusType);

        return chequeAuthResult;
    }

    /**
     * @param transactionId
     */
    private FeeType createFeeType(String transactionId) {
        FeeType feeType = null;

        // fees only apply to specific subtypes
        if (transactionSubType != null) {
            StubTransactionFee stubTransactionFee = converterTarget.getStubFeeData().getTransactionFeeMap()
                    .get(transactionSubType);

            if (stubTransactionFee != null) {
                BigDecimal feeAmount;
                Boolean waived = Boolean.FALSE;

                if (transactionHelper.isNonMember()) {
                    feeAmount = stubTransactionFee.getNonMemberAmount();
                } else {
                    feeAmount = stubTransactionFee.getAmount();
                    if ((stubTransactionFee.getWaivedCodes() != null)
                            && (stubTransactionFee.getWaivedCodes().contains(getRelationshipCode()))) {
                        waived = Boolean.TRUE;
                    }
                }

                if (feeAmount != null) {
                    feeType = new FeeType();
                    feeType.setFeeType(stubTransactionFee.getDescription());
                    feeType.setAmount(StubBISMessageConverter.convertAmount(
                            StubBISMessageConverter.STUB_CURRENCY,
                            feeAmount));
                    feeType.setGLAccount(stubTransactionFee.getGlAccount());
                    feeType.setCanChange(Boolean.valueOf(stubTransactionFee.isEditable()));
                    feeType.setWaived(waived);
                    //ProductionLogger.info(this, "adding fee of " + feeAmount + (waived.booleanValue() ? " (waived)" : "") + " for " + transactionSubType.name() + StubBaseTransactionConverter.TRANSACTION_ID + transactionId);
                }
            }
        }

        return feeType;
    }

    /**
     * @param option
     * @return
     */
    private OverrideOptions createOverrideOptions(ChequeRecommendEnum option) {
        // *** STUB ONLY SUPPORTS SINGLE OPTION WHICH IS SAME AS RECOMMEND ***
        OverrideOptions overrideOptions = new OverrideOptions();
        overrideOptions.setRecommend(option);
        overrideOptions.getOptions().add(option);
        // overrideOptions.getOptions().add( ChequeRecommendEnum.KEEP ); // NOSONAR
        // overrideOptions.getOptions().add( ChequeRecommendEnum.RETURN ); // NOSONAR
        // overrideOptions.getOptions().add( ChequeRecommendEnum.HOLD ); // NOSONAR
        // overrideOptions.getOptions().add( ChequeRecommendEnum.EXTHOLD ); // NOSONAR

        // *** NOT SUPPORTED BY STUB ***
        // overrideOptions.setNextDayOptions( value ); // NOSONAR
        // overrideOptions.getExtHoldReasons().add( "some extended hold reason" ); // NOSONAR
        return overrideOptions;
    }

    private List<MessageType> createTellerMessages() {
        List<MessageType> tellerMessages = new ArrayList<>();

        for (int i = 0; i <= random.nextInt(3); i++) // NOSONAR
        {
            MessageType messageType = new MessageType();
            messageType.setMessageId("UNKNOWN");
            messageType.setMessage("Teller message " + (i + 1));
            tellerMessages.add(messageType);
        }

        return tellerMessages;
    }

    /**
     * state == StubTransactionState.NOT_STARTED
     *
     * @param transactionId this is a new authorization as opposed to
     * re-authorize; affects whether amount is adjusted for fees
     * @return {@link StubTransaction}
     */
    private StubTransaction createStubTransaction(String transactionId) {
        String overrideReason = (transactionHelper.getOverrideInfo() != null)
                ? transactionHelper.getOverrideInfo().getReason() : null;

        StubTransaction stubTransaction = new StubTransaction(transactionId,
                transactionHelper.getTransactionType(), transactionSubType,
                transactionHelper.getSourceAccountNumber(), transactionHelper.getDestinationAccountNumber(),
                transactionHelper.getAmount(), transactionHelper.getCashBack(), tallyFees(), holdTally, token,
                newFeeAdded, transactionHelper.isNonMember(), overrideReason);
        assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();

        return stubTransaction;
    }

    /**
     * @param stubTransaction
     * @return
     * @throws StubNotFoundException
     */
    private TransactionStatusType createSpecializedStatusType(StubTransaction stubTransaction)
            throws StubNotFoundException {
        TransactionStatusType transactionStatusType = null;

        if ((stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION)) {
            // *** THIS CODE ALWAYS SETS STATUS TO CUSTOMER_VALIDATION IF NEW FEES WERE ADDED ***
            // [WR] This is dependent on the bank’s business rules. E.g. if the customers terms and conditions state
            // that there will always be a fee for a certain transaction type, then there is no need to get
            // CUSTOMER_VALIDATION. The customer has implicitly agreed already. Same with holds, A hold does not require
            // a teller override by default. Typically, if there is a hold and its set to AUTHORISED, it means that the
            // transaction can go ahead without further intervention, However, the teller may still make changes after
            // discussion with the customer.
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.CUSTOMER_VALIDATION, StubBaseTransactionConverter.BIS_CONDITION_FEE, null);
        } else if ((stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE)) {
            // TELLER_OVERRIDE means the teller must review and approve the transaction before it can go ahead.
            // optional; messages to be displayed to teller, especially if transaction was denied or requires an
            // override
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.TELLER_OVERRIDE, StubBaseTransactionConverter.BIS_CONDITION_GENERAL_OVERRIDE,
                    createTellerMessages());
        } else if (stubTransaction.getState() != StubTransactionState.AUTHORIZED) {
            // insufficient funds in source account or special handling for TE testing
            transactionStatusType = denyAuthorization(stubTransaction);
            assert (stubTransaction.getState() == StubTransactionState.DENIED) : stubTransaction.getState().toString();
        }

        return transactionStatusType;
    }

    /**
     * @param stubTransaction
     */
    private void delayAuthorize(StubTransaction stubTransaction) {
        // introduce a variable delay for testing
        if (stubTransaction.getState() == StubTransactionState.AUTHORIZED) {
            int delaySeconds = 0;

            if (stubTransaction.getRequestAmount().compareTo(StubTransaction.AUTHORIZE_DELAY_MAX_AMOUNT) <= 0) {
                delaySeconds = stubTransaction.getRequestAmount().unscaledValue().intValue();
            } else if (stubTransaction.getAdjustmentAmount().compareTo(StubTransaction.AUTHORIZE_DELAY_MAX_AMOUNT) <= 0) {
                delaySeconds = stubTransaction.getAdjustmentAmount().unscaledValue().intValue();
            }

            if (delaySeconds > 0) {
                try {
                    //ProductionLogger.info(this, DELAYED_RESPONSE_FOR_TESTING);
                    Thread.sleep(delaySeconds * 1000);
                } catch (InterruptedException e) // NOSONAR
                {
                    // ignore
                }
            }
        }
    }

    /**
     *
     * State on entry: INSUFFICIENT_FUNDS || EXCEPTION_FOR_TESTING ||
     * BIS_NOT_FOUND_FOR_TESTING || DENIED_FOR_TESTING StubTransactionState on
     * exit: DENIED;
     *
     * called when transaction authorization code returns null for balances
     * originally this meant there were insufficient funds later expanded for
     * testing Teller Enterprise; see StubAccount.isDeniedForTesting()
     *
     * @param stubTransaction
     * @return {@link TransactionStatusType}
     * @throws StubNotFoundException
     */
    private TransactionStatusType denyAuthorization(StubTransaction stubTransaction)
            throws StubNotFoundException {
        assert ((stubTransaction.getState() == StubTransactionState.INSUFFICIENT_FUNDS) // NOSONAR
                || stubTransaction.isStateAddedForTesting()) : stubTransaction.getState().toString(); // NOSONAR
        String deniedMessageId;
        String deniedMessage;
        TransactionStatusType transactionStatusType;

        if (stubTransaction.getState() == StubTransactionState.EXCEPTION_FOR_TESTING) {
            // to facilitate Teller Enterprise testing; occurs when a transaction amount is 667.00
            //ProductionLogger.info(this, "exception generated by stub server for testing; transactionId: " + stubTransaction.getTransactionId());
            throw new ArithmeticException("exception generated by stub server for testing");
        }
        if (stubTransaction.getState() == StubTransactionState.BIS_NOT_FOUND_FOR_TESTING) {
            // to facilitate Teller Enterprise testing; occurs when a transaction amount is 668.00
            //ProductionLogger.info(this, "not found error generated by stub server for testing; transactionId: " + stubTransaction.getTransactionId());
            throw new StubNotFoundException("not found error generated by stub server for testing");
        }

        if (stubTransaction.getState() == StubTransactionState.DENIED_FOR_TESTING) {
            // to facilitate testing; occurs when a transaction 666.00 >= amount <= 666.99
            deniedMessageId = "bis.denied.for.testing";
            deniedMessage = "authorization denied for testing (666.00 <= amount <= 666.99 or net amount == 6.66)";
        } else {
            // insufficient funds
            deniedMessageId = "bis.insufficient.funds";
            deniedMessage = "insufficient funds";
        }

        List<MessageType> tellerMessages = new ArrayList<>();

        MessageType messageType = new MessageType();
        messageType.setMessageId(deniedMessageId);
        messageType.setMessage(deniedMessage);
        tellerMessages.add(messageType);

        transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(TransactionStateEnum.DENIED,
                StubBaseTransactionConverter.BIS_CONDITION_INSUFFICIENT_FUNDS, tellerMessages);
        stubTransaction.setState(StubTransactionState.DENIED);
        //ProductionLogger.info( this, stubTransaction.getType().name() + ((stubTransaction.getSubType() != null) ? (" (" + stubTransaction.getSubType().name() + ")") : "") + " transaction denied: " + stubTransaction.getTransactionId());
        assert (stubTransaction.getState() == StubTransactionState.DENIED) : stubTransaction.getState().toString();

        return transactionStatusType;
    }

    /**
     * create new StubTransaction for new authorization and add it to the cache;
     * or retrieve existing transaction from cache; state ==
     * StubTransactionState.NOT_STARTED
     *
     * @param transactionId
     * @return {@link StubTransaction}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private StubTransaction getAuthorizedTransaction(String transactionId)
            throws StubNotFoundException, StubAccountClosedException {
        StubTransaction stubTransaction;

        if ((transactionId == null) || (transactionId.isEmpty())) {
            // ALP20140620 Teller Enterprise authorizes multiple transactions; they are not completed until post
            // if( hasNonCompletedTransaction( token ) ) // NOSONAR
            // { // NOSONAR
            // throw new StubBISSequenceException( "Previous transaction has not been completed" ); // NOSONAR
            // } // NOSONAR

            // new transaction
            String newTransactionId = UUID.randomUUID().toString();
            //ProductionLogger.info(this, "authorizing " + transactionHelper.getTransactionType() + ((transactionSubType != null) ? (" (" + transactionSubType + ")") : "") + StubBaseTransactionConverter.TRANSACTION + newTransactionId);

            processTransactionItems(newTransactionId, true);
            stubTransaction = createStubTransaction(newTransactionId);
            assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();
        } else {
            // re-authorize
            stubTransaction = reAuthorize(transactionId);
            assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();
        }
        assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();

        return stubTransaction;
    }

    private String getRelationshipCode() {
        return stubData.getCustomer(customerId).getRelationshipCode();
    }

    /**
     * @param stubTransaction
     * @return {@link TransactionStatusType}
     */
    private TransactionStatusType getStatusForFailedDepositItems(StubTransaction stubTransaction) {
        TransactionStatusType transactionStatusType;

        // some deposit item was not authorized
        // [WR] On the client side we are assuming the following:
        // • At least one item has TELLER_OVERRIDE -> tx is TELLER_OVERRIDE
        // • All items DENIED -> tx is DENIED
        // • No item is TELLER_OVERRIDE and not all items DENIED -> tx is CUSTOMER_VALIDATION
        // • All items AUTHORISED -> tx is AUTHORISED
        boolean allIitemsFailed = true;
        for (ChequeItemRsType chequeItemRs : transactionHelper.getChequeRsItems()) {
            if (chequeItemRs.getChequeAuthResult().getItemStatus().getTransactionState() == TransactionStateEnum.AUTHORISED) {
                allIitemsFailed = false;
                break;
            }
        }

        for (CashInItem cashInItem : transactionHelper.getCashRsItems()) {
            if (cashInItem.getItemStatus().getTransactionState() == TransactionStateEnum.AUTHORISED) {
                allIitemsFailed = false;
                break;
            }
        }

        if (allIitemsFailed) {
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.DENIED, StubBaseTransactionConverter.BIS_CONDITION_ALL_ITEMS_DENIED, null);
//            ProductionLogger.info( this, stubTransaction.getType().name() + ((stubTransaction.getSubType() != null) ? (" (" + stubTransaction.getSubType().name() + ")") : "")
//                    + " transaction denied: "
//                    + stubTransaction.getTransactionId());
            stubTransaction.setState(StubTransactionState.DENIED);
        } else {
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.CUSTOMER_VALIDATION, StubBaseTransactionConverter.BIS_CONDITION_REVIEW_ITEMS,
                    null);
//            ProductionLogger.info( this, stubTransaction.getType().name() + ((stubTransaction.getSubType() != null) ? (" (" + stubTransaction.getSubType().name() + ")") : "")
//                    + " transaction partially denied: "
//                    + stubTransaction.getTransactionId());
            stubTransaction.setState(StubTransactionState.CUSTOMER_VALIDATION);
        }

        return transactionStatusType;
    }

    /**
     * @return the stubTransactionId
     */
    String getStubTransactionId() {
        return stubTransactionId;
    }

    /**
     * authorize transaction; StubTransactionState on entry: NOT_STARTED;
     * StubTransactionState on exit: AUTHORIZED, CUSTOMER_VALIDATION, DENIED
     *
     * @param transactionId
     * @return {@link TransactionStatusType}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    TransactionStatusType processAuthorize(String transactionId)
            throws StubNotFoundException, StubAccountClosedException {
        TransactionStatusType transactionStatusType;
        // this also calculates fees, but does not add them to the response
        StubTransaction stubTransaction = getAuthorizedTransaction(transactionId);
        assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();

        // optional, may be echoed back if additional or changed information is provided as a result of the
        // authorization
        // depositDetailsType.setAccount( value ); // NOSONAR
        // optional, may be echoed back if the authorized amount is different from that requested
        // depositDetailsType.setAmount( value ); // NOSONAR
        // depositDetailsType.getAdditionalInfos().add( e ); // NOSONAR
        if (checkItemFailed) {
            transactionStatusType = getStatusForFailedDepositItems(stubTransaction);
            assert ((stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.DENIED)) : stubTransaction.getState().toString(); // NOSONAR
        } else {
            try {
                transactionStatusType = resolveAuthorizeStatus(stubTransaction);
            } catch (Exception e) {
                restoreTransaction();
                // return fact that re-authorize failed; an error or SoapFault will be returned
                // transaction will be in same state as most recent authorized response
                throw e;
            }
            assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.DENIED)) : stubTransaction.getState().toString(); // NOSONAR
        }
        assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.DENIED)) : stubTransaction.getState().toString(); // NOSONAR

        stubTransactionId = stubTransaction.getTransactionId();
        transactionCache.put(stubTransactionId, stubTransaction);
        delayAuthorize(stubTransaction);

        return transactionStatusType;
    }

    /**
     * Deposit and CashCheque transactions: validate cash and check items, add
     * fees; other transactions: add fees
     *
     * @param transactionId
     * @param addFees
     * @return
     */
    private void processTransactionItems(String transactionId, boolean addFees) {
        BigDecimal depositTally = BigDecimal.ZERO;

        if (transactionHelper.getTransactionType() == StubTransactionType.DEPOSIT) {
            convertCashItemList(transactionId, addFees);
            convertChequeItemList(transactionId); // calculates check related fees

            if (!checkItemFailed) {
                BigDecimal depositAmount = transactionHelper.getAmount();

                // all deposit item are authorized
                depositTally = cashTally.add(checkTally);
                if (depositTally.compareTo(depositAmount) != 0) {
                    //ProductionLogger.warn(this, "deposit amount does not equal individual item amounts: " + depositAmount + " vs. " + depositTally);
                    throw new IllegalArgumentException(
                            "deposit amount does not equal sum of individual item amounts: "
                            + depositAmount + " vs. " + depositTally);
                }
            }
        } else if (addFees) {
            // transfer, withdrawal
            // request is not a re-authorize that includes approved fees
            // add any applicable fees
            addFeeType(transactionId);
        }
    }

    /**
     * lookup existing StubTransaction for re-authorization;
     * StubTransactionState on exit: StubTransactionState.NOT_STARTED
     *
     * @param transactionId
     * @return {@link StubTransaction}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private StubTransaction reAuthorize(String transactionId)
            throws StubNotFoundException, StubAccountClosedException {
        StubTransaction stubTransaction = converterTarget.getStubTransaction(transactionId,
                transactionHelper.getTransactionType());

        // fees provided in the re-authorize request, indicate that the teller/customer accepted these fees
        // if status is AUTHORIZED or DENIED, replace transaction and re-process as if this is the original
        // request
        if ((stubTransaction.getState() == StubTransactionState.AUTHORIZED)
                || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION)
                || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE)
                || (stubTransaction.getState() == StubTransactionState.DENIED)) {
            // preserve transaction in current state, in case re-authorize request fails
            originalTransaction = stubTransaction;

            // remove from cache and, if authorized, reverse previous transaction
            // add replacement transaction to cache
            converterTarget.cancelStubTransaction(stubTransaction, true, null);
//            ProductionLogger.info(this, "re-authorizing " + transactionHelper.getTransactionType()
//                    + ((transactionSubType != null) ? (" (" + transactionSubType + ")") : "")
//                    + StubBaseTransactionConverter.TRANSACTION
//                    + transactionId);

            boolean addFeesDuringProcessing = true;

            // CUSTOMER_VALIDATION could be due to an invalid deposit item or fees
            if ((stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION)
                    && (transactionHelper.getRequestFees().size() > 0)) {
                // request Fees have been approved, use them; add to response instead of generating new automatic fees
                // during processing
                addFeesDuringProcessing = false;
                feeTypeList.clear();
                feeTypeList.addAll(transactionHelper.getRequestFees());
                transactionHelper.getResponseFees().addAll(feeTypeList); // add fees to response
            }

            // *** TODO ***
            // generate new transactionId; simulate Nusenda BIS impl
            // String newTransactionId = UUID.randomUUID().toString();
            String newTransactionId = transactionId;
            processTransactionItems(newTransactionId, addFeesDuringProcessing);
            stubTransaction = createStubTransaction(newTransactionId);
            assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();
        } else {
            //ProductionLogger.warn(this, StubBaseTransactionConverter.INVALID_TRANSACTION_STATE + stubTransaction.getState().name() + StubBaseTransactionConverter.TRANSACTION_ID + stubTransaction.getTransactionId());
            throw new IllegalStateException("cannot re-authorize transaction: " + stubTransaction.getTransactionId());
        }
        assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();

        return stubTransaction;
    }

    /**
     * StubTransactionState on entry: NOT_STARTED; StubTransactionState on exit:
     * AUTHORIZED, CUSTOMER_VALIDATION, DENIED
     *
     * @param stubTransaction
     * @return {@link TransactionStatusType}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private TransactionStatusType resolveAuthorizeStatus(StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();
        List<Map<String, BigDecimal>> balanceList;
        TransactionStatusType transactionStatusType;

        balanceList = authorizeTransaction(stubTransaction);

        transactionStatusType = createSpecializedStatusType(stubTransaction);
        if (transactionStatusType == null) {
            addResponseBalances(stubTransaction, balanceList);
            transactionStatusType = StubBaseTransactionConverter.convertTransactionStatusType(
                    TransactionStateEnum.AUTHORISED, null, null);
            //ProductionLogger.info(this, stubTransaction.getType().name() + ((stubTransaction.getSubType() != null) ? (" (" + stubTransaction.getSubType().name() + ")"): "") + " transaction authorized: " + stubTransaction.getTransactionId());
        }
        assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.DENIED)) : stubTransaction.getState().toString(); // NOSONAR

        return transactionStatusType;
    }

    private void restoreTransaction()
            throws StubNotFoundException, StubAccountClosedException {
        if (originalTransaction != null) {
            // authorize original transaction to restore incoming state; assume it will succeed
            StubTransaction stubTransaction = originalTransaction;
            stubTransaction.setState(StubTransactionState.NOT_STARTED);
            // adjust account balances, etc.
            resolveAuthorizeStatus(stubTransaction);
            assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.DENIED)) : stubTransaction.getState().toString(); // NOSONAR
            stubTransactionId = stubTransaction.getTransactionId();
            transactionCache.put(stubTransactionId, stubTransaction);
        }
    }

    /**
     * @return
     */
    private BigDecimal tallyFees() {
        BigDecimal totalFees = BigDecimal.ZERO;

        for (FeeType feeType : feeTypeList) {
            if ((feeType.isWaived() == null) || (!feeType.isWaived().booleanValue())) {
                totalFees = totalFees.add(feeType.getAmount().getValue());
            }
        }

        return totalFees;
    }

    private BigDecimal tallyHolds(ChequeItemRsType chequeItemRs) {
        BigDecimal totalHolds = BigDecimal.ZERO;

        List<HoldResultType> holds = chequeItemRs.getChequeAuthResult().getHold();
        for (HoldResultType holdResultType : holds) {
            totalHolds = totalHolds.add(holdResultType.getHoldAmount().getValue());
        }

        return totalHolds;
    }
}
