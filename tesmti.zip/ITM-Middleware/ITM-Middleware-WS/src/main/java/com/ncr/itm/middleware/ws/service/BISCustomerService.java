package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AccountInqRq;
import com.ncr.cxp.branch.integration.schema.AccountInqRs;
import com.ncr.cxp.branch.integration.schema.CustomerIdEnum;
import com.ncr.cxp.branch.integration.schema.CustomerInqRq;
import com.ncr.cxp.branch.integration.schema.CustomerInqRs;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRq;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRs;
import com.ncr.cxp.branch.integration.schema.EndSessionRq;
import com.ncr.cxp.branch.integration.schema.EndSessionRs;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.GetReceiptRq;
import com.ncr.cxp.branch.integration.schema.GetReceiptRs;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.cxp.branch.integration.schema.StartSessionRq;
import com.ncr.cxp.branch.integration.schema.StartSessionRs;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRq;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRs;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.impl.converter.StubBISCustomerMessageConverter;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import com.ncr.itm.middleware.ws.util.Ensure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Implementation of BISCustomer interface
 *
 * @author sb185196
 *
 */
@Service
public class BISCustomerService extends StubBISBaseServiceImpl {

    private static final String NOT_FOUND = "Not found";

    private final StubBISCustomerMessageConverter converter;

    /**
     * Constructs an instance of the class
     *
     * @param sessionManager
     * @param converter
     */
    @Autowired
    public BISCustomerService(SessionManager sessionManager, StubBISCustomerMessageConverter converter) {
        super(sessionManager);
        this.converter = converter;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISCustomer#startSession(com.ncr.cxp.localassist.integration.dto.
     * RqHeader, com.ncr.cxp.localassist.integration.dto.StartSessionRq)
     */
    //@Override
    public BISResult<StartSessionRs> startSession(final RqHeader header, final StartSessionRq request) {
        //ProductionLogger.info(this, "startSession - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithSessionTokenValidation(header, new BISCommand<StartSessionRs>() {
            @Override
            public BISResult<StartSessionRs> execute() {
                return doStartSession(header, request);
            }
        }, new StartSessionRs());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<StartSessionRs> doStartSession(RqHeader header, StartSessionRq request) {
        CustomerIdEnum idType = request.getCustomerId().getIdType();
        Ensure.notNull(request.getCustomerId(), "CustomerId");
        // *** TODO *** DON'T REQUIRE HOSTCUSTOMERID ***
        Ensure.isTrue(((idType == CustomerIdEnum.HOSTCUSTOMERID) || (idType == CustomerIdEnum.ANONYMOUS)),
                "CustomerIdEnum");
        Ensure.notNull(request.getCustomerId().getIdInfo(), "IdInfo");

        BISResult<StartSessionRs> result;

        if ((idType != CustomerIdEnum.ANONYMOUS)
                && (!converter.isCustomerIdValid(request.getCustomerId().getIdInfo()))) {
            // customer not found
            result = buildResult(header.getMsgSeqId(), null, createErrorType(BIS_NOT_FOUND,
                    "Invalid customerId", SeverityEnum.ERROR), new StartSessionRs());
        } else {
            String token = header.getAuthentication().getSessionToken();

            if (!getSessionManager().startCustomerSession(token, request.getCustomerId().getIdInfo())) {
                //ProductionLogger.info(this, "startSession - Customer session is already in progress");
                result = buildResult(header.getMsgSeqId(), null, createErrorType(BIS_SESSION_IN_PROGRESS,
                        "Customer session is already in progress", SeverityEnum.ERROR), new StartSessionRs());
            } else {
                StartSessionRs response = converter.createStartSessionResponse(request);

                if (response == null) {
                    //ProductionLogger.info(this, "startSession - Fabricated error for testing");
                    result = buildResult(header.getMsgSeqId(), null, createErrorType(BIS_SYSTEM_ERROR,
                            "Fabricated error for testing", SeverityEnum.CRITICAL), new StartSessionRs());
                } else {
                    getSessionManager().storeSessionContextValue(token, CONTEXT_KEY_ID_TYPE,
                            idType.name());
                    result = buildResult(header.getMsgSeqId(), token, null, new StartSessionRs());
                }
            }
        }

        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISCustomer#endSession(com.ncr.cxp.localassist.integration.dto.RqHeader
     * , com.ncr.cxp.localassist.integration.dto.EndSessionRq)
     */
    //@Override
    public BISResult<EndSessionRs> endSession(final RqHeader header, EndSessionRq request) {
        //ProductionLogger.info(this, "endSession - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithSessionTokenValidation(header, new BISCommand<EndSessionRs>() {
            @Override
            public BISResult<EndSessionRs> execute() {
                return doEndSession(header);
            }
        }, new EndSessionRs());
    }

    /**
     * @param header
     * @return
     */
    private BISResult<EndSessionRs> doEndSession(RqHeader header) {
        String token = header.getAuthentication().getSessionToken();

        // *** TODO *** ROLL BACK (CANCEL) NON-COMPLETED TRANSACTIONS *** ??? *** Wolf 6/25/14 ***
        getSessionManager().endCustomerSession(token);

        return buildResult(header.getMsgSeqId(), token, null, new EndSessionRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISCustomer#customerInquiry(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.CustomerInqRq)
     */
    //@Override
    public BISResult<CustomerInqRs> customerInquiry(final RqHeader header, final CustomerInqRq request) {
        //ProductionLogger.info(this, "customerInquiry - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithSessionTokenValidation(header, new BISCommand<CustomerInqRs>() {
            @Override
            public BISResult<CustomerInqRs> execute() {
                return doCustomerInquiry(header, request);
            }
        }, new CustomerInqRs());

    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<CustomerInqRs> doCustomerInquiry(RqHeader header, CustomerInqRq request) {
        Ensure.notNull(request, "CustomerInqRq");
        Ensure.notNull(request.getCustomerId(), "CustomerId");
        // *** TODO *** DON'T REQUIRE HOSTCUSTOMERID ***
        Ensure.isTrue(request.getCustomerId().getIdType() == CustomerIdEnum.HOSTCUSTOMERID, "CustomerIdEnum");
        Ensure.notNull(request.getCustomerId().getIdInfo(), "IdInfo");

        ErrorType error = null;
        CustomerInqRs response;

        response = converter.createCustomerInqResponse(request);
        if (response == null) {
            // customer not found
            response = new CustomerInqRs();
            error = createErrorType(BIS_NOT_FOUND, NOT_FOUND, SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISCustomer#customerSearch(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.CustomerSearchRq)
     */
    //@Override
    public BISResult<CustomerSearchRs> customerSearch(final RqHeader header, final CustomerSearchRq request) {
        //ProductionLogger.info(this, "customerSearch - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithSessionTokenValidation(header, new BISCommand<CustomerSearchRs>() {
            @Override
            public BISResult<CustomerSearchRs> execute() {
                return doCustomerSearch(header, request);
            }
        }, new CustomerSearchRs());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<CustomerSearchRs> doCustomerSearch(RqHeader header, CustomerSearchRq request) {
        Ensure.notNull(request, "CustomerSearchRq");
        Ensure.notNull(request.getSearchCriteria(), "SearchCriteria");
        Ensure.isFalse(request.getSearchCriteria().isEmpty(), "SearchCriteria");

        ErrorType error = null;

        CustomerSearchRs response = converter.createCustomerSearchResponse(request);
        if (response == null) {
            // account not found
            response = new CustomerSearchRs();
            error = createErrorType(BIS_NOT_FOUND, NOT_FOUND, SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISCustomer#accountInquiry(com.ncr.cxp.localassist.integration.dto
     * .RqHeader, com.ncr.cxp.localassist.integration.dto.AccountInqRq)
     */
    //@Override
    public BISResult<AccountInqRs> accountInquiry(final RqHeader header, final AccountInqRq request) {
        //ProductionLogger.info(this, "accountInquiry - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithSessionTokenValidation(header, new BISCommand<AccountInqRs>() {
            @Override
            public BISResult<AccountInqRs> execute() {
                return doAccountInquiry(header, request);
            }
        }, new AccountInqRs());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<AccountInqRs> doAccountInquiry(RqHeader header, AccountInqRq request) {
        Ensure.notNull(request, "accountInquiry");
        Ensure.notNull(request.getAccountKey(), "AccountKeies");
        Ensure.isTrue(request.getAccountKey().size() > 0., "AccountKeies");
        ErrorType error = null;
        AccountInqRs response = new AccountInqRs();

        try {
            response = converter.createAccountInqResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISCustomer#getReceipt(com.ncr.cxp.localassist.integration.dto.RqHeader
     * , com.ncr.cxp.localassist.integration.dto.GetReceiptRq)
     */
    //@Override
    public BISResult<GetReceiptRs> getReceipt(final RqHeader header, GetReceiptRq request) {
        //ProductionLogger.warn(this, "getReceipt - no implementation in product");

        return executeWithSessionTokenValidation(header, new BISCommand<GetReceiptRs>() {
            @Override
            public BISResult<GetReceiptRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new GetReceiptRs());
            }
        }, new GetReceiptRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.bis.integration.service.BISCustomer#getTransactionHistory(com.ncr.cxp.bis.integration.dto.RqHeader,
     * com.ncr.cxp.bis.integration.dto.TransactionHistoryRq)
     */
    //@Override
    public BISResult<TransactionHistoryRs> getTransactionHistory(final RqHeader header,
            final TransactionHistoryRq request) {
        //ProductionLogger.info(this, "transaction history - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithSessionTokenValidation(header, new BISCommand<TransactionHistoryRs>() {
            @Override
            public BISResult<TransactionHistoryRs> execute() {
                return doGetTransactionHistory(header, request);
            }
        }, new TransactionHistoryRs());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<TransactionHistoryRs> doGetTransactionHistory(RqHeader header, TransactionHistoryRq request) {
        ErrorType error = null;
        TransactionHistoryRs response = new TransactionHistoryRs();

        try {
            response = converter.createTransactionHistory(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }
}
