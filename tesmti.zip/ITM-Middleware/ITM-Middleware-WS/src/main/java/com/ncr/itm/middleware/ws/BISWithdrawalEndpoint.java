/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.ReverseWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.ReverseWithdrawalRsType;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISWithdrawalService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

/**
 *
 * @author naveed
 */
@Endpoint
public class BISWithdrawalEndpoint
        extends BaseEndpoint {

    private BISWithdrawalService withdrawalService;

    public BISWithdrawalService getWithdrawalService() {
        return this.withdrawalService;
    }

    @Autowired(required = false)
    public void setWithdrawalService(BISWithdrawalService withdrawalService) {
        this.withdrawalService = withdrawalService;
    }

    @Autowired
    public BISWithdrawalEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "AuthoriseWithdrawalRq")
    @ResponsePayload
    public AuthoriseWithdrawalRsType authorise(@RequestPayload AuthoriseWithdrawalRqType authoriseWithdrawalRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "authorise - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<AuthoriseWithdrawalRsType> response;
        if (this.withdrawalService == null) {
            AuthoriseWithdrawalRsType withdrawalResponse = new AuthoriseWithdrawalRsType();
            response = createNotImplementedResponse(withdrawalResponse, header);
        } else {
            response = this.withdrawalService.authoriseWithdrawal(header, authoriseWithdrawalRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "authorise - Exit");
        return (AuthoriseWithdrawalRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CompleteWithdrawalRq")
    @ResponsePayload
    public CompleteWithdrawalRsType complete(@RequestPayload CompleteWithdrawalRqType completeWithdrawalRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "complete - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<CompleteWithdrawalRsType> response;
        if (this.withdrawalService == null) {
            CompleteWithdrawalRsType withdrawalResponse = new CompleteWithdrawalRsType();
            response = createNotImplementedResponse(withdrawalResponse, header);
        } else {
            response = this.withdrawalService.completeWithdrawal(header, completeWithdrawalRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "complete - Exit");
        return (CompleteWithdrawalRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ReverseWithdrawalRq")
    @ResponsePayload
    public ReverseWithdrawalRsType reverse(@RequestPayload ReverseWithdrawalRqType reverseWithdrawalRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "reverse - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<ReverseWithdrawalRsType> response;

        if (this.withdrawalService == null) {
            ReverseWithdrawalRsType withdrawalResponse = new ReverseWithdrawalRsType();
            response = createNotImplementedResponse(withdrawalResponse, header);
        } else {
            response = this.withdrawalService.reverseWithdrawal(header, reverseWithdrawalRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "reverse - Exit");
        return (ReverseWithdrawalRsType) response.getResponse();
    }
}
