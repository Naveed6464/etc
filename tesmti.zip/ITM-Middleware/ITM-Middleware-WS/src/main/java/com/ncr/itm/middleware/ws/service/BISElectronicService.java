/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AuthoriseElectronicTxRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseElectronicTxRsType;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;

/**
 *
 * @author naveed
 */
public class BISElectronicService extends StubBISBaseServiceImpl {

    public BISElectronicService(SessionManager sessionManager) {
        super(sessionManager);
    }

    public BISResult<AuthoriseElectronicTxRsType> authoriseElectronicTx(RqHeader header, AuthoriseElectronicTxRqType authoriseElectronicTxRequest) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
