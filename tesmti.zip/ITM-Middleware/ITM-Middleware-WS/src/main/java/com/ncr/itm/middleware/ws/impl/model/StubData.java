package com.ncr.itm.middleware.ws.impl.model;

import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author ap185225
 * 
 */
public interface StubData
{

    /**
     * @param accountNumber
     * @return the accountNumber
     */
    StubAccount getAccount( String accountNumber )
            throws StubNotFoundException;

    /**
     * @param customerId
     * @return the customerId
     */
    StubCustomer getCustomer( String customerId );

    /**
     * Return a list containing account balances impacted by the transaction. Except for transfer transactions, the list
     * will only contain balances for one account. For transfer transactions the first item in the list is a list of
     * balances for source account. For transfer transactions the second item in the list is a list of balances for the
     * destination account. If the the transaction results in a negative available balance, the list value is null
     * indicating that the transaction should not be authorized.
     * 
     * @param stubTransaction
     * @return list of updated account balances for accounts impacted by authorizing the transaction
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    List<Map<String, BigDecimal>> authorizeTransaction( StubTransaction stubTransaction )
            throws StubNotFoundException, StubAccountClosedException;

    /**
     * Return a list containing account balances impacted by canceling the transaction. Except for transfer
     * transactions, the list will only contain balances for one account. For transfer transactions the first item in
     * the list is a list of balances for source account. For transfer transactions the second item in the list is a
     * list of balances for the destination account.
     * 
     * @param stubTransaction
     * @return list of updated account balances for accounts impacted by completing the transaction
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     * 
     */
    List<Map<String, BigDecimal>> cancelTransaction( StubTransaction stubTransaction )
            throws StubNotFoundException, StubAccountClosedException;

    /**
     * Update the current balance for the accounts impacted by completing the transaction.
     * 
     * @param stubTransaction
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     * 
     */
    void completeTransaction( StubTransaction stubTransaction )
            throws StubNotFoundException,
            StubAccountClosedException;

    /**
     * Update the available and current balances for the accounts impacted by reversing the transaction.
     * 
     * @param stubTransaction
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    void reverseTransaction( StubTransaction stubTransaction )
            throws StubNotFoundException,
            StubAccountClosedException;

    /**
     * Return the list of customers in searchList that match the provided name
     * 
     * @param searchList
     *            if null, search complete list
     * @param name
     *            search for customers with this name
     * @return the list of customers in searchList that match the provided name
     */
    List<StubCustomer> searchCustomersByName( List<StubCustomer> searchList, String name );

    /**
     * Return the list of customers in searchList that match the provided accountNumber
     * 
     * @param searchList
     *            if null, search complete list
     * @param accountNumber
     *            search for customers with this accountNumber
     * @return the list of customers in searchList that match the provided accountNumber
     */
    List<StubCustomer> searchCustomersByAccountNumber( List<StubCustomer> searchList, String accountNumber );

    /**
     * Return the list of customers in searchList that match the provided cardNumber
     * 
     * @param searchList
     *            if null, search complete list
     * @param cardNumber
     *            search for customers with this cardNumber
     * @return the list of customers in searchList that match the provided cardNumber
     */
    List<StubCustomer> searchCustomersByCardNumber( List<StubCustomer> searchList, String cardNumber );

    /**
     * Return the list of customers in searchList that match the provided customerId
     * 
     * @param searchList
     *            if null, search complete list
     * @param customerId
     *            search for customers with this customerId
     * @return the list of customers in searchList that match the provided customerId
     */
    List<StubCustomer> searchCustomersByCustomerId( List<StubCustomer> searchList, String customerId );

    /**
     * Return the list of customers in searchList that match the provided phoneNumber
     * 
     * @param searchList
     *            if null, search complete list
     * @param phoneNumber
     *            search for customers with this phoneNumber
     * @return the list of customers in searchList that match the provided phoneNumber
     */
    List<StubCustomer> searchCustomersByPhoneNumber( List<StubCustomer> searchList, String phoneNumber );

    /**
     * Return the list of customers in searchList that match the provided ssn
     * 
     * @param searchList
     *            if null, search complete list
     * @param ssn
     *            search for customers with this ssn
     * @return the list of customers in searchList that match the provided ssn
     */
    List<StubCustomer> searchCustomersBySsn( List<StubCustomer> searchList, String ssn );

    /**
     * @param accountNumber
     * @return
     */
    String getLastTransDate( String accountNumber );
}
