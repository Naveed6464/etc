/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

/**
 *
 * @author naveed
 */
import com.ncr.cxp.branch.integration.schema.AccountInqRq;
import com.ncr.cxp.branch.integration.schema.AccountInqRs;
import com.ncr.cxp.branch.integration.schema.CustomerInqRq;
import com.ncr.cxp.branch.integration.schema.CustomerInqRs;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRq;
import com.ncr.cxp.branch.integration.schema.CustomerSearchRs;
import com.ncr.cxp.branch.integration.schema.EndSessionRq;
import com.ncr.cxp.branch.integration.schema.EndSessionRs;
import com.ncr.cxp.branch.integration.schema.GetReceiptRq;
import com.ncr.cxp.branch.integration.schema.GetReceiptRs;
import com.ncr.cxp.branch.integration.schema.StartSessionRq;
import com.ncr.cxp.branch.integration.schema.StartSessionRs;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRq;
import com.ncr.cxp.branch.integration.schema.TransactionHistoryRs;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISCustomerService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

@Endpoint
public class BISCustomerEndpoint
        extends BaseEndpoint {

    private BISCustomerService service;

    @Autowired
    public BISCustomerEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    public BISCustomerService getCustomerService() {
        return this.service;
    }

    @Autowired(required = false)
    public void setCustomerService(BISCustomerService customerService) {
        this.service = customerService;
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "StartSessionRq")
    @ResponsePayload
    public StartSessionRs startSession(@RequestPayload StartSessionRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "startSession - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<StartSessionRs> response;
        if (this.service == null) {
            StartSessionRs startSessionResponse = new StartSessionRs();
            response = createNotImplementedResponse(startSessionResponse, header);
        } else {
            response = this.service.startSession(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "startSession - Exit");
        return (StartSessionRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "EndSessionRq")
    @ResponsePayload
    public EndSessionRs endSession(@RequestPayload EndSessionRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "endSession - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<EndSessionRs> response;

        if (this.service == null) {
            EndSessionRs endSessionResponse = new EndSessionRs();
            response = createNotImplementedResponse(endSessionResponse, header);
        } else {
            response = this.service.endSession(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "endSession - Exit");
        return (EndSessionRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "AccountInqRq")
    @ResponsePayload
    public AccountInqRs accountInquiry(@RequestPayload AccountInqRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "accountInquiry - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<AccountInqRs> response;

        if (this.service == null) {
            AccountInqRs accountInqResponse = new AccountInqRs();
            response = createNotImplementedResponse(accountInqResponse, header);
        } else {
            response = this.service.accountInquiry(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "accountInquiry - Exit");
        return (AccountInqRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CustomerInqRq")
    @ResponsePayload
    public CustomerInqRs customerInquiry(@RequestPayload CustomerInqRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "customerInquiry - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CustomerInqRs> response;
        if (this.service == null) {
            CustomerInqRs customerInqResponse = new CustomerInqRs();
            response = createNotImplementedResponse(customerInqResponse, header);
        } else {
            response = this.service.customerInquiry(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "customerInquiry - Exit");
        return (CustomerInqRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CustomerSearchRq")
    @ResponsePayload
    public CustomerSearchRs customerSearch(@RequestPayload CustomerSearchRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "customerSearch - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CustomerSearchRs> response;
        if (this.service == null) {
            CustomerSearchRs customerSearchResponse = new CustomerSearchRs();
            response = createNotImplementedResponse(customerSearchResponse, header);
        } else {
            response = this.service.customerSearch(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "customerSearch - Exit");
        return (CustomerSearchRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "GetReceiptRq")
    @ResponsePayload
    public GetReceiptRs getReceipt(@RequestPayload GetReceiptRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "getReceipt - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<GetReceiptRs> response;
        if (this.service == null) {
            GetReceiptRs getReceiptResponse = new GetReceiptRs();
            response = createNotImplementedResponse(getReceiptResponse, header);
        } else {
            response = this.service.getReceipt(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "getReceipt - Exit");
        return (GetReceiptRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "TransactionHistoryRq")
    @ResponsePayload
    public TransactionHistoryRs getTransactionHistory(@RequestPayload TransactionHistoryRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "transactionHistoryRequest - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<TransactionHistoryRs> response;
        if (this.service == null) {
            TransactionHistoryRs getTransactionHistoryResponse = new TransactionHistoryRs();
            response = createNotImplementedResponse(getTransactionHistoryResponse, header);
        } else {
            response = this.service.getTransactionHistory(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "transactionHistoryRequest - Exit");
        return (TransactionHistoryRs) response.getResponse();
    }
}
