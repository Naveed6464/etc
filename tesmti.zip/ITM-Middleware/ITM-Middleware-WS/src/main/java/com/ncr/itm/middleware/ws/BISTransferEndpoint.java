/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.AuthoriseTransferRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseTransferRsType;
import com.ncr.cxp.branch.integration.schema.CompleteTransferRqType;
import com.ncr.cxp.branch.integration.schema.CompleteTransferRsType;
import com.ncr.cxp.branch.integration.schema.ReverseTransferRqType;
import com.ncr.cxp.branch.integration.schema.ReverseTransferRsType;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISTransferService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

/**
 *
 * @author naveed
 */
@Endpoint
public class BISTransferEndpoint
        extends BaseEndpoint {

    private BISTransferService transferService;

    public BISTransferService getTransferService() {
        return this.transferService;
    }

    @Autowired(required = false)
    public void setTransferService(BISTransferService transferService) {
        this.transferService = transferService;
    }

    @Autowired
    public BISTransferEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "AuthoriseTransferRq")
    @ResponsePayload
    public AuthoriseTransferRsType authorise(@RequestPayload AuthoriseTransferRqType authoriseTransferRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "authorise - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<AuthoriseTransferRsType> response;
        if (this.transferService == null) {
            AuthoriseTransferRsType transferResponse = new AuthoriseTransferRsType();
            response = createNotImplementedResponse(transferResponse, header);
        } else {
            response = this.transferService.authoriseTransfer(header, authoriseTransferRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "authorise - Exit");
        return (AuthoriseTransferRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CompleteTransferRq")
    @ResponsePayload
    public CompleteTransferRsType complete(@RequestPayload CompleteTransferRqType completeTransferRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "complete - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);        
        BISResult<CompleteTransferRsType> response;
        if (this.transferService == null) {
            CompleteTransferRsType transferResponse = new CompleteTransferRsType();
            response = createNotImplementedResponse(transferResponse, header);
        } else {
            response = this.transferService.completeTransfer(header, completeTransferRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "complete - Exit");
        return (CompleteTransferRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ReverseTransferRq")
    @ResponsePayload
    public ReverseTransferRsType reverse(@RequestPayload ReverseTransferRqType reverseTransferRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "reverse - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        
        BISResult<ReverseTransferRsType> response;
        if (this.transferService == null) {
            ReverseTransferRsType transferResponse = new ReverseTransferRsType();
            response = createNotImplementedResponse(transferResponse, header);
        } else {
            response = this.transferService.reverseTransfer(header, reverseTransferRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "reverse - Exit");
        return (ReverseTransferRsType) response.getResponse();
    }
}
