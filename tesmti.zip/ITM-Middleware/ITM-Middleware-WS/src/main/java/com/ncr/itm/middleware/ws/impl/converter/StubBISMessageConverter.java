package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.AmountType;
import com.ncr.cxp.branch.integration.schema.BalanceType;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubDataImpl;
import com.ncr.itm.middleware.ws.util.DefaultSystemClock;
import com.ncr.itm.middleware.ws.util.SystemClock;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

// see com.ncr.cxp.localassist.integration.service.impl.converter.BISMessageConverter
/**
 * Base class for all StubBIS Message Converters
 *
 * @author ap185225
 */
public abstract class StubBISMessageConverter {

    /**
     * stub implementation assumes currency is "USD"; does not validate
     */
    public static final String STUB_CURRENCY = "USD";

    final SystemClock clock;
    final DatatypeFactory datatypeFactory;
    final StubData stubData;

    /**
     * Constructs an instance of this class.
     *
     * @param stubData
     */
    public StubBISMessageConverter(StubData stubData) {
        this.stubData = stubData;
        this.clock = new DefaultSystemClock();

        try {
            this.datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            //ProductionLogger.warn( this, "Failed to get a DatatypeFactory", e );
            throw new BISIntegrationException("Failed to get a DatatypeFactory", e);
        }
    }

    /**
     * @param currency
     * @param amount
     * @return {@link AmountType}
     */
    static AmountType convertAmount(String currency, BigDecimal amount) {
        AmountType amountType = new AmountType();
        amountType.setCurrency(currency);
        amountType.setValue(amount);

        return amountType;
    }

    /**
     * create BalanceType from account information
     *
     * @param type
     * @param currency
     * @param balance
     * @param lastTransDate
     * @return {@link BalanceType}
     */
    BalanceType convertBalance(String type, String currency, BigDecimal balance, String lastTransDate) {
        BalanceType balanceType = new BalanceType();
        balanceType.setAmount(convertAmount(currency, balance));
        balanceType.setAsOfDate(convertDate(lastTransDate));
        balanceType.setType(type);

        return balanceType;
    }

    /**
     *
     * @param dateStr
     * @return date without time elements
     */
    XMLGregorianCalendar convertDate(String dateStr) {
        return convertDate(dateStr, StubDataImpl.DATE_FORMAT_PATTERN);
    }

    /**
     * @param dateStr
     * @return date without time elements
     */
    XMLGregorianCalendar convertShortDate(String dateStr) {
        return convertDate(dateStr, StubDataImpl.DELIMITED_DATE_FORMAT_PATTERN);
    }

    /**
     * @param dateStr
     * @return date with time elements
     */
    XMLGregorianCalendar convertDateTime(String dateStr) {
        return convertDateTime(dateStr, StubDataImpl.DATE_FORMAT_PATTERN);
    }

    /**
     * @param dateStr
     * @param formatPattern
     * @return date without time elements
     */
    private XMLGregorianCalendar convertDate(String dateStr, String formatPattern) {
        XMLGregorianCalendar xmlGCal = convertDateTime(dateStr, formatPattern);

        // Ignore the time parts
        xmlGCal.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
                DatatypeConstants.FIELD_UNDEFINED);
        // Ignore the timezone part
        // xmlGCal.setTimezone( DatatypeConstants.FIELD_UNDEFINED ); // NOSONAR

        return xmlGCal;
    }

    /**
     * @param dateStr
     * @param formatPattern
     * @return date with time elements
     */
    private XMLGregorianCalendar convertDateTime(String dateStr, String formatPattern) {
        GregorianCalendar gcal = new GregorianCalendar();
        final SimpleDateFormat dateFormat = new SimpleDateFormat(formatPattern);

        try {
            if ((dateStr == null) || (dateStr.equals("--------"))) {
                gcal.setTimeInMillis(clock.getCurrentTimeMillis());
            } else {
                gcal.setTime(dateFormat.parse(dateStr));
            }
        } catch (ParseException e) {
            //ProductionLogger.warn( this, "invalid date: " + dateStr, e );
            gcal.setTimeInMillis(clock.getCurrentTimeMillis());
        }

        return datatypeFactory.newXMLGregorianCalendar(gcal);
    }

    /**
     * @return the stubData
     */
    StubData getStubData() {
        return stubData;
    }

}
