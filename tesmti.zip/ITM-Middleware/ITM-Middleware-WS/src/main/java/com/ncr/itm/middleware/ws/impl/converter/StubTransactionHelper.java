/**
 *
 */
package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.BalanceType;
import com.ncr.cxp.branch.integration.schema.CashInItemType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRqType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRsType;
import com.ncr.cxp.branch.integration.schema.DepositRsItemsType;
import com.ncr.cxp.branch.integration.schema.FeeType;
import com.ncr.cxp.branch.integration.schema.OverrideInfoType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author ap185225
 *
 */
public interface StubTransactionHelper {

    /**
     * @return
     */
    BigDecimal getAmount();

    /**
     * @return
     */
    BigDecimal getCashBack();

    /**
     * @return
     */
    List<CashInItemType> getCashInItems();

    /**
     * @return
     */
    List<DepositRsItemsType.CashInItem> getCashRsItems();

    /**
     * @return
     */
    List<ChequeItemRqType> getChequeRqItems();

    /**
     * @return
     */
    List<ChequeItemRsType> getChequeRsItems();

    /**
     * @return
     */
    String getDestinationAccountNumber();

    /**
     * @return
     */
    OverrideInfoType getOverrideInfo();

    /**
     * @return
     */
    List<FeeType> getRequestFees();

    /**
     * @return
     */
    List<BalanceType> getResponseBalances();

    /**
     * @return
     */
    List<FeeType> getResponseFees();

    /**
     * @return
     */
    List<BalanceType> getResponseToBalances();

    /**
     * @return
     */
    String getSourceAccountNumber();

    /**
     * @return
     */
    StubTransactionSubType getTransactionSubType();

    /**
     * @return
     */
    StubTransactionType getTransactionType();

    /**
     * @return
     */
    boolean isNonMember();

}
