/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

/**
 *
 * @author naveed
 */
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.entities.RsHeader;
import java.io.IOException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;

public class BISClient {

    private final TransformerFactory transformerFactory;
    private final DatatypeFactory datatypeFactory;
    protected static final String BIS_NOT_IMPLEMENTED = "BIS_NOT_IMPLEMENTED";
    protected static final String BIS_ALREADY_SIGNED_ON = "BIS_ALREADY_SIGNED_ON";
    protected static final String BIS_SESSION_IN_PROGRESS = "BIS_SESSION_IN_PROGRESS";
    private final WebServiceTemplate webServiceTemplate = new WebServiceTemplate();

    public BISClient(String uri, Jaxb2Marshaller marshaller) {
        this.webServiceTemplate.setDefaultUri(uri);
        this.webServiceTemplate.setMarshaller(marshaller);
        this.webServiceTemplate.setUnmarshaller(marshaller);

        this.transformerFactory = TransformerFactory.newInstance();
        try {
            this.datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException("Failed to get a DatatypeFactory", e);
        }
    }

    /*public <TResponse, TRequest> BISResult<TResponse> sendAndReceiveMessage(Class<TResponse> clazz, TRequest request, final RqHeader.Authentication authentication) {
        final RsHeader rsHeader = new RsHeader();

        Object result = marshalSendAndReceiveWithResponseCallback(request, new WebServiceMessageCallback()
    
      new WebServiceMessageCallback
        {
        

    

    

    public void doWithMessage(WebServiceMessage message)
            throws IOException, TransformerException {
        BISClient.this.writeSoapHeader((SoapMessage) message, authentication);
    }
}
, new WebServiceMessageCallback()
      {
        public void doWithMessage(WebServiceMessage message)
          throws IOException, TransformerException
        {
          SoapMessage soapMessage = (SoapMessage)message;
          RsHeader extractedHeader = BISClient.this.extractHeader(soapMessage.getSoapHeader());
          if (extractedHeader != null)
          {
            rsHeader.setError(extractedHeader.getError());
            rsHeader.setMsgSeqId(extractedHeader.getMsgSeqId());
            rsHeader.setSessionToken(extractedHeader.getSessionToken());
            rsHeader.setSessionState(extractedHeader.getSessionState());
          }
        }
      });
    TResponse finalResult = (TResponse)result;
    
    return new BISResult(rsHeader, finalResult);
  }
  
  private Object marshalSendAndReceiveWithResponseCallback(final Object requestPayload, final WebServiceMessageCallback requestCallback, final WebServiceMessageCallback responseCallback)
  {
    this.webServiceTemplate.sendAndReceive(new WebServiceMessageCallback()
    
      new WebServiceMessageExtractor
      {
        public void doWithMessage(WebServiceMessage request)
          throws IOException, TransformerException
        {
          if (requestPayload != null)
          {
            org.springframework.oxm.Marshaller marshaller = BISClient.this.webServiceTemplate.getMarshaller();
            if (marshaller == null) {
              throw new TransformerException("No marshaller registered.");
            }
            MarshallingUtils.marshal(marshaller, requestPayload, request);
          }
          requestCallback.doWithMessage(request);
        }
      }, new WebServiceMessageExtractor()
      {
        public Object extractData(WebServiceMessage response)
          throws IOException, TransformerException
        {
          responseCallback.doWithMessage(response);
          
          org.springframework.oxm.Unmarshaller unmarshaller = BISClient.this.webServiceTemplate.getUnmarshaller();
          if (unmarshaller == null) {
            throw new TransformerException("No unmarshaller registered.");
          }
          return MarshallingUtils.unmarshal(unmarshaller, response);
        }
      });
  }
  
  private void writeSoapHeader(SoapMessage message, RqHeader.Authentication authentication)
    throws TransformerException
  {
    RqHeader rqHeader = new RqHeader();
    rqHeader.setMsgSeqId(createAndGetUniqueMessageId());
    rqHeader.setTimeStamp(getCurrentTimeStamp());
    rqHeader.setAuthentication(authentication);
    String serializedHeader = marshall(rqHeader);
    
    Transformer transformer = this.transformerFactory.newTransformer();
    transformer.transform(new StringSource(serializedHeader), message.getSoapHeader().getResult());
  }
  
  private RsHeader extractHeader(SoapHeader soapHeader)
  {
    RsHeader rsHeader = null;
    
    Iterator<SoapHeaderElement> iter = soapHeader.examineAllHeaderElements();
    while (iter.hasNext())
    {
      SoapHeaderElement element = (SoapHeaderElement)iter.next();
      





if (element.getName().getLocalPart().equalsIgnoreCase("RsHeader")) {
        try
        {
          JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { RsHeader.class 


});
          javax.xml.bind.Unmarshaller u = jaxbContext.createUnmarshaller();
          
          u.setEventHandler(new ValidationEventHandler()
          {
            public boolean handleEvent(ValidationEvent event)
            {
              throw new RuntimeException(event.getMessage(), event.getLinkedException());
            }
          });
          Node node = ((DOMSource)element.getSource()).getNode();
          
          rsHeader = (RsHeader)u.unmarshal(node);
        }
        catch (JAXBException e)
        {
          throw new RuntimeException("Failure unmarshalling RsHeader: ", e);
        }
      }
    }
    return rsHeader;
  }
  
  private String createAndGetUniqueMessageId()
  {
    return UUID.randomUUID().toString();
  }
  
  private <T> String marshall(T payload)
  {
    try
    {
      StringWriter stringWriter = new StringWriter();
      
      JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { payload.getClass() });
      javax.xml.bind.Marshaller m = jaxbContext.createMarshaller();
      m.setProperty("jaxb.fragment", Boolean.TRUE);
      m.marshal(payload, stringWriter);
      
      return stringWriter.toString();
    }
    catch (JAXBException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  private XMLGregorianCalendar getCurrentTimeStamp()
  {
    GregorianCalendar gcal = new GregorianCalendar();
    gcal.setTimeInMillis(System.currentTimeMillis());
    return this.datatypeFactory.newXMLGregorianCalendar(gcal);
  }*/
}
