/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.entities;

/**
 *
 * @author naveed
 */
public class BISResult<T> {

    private final T response;
    private final RsHeader header;

    public BISResult(RsHeader header, T response) {
        this.response = response;
        this.header = header;
    }

    public T getResponse() {
        return (T) this.response;
    }

    public RsHeader getHeader() {
        return this.header;
    }
}
