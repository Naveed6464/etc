package com.ncr.itm.middleware.ws;

import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.context.SessionManagerImpl;
import java.net.MalformedURLException;
import java.net.URL;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author nmrehman
 */
@SpringBootApplication
@Configuration
@ComponentScan({"com.ncr.itm.middleware.ws", "com.ncr.itm.middleware.ws.service", "com.ncr.itm.middleware.ws.impl.converter", "com.ncr.itm.middleware.ws.impl.model"})
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public SessionManager method() {
        return new SessionManagerImpl();
    }

    @Bean
    public URL configUrl() throws MalformedURLException {
        return new URL("classpath:StubBISConfiguration.xml");
    }

}
