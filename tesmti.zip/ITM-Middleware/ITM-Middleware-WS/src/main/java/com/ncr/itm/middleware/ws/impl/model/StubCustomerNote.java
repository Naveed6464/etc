package com.ncr.itm.middleware.ws.impl.model;

/**
 * @author ap185225
 * 
 */
public final class StubCustomerNote
{
    private final String comment;
    private final String effectiveDate;
    private final String header;
    private final String otherData;
    private final String type; // 1 == note, 2 == warning

    /**
     * @param comment
     * @param effectiveDate
     * @param type
     * @param otherData
     */
    public StubCustomerNote( String comment, String effectiveDate, String header, String type, String otherData )
    {
        this.comment = comment;
        this.effectiveDate = effectiveDate;
        this.type = type;
        this.header = header;
        this.otherData = otherData;
    }

    /**
     * @return the comment
     */
    public String getComment()
    {
        return comment;
    }

    /**
     * @return the effectiveDate
     */
    public String getEffectiveDate()
    {
        return effectiveDate;
    }

    /**
     * @return the header
     */
    public String getHeader()
    {
        return header;
    }

    /**
     * @return the otherData
     */
    public String getOtherData()
    {
        return otherData;
    }

    /**
     * @return the type
     */
    public String getType()
    {
        return type;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "StubCustomerNote [comment=" + comment + ", effectiveDate=" + effectiveDate + ", header=" + header
                + ", type=" + type + "]";
    }

}
