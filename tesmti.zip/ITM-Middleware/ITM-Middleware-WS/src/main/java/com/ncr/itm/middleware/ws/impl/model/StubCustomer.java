package com.ncr.itm.middleware.ws.impl.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author ap185225
 * 
 *         class would be immutable if not for need for accounts can to be modified
 * 
 */
public final class StubCustomer
{
    private final String id;
    private final StubName name;
    private final String birthdate;
    private final String street;
    private final String city;
    private final String state;
    private final String zipcode;
    private final String homePhone;
    private final String relationshipCode;
    private final String ssn;
    private final List<StubJointCustomer> jointCustomers;
    private final List<StubCustomerNote> customerNotes;
    private final List<StubAccount> accounts;

    /**
     * Creates StubCustomer from parameters
     * 
     * @param id
     * @param fullName
     * @param birthdate
     * @param city
     * @param homePhone
     * @param relationshipCode
     * @param ssn
     * @param state
     * @param street
     * @param zipcode
     * @param jointCustomers
     * @param customerNotes
     * @param accounts
     */
    public StubCustomer( String id, String fullName, String birthdate, String city,
            String homePhone, String relationshipCode, String ssn, String state, String street,
            String zipcode, List<StubJointCustomer> jointCustomers, List<StubCustomerNote> customerNotes,
            List<StubAccount> accounts )
    {
        this.birthdate = birthdate;
        this.city = city;
        this.name = new StubName( fullName );
        this.homePhone = homePhone;
        this.id = id;
        this.relationshipCode = relationshipCode;
        this.ssn = ssn;
        this.state = state;
        this.street = street;
        this.zipcode = zipcode;

        // create copies of input lists
        this.jointCustomers = Collections.unmodifiableList( new ArrayList<>( jointCustomers ) );
        this.customerNotes = Collections.unmodifiableList( new ArrayList<>( customerNotes ) );
        List<StubAccount> tmpAccounts = new ArrayList<>( accounts.size() ); // accounts can be modified
        for( StubAccount account : accounts )
        {
            // create copy of input account
            tmpAccounts.add( new StubAccount( account ) );
        }
        this.accounts = Collections.unmodifiableList( tmpAccounts );
    }

    /**
     * @return the custeomer's birthdate
     */
    public String getBirthdate()
    {
        return birthdate;
    }

    /**
     * @return the city
     */
    public String getCity()
    {
        return city;
    }

    /**
     * @return the homePhone
     */
    public String getHomePhone()
    {
        return homePhone;
    }

    /**
     * @return the customer id
     */
    public String getId()
    {
        return id;
    }

    /**
     * @return the name
     */
    public StubName getName()
    {
        return name;
    }

    /**
     * @return the relationshipCode
     */
    public String getRelationshipCode()
    {
        return relationshipCode;
    }

    /**
     * @return the ssn
     */
    public String getSsn()
    {
        return ssn;
    }

    /**
     * @return the state
     */
    public String getState()
    {
        return state;
    }

    /**
     * @return the street
     */
    public String getStreet()
    {
        return street;
    }

    /**
     * @return the zipcode
     */
    public String getZipcode()
    {
        return zipcode;
    }

    /**
     * @return list of joint customers
     */
    public List<StubJointCustomer> getJointCustomers()
    {
        return Collections.unmodifiableList( new ArrayList<>( jointCustomers ) );
    }

    /**
     * @return list of customer Notes
     */
    public List<StubCustomerNote> getCustomerNotes()
    {
        return Collections.unmodifiableList( new ArrayList<>( customerNotes ) );
    }

    /**
     * Return the list of accounts owned by customer; a copy of each account is made
     * 
     * @return list of customer accounts
     */
    public List<StubAccount> getAccounts()
    {
        List<StubAccount> tmpAccounts = new ArrayList<>( accounts.size() );
        for( StubAccount account : accounts )
        {
            // create copy of account to add to list that will be returned
            tmpAccounts.add( new StubAccount( account ) );
        }

        return Collections.unmodifiableList( tmpAccounts );
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return "StubCustomer [id=" + id + ", name=" + name + ", birthdate=" + birthdate + ", street=" + street
                + ", city=" + city + ", state=" + state + ", zipcode=" + zipcode + ", homePhone=" + homePhone
                + ", relationshipCode=" + relationshipCode + ", ssn=" + ssn + ", jointCustomers=" + jointCustomers
                + ", customerNotes=" + customerNotes + ", accounts=" + accounts + "]";
    }

}
