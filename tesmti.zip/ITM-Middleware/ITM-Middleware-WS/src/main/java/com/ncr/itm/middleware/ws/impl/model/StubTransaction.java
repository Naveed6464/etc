package com.ncr.itm.middleware.ws.impl.model;

import java.math.BigDecimal;

/**
 * @author ap185225
 *
 */
public class StubTransaction {

    /**
     * Transaction types handled by stub
     */
    public enum StubTransactionType {
        DEPOSIT,
        TRANSFER,
        WITHDRAWAL,
        PAYMENT,
        ELECTRONIC,
    }

    /**
     * Transaction sub types
     *
     */
    public enum StubTransactionSubType {
        CASH_CHEQUE,
        PRINT_CHEQUE,
        SCAN
    }

    /**
     * Internal transaction states
     */
    public enum StubTransactionState {
        NOT_STARTED,
        AUTHORIZED,
        DENIED,
        TELLER_OVERRIDE,
        CUSTOMER_VALIDATION,
        // APPROVE_FEES ???
        COMPLETED,
        INSUFFICIENT_FUNDS,
        // for TE testing; set when "magic" numbers are used for transaction amounts
        DENIED_FOR_TESTING,
        EXCEPTION_FOR_TESTING,
        BIS_NOT_FOUND_FOR_TESTING,
    }

    // these are used to facilitate Teller Enterprise testing
    // more constants defined in com.ncr.cxp.ait.stub.integration.impl.converter.StubBISAuthorizeConverter
    static final BigDecimal DENIED_LOW_AMOUNT = new BigDecimal("666.00");
    static final BigDecimal DENIED_HIGH_AMOUNT = new BigDecimal("666.99");
    static final BigDecimal DENIED_ADJUSTED_AMOUNT = new BigDecimal("6.66"); // cash deposit 200.00, cash back 193.34
    static final BigDecimal EXCEPTION_AMOUNT = new BigDecimal("667.00");
    static final BigDecimal EXCEPTION_ADJUSTED_AMOUNT = new BigDecimal("6.67"); // cash deposit 200, cash back 193.33
    static final BigDecimal NOT_FOUND_AMOUNT = new BigDecimal("668.00");
    static final BigDecimal NOT_FOUND_ADJUSTED_AMOUNT = new BigDecimal("6.68"); // cash deposit 200, cash back 193.32
    static final BigDecimal TELLER_OVERRIDE_AMOUNT = new BigDecimal("669.00");
    static final BigDecimal TELLER_OVERRIDE_ADJUSTED_AMOUNT = new BigDecimal("6.69"); // cash deposit 200, cash back
    // 193.31
    public static final BigDecimal TELLER_OVERRIDE_VALIDATE_REASON_ON_COMPLETE_AMOUNT = new BigDecimal("670.00");
    public static final BigDecimal TELLER_OVERRIDE_VALIDATE_REASON_ON_COMPLETE_ADJUSTED_AMOUNT = new BigDecimal("6.70");
    public static final BigDecimal AUTHORIZE_DELAY_MAX_AMOUNT = new BigDecimal("0.99");
    public static final BigDecimal NULL_BALANCE_AMOUNT = new BigDecimal("499.00");

    // magic numbers for Complete requests
    public static final BigDecimal COMPLETE_DENIED_AMOUNT = new BigDecimal("766.00");
    public static final BigDecimal COMPLETE_DENIED_ADJUSTED_AMOUNT = new BigDecimal("7.66");
    public static final BigDecimal COMPLETE_TELLER_OVERRIDE_AMOUNT = new BigDecimal("769.00");
    public static final BigDecimal COMPLETE_TELLER_OVERRIDE_ADJUSTED_AMOUNT = new BigDecimal("7.69");

    private final BigDecimal adjustmentAmount; // used to adjust account balances
    private final BigDecimal cashBackAmount;
    private final String destinationAccountNumber; // only for transfers
    private final BigDecimal feeAmount;
    private final BigDecimal holdAmount;
    private final boolean hasOverrideReason;
    private final boolean newFeeAdded;
    private final boolean nonMember;
    private final String overrideReason;
    private final BigDecimal requestAmount;
    private final String sourceAccountNumber;
    private StubTransactionState state;
    private final StubTransactionSubType subType;
    private final long timestamp;
    private final String token;
    private final String transactionId;
    private final StubTransactionType type;

    /**
     * Creates StubTransaction state == StubTransactionState.NOT_STARTED
     *
     * @param transactionId
     * @param type
     * @param subType
     * @param srcAccountNumber
     * @param dstAccountNumber
     * @param requestAmount
     * @param cashBackAmount
     * @param feeAmount total of non-waived fees
     * @param holdAmount
     * @param token
     * @param newFeeAdded non-waived fees were added, even if amount of fee is
     * 0.00
     * @param nonMember
     */
    public StubTransaction(String transactionId, StubTransactionType type, StubTransactionSubType subType,
            String srcAccountNumber, String dstAccountNumber,
            BigDecimal requestAmount, BigDecimal cashBackAmount, BigDecimal feeAmount, BigDecimal holdAmount,
            String token, boolean newFeeAdded, boolean nonMember, String overrideReason) {
        this.transactionId = transactionId;
        this.type = type;
        this.subType = subType;
        this.sourceAccountNumber = srcAccountNumber;
        this.destinationAccountNumber = dstAccountNumber;
        this.state = StubTransactionState.NOT_STARTED;
        this.cashBackAmount = cashBackAmount;
        this.feeAmount = feeAmount;
        this.holdAmount = holdAmount;
        this.requestAmount = requestAmount;
        this.timestamp = System.currentTimeMillis();
        this.token = token;
        this.newFeeAdded = newFeeAdded;
        this.nonMember = nonMember;
        this.overrideReason = overrideReason;
        this.hasOverrideReason = (overrideReason != null);

        // do not adjust for fees on new authorization --
        // validation for cashCheque will fail in calculateAdjustmentAmount()
        // and balances won't be adjusted anyway if fees are added
        // client must make adjustment to cash back amount for fees on re-authorize request
        this.adjustmentAmount = calculateAdjustmentAmount(type, subType, requestAmount, cashBackAmount,
                (newFeeAdded ? BigDecimal.ZERO : feeAmount),
                holdAmount);

        // destinationAccountNumber only used for transfers
        assert ((destinationAccountNumber == null) || (type == StubTransactionType.TRANSFER));
        assert (feeAmount != null);
        //ProductionLogger.info( this, createLogStr() );
    }

    /**
     * Calculate the amount by which the available balance will be adjusted for
     * this transaction
     *
     * @param tranType
     * @param tranSubType
     * @param tranAmount
     * @param cashBack
     * @param fee
     * @param hold
     * @return
     */
    private BigDecimal calculateAdjustmentAmount(StubTransactionType tranType, StubTransactionSubType tranSubType,
            BigDecimal tranAmount, BigDecimal cashBack, BigDecimal fee, BigDecimal hold) {
        BigDecimal amount;

        switch (tranType) {
            case DEPOSIT:
                // reduce request amount by which available balance is modified:
                // subtract cash back, fees (re-authorize only) and holds
                amount = tranAmount.subtract(cashBack).subtract(fee).subtract(hold);

                // for cashCheque, adjusted amount must == 0; cash back == request amount - (fees + holds)
                if (((tranSubType == StubTransactionSubType.CASH_CHEQUE) || ((tranSubType == StubTransactionSubType.SCAN) && (nonMember)))
                        && (amount.compareTo(BigDecimal.ZERO) != 0)) {
                    //ProductionLogger.warn( this,"deposit amount minus (cash back and fees) should be 0.00, but is "+ amount );
                    throw new IllegalArgumentException("deposit amount minus (cash back and fees) should be 0.00, but is " + amount);
                }
                break;

            case TRANSFER:
                // increase amount withdrawn from source account
                amount = tranAmount.add(fee).negate();
                break;

            case WITHDRAWAL:
                // increase amount withdrawn from account
                amount = tranAmount.add(fee).negate();
                break;

            default:
                amount = tranAmount;
        }

        return amount;
    }

    private String createLogStr() {
        final int bufSize = 250;

        StringBuilder buf = new StringBuilder(bufSize);
        buf.append(this.newFeeAdded ? "new " : "");
        buf.append(this.nonMember ? "non member " : "");
        buf.append(this.type);
        buf.append((this.subType != null) ? (" (" + subType + ")") : "");
        buf.append(" transaction: ");
        buf.append(this.transactionId);
        buf.append("; state: ");
        buf.append(this.state);
        buf.append("; amount: ");
        buf.append(this.requestAmount);
        buf.append("; hold amount: ");
        buf.append(this.holdAmount);
        buf.append("; cash back amount: ");
        buf.append(this.cashBackAmount);
        buf.append("; fee amount: ");
        buf.append(this.feeAmount);

        return buf.toString();
    }

    /**
     * @return the adjustmentAmount
     */
    public BigDecimal getAdjustmentAmount() {
        return adjustmentAmount;
    }

    /**
     * @return the destinationAccountNumber
     */
    public String getDestinationAccountNumber() {
        return destinationAccountNumber;
    }

    /**
     * @return the feeAmount
     */
    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    /**
     * @return the holdAmount
     */
    public BigDecimal getHoldAmount() {
        return holdAmount;
    }

    /**
     * @return the overrideReason
     */
    public String getOverrideReason() {
        return overrideReason;
    }

    /**
     * @return the requestAmount
     */
    public BigDecimal getRequestAmount() {
        return requestAmount;
    }

    /**
     * @return the sourceAccountNumber
     */
    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    /**
     * @return the state
     */
    public StubTransactionState getState() {
        return state;
    }

    /**
     * @return the subType
     */
    public StubTransactionSubType getSubType() {
        return subType;
    }

    /**
     * @return the timestamp
     */
    public long getTimestamp() {
        return timestamp;
    }

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @return the transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * @return the type
     */
    public StubTransactionType getType() {
        return type;
    }

    /**
     * @return the hasOverrideReason
     */
    public boolean hasOverrideReason() {
        return hasOverrideReason;
    }

    /**
     * kludge for forcing transactions to be denied; for testing return non null
     * if either amount is special number or in special range will cause
     * transaction to be denied
     *
     * @param stubTransaction
     */
    public boolean isDeniedForTesting() {
        boolean retVal = false;
        StubTransactionState localState = null;
        BigDecimal amount = getRequestAmount();

        if ((amount.compareTo(EXCEPTION_AMOUNT) == 0)
                || (getAdjustmentAmount().compareTo(EXCEPTION_ADJUSTED_AMOUNT) == 0)) {
            localState = StubTransactionState.EXCEPTION_FOR_TESTING;
        } else if ((amount.compareTo(NOT_FOUND_AMOUNT) == 0)
                || (getAdjustmentAmount().compareTo(NOT_FOUND_ADJUSTED_AMOUNT) == 0)) {
            localState = StubTransactionState.BIS_NOT_FOUND_FOR_TESTING;
        } else if (((amount.compareTo(DENIED_LOW_AMOUNT) >= 0)
                && (amount.compareTo(DENIED_HIGH_AMOUNT) <= 0))
                || (getAdjustmentAmount().compareTo(DENIED_ADJUSTED_AMOUNT) == 0)) {
            localState = StubTransactionState.DENIED_FOR_TESTING;
        }

        if (localState != null) {
            // denied for testing
            setState(localState);
            retVal = true;
        }
        assert ((localState == null) || StubTransaction.isStateAddedForTesting(localState)) : localState.toString(); // NOSONAR

        return retVal;
    }

    /**
     * @return the nonMember
     */
    public boolean isNonMember() {
        return nonMember;
    }

    /**
     * @return the newFeeAdded
     */
    public boolean isNewFeeAdded() {
        return newFeeAdded;
    }

    /**
     * return true if state is one that was added for testing
     *
     * @return
     */
    public boolean isStateAddedForTesting() {
        return isStateAddedForTesting(this.state);
    }

    /**
     * return true if state is one that was added for testing
     *
     * @param state
     * @return
     */
    public static boolean isStateAddedForTesting(StubTransactionState state) {
        return (state == StubTransactionState.EXCEPTION_FOR_TESTING)
                || (state == StubTransactionState.BIS_NOT_FOUND_FOR_TESTING)
                || (state == StubTransactionState.DENIED_FOR_TESTING);
    }

    /**
     * @param state the state to set
     */
    public void setState(StubTransactionState state) {
        this.state = state;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StubTransaction [adjustmentAmount=" + adjustmentAmount + ", cashBackAmount=" + cashBackAmount
                + ", destinationAccountNumber=" + destinationAccountNumber + ", feeAmount=" + feeAmount
                + ", holdAmount=" + holdAmount + ", newFeeAdded=" + newFeeAdded + ", nonMember=" + nonMember
                + ", requestAmount=" + requestAmount + ", sourceAccountNumber=" + sourceAccountNumber + ", state="
                + state + ", subType=" + subType + ", timestamp=" + timestamp + ", token=" + token + ", transactionId="
                + transactionId + ", type=" + type + "]";
    }

}
