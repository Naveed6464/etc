package com.ncr.itm.middleware.ws.impl.model;

import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionState;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.xml.bind.JAXBException;

import org.springframework.stereotype.Component;

/**
 * @author ap185225
 *
 */
@Component
public class StubDataImpl implements StubData {

    /**
     * Used for parsing file "Stub Customers.txt"
     */
    private enum CustomerFieldNames {
        CUSTOMER_ID,
        RELATIONSHIP_CODE,
        FULL_NAME,
        BIRTHDATE,
        STREET,
        CITY, // 5
        STATE,
        ZIPCODE,
        HOME_PHONE,
        SSN,
        // joint information is optional
        JOINT_NAME, // 10
        JOINT_BIRTHDATE,
        JOINT_HOME_PHONE,
        JOINT_SSN,
    }

    // optional repeating fields, following joint information
    private enum CustomerNoteFields {
        TYPE, // 14, 18, etc.
        EFFECTIVE_DATE,
        HEADER,
        COMMENT
    }

    /**
     * Used for parsing file "Stub Accounts.txt"
     */
    private enum AccountFieldNames {
        CUSTOMER_ID, // account.AccountNumber = account.CustomerIdentifier + account.AccountIdentifier
        ACCOUNT_TYPE,
        ACCOUNT_ID,
        SYMITAR_ACCOUNT_TYPE,
        PRODUCT,
        ACCOUNT_NICKNAME, // 5
        CURRENT_BALANCE,
        AVAILABLE_BALANCE,
        // optional
        LOAN_PAYMENT_HOLD, // 8
        MATURITY_DATE,
        CLOSE_DATE, // 10
        MICR_ACCOUNT_NUMBER,
        SHARE_CODE,
        IRS_CODE,
        SERVICES,
        LAST_TRANS_DATE, // 15
    }

    private enum AccountFieldNames2 {
        // X... are placeholders so optional/alternative values start at correct value
        XCUSTOMER_ID,
        XACCOUNT_TYPE,
        XACCOUNT_ID,
        XSYMITAR_ACCOUNT_TYPE,
        XPRODUCT,
        XACCOUNT_NICKNAME, // 5
        XCURRENT_BALANCE,
        XAVAILABLE_BALANCE,
        // optional, alternative
        REGULAR_PAYMENT, // 8
        PAYMENT_DUE,
        PAST_DUE_PAYMENT, // 10 //IsPastDue == PAST_DUE_PAYMENT > 0
        PAYOFF_PAYMENT,
        DUE_DATE,
        INTEREST_YEAR_TO_DATE,
        INTEREST_RATE,
        MINIMUM_ADVANCE, // 15
        CLOSE_DATE, // IsClosed == closeDate != "--------"
        LOAN_CODE,
        SERVICES,
        LAST_TRANS_DATE,
        CARD_NUMBER
    }

    // *** DO NOT CHANGE ORDER, NAMES OR CASE OF THESE FIELDS ***
    // must be compatible with teller enterprise
    // ordinal value of these fields must match data in file "Stub Accounts.txt"
    public enum AccountType // NOSONAR
    {
        Unknown("Unknown"), // NOSONAR
        ShareDraft("DDA"), // NOSONAR
        Share("SAV"), // NOSONAR
        Loan("LAS"), // NOSONAR
        LineOfCredit("LineOfCredit"), // NOSONAR
        CreditCard("CreditCard"), // NOSONAR// 5
        External("External"); // NOSONAR

        private final String bankProductType;

        AccountType(String bankProductType) {
            this.bankProductType = bankProductType;
        }

        /**
         * @return the bankProductType
         */
        public String getBankProductType() {
            return bankProductType;
        }

        /**
         * Convert account type value in "Stub Accounts.txt" to enum field
         *
         * @param v from file "Stub Accounts.txt"
         * @return
         */
        public static AccountType fromValue(String v) {
            AccountType accountType = Unknown;
            int ordinalValue;

            ordinalValue = Integer.parseInt(v);

            for (AccountType value : values()) {
                if (value.ordinal() == ordinalValue) {
                    accountType = value;
                    break;
                }
            }

            return accountType;
        }
    }

    public static final String ACCOUNT_NOT_FOUND = "account not found";
    private static final String CREDIT = "Credit";
    private static final String CUSTOMER_NOTES = "95";
    private static final String CUSTOMER_WARNINGS = "96";
    public static final String DATE_FORMAT_PATTERN = "MMddyyyy";
    private static final String DEBIT = "Debit";
    public static final String DELIMITED_DATE_FORMAT_PATTERN = "M/d/yyyy";
    private static final int ITEM_COUNT_NOTE = 30;
    private static final int ITEM_COUNT_WARNING = 30;
    private static final int LONG_TEXT_FREQUENCY = 5;
    // generated at http://www.lipsum.com/
    private static final String LONG_TEXT = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris rhoncus ligula dolor, sit amet lobortis felis vehicula sed. Quisque volutpat vel leo id venenatis. Praesent quis euismod arcu. Pellentesque ullamcorper ultrices justo, ut sodales ligula lobortis ut. Vivamus bibendum cursus orci aliquam.";
    private static final int MAX_DATE_OFFSET = 91;
    private static final int MAX_TRANSACTION_HISTORY_VALUE = 110000;
    private static final int SPECIAL_CHARACTERS_FREQUENCY = 10;
    private static final String SPECIAL_CHARACTERS = "Special characters: ~!@#$%^‰™";
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_CREDIT_CARD = 20;
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_EXTERNAL = 0;
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_LINE_OF_CREDIT = 5;
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_LOAN = 10;
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_SHARE = 15;
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_SHARE_DRAFT = 50;
    private static final int TRANSACTION_HISTORY_ITEM_COUNT_UNKNOWN = 0;
    private static final double VALUE_SCALE_CONVERTER = 100.;

    private final Random random = new Random();
    private final SimpleDateFormat delimitedDateFormatPattern = new SimpleDateFormat(
            DELIMITED_DATE_FORMAT_PATTERN);
    private final Map<String, List<StubAccount>> stubAccountMap; // unmodifiableList
    private final List<StubCustomer> stubCustomerList; // unmodifiableList

    public StubDataImpl() {
        this.stubAccountMap = null;
        this.stubCustomerList = null;
    }

    /**
     * Creates StubCustomer and StubAccount objects by parsing stub data files
     *
     * @param customerResource InputStream for file "Stub Customers.txt"
     * @param accountResource InputStream for file "Stub Accounts.txt"
     * @throws IOException
     * @throws JAXBException
     */
    public StubDataImpl(InputStream customerResource, InputStream accountResource)
            throws IOException, JAXBException {
        stubAccountMap = Collections.unmodifiableMap(parseAccountData(accountResource));
        stubCustomerList = Collections.unmodifiableList(parseCustomerData(customerResource));
    }

    /**
     * Creates StubAccount
     *
     * @param accountData line of text from stub data file
     * @return StubAccount
     */
    private StubAccount createAccount(String accountData) {
        StubAccount account;
        String[] splitData = accountData.replaceAll("\t", "").split(",");

        String accountId = splitData[AccountFieldNames.ACCOUNT_ID.ordinal()].trim();
        AccountType accountType = AccountType.fromValue(splitData[AccountFieldNames.ACCOUNT_TYPE.ordinal()].trim());
        BigDecimal availableBalance = new BigDecimal(splitData[AccountFieldNames.AVAILABLE_BALANCE.ordinal()].trim());
        String cardNumber = null;
        String closeDate = null;
        BigDecimal currentBalance = new BigDecimal(splitData[AccountFieldNames.CURRENT_BALANCE.ordinal()].trim());
        String customerId = splitData[AccountFieldNames.CUSTOMER_ID.ordinal()].trim();
        String accountNumber = customerId + "-" + accountId;
        String dueDate = null;
        String interestRate = null;
        BigDecimal interestYearToDate = null;
        String irsCode = null;
        String lastTransDate = null;
        String loanCode = null;
        BigDecimal loanPaymentHold = null;
        String maturityDate = null;
        String micrAccountNumber = null;
        BigDecimal minimumAdvance = null;
        String nickname = splitData[AccountFieldNames.ACCOUNT_NICKNAME.ordinal()].trim();
        BigDecimal pastDuePayment = null;
        BigDecimal paymentDue = null;
        BigDecimal payoffPayment = null;
        String product = splitData[AccountFieldNames.PRODUCT.ordinal()].trim();
        BigDecimal regularPayment = null;
        String services = null;
        String shareCode = null;
        String symitarAccountType = splitData[AccountFieldNames.SYMITAR_ACCOUNT_TYPE.ordinal()].trim();
        List<StubTransactionDetail> transactionDetails = createTransactionDetails(accountType);

        // optional information
        if (isDepositAccount(accountType)
                && (splitData.length > AccountFieldNames.LAST_TRANS_DATE.ordinal())) {
            closeDate = splitData[AccountFieldNames.CLOSE_DATE.ordinal()].trim();
            irsCode = splitData[AccountFieldNames.IRS_CODE.ordinal()].trim();
            lastTransDate = splitData[AccountFieldNames.LAST_TRANS_DATE.ordinal()].trim();
            maturityDate = splitData[AccountFieldNames.MATURITY_DATE.ordinal()].trim();
            micrAccountNumber = splitData[AccountFieldNames.MICR_ACCOUNT_NUMBER.ordinal()].trim();
            services = splitData[AccountFieldNames.SERVICES.ordinal()].trim();
            shareCode = splitData[AccountFieldNames.SHARE_CODE.ordinal()].trim();
            loanPaymentHold = new BigDecimal(splitData[AccountFieldNames.LOAN_PAYMENT_HOLD.ordinal()].trim());
        } else if ((isLoanAccount(accountType))
                && (splitData.length > AccountFieldNames2.CARD_NUMBER.ordinal())) {
            cardNumber = splitData[AccountFieldNames2.CARD_NUMBER.ordinal()].trim();
            closeDate = splitData[AccountFieldNames2.CLOSE_DATE.ordinal()].trim();
            dueDate = splitData[AccountFieldNames2.DUE_DATE.ordinal()].trim();
            interestRate = splitData[AccountFieldNames2.INTEREST_RATE.ordinal()].trim();
            interestYearToDate = new BigDecimal(splitData[AccountFieldNames2.INTEREST_YEAR_TO_DATE.ordinal()].trim());
            lastTransDate = splitData[AccountFieldNames2.LAST_TRANS_DATE.ordinal()].trim();
            loanCode = splitData[AccountFieldNames2.LOAN_CODE.ordinal()].trim();
            minimumAdvance = new BigDecimal(splitData[AccountFieldNames2.MINIMUM_ADVANCE.ordinal()].trim());
            pastDuePayment = new BigDecimal(splitData[AccountFieldNames2.PAST_DUE_PAYMENT.ordinal()].trim());
            paymentDue = new BigDecimal(splitData[AccountFieldNames2.PAYMENT_DUE.ordinal()].trim());
            payoffPayment = new BigDecimal(splitData[AccountFieldNames2.PAYOFF_PAYMENT.ordinal()].trim());
            regularPayment = new BigDecimal(splitData[AccountFieldNames2.REGULAR_PAYMENT.ordinal()].trim());
            services = splitData[AccountFieldNames2.SERVICES.ordinal()].trim();
        } else {
            throw new IllegalStateException("Account data did not parse correctly; accountId: " + accountId
                    + "; accountType: " + accountType + "; splitData.length: " + splitData.length);
        }

        account = new StubAccount(accountId, accountNumber, accountType, availableBalance,
                cardNumber, closeDate, currentBalance, customerId, dueDate, interestRate,
                interestYearToDate, irsCode, lastTransDate, loanCode,
                loanPaymentHold, maturityDate, micrAccountNumber, minimumAdvance,
                nickname, pastDuePayment, paymentDue, payoffPayment, product,
                regularPayment, services, shareCode, symitarAccountType, transactionDetails);

        return account;
    }

    /**
     * @param dayOffset
     * @return
     */
    private GregorianCalendar createCalendar(int dayOffset) {
        GregorianCalendar calendar = new GregorianCalendar();

        calendar.add(Calendar.DATE, dayOffset * -1);
        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            calendar.add(Calendar.DATE, -1);
        }
        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            calendar.add(Calendar.DATE, 1);
        }

        return calendar;
    }

    /**
     * Creates StubCustomer
     *
     * @param customerData line of text from stub data file
     * @return StubCustomer
     */
    private StubCustomer createCustomer(String customerData) {
        StubCustomer customer;
        String[] splitData = customerData.replaceAll("\t", "").split(",");

        String birthdate = splitData[CustomerFieldNames.BIRTHDATE.ordinal()].trim();
        String city = splitData[CustomerFieldNames.CITY.ordinal()].trim();
        String fullName = splitData[CustomerFieldNames.FULL_NAME.ordinal()].trim();
        String homePhone = splitData[CustomerFieldNames.HOME_PHONE.ordinal()].trim();
        String id = splitData[CustomerFieldNames.CUSTOMER_ID.ordinal()].trim();
        String relationshipCode = splitData[CustomerFieldNames.RELATIONSHIP_CODE.ordinal()].trim();
        String ssn = splitData[CustomerFieldNames.SSN.ordinal()].trim();
        String state = splitData[CustomerFieldNames.STATE.ordinal()].trim();
        String street = splitData[CustomerFieldNames.STREET.ordinal()].trim();
        String zipcode = splitData[CustomerFieldNames.ZIPCODE.ordinal()].trim();

        // joint information is optional
        List<StubJointCustomer> tmpJointCustomers = new ArrayList<>();
        if (splitData.length > CustomerFieldNames.JOINT_SSN.ordinal()) {
            StubJointCustomer jointCustomer = new StubJointCustomer(
                    splitData[CustomerFieldNames.JOINT_NAME.ordinal()].trim(),
                    splitData[CustomerFieldNames.JOINT_BIRTHDATE.ordinal()].trim(),
                    splitData[CustomerFieldNames.JOINT_HOME_PHONE.ordinal()].trim(),
                    splitData[CustomerFieldNames.JOINT_SSN.ordinal()].trim());
            tmpJointCustomers.add(jointCustomer);
        }

        // begin customer note fields
        int noteIndex = CustomerFieldNames.values().length;
        List<StubCustomerNote> tmpCustomerNotes = new ArrayList<>();
        while (splitData.length > noteIndex) {
            StubCustomerNote note = new StubCustomerNote(
                    splitData[noteIndex + CustomerNoteFields.COMMENT.ordinal()].trim(), // comment
                    splitData[noteIndex + CustomerNoteFields.EFFECTIVE_DATE.ordinal()].trim(), // effectiveDate
                    splitData[noteIndex + CustomerNoteFields.HEADER.ordinal()].trim(), // header
                    splitData[noteIndex + CustomerNoteFields.TYPE.ordinal()].trim(), // type
                    null); // otherData
            noteIndex += CustomerNoteFields.values().length;
            tmpCustomerNotes.add(note);
        }

        // generate more notes and warnings
        if (id.equals(CUSTOMER_NOTES)) {
            int[] dateOffsets = initializeDayOffsets(ITEM_COUNT_NOTE);

            for (int i = 0; i < dateOffsets.length; i++) {
                tmpCustomerNotes.add(createRandomNote("1", dateOffsets[i], i + 1));
            }
        } else if (id.equals(CUSTOMER_WARNINGS)) {
            int[] dateOffsets = initializeDayOffsets(ITEM_COUNT_WARNING);

            for (int i = 0; i < dateOffsets.length; i++) {
                tmpCustomerNotes.add(createRandomNote("2", dateOffsets[i], i + 1));
            }
        }

        List<StubAccount> tmpAccounts = stubAccountMap.get(id);
        if (tmpAccounts == null) {
            tmpAccounts = new ArrayList<>();
        }

        customer = new StubCustomer(id, fullName, birthdate, city, homePhone, relationshipCode, ssn, state, street,
                zipcode, tmpJointCustomers, tmpCustomerNotes, tmpAccounts);

        return customer;
    }

    /**
     * @param noteType
     * @return
     */
    private StubCustomerNote createRandomNote(String noteType, int dayOffset, int noteIndex) {
        GregorianCalendar calendar = createCalendar(dayOffset);
        String comment;

        if (random.nextInt(SPECIAL_CHARACTERS_FREQUENCY) == 0) {
            comment = SPECIAL_CHARACTERS;
        } else if (random.nextInt(LONG_TEXT_FREQUENCY) == 0) {
            comment = LONG_TEXT;
        } else {
            comment = "comment " + noteIndex;
        }

        StubCustomerNote note = new StubCustomerNote(
                comment,
                delimitedDateFormatPattern.format(calendar.getTime()),
                "Title " + noteIndex, // title
                noteType, "Some additional value " + noteIndex);

        return note;
    }

    /**
     * @param date
     * @param balanceValue
     * @return
     */
    private StubTransactionDetail createTransactionDetail(GregorianCalendar date, BigDecimal balanceValue) {
        String description;
        String transactionType;
        BigDecimal amountValue = new BigDecimal(random.nextInt(MAX_TRANSACTION_HISTORY_VALUE)
                / VALUE_SCALE_CONVERTER);
        String value1;
        String value2;

        amountValue = amountValue.setScale(2, BigDecimal.ROUND_DOWN);

        if (random.nextInt(2) == 0) {
            transactionType = DEBIT;
            amountValue = amountValue.negate();
        } else {
            transactionType = CREDIT;
        }

        if (random.nextInt(SPECIAL_CHARACTERS_FREQUENCY) == 0) {
            description = SPECIAL_CHARACTERS;
        } else if (random.nextInt(LONG_TEXT_FREQUENCY) == 0) {
            description = LONG_TEXT;
        } else {
            description = "Description " + getRandomValueModifier();
        }

        if (random.nextInt(SPECIAL_CHARACTERS_FREQUENCY) == 0) {
            value1 = SPECIAL_CHARACTERS;
        } else if (random.nextInt(LONG_TEXT_FREQUENCY) == 0) {
            value1 = LONG_TEXT;
        } else {
            value1 = "Value " + getRandomValueModifier();
        }

        if (random.nextInt(LONG_TEXT_FREQUENCY) == 0) {
            value2 = LONG_TEXT;
        } else {
            value2 = "Value " + (getRandomValueModifier() * 2);
        }

        return new StubTransactionDetail(date, date, transactionType, amountValue, balanceValue, description, "Key1",
                value1, "Key2", value2);
    }

    private List<StubTransactionDetail> createTransactionDetails(StubDataImpl.AccountType accountType) {
        List<StubTransactionDetail> transactionDetails;
        int itemCount;

        switch (accountType) {
            case ShareDraft:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_SHARE_DRAFT;
                break;

            case Share:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_SHARE;
                break;

            case Loan:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_LOAN;
                break;

            case LineOfCredit:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_LINE_OF_CREDIT;
                break;

            case CreditCard:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_CREDIT_CARD;
                break;

            case External:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_EXTERNAL;
                break;

            default:
                itemCount = TRANSACTION_HISTORY_ITEM_COUNT_UNKNOWN;
                break;
        }
        transactionDetails = new ArrayList<>(itemCount);

        if (itemCount > 0) {
            BigDecimal balanceValue;
            int[] dateOffsets = initializeDayOffsets(itemCount);

            balanceValue = new BigDecimal(random.nextInt(MAX_TRANSACTION_HISTORY_VALUE) / VALUE_SCALE_CONVERTER);
            balanceValue = balanceValue.setScale(2, BigDecimal.ROUND_DOWN);

            for (int i = 0; i < dateOffsets.length; i++) {
                StubTransactionDetail transactionDetail = createTransactionDetail(createCalendar(dateOffsets[i]),
                        balanceValue);
                transactionDetails.add(transactionDetail);
                balanceValue = balanceValue.subtract(transactionDetail.getTransactionAmount());
            }
        }

        return transactionDetails;
    }

    /**
     * @return
     */
    private int getRandomValueModifier() {
        return (random.nextInt(10) + 1); // NOSONAR
    }

    /**
     * @param size
     * @return
     */
    private int[] initializeDayOffsets(int size) {
        int[] dateOffsets = new int[size];

        for (int i = 0; i < size; i++) {
            // 0 to 90 day offset
            dateOffsets[i] = random.nextInt(MAX_DATE_OFFSET);
        }
        Arrays.sort(dateOffsets);

        return dateOffsets;
    }

    /**
     * @param accountType
     * @return
     */
    private boolean isDepositAccount(AccountType accountType) {
        boolean retVal = false;

        if ((accountType == AccountType.Share) || (accountType == AccountType.ShareDraft)) {
            retVal = true;
        }

        return retVal;
    }

    private boolean isLoanAccount(AccountType accountType) {
        boolean retVal = false;

        if ((accountType == AccountType.Loan) || (accountType == AccountType.External)
                || (accountType == AccountType.LineOfCredit) || (accountType == AccountType.CreditCard)) {
            retVal = true;
        }
        return retVal;

    }

    /**
     * Creates a list of StubAccounts by parsing "Stub Accounts.txt"
     *
     * @param accountResource InputStream for file "Stub Accounts.txt"
     * @return list of StubAccounts
     * @throws IOException
     */
    private Map<String, List<StubAccount>> parseAccountData(InputStream accountResource)
            throws IOException {
        Map<String, List<StubAccount>> accountMap = new HashMap<>();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(accountResource))) {
            String accountData;

            while ((accountData = in.readLine()) != null) {
                accountData = accountData.trim();

                // ignore any comment lines in the file
                if (accountData.startsWith("*")) {
                    continue;
                }

                // add account to customer's account list
                // account data file began with utf-8 BOM or something; caused some problems; edited file with WordPad
                // removed chars
                StubAccount account = createAccount(accountData);
                List<StubAccount> tmpAccounts = accountMap.get(account.getCustomerId());
                if (tmpAccounts == null) {
                    // create list for this customer
                    tmpAccounts = new ArrayList<>();
                    accountMap.put(account.getCustomerId(), tmpAccounts);
                }
                tmpAccounts.add(account);
            }
        } catch (IOException e) {
            throw e;
        }

        return accountMap;

    }

    /**
     * Creates a list of StubCustomers by parsing "Stub Customers.txt"
     *
     * @param customerResource InputStream for file "Stub Customers.txt"
     * @return list of StubCustomers
     * @throws IOException
     */
    private List<StubCustomer> parseCustomerData(InputStream customerResource)
            throws IOException {
        List<StubCustomer> tmpCustomers = new ArrayList<>();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(customerResource))) {
            String customerData;

            while ((customerData = in.readLine()) != null) {
                customerData = customerData.trim();

                // ignore any comment lines in the file
                if (customerData.startsWith("*")) {
                    continue;
                }

                StubCustomer customer = createCustomer(customerData);
                tmpCustomers.add(customer);
            }
        } catch (IOException e) {
            throw e;
        }

        return tmpCustomers;
    }

    /**
     * @param stubTransaction
     * @param stubAccount
     * @return
     */
    private Map<String, BigDecimal> authorizeAccount(StubTransaction stubTransaction, StubAccount stubAccount) {
        Map<String, BigDecimal> balances = null;
        StubTransaction.StubTransactionState state;

        if (stubAccount == null) {
            // parallel code to StubAccount.authorizeTransaction()
            assert ((stubTransaction.isNonMember()));
            // scan item transactions may add fees of 0.00
            if (stubTransaction.isNewFeeAdded()) // && ( stubTransaction.getFeeAmount().compareTo( BigDecimal.ZERO ) > 0 ) )
            {
                state = StubTransaction.StubTransactionState.CUSTOMER_VALIDATION;
            } else {
                balances = new HashMap<String, BigDecimal>(2);
                state = StubTransaction.StubTransactionState.AUTHORIZED;
            }
            assert ((state == StubTransactionState.AUTHORIZED) // NOSONAR
                    || (state == StubTransactionState.CUSTOMER_VALIDATION)) : state.toString(); // NOSONAR
            stubTransaction.setState(state);
        } else {
            // only way source account will get updated
            balances = stubAccount.authorizeTransaction(stubTransaction);
            assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                    || (stubTransaction.getState() == StubTransactionState.INSUFFICIENT_FUNDS) // NOSONAR
                    || stubTransaction.isStateAddedForTesting()) : stubTransaction.getState().toString(); // NOSONAR
        }

        return balances;
    }

    /*
     * StubTransactionState on entry: NOT_STARTED
     * 
     * StubTransactionState on exit: AUTHORIZED, CUSTOMER_VALIDATION, EXCEPTION_FOR_TESTING, BIS_NOT_FOUND_FOR_TESTING,
     * DENIED_FOR_TESTING
     * 
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#authorizeTransaction(com.ncr.cxp.ait.stub.model.StubTransaction)
     */
    @Override
    public List<Map<String, BigDecimal>> authorizeTransaction(StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        assert (stubTransaction.getState() == StubTransactionState.NOT_STARTED) : stubTransaction.getState().toString();
        List<Map<String, BigDecimal>> balanceList = new ArrayList<>(2);
        StubAccount stubSourceAccount = null;

        // account number may be null for non-member transactions (CashCheque, etc.)
        if (!stubTransaction.isNonMember()) {
            stubSourceAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                    stubTransaction.getSourceAccountNumber());
        }

        // validate destination account before authorizeAccount() on source account, which may change available balance
        StubAccount stubDestinationAccount = null;
        if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
            stubDestinationAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                    stubTransaction.getDestinationAccountNumber());
        }

        balanceList.add(authorizeAccount(stubTransaction, stubSourceAccount));
        // adjust destination account balances only when source account was authorized
        if ((stubTransaction.getType() == StubTransactionType.TRANSFER)
                && (stubTransaction.getState() == StubTransactionState.AUTHORIZED)) {
            balanceList.add(authorizeAccount(stubTransaction, stubDestinationAccount));
        }

        assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.CUSTOMER_VALIDATION) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE) // NOSONAR
                || (stubTransaction.getState() == StubTransactionState.INSUFFICIENT_FUNDS)); // NOSONAR

        return balanceList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#cancelTransaction(com.ncr.cxp.ait.stub.model.StubTransaction)
     */
    @SuppressWarnings("null")
    @Override
    public List<Map<String, BigDecimal>> cancelTransaction(StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        // *** TODO *** REVERSE FEE(s) FROM GL ACCOUNT(s) *** NOT IMPLEMENTED FOR STUB ***

        List<Map<String, BigDecimal>> balanceList = new ArrayList<Map<String, BigDecimal>>(2);

        // exclude non-member transactions
        if ((stubTransaction.getSubType() != StubTransactionSubType.CASH_CHEQUE) && (!stubTransaction.isNonMember())) {
            // only way source account will get updated
            StubAccount stubAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                    stubTransaction.getSourceAccountNumber());

            StubAccount stubDestinationAccount = null;
            if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
                stubDestinationAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                        stubTransaction.getDestinationAccountNumber());
            }

            // roll back change to account balance
            balanceList.add(stubAccount.cancelTransaction(stubTransaction));
            if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
                // roll back change to account balance
                balanceList.add(stubDestinationAccount.cancelTransaction(stubTransaction));
            }
        } else {
            balanceList.add(new HashMap<String, BigDecimal>(2));
        }

        return balanceList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#completeTransaction(com.ncr.cxp.ait.stub.model.StubTransaction)
     */
    @SuppressWarnings("null")
    @Override
    public void completeTransaction(StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        // exclude non-member transactions
        if ((stubTransaction.getSubType() != StubTransactionSubType.CASH_CHEQUE) && (!stubTransaction.isNonMember())) {
            // only way source account will get updated
            StubAccount stubAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                    stubTransaction.getSourceAccountNumber());

            StubAccount stubDestinationAccount = null;
            if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
                stubDestinationAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                        stubTransaction.getDestinationAccountNumber());
            }

            stubAccount.completeTransaction(stubTransaction);
            if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
                // update current balance
                stubDestinationAccount.completeTransaction(stubTransaction);
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#reverseTransaction(com.ncr.cxp.ait.stub.model.StubTransaction)
     */
    @SuppressWarnings("null")
    @Override
    public void reverseTransaction(StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        // *** TODO *** REVERSE FEE(s) FROM GL ACCOUNT(s) *** NOT IMPLEMENTED FOR STUB ***

        // exclude non-member transactions
        if ((stubTransaction.getSubType() != StubTransactionSubType.CASH_CHEQUE) && (!stubTransaction.isNonMember())) {
            // only way source account will get updated
            StubAccount stubAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                    stubTransaction.getSourceAccountNumber());

            StubAccount stubDestinationAccount = null;
            if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
                stubDestinationAccount = getLiveAccountAndValidate(stubTransaction.getTransactionId(),
                        stubTransaction.getDestinationAccountNumber());
            }

            // roll back change to account balance
            stubAccount.reverseTransaction(stubTransaction);
            if (stubTransaction.getType() == StubTransactionType.TRANSFER) {
                // roll back change to account balance
                stubDestinationAccount.reverseTransaction(stubTransaction);
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#getLastTransDate(java.lang.String)
     */
    @Override
    public String getLastTransDate(String accountNumber) {

        String lastTransDate = null;

        if (StringUtils.hasLength(accountNumber)) {
            lastTransDate = getLiveAccount(accountNumber).getLastTransDate();
        }

        return lastTransDate;
    }

    /**
     * Returns reference to live account rather than a copy to enable changes to
     * balances and last transaction date. This is only to be used internally by
     * this class. Everywhere else should use getAccount()
     *
     * @param accountNumber identifies requested account
     * @return StubAccount
     */
    private StubAccount getLiveAccount(String accountNumber) {
        StubAccount account = null;

        // validate input
        if (accountNumber == null) {
            throw new IllegalArgumentException("accountNumber parameter is null");
        }

        // get accountList for customer
        String trimmedAccountNumber = accountNumber.trim();
        String[] splitData = trimmedAccountNumber.split("-");
        if (splitData.length != 2) {
            throw new IllegalArgumentException("invalid accountNumber");
        }

        List<StubAccount> tmpAccounts = stubAccountMap.get(splitData[0].trim());
        if (tmpAccounts != null) {
            // find requested account
            for (StubAccount tmpAccount : tmpAccounts) {
                if (tmpAccount.getAccountNumber().equals(trimmedAccountNumber)) {
                    account = tmpAccount;
                    break;
                }
            }
        }

        return account; // live account
    }

    /**
     * Returns reference to live account rather than a copy to enable changes to
     * balances and last transaction date. This is only to be used internally by
     * this class. Everywhere else should use getAccount()
     *
     * @param transactionId
     * @param accountNumber identifies requested account
     * @return StubAccount
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private StubAccount getLiveAccountAndValidate(String transactionId, String accountNumber)
            throws StubNotFoundException, StubAccountClosedException {
        StubAccount stubAccount = getLiveAccount(accountNumber);
        if (stubAccount == null) {
            // account not found
            //ProductionLogger.warn(this, "account not found; transactionId: " + transactionId);
            throw new StubNotFoundException(ACCOUNT_NOT_FOUND);
        }
        if (stubAccount.isClosed()) {
            //ProductionLogger.warn(this, "account is closed; transactionId: " + transactionId);
            throw new StubAccountClosedException("account is closed");
        }

        return stubAccount; // live account
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#getAccount(java.lang.String)
     */
    @Override
    public StubAccount getAccount(String accountNumber)
            throws StubNotFoundException {
        StubAccount account = null;

        StubAccount tmpAccount = getLiveAccount(accountNumber);
        if (tmpAccount != null) {
            account = new StubAccount(tmpAccount);
        } else {
            // account not found
            //ProductionLogger.warn(this, ACCOUNT_NOT_FOUND);
            throw new StubNotFoundException(ACCOUNT_NOT_FOUND);
        }

        return account;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#getCustomer(java.lang.String)
     */
    @Override
    public StubCustomer getCustomer(String customerId) {
        StubCustomer customer = null;

        // validate input
        if (customerId == null) {
            throw new IllegalArgumentException("customerId parameter is null");
        }

        // find requested customer
        for (StubCustomer tmpCustomer : stubCustomerList) {
            if (tmpCustomer.getId().trim().equals(customerId.trim())) {
                customer = tmpCustomer;
                break;
            }
        }

        return customer;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#searchCustomersByName(java.util.List, java.lang.String)
     */
    @Override
    public List<StubCustomer> searchCustomersByName(List<StubCustomer> searchList, String name) {
        List<StubCustomer> customers = null;

        if (name != null) {
            customers = new ArrayList<>();

            // if we have a results list from a previous criteria, use it as the source list in successive searches
            List<StubCustomer> listToSearch = searchList;
            String tmpName = name.trim();

            // if no list is provided, search complete list
            if (listToSearch == null) {
                listToSearch = stubCustomerList;
            }

            for (StubCustomer customer : listToSearch) {
                if (customer.getName().getFullName().startsWith(tmpName)
                        || customer.getName().getLastName().startsWith(tmpName)
                        || customer.getName().getLastName().startsWith(tmpName)) {
                    customers.add(customer);
                }
            }
        }

        return customers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#searchCustomersByAccountNumber(java.util.List, java.lang.String)
     */
    @Override
    public List<StubCustomer> searchCustomersByAccountNumber(List<StubCustomer> searchList, String accountNumber) {
        List<StubCustomer> customers = null;

        if (accountNumber != null) {
            customers = new ArrayList<>();
            String tmpAccountNumber = accountNumber.trim();

            // if we have a results list from a previous criteria, use it as the source list in successive searches
            List<StubCustomer> listToSearch = searchList;

            // if no list is provided, search complete list
            if (listToSearch == null) {
                listToSearch = stubCustomerList;
            }

            for (StubCustomer customer : listToSearch) {
                for (StubAccount account : customer.getAccounts()) {
                    if (account.getAccountNumber().startsWith(tmpAccountNumber)) {
                        customers.add(customer);
                        break;
                    }
                }
            }
        }

        return customers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#searchCustomersByCardNumber(java.util.List, java.lang.String)
     */
    @Override
    public List<StubCustomer> searchCustomersByCardNumber(List<StubCustomer> searchList, String cardNumber) {
        List<StubCustomer> customers = null;

        if (cardNumber != null) {
            customers = new ArrayList<>();
            String tmpCardNumber = cardNumber.trim();

            // if we have a results list from a previous criteria, use it as the source list in successive searches
            List<StubCustomer> listToSearch = searchList;

            // if no list is provided, search complete list
            if (listToSearch == null) {
                listToSearch = stubCustomerList;
            }

            for (StubCustomer customer : listToSearch) {
                List<StubAccount> accounts = customer.getAccounts();
                for (StubAccount account : accounts) {
                    if ((account.getCardNumber() != null)
                            && (account.getCardNumber().startsWith(tmpCardNumber))) {
                        customers.add(customer);
                        break;
                    }
                }
            }
        }

        return customers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#searchCustomersByCustomerId(java.util.List, java.lang.String)
     */
    @Override
    public List<StubCustomer> searchCustomersByCustomerId(List<StubCustomer> searchList, String customerId) {
        List<StubCustomer> customers = null;

        if (customerId != null) {
            customers = new ArrayList<>();
            String tmpCustomerId = customerId.trim();

            // if we have a results list from a previous criteria, use it as the source list in successive searches
            List<StubCustomer> listToSearch = searchList;

            // if no list is provided, search complete list
            if (listToSearch == null) {
                listToSearch = stubCustomerList;
            }

            for (StubCustomer customer : listToSearch) {
                if (customer.getId().startsWith(tmpCustomerId)) {
                    customers.add(customer);
                }
            }
        }

        return customers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#searchCustomersByPhoneNumber(java.util.List, java.lang.String)
     */
    @Override
    public List<StubCustomer> searchCustomersByPhoneNumber(List<StubCustomer> searchList, String phoneNumber) {
        List<StubCustomer> customers = null;

        if (phoneNumber != null) {
            customers = new ArrayList<>();
            String tmpPhoneNumber = phoneNumber.trim();

            // if we have a results list from a previous criteria, use it as the source list in successive searches
            List<StubCustomer> listToSearch = searchList;

            // if no list is provided, search complete list
            if (listToSearch == null) {
                listToSearch = stubCustomerList;
            }

            for (StubCustomer customer : listToSearch) {
                if (customer.getHomePhone().startsWith(tmpPhoneNumber)) {
                    customers.add(customer);
                }
            }
        }

        return customers;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ncr.cxp.ait.stub.model.StubData#searchCustomersBySsn(java.util.List, java.lang.String)
     */
    @Override
    public List<StubCustomer> searchCustomersBySsn(List<StubCustomer> searchList, String ssn) {
        List<StubCustomer> customers = null;

        if (ssn != null) {
            customers = new ArrayList<>();
            String tmpSsn = ssn.trim();

            // if we have a results list from a previous criteria, use it as the source list in successive searches
            List<StubCustomer> listToSearch = searchList;

            if (listToSearch == null) {
                // if no list is provided, search complete list
                listToSearch = stubCustomerList;
            }

            for (StubCustomer customer : listToSearch) {
                if (customer.getSsn().startsWith(tmpSsn)) {
                    customers.add(customer);
                }
            }
        }

        return customers;
    }

    // *** TODO *** TEMPORARY ***
    @SuppressWarnings("unused")
    private static void readObject(String[] args) // main, renamed to prevent sonar flag
    {
        final String customerFileName = "Stub Customers.txt";
        final String accountFileName = "Stub Accounts.txt";

        // Class clazz = Class.forName( "ReadStubData" ); // NOSONAR
        // clazz.getResourceAsStream( customerFileName ); // NOSONAR
        // ApplicationContext appContext = new ClassPathXmlApplicationContext( new String[] {} ); // NOSONAR
        // // Resource resource = appContext.getResource( "classpath:/" + customerFileName ); // NOSONAR
        // try (BufferedReader in = new BufferedReader( new InputStreamReader( resource.getInputStream() ) )) // NOSONAR
        // URL resource = com.ncr.cxp.integraton.ait.stub.model.StubDataImpl.class.getResource( "/" // +
        // customerFileName ); // NOSONAR
        try {
            InputStream customerResource = StubDataImpl.class.getResourceAsStream("/" + customerFileName);
            InputStream accountResource = StubDataImpl.class.getResourceAsStream("/" + accountFileName);
            StubData stubData = new StubDataImpl(customerResource, accountResource);
            StubCustomer customer = stubData.getCustomer("3");
            System.out.println("customer = " + customer); // NOSONAR
        } catch (Exception e) // NOSONAR
        {
            e.printStackTrace(); // NOSONAR
        }
    }
}
