package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseDepositRsType;
import com.ncr.cxp.branch.integration.schema.BalanceType;
import com.ncr.cxp.branch.integration.schema.CashInItemType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRqType;
import com.ncr.cxp.branch.integration.schema.ChequeItemRsType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRqType;
import com.ncr.cxp.branch.integration.schema.CompleteDepositRsType;
import com.ncr.cxp.branch.integration.schema.DepositCompletionInfoType;
import com.ncr.cxp.branch.integration.schema.DepositDetailsType;
import com.ncr.cxp.branch.integration.schema.DepositInfoType;
import com.ncr.cxp.branch.integration.schema.DepositRsItemsType;
import com.ncr.cxp.branch.integration.schema.DepositRsItemsType.CashInItem;
import com.ncr.cxp.branch.integration.schema.FeeType;
import com.ncr.cxp.branch.integration.schema.OverrideInfoType;
import com.ncr.cxp.branch.integration.schema.ReverseDepositRqType;
import com.ncr.cxp.branch.integration.schema.ReverseDepositRsType;
import com.ncr.cxp.branch.integration.schema.TransactionStatusType;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubFeeData;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionCache;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Message converter for the BIS Deposit Service
 *
 * @author ap185225
 */
@Component
public class StubBISDepositMessageConverter extends StubBaseTransactionConverter {

    /**
     * @param stubData
     * @param stubFeeData
     * @param transactionCache
     */
    @Autowired
    public StubBISDepositMessageConverter(StubData stubData, StubFeeData stubFeeData,
            StubTransactionCache transactionCache) {
        super(stubData, stubFeeData, transactionCache);
    }

    /**
     * Creates a {@link AuthoriseDepositRs} based on the supplied
     * {@link StubData}
     *
     * @param request
     * @param token
     * @param customerId
     * @param customerIdType
     * @return {@link AuthoriseDepositRs}
     * @throws StubNotFoundException
     * @throws StubAccountClosedException
     */
    public AuthoriseDepositRsType createAuthorizeDepositResponse(AuthoriseDepositRqType request, String token,
            String customerId, String customerIdType)
            throws StubNotFoundException, StubAccountClosedException {
        AuthoriseDepositRsType response = new AuthoriseDepositRsType();
        DepositDetailsType depositDetailsType = new DepositDetailsType();
        response.setDepositDetails(depositDetailsType);
        depositDetailsType.setDepositItems(new DepositRsItemsType());
        DepositInfoType depositInfoType = request.getDepositInfo();
        String transactionId = request.getTransactionId();

        // *** TODO *** WRITE THIS TO LOG ??? ***
        // OverrideInfoType overrideInfo = depositInfo.getOverrideInfo(); // NOSONAR
        // String detail = overrideInfo.getDetail(); // NOSONAR
        // String reason = overrideInfo.getReason(); // NOSONAR
        StubDepositHelper depositHelper = new StubDepositHelper(depositInfoType, depositDetailsType, customerIdType);
        StubBISAuthorizeConverter authorizeConverter = new StubBISAuthorizeConverter(
                this,
                depositHelper,
                token,
                customerId);

        // *** TODO *** VALIDATE VALID OPERATIONS *** VALIDATE IF WE CAN PERFORM TRANSACTION FOR accountKey.getType()
        try {
            // formal authorization process
            response.setTransactionStatus(authorizeConverter.processAuthorize(transactionId));
            response.setTransactionId(authorizeConverter.getStubTransactionId());
        } catch (Exception e) {
            //ProductionLogger.warn(this, e.getMessage(), e);
            throw e;
        }

        return response;
    }

    /**
     * Creates a {@link CompleteDepositRs} based on the supplied
     * {@link StubData}
     *
     * @param request
     * @return {@link CompleteDepositRs}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    public CompleteDepositRsType createCompleteDepositResponse(CompleteDepositRqType request)
            throws StubNotFoundException, StubAccountClosedException {
        DepositCompletionInfoType depositCompletionInfo = request.getDepositCompletionInfo();
        CompleteDepositRsType response = new CompleteDepositRsType();
        String transactionId = request.getTransactionId();

        // optional
        // List<CashMixType> cashInDetails = depositCompletionInfo.getCashInDetails(); // NOSONAR
        // List<CashMixType> cashOutDetails = depositCompletionInfo.getCashOutDetails(); // NOSONAR
        // List<ChequeInDetailType> chequeInDetails = depositCompletionInfo.getChequeInDetails(); // NOSONAR
        TransactionStatusType transactionStatusType = completeTransaction(transactionId, StubTransactionType.DEPOSIT,
                depositCompletionInfo.getTransactionCompletionResult());

        response.setTransactionStatus(transactionStatusType);
        response.setTransactionId(request.getTransactionId());

        return response;
    }

    /**
     * Creates a {@link ReverseDepositRs} based on the supplied {@link StubData}
     *
     * @param request
     * @return {@link ReverseDepositRs}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    public ReverseDepositRsType createReverseDepositResponse(ReverseDepositRqType request)
            throws StubNotFoundException, StubAccountClosedException {
        ReverseDepositRsType response = new ReverseDepositRsType();
        String transactionId = request.getTransactionId();

        TransactionStatusType transactionStatusType = reverseTransaction(transactionId, StubTransactionType.DEPOSIT);
        response.setTransactionStatus(transactionStatusType);
        response.setTransactionId(request.getTransactionId());

        return response;
    }

    /**
     * @author ap185225
     *
     */
    private final class StubDepositHelper extends StubTransactionHelperImpl {

        private final DepositInfoType depositInfoType;
        private final DepositDetailsType depositDetailsType;

        /**
         * @param depositInfoType
         * @param depositDetailsType
         * @param customerIdType
         */
        private StubDepositHelper(DepositInfoType depositInfoType, DepositDetailsType depositDetailsType,
                String customerIdType) {
            super(customerIdType);
            this.depositInfoType = depositInfoType;
            this.depositDetailsType = depositDetailsType;
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getDepositAmount()
         */
        @Override
        public BigDecimal getAmount() {
            return depositInfoType.getAmount().getValue();
        }

        @Override
        public BigDecimal getCashBack() {
            BigDecimal cashBack = BigDecimal.ZERO;

            if (depositInfoType.getCashBack() != null) {
                cashBack = depositInfoType.getCashBack().getValue();
            }

            return cashBack;
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getChequeRqItems()
         */
        @Override
        public List<CashInItemType> getCashInItems() {
            return depositInfoType.getDepositItems().getCashInItem();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getCashRsItems()
         */
        @Override
        public List<CashInItem> getCashRsItems() {
            return this.depositDetailsType.getDepositItems().getCashInItem();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getChequeRqItems()
         */
        @Override
        public List<ChequeItemRqType> getChequeRqItems() {
            return depositInfoType.getDepositItems().getChequeRqItem();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getChequeRsItems()
         */
        @Override
        public List<ChequeItemRsType> getChequeRsItems() {
            return this.depositDetailsType.getDepositItems().getChequeRsItem();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getOverrideInfo()
         */
        @Override
        public OverrideInfoType getOverrideInfo() {
            return depositInfoType.getOverrideInfo();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getRequestFees()
         */
        @Override
        public List<FeeType> getRequestFees() {
            return depositInfoType.getFee();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getResponseBalances()
         */
        @Override
        public List<BalanceType> getResponseBalances() {
            return depositDetailsType.getBalance();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getResponseFees()
         */
        @Override
        public List<FeeType> getResponseFees() {
            return depositDetailsType.getFee();
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getSourceAccountNumber()
         */
        @Override
        public String getSourceAccountNumber() {
            String sourceAccountNumber = null;

            // sourceAccount is optional for cashCheque, scan item when customer ID type is ANONYMOUS (non-member)
            // do not return account number for non-member sessions
            // *** TODO *** HOW WILL WE HANDLE NON-MEMBER PRINT CHECK TRANSACTIONS? ***
            if (!isNonMember()) {
                if (depositInfoType.getAccount().getType() == null) {
                    throw new IllegalArgumentException("missing account type");
                }
                sourceAccountNumber = depositInfoType.getAccount().getNumber();
            }

            return sourceAccountNumber;
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getTransactionSubType()
         */
        @Override
        public StubTransactionSubType getTransactionSubType() {
            return convertTransactionSubType(depositInfoType.getTransactionType());
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.ncr.cxp.ait.stub.integration.impl.converter.StubTransactionHelper#getTransactionType()
         */
        @Override
        public StubTransactionType getTransactionType() {
            return StubTransactionType.DEPOSIT;
        }

    }
}
