/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.AuthorisePaymentRqType;
import com.ncr.cxp.branch.integration.schema.AuthorisePaymentRsType;
import com.ncr.cxp.branch.integration.schema.CompletePaymentRqType;
import com.ncr.cxp.branch.integration.schema.CompletePaymentRsType;
import com.ncr.cxp.branch.integration.schema.ReversePaymentRqType;
import com.ncr.cxp.branch.integration.schema.ReversePaymentRsType;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISPaymentService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

/**
 *
 * @author naveed
 */
@Endpoint
public class BISPaymentEndpoint
        extends BaseEndpoint {

    private BISPaymentService paymentService;

    public BISPaymentService getPaymentService() {
        return this.paymentService;
    }

    @Autowired(required = false)
    public void setPaymentService(BISPaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @Autowired
    public BISPaymentEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "AuthorisePaymentRq")
    @ResponsePayload
    public AuthorisePaymentRsType authorise(@RequestPayload AuthorisePaymentRqType authorisePaymentRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "authorise - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<AuthorisePaymentRsType> response;
        if (this.paymentService == null) {
            AuthorisePaymentRsType paymentResponse = new AuthorisePaymentRsType();
            response = createNotImplementedResponse(paymentResponse, header);
        } else {
            response = this.paymentService.authorisePayment(header, authorisePaymentRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "authorise - Exit");
        return (AuthorisePaymentRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CompletePaymentRq")
    @ResponsePayload
    public CompletePaymentRsType complete(@RequestPayload CompletePaymentRqType completePaymentRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "complete - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CompletePaymentRsType> response;

        if (this.paymentService == null) {
            CompletePaymentRsType paymentResponse = new CompletePaymentRsType();
            response = createNotImplementedResponse(paymentResponse, header);
        } else {
            response = this.paymentService.completePayment(header, completePaymentRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "complete - Exit");
        return (CompletePaymentRsType) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ReversePaymentRq")
    @ResponsePayload
    public ReversePaymentRsType reverse(@RequestPayload ReversePaymentRqType reversePaymentRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "reverse - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<ReversePaymentRsType> response;
        if (this.paymentService == null) {
            ReversePaymentRsType paymentResponse = new ReversePaymentRsType();
            response = createNotImplementedResponse(paymentResponse, header);
        } else {
            response = this.paymentService.reversePayment(header, reversePaymentRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "reverse - Exit");
        return (ReversePaymentRsType) response.getResponse();
    }
}
