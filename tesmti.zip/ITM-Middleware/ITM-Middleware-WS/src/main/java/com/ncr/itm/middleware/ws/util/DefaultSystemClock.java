package com.ncr.itm.middleware.ws.util;

public class DefaultSystemClock implements SystemClock {

    @Override
    public long getCurrentTimeMillis() {
        return System.currentTimeMillis();
    }
}
