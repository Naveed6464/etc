/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

/**
 *
 * @author naveed
 */
import com.ncr.cxp.branch.integration.schema.GetConfigurationRq;
import com.ncr.cxp.branch.integration.schema.GetConfigurationRs;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISConfigurationService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

@Endpoint
public class BISConfigurationEndpoint
        extends BaseEndpoint {

    private final BISConfigurationService configurationService;

    @Autowired
    public BISConfigurationEndpoint(BISConfigurationService configurationService, HeaderProcessor headerProcessor) {
        super(headerProcessor);
        this.configurationService = configurationService;
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "GetConfigurationRq")
    @ResponsePayload
    public GetConfigurationRs getConfiguration(@RequestPayload GetConfigurationRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "getCnfiguration - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<GetConfigurationRs> response = this.configurationService.getConfiguration(header, request);
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "getConfiguration - Exit");
        return (GetConfigurationRs) response.getResponse();
    }
}
