package com.ncr.itm.middleware.ws.impl.model.exceptions;

/**
 * @author pm250114
 */
public class StubNotFoundException extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = 557458985574177435L;

    /**
     * @param message
     */
    public StubNotFoundException( String message )
    {
        super( message );
    }

}
