/**
 *
 */
package com.ncr.itm.middleware.ws.impl.model;

import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import java.util.Map;

/**
 * @author ap185225
 *
 */
public interface StubFeeData {

    /**
     * @return
     */
    Map<StubTransactionSubType, StubTransactionFee> getTransactionFeeMap();

}
