/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.entities.RsHeader;

/**
 *
 * @author naveed
 */
public class BaseEndpoint {

    protected static final String NAMESPACE_URI = "http://www.ncr.com/cxp/branch/integration/schema";
    protected static final String TERMINALSESSION = "TERMINAL";
    protected static final String TELLERSESSION = "TELLER";
    protected static final String BIS_SYSTEM_ERROR = "BIS_SYSTEM_ERROR";
    protected static final String BIS_INVALID_TOKEN = "BIS_INVALID_TOKEN";
    protected static final String BIS_SYSTEM_UNAVAILABLE = "BIS_SYSTEM_UNAVAILABLE";
    protected static final String BIS_UNKNOWN_ERROR = "BIS_UNKNOWN_ERROR";
    protected static final String BIS_NOT_CONNECTED = "BIS_NOT_CONNECTED";
    protected static final String BIS_BAD_REQUEST = "BIS_BAD_REQUEST";
    protected static final String BIS_ACCESS_DENIED = "BIS_ACCESS_DENIED";
    protected static final String BIS_INVALID_CUSTOMER_CREDENTIALS = "BIS_INVALID_CUSTOMER_CREDENTIALS";
    protected static final String BIS_SESSION_IN_PROGRESS = "BIS_SESSION_IN_PROGRESS";
    protected static final String BIS_NOT_IMPLEMENTED = "BIS_NOT_IMPLEMENTED";
    protected static final String BIS_SEQUENCE_ERROR = "BIS_SEQUENCE_ERROR";
    protected static final String BIS_NOT_FOUND = "BIS_NOT_FOUND";
    protected static final String BIS_ALREADY_SIGNED_ON = "BIS_ALREADY_SIGNED_ON";
    protected static final String BIS_INVALID_BRANCHID = "BIS_INVALID_BRANCHID";
    protected static final String BIS_ALREADY_SIGNED_OFF = "BIS_ALREADY_SIGNED_OFF";
    protected static final String BIS_NO_CUSTOMER_SESSION = "BIS_NO_CUSTOMER_SESSION";
    protected static final String NOT_IMPLEMENTED = "Not implemented";
    private final HeaderProcessor headerProcessor;

    public BaseEndpoint(HeaderProcessor headerProcessor) {
        this.headerProcessor = headerProcessor;
    }

    public HeaderProcessor getHeaderProcessor() {
        return this.headerProcessor;
    }

    protected <T> BISResult<T> createNotImplementedResponse(T responseBody, RqHeader header) {
        RsHeader rsHeader = new RsHeader();
        ErrorType error = new ErrorType();
        error.setErrorCode("BIS_NOT_IMPLEMENTED");
        error.setErrorMessage("Not implemented");
        error.setSeverity(SeverityEnum.ERROR);
        rsHeader.setError(error);
        rsHeader.setMsgSeqId(header.getMsgSeqId());
        if ((header.getAuthentication() != null) && (header.getAuthentication().getSessionToken() != null) && (!header.getAuthentication().getSessionToken().isEmpty())) {
            rsHeader.setSessionToken(header.getAuthentication().getSessionToken());
        }
        return new BISResult(rsHeader, responseBody);
    }
}
