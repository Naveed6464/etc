package com.ncr.itm.middleware.ws.impl.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ap185225
 *
 * Used to marshal list of Fee objects
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "transactionFees")
public final class StubTransactionFeeList {

    @XmlElement(name = "transactionFee")
    private List<StubTransactionFee> transactionFees;

    /**
     * Creates StubFeeList
     */
    StubTransactionFeeList() {
        // needed for JAXB
    }

    // *** TO DO *** TEMPORARY ***
    /**
     * @param transactionFees
     */
    private StubTransactionFeeList(List<StubTransactionFee> transactionFees) {
        this.transactionFees = transactionFees;
    }

    /**
     * @return the transactionFees
     */
    List<StubTransactionFee> getTransactionFees() {
        return transactionFees;
    }

    // *** TODO *** TEMPORARY ***
    @SuppressWarnings("unused")
    private static void readObject(String[] args) // main, renamed to prevent sonar flag
    {
        List<StubTransactionFee> transactionFees = new ArrayList<>();
        Set<String> waivedCodes = new HashSet<>(Arrays.asList(new String[]{"0", "91"}));

        StubTransactionFee fee = new StubTransactionFee(
                new BigDecimal("2.00"),
                "Print Check Fee",
                false,
                StubTransaction.StubTransactionSubType.PRINT_CHEQUE,
                "401",
                new BigDecimal("7.00"),
                waivedCodes);
        transactionFees.add(fee);

        fee = new StubTransactionFee(
                BigDecimal.ZERO,
                "Scan Fee",
                true,
                StubTransaction.StubTransactionSubType.SCAN,
                "402",
                BigDecimal.ZERO,
                waivedCodes);
        transactionFees.add(fee);

        fee = new StubTransactionFee(
                new BigDecimal("3.00"),
                "Cash Check Fee",
                false,
                StubTransaction.StubTransactionSubType.CASH_CHEQUE,
                "403",
                new BigDecimal("5.00"),
                waivedCodes);
        transactionFees.add(fee);

        try {
            JAXBContext context = JAXBContext.newInstance(StubTransactionFeeList.class);
            Marshaller marshaller = context.createMarshaller();

            // fees
            StubTransactionFeeList transactionFeeList = new StubTransactionFeeList(transactionFees);
            // StringWriter writer = new StringWriter(); // NOSONAR
            // marshaller.marshal( transactionFeeList, writer ); // NOSONAR

            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(transactionFeeList, System.out); // NOSONAR
        } catch (JAXBException e) // NOSONAR
        {
            e.printStackTrace(); // NOSONAR
        }
    }
}
