/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

/**
 *
 * @author naveed
 */
import com.ncr.cxp.branch.integration.schema.CashAdjustmentRq;
import com.ncr.cxp.branch.integration.schema.CashAdjustmentRs;
import com.ncr.cxp.branch.integration.schema.CloseBranchRq;
import com.ncr.cxp.branch.integration.schema.CloseBranchRs;
import com.ncr.cxp.branch.integration.schema.ConnectRq;
import com.ncr.cxp.branch.integration.schema.ConnectRs;
import com.ncr.cxp.branch.integration.schema.OpenBranchRq;
import com.ncr.cxp.branch.integration.schema.OpenBranchRs;
import com.ncr.cxp.branch.integration.schema.ServiceInqRq;
import com.ncr.cxp.branch.integration.schema.ServiceInqRs;
import com.ncr.cxp.branch.integration.schema.SignoffRq;
import com.ncr.cxp.branch.integration.schema.SignoffRs;
import com.ncr.cxp.branch.integration.schema.SignonRq;
import com.ncr.cxp.branch.integration.schema.SignonRs;
import com.ncr.cxp.branch.integration.schema.VerifySessionRq;
import com.ncr.cxp.branch.integration.schema.VerifySessionRs;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.service.BISAdminService;
import javax.xml.bind.JAXBException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeader;

@Endpoint
public class BISAdminEndpoint
        extends BaseEndpoint {

    private BISAdminService service;

    @Autowired
    public BISAdminEndpoint(HeaderProcessor headerProcessor) {
        super(headerProcessor);
    }

    public BISAdminService getAdminService() {
        return this.service;
    }

    @Autowired(required = false)
    public void setAdminService(BISAdminService adminService) {
        this.service = adminService;
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ConnectRq")
    @ResponsePayload
    public ConnectRs connect(@RequestPayload ConnectRq connectRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "connect - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);

        BISResult<ConnectRs> response;
        if (this.service == null) {
            ConnectRs errorResponse = new ConnectRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.connect(header);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "connect - Exit");
        return (ConnectRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "ServiceInqRq")
    @ResponsePayload
    public ServiceInqRs serviceInq(@RequestPayload ServiceInqRq serviceInqRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "serviceInq - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<ServiceInqRs> response;

        if (this.service == null) {
            ServiceInqRs errorResponse = new ServiceInqRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.serviceInq(header, serviceInqRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "serviceInq - Exit");
        return (ServiceInqRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "SignonRq")
    @ResponsePayload
    public SignonRs signOn(@RequestPayload SignonRq signonRequest, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "signOn - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<SignonRs> response;
        if (this.service == null) {
            SignonRs errorResponse = new SignonRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.signon(header, signonRequest);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "signOn - Exit");
        return (SignonRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "SignoffRq")
    @ResponsePayload
    public SignoffRs signOff(@RequestPayload SignoffRq signOffRq, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "signOff - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<SignoffRs> response;
        if (this.service == null) {
            SignoffRs errorResponse = new SignoffRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.signoff(header);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "signOff - Exit");
        return (SignoffRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "OpenBranchRq")
    @ResponsePayload
    public OpenBranchRs openBranch(@RequestPayload OpenBranchRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "openBranch - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<OpenBranchRs> response;
        if (this.service == null) {
            OpenBranchRs errorResponse = new OpenBranchRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.openBranch(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "openBranch - Exit");
        return (OpenBranchRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CloseBranchRq")
    @ResponsePayload
    public CloseBranchRs closeBranch(@RequestPayload CloseBranchRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "closeBranch - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CloseBranchRs> response;
        if (this.service == null) {
            CloseBranchRs errorResponse = new CloseBranchRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.closeBranch(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "closeBranch - Exit");
        return (CloseBranchRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "CashAdjustmentRq")
    @ResponsePayload
    public CashAdjustmentRs cashAdjustment(@RequestPayload CashAdjustmentRq request, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "cashAdjustment - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<CashAdjustmentRs> response;
        if (this.service == null) {
            CashAdjustmentRs errorResponse = new CashAdjustmentRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.cashAdjustment(header, request);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "cashAdjustment - Exit");
        return (CashAdjustmentRs) response.getResponse();
    }

    @PayloadRoot(namespace = "http://www.ncr.com/cxp/branch/integration/schema", localPart = "VerifySessionRq")
    @ResponsePayload
    public VerifySessionRs verifySession(@RequestPayload VerifySessionRq verifySessionRq, SoapHeader soapHeader, MessageContext messageContext)
            throws JAXBException {
        //ProductionLogger.info(this, "verifySession - Entry");

        RqHeader header = getHeaderProcessor().handleRequestHeader(soapHeader);
        BISResult<VerifySessionRs> response;
        if (this.service == null) {
            VerifySessionRs errorResponse = new VerifySessionRs();
            response = createNotImplementedResponse(errorResponse, header);
        } else {
            response = this.service.verifySession(header, verifySessionRq);
        }
        getHeaderProcessor().addResponseHeader(messageContext, response.getHeader());

        //ProductionLogger.info(this, "verifySession - Exit");
        return (VerifySessionRs) response.getResponse();
    }
}
