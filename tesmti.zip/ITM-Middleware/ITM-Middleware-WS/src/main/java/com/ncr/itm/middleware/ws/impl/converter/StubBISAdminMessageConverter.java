package com.ncr.itm.middleware.ws.impl.converter;

import com.ncr.cxp.branch.integration.schema.SignoffRs;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Message converter for the BIS Admin Service
 *
 * @author ap185225
 */
@Component
public class StubBISAdminMessageConverter extends StubBISMessageConverter {

    private final StubTransactionCache transactionCache;

    /**
     * @param stubData
     */
    @Autowired
    public StubBISAdminMessageConverter(StubData stubData, StubTransactionCache transactionCache) {
        super(stubData);
        this.transactionCache = transactionCache;
    }

    /**
     * clean up any non-completed transactions created during session
     *
     * @param token
     */
    public SignoffRs createSignoffResponse(String token) {
        transactionCache.cleanup(token);

        return new SignoffRs();
    }

}
