package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AdditionalInfoType;
import com.ncr.cxp.branch.integration.schema.CashAdjustmentRq;
import com.ncr.cxp.branch.integration.schema.CashAdjustmentRs;
import com.ncr.cxp.branch.integration.schema.CloseBranchRq;
import com.ncr.cxp.branch.integration.schema.CloseBranchRs;
import com.ncr.cxp.branch.integration.schema.ConnectRs;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.OpenBranchRq;
import com.ncr.cxp.branch.integration.schema.OpenBranchRs;
import com.ncr.cxp.branch.integration.schema.ServiceInqRq;
import com.ncr.cxp.branch.integration.schema.ServiceInqRs;
import com.ncr.cxp.branch.integration.schema.ServiceInqRs.ServiceAvailability;
import com.ncr.cxp.branch.integration.schema.ServiceInqRs.ServiceState;
import com.ncr.cxp.branch.integration.schema.ServiceStatusEnum;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.cxp.branch.integration.schema.SignoffRs;
import com.ncr.cxp.branch.integration.schema.SignonRq;
import com.ncr.cxp.branch.integration.schema.SignonRs;
import com.ncr.cxp.branch.integration.schema.SignonRs.Profile;
import com.ncr.cxp.branch.integration.schema.SignonTypeEnum;
import com.ncr.cxp.branch.integration.schema.VerifySessionRq;
import com.ncr.cxp.branch.integration.schema.VerifySessionRs;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.impl.converter.StubBISAdminMessageConverter;
import com.ncr.itm.middleware.ws.util.Ensure;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * Implementation of BIS Admin Service Interface
 *
 * @author ap185225
 */
@Service
public class BISAdminService extends StubBISBaseServiceImpl {

    private static final String DELAYED_RESPONSE_FOR_TESTING = "delayed response for testing";
    private static final int SECONDS_DELAY = 10 * 1000; // 10 seconds
    // *** TODO *** TEMPORARY *** ADD TO CONFIG FILE? ***
    // private static final String TELLER_ID = "SIGNON_ID"; // NOSONAR
    private static final String TELLER_ID = "";
    private static final String TELLER_PWD = "123456";

    // TellerEnterprise matches CORE_SERVICE string
    // *** TODO *** CHANGE CBI ??? *** ADD TO CONFIGURATION ??? ***
    // *** THIS WILL BE DIFFERENT FOR EACH IMPLEMENTATION ***
    // *** SOME IMPLEMENTATIONS MAY HAVE MULTIPLE SERVICES ***
    protected static final String CORE_SERVICE = "CbiSampleCoreService";

    protected static final String ALREADY_SIGNED_ON = "already signed on";

    private final StubBISAdminMessageConverter converter;
    private final List<ServiceAvailability> services;

    /**
     * Constructs an instance of the class.
     *
     * @param sessionManager
     * @param converter
     */
    @Autowired
    public BISAdminService(SessionManager sessionManager, StubBISAdminMessageConverter converter) {
        super(sessionManager);
        this.converter = converter;

        services = new ArrayList<>(7); // NOSONAR
        // *** ADD ServiceAvailability FOR CORE_SERVICE? ***
        services.add(createServiceAvailability("admin"));
        services.add(createServiceAvailability("configuration"));
        services.add(createServiceAvailability("customer"));
        services.add(createServiceAvailability("deposit"));
        services.add(createServiceAvailability("transfer"));
        services.add(createServiceAvailability("withdrawal"));
    }

    /**
     * @param serviceName
     * @return
     */
    private ServiceAvailability createServiceAvailability(String serviceName) {
        ServiceAvailability serviceAvailability = new ServiceInqRs.ServiceAvailability();

        serviceAvailability.setServiceName(serviceName);
        serviceAvailability.setServiceAvailable(true);

        return serviceAvailability;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#connect(com.ncr.cxp.localassist.integration.dto.RqHeader)
     */
    //@Override
    public BISResult<ConnectRs> connect(RqHeader header) {
        //ProductionLogger.info(this, "connect - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());
        ensureValidMsgSeqId(header);

        // connect() is just a ping for stub core; no authentication credentials required, no token returned
        return buildResult(header.getMsgSeqId(), null, null, new ConnectRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#signon(com.ncr.cxp.localassist.integration.dto.RqHeader,
     * com.ncr.cxp.localassist.integration.dto.SignonRq)
     */
    //@Override
    public BISResult<SignonRs> signon(final RqHeader header, final SignonRq request) {
        //ProductionLogger.info(this, "signon - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());
        SignonRs response = new SignonRs();
        ErrorType error = null;
        String token = null;
        SignonTypeEnum signonType = request.getSignonInfo().getSignonType();
        String id;
        String pwd;

        try {
            ensureValidMsgSeqId(header);
            Ensure.notNull(request.getSignonInfo().getSignonType(), "SignonTypeEnum");
            Ensure.isNull(header.getSessionState(), "SessionState should be null for signon");

            if ((signonType == SignonTypeEnum.TELLER)
                    && (header.getAuthentication().getTellerCredentials() != null)) {
                id = header.getAuthentication().getTellerCredentials().getUserId();
                pwd = header.getAuthentication().getTellerCredentials().getPassword();
            } else if (header.getAuthentication().getTerminalCredentials() != null) {
                id = header.getAuthentication().getTerminalCredentials().getDeviceId();
                pwd = header.getAuthentication().getTerminalCredentials().getDeviceCredentialDetails();
            } else {
                throw new IllegalArgumentException("Authentication credentials");
            }

            // *** TODO *** TEMPORARY *** WILDCARD FOR DEVELOPMENT ***
            // if( ( id.equals( TELLER_ID ) ) && ( pwd.equals( TELLER_PWD ) ) ) // NOSONAR
            if (StringUtils.hasText(id) && StringUtils.hasText(pwd)
                    && id.startsWith(TELLER_ID) && pwd.equals(TELLER_PWD)) {
                if (getSessionManager().isValid(signonType.name(), id)) {
                    //ProductionLogger.warn(this, "signon - session for supplied credentials already exists");
                    error = createErrorType(BIS_ALREADY_SIGNED_ON, ALREADY_SIGNED_ON, SeverityEnum.WARNING);
                } else {
                    token = getSessionManager().startSession(signonType.name(), id);
                    getSessionManager().storeSessionContextValue(getSessionTokenFromRequest(header), CORE_SERVICE,
                            ServiceStatusEnum.SIGNED_ON.toString());
                }
            } else {
                //ProductionLogger.warn(this, "signon - Invalid credentials");
                error = createErrorType(BIS_ACCESS_DENIED, "Invalid credentials", SeverityEnum.ERROR);

                delaySignon(pwd);
            }

            // used by client side integration tests
            Profile profile = new SignonRs.Profile();
            response.setProfile(profile);
            List<AdditionalInfoType> profileItems = profile.getProfileItem();
            AdditionalInfoType additionalInfoType = new AdditionalInfoType();
            additionalInfoType.setKey("someKey");
            additionalInfoType.setValue("someValue");
            profileItems.add(additionalInfoType);
        } catch (IllegalArgumentException e) {
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), token, error, response);
    }

    private void delaySignon(String pwd) {
        // allow testing of wait screen
        if (StringUtils.hasText(pwd) && (pwd.length() < (TELLER_PWD.length() / 2))) {
            try {
                //ProductionLogger.info(this, DELAYED_RESPONSE_FOR_TESTING);
                Thread.sleep(SECONDS_DELAY);
            } catch (InterruptedException e) // NOSONAR
            {
                // ignore
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#signoff(com.ncr.cxp.localassist.integration.dto.RqHeader)
     */
    //@Override
    public BISResult<SignoffRs> signoff(final RqHeader header) {
        //ProductionLogger.info(this, "signoff - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());
        ErrorType error = null;
        SignoffRs response = new SignoffRs();
        String token = null;

        try {
            ensureValidMsgSeqId(header); // needed to ensure AIT is functioning correctly
            token = header.getAuthentication().getSessionToken();
            response = converter.createSignoffResponse(token);
            if (((token == null) || (token.isEmpty()))
                    && (header.getAuthentication().getTellerCredentials() != null)) {
                // [WR] ... Typically a signoff could be issued with the teller id rather than the session token if the
                // client app crashes.
                // allow null token, teller_id to clear existing token; to allow new signon
                getSessionManager().endSession(SignonTypeEnum.TELLER.name(),
                        header.getAuthentication().getTellerCredentials().getUserId());
            } else if (getSessionManager().isValid(token)) {
                // log out even if invalid session state
                getSessionManager().endSession(token);
                ensureValidSessionState(header); // needed to ensure AIT is functioning correctly
            } else {
                //ProductionLogger.warn(this, "signoff - invalid session token");
                error = createErrorType(BIS_INVALID_TOKEN, BIS_INVALID_TOKEN, SeverityEnum.CRITICAL);
            }

            if (token != null) {
                getSessionManager().deleteSessionState(token);
            }
        } catch (IllegalArgumentException e) {
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), null, error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#openBranch(com.ncr.cxp.localassist.integration.dto.RqHeader,
     * com.ncr.cxp.localassist.integration.dto.OpenBranchRq)
     */
    //@Override
    public BISResult<OpenBranchRs> openBranch(final RqHeader header, OpenBranchRq request) {
        //ProductionLogger.warn(this, "openBranch - no implementation in product");

        return executeWithSessionTokenValidation(header, new BISCommand<OpenBranchRs>() {
            @Override
            public BISResult<OpenBranchRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new OpenBranchRs());
            }
        }, new OpenBranchRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#closeBranch(com.ncr.cxp.localassist.integration.dto.RqHeader
     * , com.ncr.cxp.localassist.integration.dto.CloseBranchRq)
     */
    //@Override
    public BISResult<CloseBranchRs> closeBranch(final RqHeader header, CloseBranchRq request) {
        //ProductionLogger.warn(this, "closeBranch - no implementation in product");

        return executeWithSessionTokenValidation(header, new BISCommand<CloseBranchRs>() {
            @Override
            public BISResult<CloseBranchRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new CloseBranchRs());
            }
        }, new CloseBranchRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#buySell(com.ncr.cxp.localassist.integration.dto.RqHeader,
     * com.ncr.cxp.localassist.integration.dto.CashAdjustmentRq)
     */
    //@Override
    public BISResult<CashAdjustmentRs> cashAdjustment(final RqHeader header, CashAdjustmentRq request) {
        //ProductionLogger.warn(this, "cashAdjustment - no implementation in product");

        return executeWithSessionTokenValidation(header, new BISCommand<CashAdjustmentRs>() {
            @Override
            public BISResult<CashAdjustmentRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new CashAdjustmentRs());
            }
        }, new CashAdjustmentRs());
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISAdmin#serviceInq(com.ncr.cxp.localassist.integration.dto.RqHeader,
     * com.ncr.cxp.localassist.integration.dto.ServiceInqRq)
     */
    //@Override
    public BISResult<ServiceInqRs> serviceInq(final RqHeader header, ServiceInqRq request) {
        //ProductionLogger.info(this, "serviceInq - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());
        ensureValidMsgSeqId(header);
        // *** ALP20140507 serviceInq() DOES NOT REQUIRE A TOKEN *** DOES NOT REQUIRE THAT connect() BE CALLED FIRST ***
        ServiceInqRs response = new ServiceInqRs();
        response.getServiceAvailability().addAll(services);

        ServiceState serviceState = new ServiceState();
        response.getServiceState().add(serviceState);
        serviceState.setServiceId(CORE_SERVICE);
        serviceState.setServiceStatus(ServiceStatusEnum.SIGNED_ON);

        return buildResult(header.getMsgSeqId(), null, null, response);
    }

    //@Override
    public BISResult<VerifySessionRs> verifySession(final RqHeader header, VerifySessionRq request) {
        //ProductionLogger.warn(this, "verifySession - no implementation in product");

        return executeWithSessionTokenValidation(header, new BISCommand<VerifySessionRs>() {
            @Override
            public BISResult<VerifySessionRs> execute() {
                return buildNotImplementedResult(header.getMsgSeqId(), null,
                        new VerifySessionRs());
            }
        }, new VerifySessionRs());
    }

}
