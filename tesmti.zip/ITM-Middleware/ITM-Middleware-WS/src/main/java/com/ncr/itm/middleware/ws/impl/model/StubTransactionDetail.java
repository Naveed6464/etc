package com.ncr.itm.middleware.ws.impl.model;

import java.math.BigDecimal;
import java.util.GregorianCalendar;

/**
 * @author ap185225
 * 
 */
public class StubTransactionDetail
{
    private final GregorianCalendar effectiveDate;
    private final GregorianCalendar postedDate;
    private final String transactionType;
    private final BigDecimal transactionAmount;
    private final BigDecimal balance;
    private final String description;
    private final String key1;
    private final String key2;
    private final String value1;
    private final String value2;

    /**
     * @param effectiveDate
     * @param postedDate
     * @param transactionType
     * @param transactionAmount
     * @param balance
     * @param description
     * @param key1
     * @param value1
     * @param key2
     * @param value2
     */
    public StubTransactionDetail( GregorianCalendar effectiveDate, GregorianCalendar postedDate,
            String transactionType, BigDecimal transactionAmount, BigDecimal balance, String description, String key1,
            String value1, String key2, String value2 )
    {
        this.effectiveDate = effectiveDate;
        this.postedDate = postedDate;
        this.transactionType = transactionType;
        this.transactionAmount = transactionAmount;
        this.balance = balance;
        this.description = description;
        this.key1 = key1;
        this.value1 = value1;
        this.key2 = key2;
        this.value2 = value2;
    }

    /**
     * @return the effectiveDate
     */
    public GregorianCalendar getEffectiveDate()
    {
        return effectiveDate;
    }

    /**
     * @return the postedDate
     */
    public GregorianCalendar getPostedDate()
    {
        return postedDate;
    }

    /**
     * @return the transactionType
     */
    public String getTransactionType()
    {
        return transactionType;
    }

    /**
     * @return the transactionAmount
     */
    public BigDecimal getTransactionAmount()
    {
        return transactionAmount;
    }

    /**
     * @return the balance
     */
    public BigDecimal getBalance()
    {
        return balance;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @return the key1
     */
    public String getKey1()
    {
        return key1;
    }

    /**
     * @return the key2
     */
    public String getKey2()
    {
        return key2;
    }

    /**
     * @return the value1
     */
    public String getValue1()
    {
        return value1;
    }

    /**
     * @return the value2
     */
    public String getValue2()
    {
        return value2;
    }

}
