package com.ncr.itm.middleware.ws.util;

/**
 * Abstracts the system clock
 *
 * @author Erich Eichinger
 * @since 03/09/12
 */
public interface SystemClock {

    /**
     * returns the current system time in milliseconds since 1970 midnight GMT
     *
     * @return the current system time
     */
    long getCurrentTimeMillis();
}
