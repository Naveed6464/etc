/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws;

import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.entities.RsHeader;
import java.util.Iterator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.dom.DOMSource;
import org.springframework.stereotype.Service;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Node;

/**
 *
 * @author naveed
 */
@Service
public class HeaderProcessor {

    public RqHeader handleRequestHeader(SoapHeader soapHeader)
            throws JAXBException {
        RqHeader rqHeader = null;

        Iterator<SoapHeaderElement> iter = soapHeader.examineAllHeaderElements();
        while (iter.hasNext()) {
            SoapHeaderElement element = (SoapHeaderElement) iter.next();
            if (element.getName().getLocalPart().equalsIgnoreCase("RqHeader")) {
                JAXBContext jaxbContext = JAXBContext.newInstance(new Class[]{RqHeader.class});
                Unmarshaller u = jaxbContext.createUnmarshaller();

                Node node = ((DOMSource) element.getSource()).getNode();

                rqHeader = (RqHeader) u.unmarshal(node);
            }
        }
        return rqHeader;
    }

    public void addResponseHeader(MessageContext messageContext, RsHeader header)
            throws JAXBException {
        if (header != null) {
            SoapMessage soapResponse = (SoapMessage) messageContext.getResponse();
            Marshaller m = JAXBContext.newInstance(new Class[]{RsHeader.class}).createMarshaller();
            m.marshal(header, soapResponse.getSoapHeader().getResult());
        }
    }
}
