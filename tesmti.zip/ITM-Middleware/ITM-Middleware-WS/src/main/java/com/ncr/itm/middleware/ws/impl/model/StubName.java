package com.ncr.itm.middleware.ws.impl.model;

/**
 * @author ap185225
 *
 */
public class StubName {

    private static final String NO_LAST_NAME = "Nolastname";

    private final String fullName;
    private final String firstName;
    private final String lastName;

    /**
     * Creates StubName by parsing a fullName
     *
     * @param fullName
     */
    public StubName(String fullName) {
        this.fullName = fullName;
        if (fullName == null) {
            this.firstName = null;
            this.lastName = null;
        } else {
            String[] names = fullName.split(" ");
            if (names.length > 1) {
                this.firstName = names[0];
                this.lastName = names[names.length - 1];
            } else if (NO_LAST_NAME.equalsIgnoreCase(names[0])) {
                // match Nusenda data
                this.firstName = names[0] + " Nusenda";
                this.lastName = "";
            } else {
                this.firstName = null;
                this.lastName = names[0];
            }
        }
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "StubName [fullName=" + fullName + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

}
