/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.ws.context;

import java.util.Map;

/**
 *
 * @author naveed
 */
public abstract interface SessionManager {

    public static final String CONTEXT_KEY_ID = "CONTEXT_KEY_ID";
    public static final String CONTEXT_KEY_CUSTOMER_ID = "CONTEXT_KEY_CUSTOMER_ID";

    public abstract String startSession(String paramString1, String paramString2);

    public abstract String startSession(String paramString1, String paramString2, String paramString3);

    public abstract void endSession(String paramString);

    public abstract void endSession(String paramString1, String paramString2);

    public abstract String getToken(String paramString1, String paramString2);

    public abstract boolean isValid(String paramString);

    public abstract boolean isValid(String paramString1, String paramString2);

    public abstract boolean startCustomerSession(String paramString1, String paramString2);

    public abstract void endCustomerSession(String paramString);

    public abstract boolean isCustomerSessionActive(String paramString);

    public abstract Map<String, String> obtainSessionContextData(String paramString);

    public abstract void storeSessionContextValue(String paramString1, String paramString2, String paramString3);

    public abstract String removeSessionContextValue(String paramString1, String paramString2);

    public abstract void reset();

    public abstract void putSessionState(String paramString, Map<String, String> paramMap);

    public abstract Map<String, String> getSessionState(String paramString);

    public abstract void deleteSessionState(String paramString);
}
