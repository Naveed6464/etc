package com.ncr.itm.middleware.ws.impl.converter;

import static com.ncr.cxp.branch.integration.schema.GoodCompletionEnum.OK;
import com.ncr.cxp.branch.integration.schema.MessageType;
import com.ncr.cxp.branch.integration.schema.TransactionCompletionResult;
import com.ncr.cxp.branch.integration.schema.TransactionCompletionResult.CompletionIssues;
import com.ncr.cxp.branch.integration.schema.TransactionStateEnum;
import com.ncr.cxp.branch.integration.schema.TransactionStatusType;
import com.ncr.itm.middleware.ws.impl.model.StubData;
import com.ncr.itm.middleware.ws.impl.model.StubFeeData;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionState;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionSubType;
import com.ncr.itm.middleware.ws.impl.model.StubTransaction.StubTransactionType;
import com.ncr.itm.middleware.ws.impl.model.StubTransactionCache;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import java.util.List;
import org.springframework.util.StringUtils;

// see com.ncr.cxp.localassist.integration.service.impl.converter.BISMessageConverter
/**
 * Base class for all StubBIS Message Converters
 *
 * @author ap185225
 */
public abstract class StubBaseTransactionConverter extends StubBISMessageConverter {

    static final String INVALID_TRANSACTION_STATE = "invalid transaction state: ";

    static final String TRANSACTION_ID = "; transactionId: ";

    static final String TRANSACTION = " transaction: ";

    // strings duplicated in StubBISBaseServiceImpl
    static final String SUB_TYPE_CASHCHEQUE = "CASHCHEQUE";

    static final String SUB_TYPE_PRINT_CHEQUE = "PRINTCHEQUE";

    static final String SUB_TYPE_SCAN_ITEM = "SCANITEM";

    /**
     * Condition code to indicate a fee is associated with a transaction
     */
    static final String BIS_CONDITION_FEE = "BIS_ACCEPT_FEES";

    /**
     * Condition code to indicate a review is needed
     */
    static final String BIS_CONDITION_REVIEW_ITEMS = "BIS_REVIEW_ITEMS";

    /**
     * Condition code to indicate General override conditions that the teller
     * must confirm
     */
    static final String BIS_CONDITION_GENERAL_OVERRIDE = "BIS_GENERAL_OVERRIDE";

    /**
     * Condition code to indicate all submitted items were denied
     */
    static final String BIS_CONDITION_ITEM_DENIED = "BIS_ITEM_DENIED";

    /**
     * Condition code to indicate all submitted items were denied
     */
    static final String BIS_CONDITION_ALL_ITEMS_DENIED = "BIS_ALL_ITEMS_DENIED";

    /**
     * Condition code to indicate insufficient funds
     */
    static final String BIS_CONDITION_INSUFFICIENT_FUNDS = "BIS_INSUFFICIENT_FUNDS";

    private final StubTransactionCache transactionCache;

    private final StubFeeData stubFeeData;

    /**
     * Constructs an instance of this class.
     *
     * @param stubData
     * @param stubFeeData
     * @param transactionCache
     */
    StubBaseTransactionConverter(final StubData stubData, final StubFeeData stubFeeData,
            final StubTransactionCache transactionCache) {
        super(stubData);
        this.transactionCache = transactionCache;
        this.stubFeeData = stubFeeData;
    }

    /**
     * @param stubTransaction
     * @param isReAuthorize
     * @param completionIssues
     * @return {@link TransactionStatusType}
     * @throws StubNotFoundException
     * @throws StubAccountClosedException
     */
    TransactionStatusType cancelStubTransaction(final StubTransaction stubTransaction, final boolean isReAuthorize,
            final CompletionIssues completionIssues) throws StubNotFoundException, StubAccountClosedException {
        if (stubTransaction.getState() == StubTransactionState.COMPLETED) {
            //ProductionLogger.warn(this, "cannot cancel completed transaction, use reverse instead; transactionId: " + stubTransaction.getTransactionId());
            throw new IllegalStateException("cannot cancel completed transaction; use reverse instead");
        }
        TransactionStatusType transactionStatusType;

        if (stubTransaction.getState() == StubTransactionState.AUTHORIZED) {
            // roll back change to account balance
            this.stubData.cancelTransaction(stubTransaction);
        }
        this.transactionCache.remove(stubTransaction.getTransactionId());
        transactionStatusType = convertTransactionStatusType(TransactionStateEnum.AUTHORISED, null, null);

        if (!isReAuthorize) {
            //ProductionLogger.info(this,stubTransaction.getType().name() + " transaction canceled: " + stubTransaction.getTransactionId());
            if (completionIssues != null) {
                if (completionIssues.getCancellationReason() != null) {
                    //ProductionLogger.info(this, completionIssues.getCancellationReason());
                } else {
                    //ProductionLogger.info(this, completionIssues.getReversalReason());
                }
            }
        }

        return transactionStatusType;
    }

    public StubTransactionState checkCompleteMagicNumbers(final StubTransaction stubTransaction) {
        StubTransactionState state = StubTransactionState.COMPLETED;

        if (((stubTransaction.getRequestAmount().compareTo(StubTransaction.COMPLETE_DENIED_AMOUNT) == 0) || (stubTransaction
                .getAdjustmentAmount().compareTo(StubTransaction.COMPLETE_DENIED_ADJUSTED_AMOUNT) == 0))
                && (!stubTransaction.hasOverrideReason())) {
            state = StubTransactionState.DENIED_FOR_TESTING;
        } else if (((stubTransaction.getRequestAmount().compareTo(StubTransaction.COMPLETE_TELLER_OVERRIDE_AMOUNT) == 0) || (stubTransaction
                .getAdjustmentAmount().compareTo(StubTransaction.COMPLETE_TELLER_OVERRIDE_ADJUSTED_AMOUNT) == 0))
                && (!stubTransaction.hasOverrideReason())) {
            state = StubTransactionState.TELLER_OVERRIDE;
        } else if (((stubTransaction.getRequestAmount()
                .compareTo(StubTransaction.TELLER_OVERRIDE_VALIDATE_REASON_ON_COMPLETE_AMOUNT) == 0) || (stubTransaction
                .getAdjustmentAmount()
                .compareTo(StubTransaction.TELLER_OVERRIDE_VALIDATE_REASON_ON_COMPLETE_ADJUSTED_AMOUNT) == 0))
                && (!"123".equals(stubTransaction.getOverrideReason()))) {
            state = StubTransactionState.TELLER_OVERRIDE;
        }

        return state;
    }

    /**
     * @param stubTransaction
     * @return {@link TransactionStatusType}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    private TransactionStatusType completeStubTransaction(final StubTransaction stubTransaction)
            throws StubNotFoundException, StubAccountClosedException {
        if (stubTransaction.getState() != StubTransactionState.AUTHORIZED) {
            //ProductionLogger.warn(this, INVALID_TRANSACTION_STATE + stubTransaction.getState().name() + TRANSACTION_ID + stubTransaction.getTransactionId());
            throw new IllegalStateException("transaction state is not " + StubTransactionState.AUTHORIZED.toString()
                    + ": " + stubTransaction.getState());
        }

        TransactionStatusType transactionStatusType;

        // enable Teller Enterprise testing
        StubTransactionState state = checkCompleteMagicNumbers(stubTransaction);
        if (state == StubTransactionState.COMPLETED) {
            this.stubData.completeTransaction(stubTransaction);
            stubTransaction.setState(StubTransactionState.COMPLETED);
            transactionStatusType = convertTransactionStatusType(TransactionStateEnum.AUTHORISED, null, null);
            //ProductionLogger.info(this, stubTransaction.getType().name() + " transaction completed: "+ stubTransaction.getTransactionId());
            assert ((stubTransaction.getState() == StubTransactionState.COMPLETED));
        } else {
            // prevents balance adjustment on re-authorize; not needed anyway; stubTransaction.setState( state );
            switch (state) {
                case DENIED_FOR_TESTING:
                    transactionStatusType = convertTransactionStatusType(TransactionStateEnum.DENIED, null, null);
                    break;

                case TELLER_OVERRIDE:
                    transactionStatusType = convertTransactionStatusType(TransactionStateEnum.TELLER_OVERRIDE, null,
                            null);
                    break;

                default:
                    transactionStatusType = convertTransactionStatusType(TransactionStateEnum.DENIED, null, null);
            }
            assert ((stubTransaction.getState() == StubTransactionState.AUTHORIZED));
            // || ( stubTransaction.getState() == StubTransactionState.DENIED_FOR_TESTING )
            // || ( stubTransaction.getState() == StubTransactionState.TELLER_OVERRIDE ) );
        }
        assert ((stubTransaction.getState() == StubTransactionState.COMPLETED) || (stubTransaction.getState() == StubTransactionState.AUTHORIZED));

        return transactionStatusType;
    }

    /**
     * @param transactionId
     * @param type
     * @param transactionCompletionResult
     * @return {@link TransactionStatusType}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    TransactionStatusType completeTransaction(final String transactionId, final StubTransactionType type,
            final TransactionCompletionResult transactionCompletionResult) throws StubNotFoundException,
            StubAccountClosedException {
        //ProductionLogger.info(this, "completing " + type + TRANSACTION + transactionId);
        StubTransaction stubTransaction = getStubTransaction(transactionId, type);
        TransactionStatusType transactionStatusType;

        // leave this code as is; this follows spec; need to fix spec
        if (transactionCompletionResult.getGoodCompletion() != null) {
            switch (transactionCompletionResult.getGoodCompletion()) {
                case OK:
                    transactionStatusType = completeStubTransaction(stubTransaction);

                    break;

                // case CUSTOMERCANCELLED
                // case DENIED // *** TODO *** WHAT DOES THIS MEAN? ***
                default:
                    transactionStatusType = cancelStubTransaction(stubTransaction, false, null);
                    // GM: Added to check if AIT supports teller override at complete withdrawal response
                    // transactionStatusType = convertTransactionStatusType(TransactionStateEnum.TELLER_OVERRIDE, null,
                    // null);
                    break;
            }
        } else {
            transactionStatusType = cancelStubTransaction(stubTransaction, false,
                    transactionCompletionResult.getCompletionIssues());
        }

        return transactionStatusType;
    }

    /**
     * @param state
     * @param condition
     * @param tellerMessageId
     * @return {@link TransactionStatusType}
     */
    static TransactionStatusType convertTransactionStatusType(final TransactionStateEnum state, final String condition,
            final List<MessageType> tellerMessages) {
        TransactionStatusType transactionStatusType = new TransactionStatusType();

        transactionStatusType.setTransactionState(state);
        transactionStatusType.setCondition(condition);

        if ((tellerMessages != null) && (tellerMessages.size() > 0)) {
            // optional; messages to be displayed to teller, especially if transaction was denied or requires an
            // override
            transactionStatusType.getTellerMessage().addAll(tellerMessages);
        }

        // optional; messages to be displayed to customer, especially. if transaction was denied or requires an override
        // transactionStatusType.getCustomerMessages().add( e ); // NOSONAR
        return transactionStatusType;
    }

    /**
     * @param subType
     * @return
     */
    StubTransactionSubType convertTransactionSubType(final String subType) {
        StubTransactionSubType transactionSubType = null;

        if (StringUtils.hasLength(subType)) {
            if (subType.equalsIgnoreCase(SUB_TYPE_CASHCHEQUE)) {
                transactionSubType = StubTransactionSubType.CASH_CHEQUE;
            } else if (subType.equalsIgnoreCase(SUB_TYPE_PRINT_CHEQUE)) {
                transactionSubType = StubTransactionSubType.PRINT_CHEQUE;
            } else if (subType.equalsIgnoreCase(SUB_TYPE_SCAN_ITEM)) {
                transactionSubType = StubTransactionSubType.SCAN;
            } else {
                //ProductionLogger.warn(this, "Unsupported transaction subType: " + subType);
            }
        }

        return transactionSubType;
    }

    /**
     * @return the stubFeeData
     */
    StubFeeData getStubFeeData() {
        return this.stubFeeData;
    }

    /**
     * @return the transactionCache
     */
    StubTransactionCache getTransactionCache() {
        return this.transactionCache;
    }

    /**
     * @param transactionId
     * @param type
     * @return {@link StubTransaction}
     */
    StubTransaction getStubTransaction(final String transactionId, final StubTransactionType type) {
        StubTransaction stubTransaction = this.transactionCache.get(transactionId);
        if (stubTransaction == null) {
            //ProductionLogger.warn(this, "Referenced transactionId does not exist: " + transactionId);
            throw new IllegalArgumentException("Referenced transactionId does not exist: " + transactionId);
        } else if (stubTransaction.getType() != type) {
            //ProductionLogger.warn(this, "Referenced transactionId is wrong type (" + stubTransaction.getType().name()+ ":" + type.name() + ") for this request: " + transactionId);
            throw new IllegalStateException("Referenced transactionId is wrong type for this request: "
                    + type.toString());
        }

        return stubTransaction;
    }

    /**
     * @param transactionId
     * @param type
     * @return {@link TransactionStatusType}
     * @throws StubAccountClosedException
     * @throws StubNotFoundException
     */
    TransactionStatusType reverseTransaction(final String transactionId, final StubTransactionType type)
            throws StubNotFoundException, StubAccountClosedException {
        //ProductionLogger.info(this, "reversing " + type + TRANSACTION + transactionId);
        StubTransaction stubTransaction = getStubTransaction(transactionId, type);
        TransactionStatusType transactionStatusType;

        if (stubTransaction.getState() != StubTransactionState.COMPLETED) {
            //ProductionLogger.warn(this, INVALID_TRANSACTION_STATE + stubTransaction.getState().name() + TRANSACTION_ID + stubTransaction.getTransactionId());
            throw new IllegalStateException("transaction state is not " + StubTransactionState.COMPLETED.toString()
                    + ": " + stubTransaction.getState());
        }

        // roll back change to account balance
        this.stubData.reverseTransaction(stubTransaction);
        this.transactionCache.remove(stubTransaction.getTransactionId());
        transactionStatusType = convertTransactionStatusType(TransactionStateEnum.AUTHORISED, null, null);
        //ProductionLogger.info(this, stubTransaction.getType().name() + " transaction reversed: "+ stubTransaction.getTransactionId());

        return transactionStatusType;
    }

}
