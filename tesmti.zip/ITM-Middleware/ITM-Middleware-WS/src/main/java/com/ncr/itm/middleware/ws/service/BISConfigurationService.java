package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.GetConfigurationRq;
import com.ncr.cxp.branch.integration.schema.GetConfigurationRs;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.cxp.branch.integration.schema.SupportType;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.impl.converter.BuildInformation;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BISConfigurationService extends StubBISBaseServiceImpl {

    private static final String CONFIGURATION_IS_SAME_AS_PREVIOUS_REQUEST = "configuration is same as previous request";
    private final URL config;

    /**
     * Creates a new BISConfigurationImpl with the supplied configuration input
     * source
     *
     * @param sessionManager
     * @param config
     */
    @Autowired
    public BISConfigurationService(SessionManager sessionManager, URL config) {
        super(sessionManager);
        this.config = config;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISConfiguration#getConfiguration(com.ncr.cxp.localassist.integration
     * .dto.RqHeader, com.ncr.cxp.localassist.integration.dto.GetConfigurationRq)
     */
    //@Override
    public BISResult<GetConfigurationRs> getConfiguration(RqHeader header, GetConfigurationRq request) {
        //ProductionLogger.info( this, "getConfiguration - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId() );
        String currentVersion = request.getCurrentVersion();

        BISResult<GetConfigurationRs> result = parseConfig(header, new GetConfigurationRs());

        if ((currentVersion != null) && (currentVersion.equals(result.getResponse().getVersion()))) {
            //ProductionLogger.warn(this, "getConfiguration - " + CONFIGURATION_IS_SAME_AS_PREVIOUS_REQUEST);
            result = buildResult(header.getMsgSeqId(), null,
                    createErrorType(BIS_NO_CHANGE, CONFIGURATION_IS_SAME_AS_PREVIOUS_REQUEST, SeverityEnum.WARNING),
                    new GetConfigurationRs());
        }

        return result;
    }

    /**
     * Loads a configuration file based on the Type of the defaultResponse
     * parameter
     *
     * @param header
     * @param defaultResponse
     * @return BISResult including the configuration response
     */
    protected BISResult<GetConfigurationRs> parseConfig(RqHeader header, GetConfigurationRs defaultResponse) {
        ErrorType error = null;
        GetConfigurationRs response = defaultResponse;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(defaultResponse.getClass());
            Unmarshaller u = jaxbContext.createUnmarshaller();
            response = (GetConfigurationRs) u.unmarshal(this.config);

            // set service version numbers at runtime from version embedded in each interface
            Map<String, String> serviceMap = BuildInformation.getServiceVersionMap();
            List<SupportType.Services.Service> services = response.getSupportedServices().getServices().getService();
            for (SupportType.Services.Service service : services) {
                String version = serviceMap.get(service.getServiceName().getLocalPart());

                if (version != null) {
                    service.setVersion(version);
                }
            }
        } catch (JAXBException e) {
            //ProductionLogger.warn(this, e.getMessage(), e);
            error = new ErrorType();
            error.setErrorCode(BIS_UNKNOWN_ERROR);
            error.setSeverity(SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), null, error, response);
    }

}
