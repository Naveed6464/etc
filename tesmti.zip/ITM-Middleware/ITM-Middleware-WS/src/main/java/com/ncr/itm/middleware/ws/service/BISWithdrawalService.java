package com.ncr.itm.middleware.ws.service;

import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.AuthoriseWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.CompleteWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.ErrorType;
import com.ncr.cxp.branch.integration.schema.ReverseWithdrawalRqType;
import com.ncr.cxp.branch.integration.schema.ReverseWithdrawalRsType;
import com.ncr.cxp.branch.integration.schema.SeverityEnum;
import com.ncr.itm.middleware.ws.context.SessionManager;
import com.ncr.itm.middleware.ws.entities.BISResult;
import com.ncr.itm.middleware.ws.entities.RqHeader;
import com.ncr.itm.middleware.ws.impl.converter.StubBISWithdrawalMessageConverter;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubAccountClosedException;
import com.ncr.itm.middleware.ws.impl.model.exceptions.StubNotFoundException;
import com.ncr.itm.middleware.ws.util.Ensure;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Implementation of BIS Withdrawal Service Interface
 *
 * @author ap185225
 */
@Service
public class BISWithdrawalService extends StubBISBaseServiceImpl {

    private final StubBISWithdrawalMessageConverter converter;

    /**
     * Constructs a new instance of the class.
     *
     * @param sessionManager
     * @param converter
     */
    @Autowired
    public BISWithdrawalService(SessionManager sessionManager, StubBISWithdrawalMessageConverter converter) {
        super(sessionManager);
        this.converter = converter;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISWithdrawal#authoriseWithdrawal(com.ncr.cxp.localassist.integration
     * .dto.RqHeader, com.ncr.cxp.localassist.integration.dto.AuthoriseWithdrawalRq)
     */
    //@Override
    public BISResult<AuthoriseWithdrawalRsType> authoriseWithdrawal(final RqHeader header, final AuthoriseWithdrawalRqType request) {
        //ProductionLogger.info(this, "authoriseWithdrawal - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<AuthoriseWithdrawalRsType>() {
            @Override
            public BISResult<AuthoriseWithdrawalRsType> execute() {
                return doAuthoriseWithdrawal(header, request);
            }
        }, new AuthoriseWithdrawalRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<AuthoriseWithdrawalRsType> doAuthoriseWithdrawal(RqHeader header, AuthoriseWithdrawalRqType request) {
        String token = header.getAuthentication().getSessionToken();
        Ensure.notNull(request, "AuthoriseWithdrawalRq");
        Ensure.notNull(request.getWithdrawalInfo(), "WithdrawalInfoType");
        // *** TODO *** REPLACE FOLLOWING THREE TESTS IF NON-MEMBER PRINT CHECK SUPPORTS NULL ACCOUNT ***
        // Ensure.isTrue( CustomerIdEnum.HOSTCUSTOMERID.name().equals( getCustomerIdType( token ) ),
        // "CustomerIdEnum" )
        Ensure.isTrue((request.getWithdrawalInfo().getTransactionType() == null)
                || SUB_TYPE_PRINT_CHEQUE.equalsIgnoreCase(request.getWithdrawalInfo().getTransactionType()),
                "TransactionType");
        Ensure.notNull(request.getWithdrawalInfo().getAccount(), "AccountKeyType");
        // account can be null for print check subtype (non-member transaction)
        // Ensure.isTrue(
        // ( ( ( request.getWithdrawalInfo().getAccount() != null )
        // && CustomerIdEnum.HOSTCUSTOMERID.name().equals( getCustomerIdType( token ) ) ) )
        // || ( ( request.getWithdrawalInfo().getAccount() == null )
        // && CustomerIdEnum.ANONYMOUS.name().equals( getCustomerIdType( token ) ) ),
        // "AccountKeyType" )
        // Ensure.isTrue(
        // CustomerIdEnum.HOSTCUSTOMERID.name().equals( getCustomerIdType( token ) )
        // || ( SUB_TYPE_PRINT_CHEQUE.equalsIgnoreCase( request.getWithdrawalInfo().getTransactionType() ) ),
        // "TransactionType" )
        // ???
        // Ensure.isTrue(
        // CustomerIdEnum.ANONYMOUS.name().equals( getCustomerIdType( token ) )
        // || ( request.getWithdrawalInfo().getTransactionType() == null )
        // || ( SUB_TYPE_PRINT_CHEQUE.equalsIgnoreCase( request.getWithdrawalInfo().getTransactionType() ) ),
        // "TransactionType" )

        Ensure.notNull(request.getWithdrawalInfo().getAmount(), "AmountType");
        Ensure.isTrue(request.getWithdrawalInfo().getAmount().getValue().compareTo(BigDecimal.ZERO) > 0,
                "AmountType");
        ErrorType error = null;
        AuthoriseWithdrawalRsType response = new AuthoriseWithdrawalRsType();

        try {
            response = converter.createAuthorizeWithdrawalResponse(request, token, getCustomerId(token),
                    getCustomerIdType(token));
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), token, error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISWithdrawal#completeWithdrawal(com.ncr.cxp.localassist.integration
     * .dto.RqHeader, com.ncr.cxp.localassist.integration.dto.CompleteWithdrawalRq)
     */
    //@Override
    public BISResult<CompleteWithdrawalRsType> completeWithdrawal(final RqHeader header, final CompleteWithdrawalRqType request) {
        //ProductionLogger.info(this, "completeWithdrawal - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<CompleteWithdrawalRsType>() {
            @Override
            public BISResult<CompleteWithdrawalRsType> execute() {
                return doCompleteWithdrawal(header, request);
            }
        }, new CompleteWithdrawalRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<CompleteWithdrawalRsType> doCompleteWithdrawal(RqHeader header, CompleteWithdrawalRqType request) {
        Ensure.notNull(request.getTransactionId(), "transactionId");
        Ensure.isTrue(
                (request.getWithdrawalCompletionInfo().getTransactionCompletionResult().getGoodCompletion() != null)
                || ((request.getWithdrawalCompletionInfo().getTransactionCompletionResult().getCompletionIssues() != null)
                && ((request.getWithdrawalCompletionInfo().getTransactionCompletionResult().getCompletionIssues().getCancellationReason() != null)
                || (request.getWithdrawalCompletionInfo().getTransactionCompletionResult().getCompletionIssues().getReversalReason() != null))),
                "TransactionCompletionResult");

        ErrorType error = null;
        CompleteWithdrawalRsType response = new CompleteWithdrawalRsType();

        try {
            response = converter.createCompleteWithdrawalResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ncr.cxp.localassist.integration.service.BISWithdrawal#reverseWithdrawal(com.ncr.cxp.localassist.integration
     * .dto.RqHeader, com.ncr.cxp.localassist.integration.dto.ReverseWithdrawalRq)
     */
    //@Override
    public BISResult<ReverseWithdrawalRsType> reverseWithdrawal(final RqHeader header, final ReverseWithdrawalRqType request) {
        //ProductionLogger.info(this, "reverseWithdrawal - AIT Stub implementation, MsgSeqId: " + header.getMsgSeqId());

        return executeWithCustomerSessionValidation(header, new BISCommand<ReverseWithdrawalRsType>() {
            @Override
            public BISResult<ReverseWithdrawalRsType> execute() {
                return doReverseWithdrawal(header, request);
            }
        }, new ReverseWithdrawalRsType());
    }

    /**
     * @param header
     * @param request
     * @return
     */
    private BISResult<ReverseWithdrawalRsType> doReverseWithdrawal(RqHeader header, ReverseWithdrawalRqType request) {
        Ensure.notNull(request, "ReverseWithdrawalRq");
        Ensure.notNull(request.getTransactionId(), "transactionId");
        ErrorType error = null;
        ReverseWithdrawalRsType response = new ReverseWithdrawalRsType();

        try {
            response = converter.createReverseWithdrawalResponse(request);
        } catch (StubNotFoundException e) // NOSONAR
        {
            // account not found
            error = createErrorType(BIS_NOT_FOUND, e.getMessage(), SeverityEnum.ERROR);
        } catch (StubAccountClosedException e) // NOSONAR
        {
            // account closed
            error = createErrorType(BIS_BAD_REQUEST, e.getMessage(), SeverityEnum.ERROR);
        }

        return buildResult(header.getMsgSeqId(), getSessionTokenFromRequest(header), error, response);
    }

}
