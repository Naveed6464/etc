/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.naveed.demo.web.servlets;

import com.google.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.inject.Singleton;
import javax.servlet.ServletConfig;
import javax.xml.ws.Endpoint;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

/**
 *
 * @author Naveedur Rahman
 * @since Oct 1, 2019
 * @version 1.0
 *
 */
@Singleton
public class WebServiceServlet extends CXFNonSpringServlet {

    private List<String> packages = new ArrayList<>();
    HelloWebService helloWebService;
    HelloWebService2 helloWebService2;
    
    @Inject
    public WebServiceServlet(HelloWebService helloWebService, HelloWebService2 helloWebService2) {
        this.helloWebService = helloWebService;
        this.helloWebService2 = helloWebService2;
    }

    @Override
    protected void loadBus(ServletConfig sc) {
        super.loadBus(sc);
//        BusFactory.setDefaultBus(getBus());
        Endpoint.publish("/hello", helloWebService);
        Endpoint.publish("/hello2", helloWebService2);
    }
    
    
//    private void componenScan() {
//        try {
//            List<Class<?>> modules = new ArrayList<>();
//            ClassGraph classGraph = new ClassGraph().enableAnnotationInfo().whitelistPackages("com.technas");
//            try (ScanResult scanResult = classGraph.scan()) {
//                modules = scanResult.getClassesWithAnnotation(TechnasComponentScan.class.getCanonicalName()).loadClasses();
//            } catch (Exception ex) {
//                ex.printStackTrace();
//                log.error("Exception on Class Graph Error " + ex);
//            }
//            componenScan(modules);
//        } catch (Exception e) {
//            e.printStackTrace();
//            log.error("Component Scan Exception " + e);
//        }
//    }
//
//    private void componenScan(List<Class<?>> modules) {
//        for (Class cls : modules) {
//            TechnasComponentScan moduleScan = (TechnasComponentScan) cls.getAnnotation(TechnasComponentScan.class);
//            this.packages.addAll(Arrays.asList(moduleScan.webservices()));
//        }
//    }
//
//    @Override
//    protected void loadBus(ServletConfig sc) {
//        super.loadBus(sc);
//        List<Class<?>> webservices = new ArrayList<>();
//        ClassGraph classGraph = new ClassGraph().enableAnnotationInfo().whitelistPackages(packages.toArray(new String[packages.size()]));
//        try (ScanResult scanResult = classGraph.scan()) {
//            webservices = scanResult.getClassesWithAnnotation(WSComponent.class.getCanonicalName()).loadClasses();
//        } catch (Exception ex) {
//            ex.printStackTrace();
//            log.error("Exception on Class Graph Error " + ex);
//        }
//        for (Class cls : webservices) {
//            log.info("Binding Webservice " + cls.getName());
//            WSComponent wsService = (WSComponent) cls.getAnnotation(WSComponent.class);
//            if (wsService.path() != null && !wsService.path().isEmpty()) {
//                Endpoint.publish("/" + wsService.path(), injector.getInstance(cls));
//            }
//        }
//    }
}