package com.naveed.demo.web.config;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.servlet.GuiceFilter;
import com.google.inject.servlet.ServletModule;
import com.naveed.demo.web.servlets.HelloServlet;
import java.util.Set;
import javax.servlet.FilterRegistration;
import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import javax.servlet.annotation.HandlesTypes;

/**
 *
 * @author Naveedur Rahman
 * @since Oct 4, 2016
 * @version 1.0
 *
 */
//@HandlesTypes(WebApplicationInitializer.class)
public class WebConfig implements ServletContainerInitializer {

    @Override
    public void onStartup(Set<Class<?>> set, ServletContext servletContext) throws ServletException {
        System.out.println(">>>>>>>>>>>>> Container Intializer!");
        servletContext.addFilter("guiceFilter", GuiceFilter.class).addMappingForUrlPatterns(null, true, "/*");
        Guice.createInjector(new AppModule());
    }

}
