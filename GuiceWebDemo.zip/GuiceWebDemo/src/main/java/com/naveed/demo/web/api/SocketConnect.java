/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.demo.web.api;

/**
 *
 * @author naveedur
 */
import java.io.*;
import java.net.Socket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SocketConnect {

    Socket soc;
    OutputStream out;
    DataOutputStream dout;
    BufferedReader reader;

    private final static Logger log = LoggerFactory.getLogger(SocketConnect.class);

    private static SocketConnect conect = new SocketConnect();

    public static SocketConnect getInstance() {
        return conect;
    }

    //ATTProperties property = ATTProperties.getInstance();

    private SocketConnect() {
        try {
            //soc = new Socket(property.getHostName(), property.getOFS_SOCKET_PORT());
            //Todo inject host name and port
            out = soc.getOutputStream();
            dout = new DataOutputStream(out);
            reader = new BufferedReader(new InputStreamReader(soc.getInputStream()));
            System.out.println(reader.readLine());
            System.out.println(reader.readLine());
            System.out.println(reader.readLine());
            dout.write("Request\n".getBytes());
            System.out.println(reader.readLine());
        } catch (Exception e) {
            System.out.println("Error " + e.toString());
        }
    }

    public String socketCall(String arg) {
        String subVal = "";
        try {
            dout.write("Request\n".getBytes());
            subVal = reader.readLine().toString();
            dout.write(arg.getBytes());
            subVal = reader.readLine().toString();
        } catch (Exception e) {
            subVal = "Error";
        }
        return subVal;
    }

    public static void main(String[] args) {
        SocketConnect sc = new SocketConnect();
        sc.socketCall("ENQUIRY.SELECT,,INPUTT/654321,TM.DAILY.REPORT.ATTV2,PROCESS.DATE:EQ=20111215\n");
        sc.socketCall("ENQUIRY.SELECT,,INPUTT/654321,TM.DAILY.REPORT.ATTV2,PROCESS.DATE:EQ=20111215\n");
        String res = sc.socketCall("ENQUIRY.SELECT,,INPUTT/654321,TM.DAILY.REPORT.ATTV2,PROCESS.DATE:EQ=20111215\n");
        System.out.println(" " + res);
        FileWriter outFile;
        try {
            outFile = new FileWriter("C:/TestOFs.txt");
            outFile.write(res);
            outFile.close();
        } catch (IOException ex) {
            log.error("" + ex);
        }
    }
}
