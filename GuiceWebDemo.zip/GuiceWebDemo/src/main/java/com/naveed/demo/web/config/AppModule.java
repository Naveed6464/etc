/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.naveed.demo.web.config;

import com.google.inject.servlet.ServletModule;
import com.naveed.demo.web.servlets.HelloServlet;
import com.naveed.demo.web.servlets.WebServiceServlet;

/**
 *
 * @author Naveedur Rahman
 * @since Oct 1, 2019
 * @version 1.0
 *
 */
public class AppModule extends ServletModule {
    
    
    
     @Override
     protected void configureServlets() {
         System.out.println(">>>>>>>>> configure servlets");
       serve("/api/*").with(HelloServlet.class);
       serve("/ws/*").with(WebServiceServlet.class);
     }

}
