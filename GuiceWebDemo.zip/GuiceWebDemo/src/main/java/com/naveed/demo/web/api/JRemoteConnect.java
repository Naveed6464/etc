/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.demo.web.api;

import com.jbase.jremote.*;
import java.io.FileWriter;
import javax.inject.Inject;
import javax.inject.Singleton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Naveedur Rahman
 * @since Mar 15, 2017
 * @version 1.0
 *
 */
@Singleton
public class JRemoteConnect {

    private final Logger log = LoggerFactory.getLogger(JRemoteConnect.class);

    int invoketry = 3;
    public static int invokeCount = 0;

    static JConnection cx = null;

    public void JRConnect() {
        try {
            DefaultJConnectionFactory cxf = new DefaultJConnectionFactory();
            //Todo
            cxf.setHost("10.0.0.7");
            cxf.setPort(20005);      //Port should match the port jAgent is listening on
            //cxf.useSSL(true)
            cx = cxf.getConnection("R11", "R11");
            //JStatement js = cx.createStatement();            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized String JRemInvokeFast(String arg) {
        if (invokeCount == 0) {
            JRConnect();
            invokeCount++;
        }
        String subVal = "";
        try {
            String[] args = arg.split(" ");
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray(args[1]));
            params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call(args[0] + ".JREM", params);
            subVal = returnParams.get(1).get(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (subVal.contains("<MI-II>")) {
            subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
            log.info("JremoteInvokeFast: (" + arg + ") " + subVal);
        } else {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. Invoke Fast." + arg + " Val " + subVal);
        }
        return subVal;
    }

    public synchronized String JRemCall(String routine, String arg, String host, int port, String user, String pwd) throws JRemoteException {
        DefaultJConnectionFactory cxf = new DefaultJConnectionFactory();
        cxf.setHost(host);
        cxf.setPort(port);      //Port should match the port jAgent is listening on
        String subVal = "";
        cx = cxf.getConnection(user, pwd);//This not required
        //JStatement js = cx.createStatement();
        try {
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray(arg));
            //params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call(routine, params);
            if (returnParams != null) {
                String res_all = returnParams.toString();
                int res_length = res_all.length();
                // remove "["... "]"
                System.out.println(res_all.substring(4, res_length - 1));
                subVal = res_all.substring(4, res_length - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return subVal;
    }

    public synchronized String JRemCall(String routine,String host, int port, String user, String pwd,  String... args) {
        String subVal = "";
        try {
            DefaultJConnectionFactory cxf = new DefaultJConnectionFactory();
            cxf.setHost(host);
            cxf.setPort(port);      //Port should match the port jAgent is listening on
            cx = cxf.getConnection(user, pwd);//This not required
            //JStatement js = cx.createStatement();
            JSubroutineParameters params = new JSubroutineParameters();
            for (String arg : args) {
                params.add(new JDynArray(arg));
            }
            //params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call(routine, params);
            if (returnParams != null) {
                String res_all = returnParams.toString();
                int res_length = res_all.length();
                // remove "["... "]"
                System.out.println(res_all.substring(4, res_length - 1));
                subVal = res_all.substring(4, res_length - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }
        return subVal;
    }

    public synchronized String JRemCall2(String routine, String arg) {
        if (invokeCount == 0) {
            JRConnect();
            invokeCount++;
        }
        String subVal = "";
        try {
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray(arg));
            params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call(routine, params);
            subVal = returnParams.get(1).get(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (subVal.contains("<MI-II>")) {
            subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
        } else {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
        }
        return subVal;
    }

    public synchronized String JRemUserAuth(String user, String pass) {
        if (invokeCount == 0) {
            JRConnect();
            invokeCount++;
        }
        String subVal = "";
        try {
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray(user));
            params.add(new JDynArray(pass));
            JSubroutineParameters returnParams = cx.call("ATT.CHECK.VALID.USER", params);
            subVal = returnParams.get(1).get(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return subVal;
    }

    public String getBankGroupList() {

        String subVal = "";
        try {
            if (invokeCount == 0) {
                JRConnect();
                invokeCount++;
            }
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray("BANK.LIST"));
            params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call("ATT.GET.BANK.PRODUCT.DETAILS.JREM", params);
            subVal = returnParams.get(1).get(1);
            if (subVal.contains("<MI-II>")) {
                subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
                JSubroutineParameters params2 = new JSubroutineParameters();
                params2.add(new JDynArray("GROUP.EVENT.LIST"));
                params2.add(new JDynArray("two"));
                JSubroutineParameters returnParams2 = cx.call("ATT.GET.BANK.PRODUCT.EVENT.DET.JREM", params2);
                String newsubVal = returnParams2.get(1).get(1);
                newsubVal = newsubVal.substring(newsubVal.indexOf("<MI-II>") + 7, newsubVal.indexOf("</MI-II>"));
                subVal = subVal + "#" + newsubVal;
            }
        } catch (Exception e) {
            e.printStackTrace();
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. Bank List -Val " + subVal);
        }
        return subVal;
    }

    public String JRemInvoke(String arg) {

        String subVal = "";
        int inc = 0;
        do {
            try {
                if (invokeCount == 0) {
                    JRConnect();
                    invokeCount++;
                }
                String[] args = arg.split(" ");
                JSubroutineParameters params = new JSubroutineParameters();
                params.add(new JDynArray(args[1]));
                params.add(new JDynArray("two"));
                JSubroutineParameters returnParams = cx.call(args[0] + ".JREM", params);
                subVal = returnParams.get(1).get(1);
                log.info("JremoteInvoke: (" + arg + ") " + subVal);
            } catch (Exception e) {
                e.printStackTrace();
                invokeCount = 0;
            }
            inc++;
            if (inc == invoketry) {
                break;
            }
        } while (!subVal.contains("<MI-II>"));
        if (!subVal.contains("<MI-II>")) {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. JRemInvoke " + arg + " Val " + subVal);
        }
        return subVal;
    }

    public String JRemCOBExpected(String arg) {
        String subVal = "";
        int inc = 0;
        do {
            try {
                if (invokeCount == 0) {
                    JRConnect();
                    invokeCount++;
                }
                String[] args = arg.split(" ");
                JSubroutineParameters params = new JSubroutineParameters();
                params.add(new JDynArray(args[1]));
                params.add(new JDynArray("two"));
                JSubroutineParameters returnParams = cx.call(args[0], params);
                subVal = returnParams.get(1).get(1);
                log.info("JRemCOBExpected : (" + arg + ") " + subVal);
            } catch (Exception e) {
                e.printStackTrace();
                invokeCount = 0;
            }
            inc++;
            if (inc == invoketry) {
                break;
            }
        } while (!subVal.contains("<MI-II>"));
        if (!subVal.contains("<MI-II>")) {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. JRemCOBExpected " + arg + " Val " + subVal);
        }
        return subVal;
    }

    public String invokeExpected(String arg) {
        invokeCount = 0;
        String subVal = "";
        try {
            JRConnect();
            String[] args = arg.split(" ");
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray(args[1]));
            params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call(args[0] + ".JREM", params);
            subVal = returnParams.get(1).get(1);
            log.info("InvokeExpected: (" + arg + ") Result: " + subVal);
            System.out.println("InvokeExpected: (" + arg + ") Result: " + subVal);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return subVal;
    }

    public String invokeJRemote(String arg) {
        invokeCount = 0;
        String subVal = "";
        int inc = 0;
        do {
            try {
                if (invokeCount == 0) {
                    JRConnect();
                    invokeCount++;
                }
                String[] args = arg.split(" ");
                JSubroutineParameters params = new JSubroutineParameters();
                params.add(new JDynArray(args[1]));
                params.add(new JDynArray("two"));
                JSubroutineParameters returnParams = cx.call(args[0] + ".JREM", params);
                subVal = returnParams.get(1).get(1);
                log.info("InvokeJremote: (" + arg + ") " + subVal);
            } catch (Exception e) {
                e.printStackTrace();
                invokeCount = 0;
            }
            inc++;
            if (inc == invoketry) {
                break;
            }
        } while (!subVal.contains("<MI-II>"));
        if (!subVal.contains("<MI-II>")) {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. Invoke JRemote." + arg + " Val " + subVal);
        }
        return subVal;
    }

    public String doExpected(String args) {
        String subVal = "";
        //int inc = 0;
        //do {
        try {
            invokeCount = 0;
            JRConnect();
            JSubroutineParameters params = new JSubroutineParameters();
            params.add(new JDynArray(args));
            params.add(new JDynArray("two"));
            JSubroutineParameters returnParams = cx.call("ATT.UPDATE.EXPECTED.V4.JREM.PRO", params);
            subVal = returnParams.get(1).get(1);
            //System.out.println("1st parameter: " + returnParams.get(0).get(1));                
        } catch (Exception e) {
            e.printStackTrace();
            invokeCount = 0;
        }
        if (subVal.contains("<MI-II>")) {
            subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
            log.info("Do Expected: ( " + args + " ) Result: " + subVal + " Rtine: ATT.UPDATE.EXPECTED.V3.JREM");
        }
        return subVal;
    }

    public String RuleGenerate(String args, String odr) {
        String subVal = "";
        int inc = 0;
        do {
            try {
                JRConnect();
                JSubroutineParameters params = new JSubroutineParameters();
                params.add(new JDynArray("SCRIPT#" + args));
                params.add(new JDynArray("two"));
                JSubroutineParameters returnParams = cx.call("ATT.BUILD.SCREEN.V3.JREM", params);
                subVal = returnParams.get(1).get(1);
            } catch (Exception e) {
                e.printStackTrace();
                invokeCount = 0;
            }
            inc++;
            if (inc == invoketry) {
                break;
            }
        } while (!subVal.contains("<MI-II>"));
        if (!subVal.contains("<MI-II>")) {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. Invoke Telnet." + args + " Val " + subVal);
        } else {
            subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
            log.info("RuleGenerate: ( " + args + ") Result: " + subVal + " Rtine: ATT.BUILD.SCREEN.V3.JREM");
        }
        return subVal;
    }

    public String invokeMeRuleGenerate(String args) {
        invokeCount = 0;

        String subVal = "";
        int inc = 0;
        do {
            try {
                if (invokeCount == 0) {
                    JRConnect();
                    invokeCount++;
                }
                JSubroutineParameters params = new JSubroutineParameters();
                params.add(new JDynArray("SCENARIO#" + args));
                params.add(new JDynArray("two"));
                JSubroutineParameters returnParams = cx.call("ATT.BUILD.SCREEN.JREM", params);
                subVal = returnParams.get(1).get(1);

            } catch (Exception e) {
                e.printStackTrace();
                invokeCount = 0;
            }
            inc++;
            if (inc == invoketry) {
                break;
            }
        } while (!subVal.contains("<MI-II>"));

        if (subVal.contains("<MI-II>")) {
            subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
            try {
                //Todos
                FileWriter outFile = new FileWriter("/" + args);
                outFile.write(subVal);
                outFile.close();
            } catch (Exception e) {
            }
            log.info("RuleGenerate:SENARIO : " + subVal);
            log.info("invokeMeRuleGenerate: ( " + args + ") Result: " + subVal + " Rtine: ATT.BUILD.SCREEN.JREM");
        } else {
            log.error("RuleGenerate:SENARIO ERR " + inc + ":" + subVal);
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Values from Database. Invoke Telnet." + args + " Val " + subVal);
        }
        return subVal;
    }

    public static void CloseConection() {
        try {
            cx.close();
        } catch (Exception e) {
            System.out.println("Error while closing the connection " + e.toString());
        }
    }

    public String ATTCreateScripts(String args) {
        invokeCount = 0;

        String subVal = "";
        int inc = 0;
        do {
            try {
                if (invokeCount == 0) {
                    JRConnect();
                    invokeCount++;
                }
                JSubroutineParameters params = new JSubroutineParameters();
                params.add(new JDynArray(args));
                params.add(new JDynArray("two"));
                JSubroutineParameters returnParams = cx.call("ATT.CREATE.SCRIPT.V5.JREM", params);
                subVal = returnParams.get(1).get(1);
            } catch (Exception e) {
                e.printStackTrace();
                invokeCount = 0;
            }
            inc++;
            if (inc == invoketry) {
                break;
            }
        } while (!subVal.contains("<MI-II>"));
        if (subVal.contains("<MI-II>")) {
            subVal = subVal.substring(subVal.indexOf("<MI-II>") + 7, subVal.indexOf("</MI-II>"));
            log.info("ATTCreateScripts: ( " + args + ") Result: " + subVal + " Rtine: ATT.CREATE.SCRIPT.V5.JREM");
        } else {
            subVal = "<MI-II>Error Message :  Response time out</MI-II>";
            log.error("Failed to get the Expected Values from Database. doExpected." + args + " val " + subVal);
        }
        return subVal;
    }

    public static void main(String args[]) throws Exception {
        JRemoteConnect jrem = new JRemoteConnect();
        //String res = jrem.JRemCall("ATT.OFS", "ENQUIRY.SELECT,,INPUTT/123456,CURRENCY-LIST");
//        res = jrem.getBankGroupList();
//        System.out.println(" ss " + res);
//        res = jrem.getBankGroupList();
//        System.out.println(" ss " + res);
//        res = jrem.JRemInvoke("ATT.CLIENT.ADDRESS LCH");
//        System.out.println(" ss : " + res);
//        res = jrem.invokeMeRuleGenerate("PACS00060629~TCASE15920001741");
//        res = jrem.JRemUserAuth("NAVEED64", "123123");
//        res = jrem.JRemInvokeFast("ATT.GET.BANK.PRODUCT.DETAILS.V4 TEST.SCENARIO.LIST~LCH");
//        System.out.println(" res " + res);
//        res = jrem.JRemCall2("ATT.GET.BANK.PRODUCT.DETAILS.V4.JREM", "TEST.SCENARIO.LIST~LCH");
    }
}
