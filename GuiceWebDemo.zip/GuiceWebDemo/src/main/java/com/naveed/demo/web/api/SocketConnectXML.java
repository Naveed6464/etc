/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.demo.web.api;

/**
 *
 * @author naveedur
 */
import java.io.*;
import java.net.Socket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SocketConnectXML {

    Socket soc;
    OutputStream out;
    DataOutputStream dout;
    BufferedReader reader;

    private final Logger log = LoggerFactory.getLogger(SocketConnectXML.class);

    private static SocketConnectXML conect = new SocketConnectXML();

    public static SocketConnectXML getInstance() {
        return conect;
    }

    //ATTProperties property = ATTProperties.getInstance();

    private SocketConnectXML() {
        try {
            //soc = new Socket(property.getHostName(), 4646);
            //Todo
            soc = new Socket("hostName inject here", 4646);
            out = soc.getOutputStream();
            dout = new DataOutputStream(out);
            reader = new BufferedReader(new InputStreamReader(soc.getInputStream()));
            System.out.println(reader.readLine());
            System.out.println(reader.readLine());
            System.out.println(reader.readLine());
            dout.write("Request\n".getBytes());
            System.out.println(reader.readLine());
        } catch (Exception e) {
            System.out.println("Error " + e.toString());
        }
    }

    public String socketCall(String arg) {
        String subVal = "";
        try {

            dout.write(arg.getBytes());
            subVal = reader.readLine().toString();
        } catch (Exception e) {
            subVal = "Error";
        }
        return subVal;
    }

    public static void main(String[] args) {
        SocketConnectXML sc = SocketConnectXML.getInstance();
        String res = sc.socketCall("<NAVEEDXML><?xml version=\"1.0\" encoding=\"UTF-8\"?><ofsSessionRequest xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" schemaLocation=\"\\WEB-INF\\xml\\schema\\ofsSessionRequest.xsd\"><requestType>CREATE.SESSION</requestType><requestArguments><signOnName>NAVEED64</signOnName><password>123123</password></requestArguments></ofsSessionRequest></NAVEEDXML>\n");
        System.out.println("Result - " + res);
//        FileWriter outFile;
//        try {
//            outFile = new FileWriter("C:/TestOFs.txt");
//            outFile.write(res);
//            outFile.close();
//        } catch (IOException ex) {
//            Logger.getLogger(SocketConnectXML.class.getName()).log(Level.SEVERE, null, ex);
//        }

    }
}
