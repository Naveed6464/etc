/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.naveed.demo.web.servlets;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Naveedur Rahman
 * @since Oct 1, 2019
 * @version 1.0
 *
 */
@WebService(serviceName = "IssueRemittance", targetNamespace = "http://simulator.corebanking.rmt", portName = "IssueRemittancePort", name = "remittance")
public class HelloWebService {

    
    @WebMethod
    public String getAccount(@WebParam(name = "id") String id) {
        return "Hello " + id;
    }
}
