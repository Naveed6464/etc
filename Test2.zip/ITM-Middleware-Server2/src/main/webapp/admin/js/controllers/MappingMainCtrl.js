/*global require*/
'use strict';

define(['angular'], function(angular) {

    var controller = ['$scope', '$state', '$http', 'Statements', 'NgTableParams', 'REST_HOST', function MappingMainCtrl(
                $scope, $state, $http, Statements, NgTableParams, REST_HOST) {
            $scope.entityName = "mapping";
            $scope.app = {
                "name": "mapping", "title": "File Mapping", "img": "icon-48-stats.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "fileType", "label": "File Type", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "Delimiter", "label": "Delimiter", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2},
                    {"model": "PreProcessRTN", "label": "Pre Process RTN", "position": 2, "reportPosition": 2, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 3},
                    {"model": "recordType", "label": "RecordType", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 4},
                    {"model": "fieldName", "label": "Field Name", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 10},
                    {"model": "operation", "label": "Operation", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 5},
                    {"model": "conversion", "label": "Conversion", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 11},
                    {"model": "position", "label": "Position", "position": 5, "reportPosition": 5, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 6},
                    {"model": "startPosition", "label": "startPosition", "position": 6, "reportPosition": 6, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 7},
                    {"model": "length", "label": "Length", "position": 7, "reportPosition": 7, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 8}                    
                ],
                "id": 1};

            var columnDefs = [];
            for (var i in $scope.app.fields) {
                columnDefs[i] = {"field": $scope.app.fields[i].model, "name": $scope.app.fields[i].label};
            }
            columnDefs[$scope.app.fields.length] = {
                "name": "Action", //class=\"ui-grid-cell-contents\"
                enableSorting: false,
                enableColumnMenu: false,
                cellTemplate: "<div><a class='btn btn-default btn-sm' ui-sref=\"" + 'application.edit'
                        + "({id: row.entity.id})"
                        + "\"><i class='glyphicon glyphicon-edit'></i></a>  "
                        + "<a class='btn btn-default btn-sm' ui-sref=\"" + 'application.view'
                        + "({id: row.entity.id})"
                        + "\"><i class='glyphicon glyphicon-th-list'></i></a></div>"
            };
            $scope.gridOptions = {};
            $scope.gridOptions.columnDefs = columnDefs;
            $scope.data = Statements;

            $scope.tableParams = new NgTableParams({
                page: 1, // show first page
                count: 10 // count per page
            }, {
                total: $scope.data.length, // length of data
                getData: function($defer, params) {
                    $defer.resolve($scope.data.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });

            $scope.gotoToNew = function() {
                $state.go($scope.entityName + '.new');
            };
        }
    ];
    return controller;
});