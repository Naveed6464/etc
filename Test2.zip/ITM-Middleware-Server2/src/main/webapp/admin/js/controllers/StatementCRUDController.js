/*global require*/
'use strict';

define(['angular'], function (angular) {

    var controller = ['$scope', '$state', '$stateParams', '$http', 'REST_HOST',
        function StatementCRUDController($scope, $state, $stateParams, $http, REST_HOST) {

            //$scope.app = App;
            $scope.app = {
                "name": "statement", "title": "Statement Types", "img": "icon-48-stats.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "statementName", "label": "Statement Name", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "defJasperFile", "label": "Default JasperFile Name", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2},
                    {"model": "defPromoImg", "label": "Default Promotion Img", "position": 2, "reportPosition": 2, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 3},
                    {"model": "defPromoText", "label": "Default Promotion Text", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 4},
                    {"model": "defPromoText2", "label": "Default Promotion Text2", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 10},
                    {"model": "defFavoriteLink", "label": "Default Favorite Link", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 5},
                    {"model": "defFavoriteLinkName", "label": "Default Favorite LinkName", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 11},
                    {"model": "defEmailSubject", "label": "Default Email Subject", "position": 5, "reportPosition": 5, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 6},
                    {"model": "defEmailText", "label": "Default Email Text", "position": 6, "reportPosition": 6, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 7},
                    {"model": "recordType", "label": "CustomerType Record Name", "position": 7, "reportPosition": 7, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 8},
                    {"model": "columnNo", "label": "CustomerType Column No", "position": 8, "reportPosition": 8, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 9}
                ],
                "id": 1};
            $scope.isFormNew = true;
            $scope.isFormEdit = true;
            var Entity = {};
            if (!$stateParams.id || $stateParams.id === 'new') {
                $scope.entity = Entity;
            } else {
                $scope.isFormNew = false;
                $scope.entity = Entity;
                $http.get(REST_HOST + $scope.app.name + '/' + $stateParams.id).then(
                        function success(response) {
                            $scope.entity = response.data;
                        });
            }

            $scope.gotoToMain = function () {
                $state.go("statement.main");
            };
        }
    ];
    return controller;
});