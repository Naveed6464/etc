/*global require*/
'use strict';

define(['angular'], function(angular) {

    var controller = ['$scope', '$state', '$http', 'Customer', 'NgTableParams', 'REST_HOST', function CustomerMainController(
                $scope, $state, $http, Customer, NgTableParams, REST_HOST) {
            $scope.entityName = "customer";
            $scope.app = {
                "name": "customer", "title": "Customer Types", "img": "icon-48-themes.png", "dashBoardImg": "user.png", "visible": true,
                "fields": [
                    {"model": "statementName", "label": "Statement Name", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 1},
                    {"model": "customerType", "label": "Customer Type", "position": 0, "reportPosition": 0, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 10},
                    {"model": "jasperFile", "label": "JasperFile Name", "position": 1, "reportPosition": 1, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 2},
                    {"model": "promoImg", "label": "Promotion Img", "position": 2, "reportPosition": 2, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 3},
                    {"model": "promoText", "label": "Promotion Text", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 4},
                    {"model": "promoText2", "label": "Promotion Text2", "position": 3, "reportPosition": 3, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 8},
                    {"model": "favoriteLink", "label": "Favorite Link", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 5},
                    {"model": "favoriteLinkName", "label": "Favorite Link Name", "position": 4, "reportPosition": 4, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 9},
                    {"model": "emailSubject", "label": "Email Subject", "position": 5, "reportPosition": 5, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 6},
                    {"model": "emailText", "label": "Email Text", "position": 6, "reportPosition": 6, "visible": true, "visibleInReports": true, "widgetType": "text", "errorMsg": "", "defaultValue": "", "placeHolder": "", "required": true, "minLength": 0, "maxLength": 0, "pattern": "", "id": 7}
                ],
                "id": 1};


            $scope.data = Customer;

            $scope.tableParams = new NgTableParams({
                page: 1, // show first page
                count: 10 // count per page
            }, {
                total: $scope.data.length, // length of data
                getData: function($defer, params) {
                    $defer.resolve($scope.data.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });

            $scope.gotoToNew = function() {
                $state.go($scope.entityName + '.new');
            };
        }
    ];
    return controller;
});