/*global require*/
'use strict';

define(function () {


    /*define(['controllers/controllers'], function(controllers) {     
     controllers.controller('HelloController', ['$scope', function HelloController($scope) {
     $scope.greeting = {text: 'Hello'};
     }
     ]);*/

    var controller = ['$scope', '$http', '$state', 'Settings', 'REST_HOST', function UploadController($scope, $http, $state, Settings, REST_HOST) {
            
            $scope.settings = Settings;
            $scope.saveSettings = function(){
              $http.post(REST_HOST + 'postsettings.do', $scope.settings).
                        success(function (data, status, headers, config) {
                            alert("Settings saved Successfully");
                            $state.go("home.upload");
                        }).
                        error(function (data, status, headers, config) {
                            alert("Error while submitting....");
                        });  
            };
            $scope.fileSelected = false;

            $scope.onFileSet = function (files) {
                $scope.fileSelected = true;
            };

            /*$scope.onFileSelected = function (files) {
             $scope.fileSelected = true;                
             };*/

            $scope.uploadComplete = function (content) {
                alert("Jasper Files Uploaded Successfully");
                //$state.go("home.generate", {fileName: content});
            };
            
            
        }
    ];

    return controller;
});