/*global require*/
'use strict';

define(function () {

    return ['$rootScope', function ($rootScope) {
            return {
                scope: {
                    app: '=',
                    entity: '='                    
                },
                templateUrl: 'views/templates/saladinFormView.html',
                replace: true,
                controller: ['$scope', '$state', function ($scope, $state) {
                        $scope.gotoToMain = function () {
                            $state.go($scope.app.name + ".main");
                        };
                    }],
                link: function (scope, element, attrs) {

                }
            };
        }];
});