/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$rootScope', '$http', 'REST_HOST', function ViewStatementController($scope, $rootScope, $http, REST_HOST) {
            $scope.batchId = '';
            $scope.batchFile = '';
            $scope.acctNo = '';
            $scope.byBatchId = [];
            $scope.byBatchFile = [];
            $scope.byAcctNo = [];

            $scope.showBatchById = function (batchId) {
                $http.get('viewstatement.do', {params: {by: 'batchId', id: batchId}}).success(function (data, status, headers, config) {
                    $scope.byBatchId = data;                                        
                });
            };

            $scope.showBatchByFile = function (batchFile) {
                $http.get('viewstatement.do', {params: {by: 'batchFile', id: batchFile}}).success(function (data, status, headers, config) {
                    $scope.byBatchFile = data;
                });
            };

            $scope.showBatchByAcctNo = function (acctNo) {
                $http.get('viewstatement.do', {params: {by: 'acctNo', id: acctNo}}).success(function (data, status, headers, config) {
                    $scope.byAcctNo = data;
                });
            };

            $scope.pdfReport = function (fileName) {
                window.open(REST_HOST + 'getStatementPdf.do?file='+ fileName, '_blank', '');
            };

        }
    ];

    return controller;
});