/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$state', '$stateParams', '$http', 'REST_HOST', 'Batches', function GenerateController(
                $scope, $state, $stateParams, $http, REST_HOST, Batches) {

            $scope.fileName = $stateParams.fileName;
            $scope.batches = Batches;

            $scope.gridOptions = {
                data: "batches",
                multiSelect: true,
                enableRowSelection: true,
                enableSelectAll: true,
                showGridFooter: true,
                //selectionRowHeaderWidth: 35,
                //rowHeight: 35
                columnDefs: [
                    {field: 'id', displayName: 'Batch Id'},
                    {field: 'fileName', displayName: 'Batch Filename'},
                    {field: 'fileSize', displayName: 'Batch FileSize'},
                    {field: 'status', displayName: 'Status'},
                    {field: 'username', displayName: 'User'}
                ]
            };

            $scope.gridOptions.onRegisterApi = function (gridApi) {
                $scope.gridApi = gridApi;
            };

            $scope.generate = function () {                
                $http.post('generate.do', $scope.gridApi.selection.getSelectedRows()).success(function (data, status, headers, config) {
                    $state.go("home.send");
                }).error(function(data, status, headers, config) {
                    alert("Error while creating Statements.");
                });
            };

            $scope.deletebatch = function () {
                //$http.get('generate.do', {
                //  params: {fileName: $scope.fileName}
                $http.post('deleteBatch.do', $scope.gridApi.selection.getSelectedRows()).success(function (data, status, headers, config) {
                    //$state.go("home.generate");
                    $http.get('getuploads.do').success(function (data, status, headers, config) {
                        $scope.uploads = data;
                    });
                });
            };
        }
    ];

    return controller;
});