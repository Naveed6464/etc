/*global require*/
'use strict';

define(function () {

    var controller = ['$scope', '$http', 'delivered', 'failed', 'partial', 'REST_HOST', function ReportController($scope, $http, delivered, failed, partial, REST_HOST) {

            $scope.delivered = delivered;
            $scope.failed = failed;
            $scope.partial = partial;
            
            $scope.batchId = '';
            $scope.username = '';
            $scope.byBatchId = [];
            /*$http.get('getallreports.do').success(function (data, status, headers, config) {
             $scope.reports = data;
             });*/

            $scope.showBatchById = function (batchId) {
                $http.get('report.do', {params: {report: 'report', id: batchId}}).success(function (data, status, headers, config) {
                    $scope.byBatchId = data;
                });
            };
            
            $scope.showActivity = function (username) {
                $http.get('report.do', {params: {report: 'activity', id: username}}).success(function (data, status, headers, config) {
                    $scope.byBatchId = data;
                });
            };

            $scope.pdfReport = function (reportName) {
                window.open(REST_HOST + 'getReportPdf.do?report=' + reportName, '_blank', '');
            };

        }
    ];

    return controller;
});