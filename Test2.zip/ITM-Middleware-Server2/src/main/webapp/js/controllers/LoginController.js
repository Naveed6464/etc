/*global require*/
'use strict';

define(function () {


    /*define(['controllers/controllers'], function(controllers) {     
     controllers.controller('HelloController', ['$scope', function HelloController($scope) {
     $scope.greeting = {text: 'Hello'};
     }
     ]);*/


    var controller = ['$rootScope', '$scope', '$http', '$state', 'localStorageService', 'REST_HOST', function LoginController(
                $rootScope, $scope, $http, $state, localStorageService, REST_HOST) {

            $scope.user = {username: '', password: ''};

            $scope.login = function () {               
                $http.post(REST_HOST + 'login', $scope.user).success(function (data, status, headers, config) {
                    $scope.errorMsg = "";
                    localStorageService.set("token", data.token);
                    $scope.user.password = '';
                    $rootScope.currentUser = $scope.user;
                    $state.go("home");
                }).error(function (data, status, headers, config) {
                    $scope.user.password = '';
                    $scope.errorMsg = "Invalid Username or passwrod!";
                });
            };
        }
    ];

    return controller;
});



