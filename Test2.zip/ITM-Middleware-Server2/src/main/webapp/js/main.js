/*global require*/
'use strict';

require.config({
    paths: {
        angular: '../lib/angular/angular.min',
        angularResource: '../lib/angular/angular-resource.min',
        angularTouch: '../lib/angular/angular-touch.min',
        angularAnimate: '../lib/angular/angular-animate.min',
        angularUIRoute: '../lib/angular/angular-ui-router.min',
        angularUIGrid: '../lib/angular/ui-grid.min',
        angularUIBootstrap: '../lib/angular/ui-bootstrap-tpls-0.12.1.min',
        angularLocalStorage: '../lib/angular-related/angular-local-storage.min',
        angularLoad: '../lib/angular/loading-bar.min',
        jquery: '../lib/jquery/jquery-1.11.2.min',
        bootstrap: '../lib/bootstrap/bootstrap.min',
        shim: '../lib/shimsham/es5-shim.min',
        sham: '../lib/shimsham/es5-sham.min',
        ngupload: '../lib/angular/ng-upload.min',
        saladin: '../lib/saladin/saladin'

    },
    shim: {
        angular: {
            deps: ["jquery"],
            exports: 'angular'
        },
        angularResource: {deps: ['angular']},
        angularTouch: {deps: ['angular']},
        angularAnimate: {deps: ['angular']},
        angularUIRoute: {deps: ['angular']},
        angularUIGrid: {deps: ['angular']},
        angularUIBootstrap: {deps: ['angular']},
        angularLocalStorage: {deps: ['angular']},
        angularLoad: {deps: ['angular']},
        bootstrap: {deps: ["jquery"]},
        ngupload: {deps: ['angular']},
        saladin: {deps: ['angular']}
    }
});

require([
    'jquery',
    'angular',
    'angularUIRoute',
    'angularUIGrid',
    'angularTouch',
    'angularAnimate',
    'angularUIBootstrap',
    'angularLocalStorage',
    'angularLoad',
    'shim', 'sham',
    'ngupload',
    'saladin',
    'bootstrap',
    'app',
    'routes',
    'config'
], function ($, angular) {
    angular.bootstrap(document, ['myApp']);
});