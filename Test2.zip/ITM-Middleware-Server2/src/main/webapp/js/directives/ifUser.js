/*global require*/
'use strict';

define(function () {

    return ['$rootScope', function ($rootScope) {
            return {                
                link: function (scope, element, attrs) {
                    $rootScope.$watch('user', function (user) {                        
                        if (user && user.username) {
                            element.show();
                        } else {
                            element.hide();
                        }
                    });
                }
            };
        }];
});