/*global require*/
'use strict';

define([
    'angular',
    'directives/onFileSelected',
    'directives/ifUser'
], function (angular, onFileSelected, ifUser) {

    var directives = angular.module('directives', []);

    var directivesList = {
        onFileSelected: onFileSelected,
        ifUser:ifUser
    };

    angular.forEach(directivesList, function (directive, name) {
        directives.directive(name, directive);
    });
});