/*global require*/
'use strict';

define([
    'angular',
    'services/UserService',
    'services/ReportService'
], function(angular, UserService, ReportService) {

    var services = angular.module('services', ['ngResource']);

    var servicesList = {
        UserService: UserService,
        ReportService: ReportService
    };

    angular.forEach(servicesList, function(service, name) {
        services.factory(name, service);
    });
});