/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.auth;

import com.naveed.ws.domain.entities.User;
import com.naveed.ws.domain.services.UserService;
import java.util.HashSet;
import java.util.Set;
import javax.inject.Inject;
import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAccount;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.authz.permission.WildcardPermission;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;

/**
 *
 * @author Administrator
 */
public class JpaAuthorizingRealm extends AuthorizingRealm {

    public static final String REALM_NAME = "JPA_REALM";
    public static final int HASH_ITERATIONS = 200;
    @Inject
    private UserService userService;

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        final String username = (String) principals.getPrimaryPrincipal();

        final User user = userService.findByUsername(username);

        final Set<String> roles = new HashSet<String>(user.getRoles().size());
        for (final String role : user.getRoles()) {
            roles.add(role);
        }
        roles.add(user.getRole());
        final Set<org.apache.shiro.authz.Permission> permissions = new HashSet<>(user.getPermissions().size());
        for (final String permission : user.getPermissions()) {
            permissions.add(new WildcardPermission(permission));
        }
        final SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo(roles);
        authorizationInfo.setObjectPermissions(permissions);
        return authorizationInfo;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        if (!(token instanceof UsernamePasswordToken)) {
            throw new IllegalStateException("Token has to be instance of UsernamePasswordToken class");
        }
        final UsernamePasswordToken userPassToken = (UsernamePasswordToken) token;
        if (userPassToken.getUsername() == null) {
            throw new AccountException("Null usernames are not allowed by this realm.");
        }
        final User user = userService.findByUsername(userPassToken.getUsername());
        final SimpleAccount simpleAccount = new SimpleAccount(user.getUsername(), user.getPassword(),
                ByteSource.Util.bytes(user.getSalt()), REALM_NAME);
        return simpleAccount;
    }

    @Override
    @Inject
    public void setCredentialsMatcher(final CredentialsMatcher credentialsMatcher) {
        super.setCredentialsMatcher(credentialsMatcher);
    }
}
