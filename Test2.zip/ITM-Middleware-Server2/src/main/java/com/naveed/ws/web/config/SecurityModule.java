/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.config;

import com.google.inject.Provides;
import com.google.inject.name.Names;
import com.naveed.ws.web.auth.JpaAuthorizingRealm;
import com.naveed.ws.web.auth.SecurityUtil;
import java.net.MalformedURLException;
import java.net.URL;
import javax.inject.Singleton;
import javax.servlet.ServletContext;
import org.apache.shiro.authc.credential.CredentialsMatcher;
import org.apache.shiro.config.Ini;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.guice.web.ShiroWebModule;
import org.apache.shiro.realm.text.IniRealm;

/**
 *
 * @author Administrator
 */
public class SecurityModule extends ShiroWebModule {

    private final ServletContext servletContext;

    public SecurityModule(ServletContext servletContext) {
        super(servletContext);
        this.servletContext = servletContext;
    }

    @Override
    public void configureShiroWeb() {
        bind(CredentialsMatcher.class).toInstance(new SecurityUtil().getCredentialMatcher());
        bind(SimpleHash.class).toInstance(new SecurityUtil().getHash());
        bindConstant().annotatedWith(Names.named("shiro.loginUrl")).to("/app/index.html#/login");
        //bindRealm().toConstructor(IniRealm.class.getConstructor(Ini.class));
        bindRealm().to(IniRealm.class);
        bindRealm().toInstance(new JpaAuthorizingRealm());

        addFilterChain("/index.html#/login", AUTHC);
        addFilterChain("/logout", LOGOUT);
        addFilterChain("/public/**", ANON);
        addFilterChain("/api/**", AUTHC);
        addFilterChain("/stuff/allowed/**", AUTHC_BASIC);
        addFilterChain("/stuff/forbidden/**", AUTHC_BASIC, config(PERMS, "no"));
        //addFilterChain("/**", AUTHC_BASIC);
    }

    @Provides
    @Singleton
    IniRealm loadIniRealm(Ini ini) {        
        IniRealm realm = new IniRealm(ini);
        return realm;
    }

    @Provides
    @Singleton
    Ini loadShiroIni() throws MalformedURLException {
        //return Ini.fromResourcePath("classpath:shiro.ini");
        URL iniUrl = servletContext.getResource("/WEB-INF/shiro.ini");
        return Ini.fromResourcePath("url:" + iniUrl.toExternalForm());
    }

}
