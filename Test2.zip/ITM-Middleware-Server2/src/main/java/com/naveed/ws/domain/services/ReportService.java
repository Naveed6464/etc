/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.domain.services;

import com.naveed.ws.domain.entities.Report;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author Administrator
 */
public class ReportService {

    EntityManagerFactory emf = null;
    private EntityManager em;

    public ReportService() {
        emf = Persistence.createEntityManagerFactory("dbunit");
    }

    public EntityManager getEntityManager() {
        if (em == null) {
            em = emf.createEntityManager();
        }
        return em;
    }

    public Report save(Report entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(entity);
            entityManager.flush();
        } finally {
            entityManager.getTransaction().commit();
        }
        return entity;
    }

    public Report find(Long id) {
        return (Report) getEntityManager().find(Report.class, id);
    }

    public List<Report> findAll() {
        return getEntityManager().createQuery("SELECT e FROM Report " + " e").getResultList();
    }

    public Report update(Report entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Report merge = entityManager.merge(entity);
            entityManager.flush();
            return merge;
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public void delete(Long id) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Report entity = find(id);
            entityManager.remove(entity);
            entityManager.flush();
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public List<Report> getNotSendReports() {
        Query query = getEntityManager().createQuery("SELECT e FROM Report " + " e WHERE e.status = :arg");
        query.setParameter("arg", "Not Send");
        return query.getResultList();
    }
}
