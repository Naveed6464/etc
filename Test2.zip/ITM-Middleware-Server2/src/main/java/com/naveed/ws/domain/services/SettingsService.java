/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.domain.services;

import com.naveed.ws.domain.entities.Settings;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Administrator
 */
public class SettingsService {

    EntityManagerFactory emf = null;
    private EntityManager em;

    public SettingsService() {
        emf = Persistence.createEntityManagerFactory("dbunit");
    }

    public EntityManager getEntityManager() {
        //if (em == null) {
        //em = emf.createEntityManager();
        //}
        return emf.createEntityManager();
    }

    public Settings save(Settings entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(entity);
            entityManager.flush();
        } finally {
            entityManager.getTransaction().commit();
        }
        return entity;
    }

    public Settings find(Long id) {
        return (Settings) getEntityManager().find(Settings.class, id);
    }

    public List<Settings> findAll() {
        return getEntityManager().createQuery("SELECT e FROM Settings " + " e").getResultList();
    }

    public Settings update(Settings entity) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Settings merge = entityManager.merge(entity);
            entityManager.flush();
            return merge;
        } finally {
            entityManager.getTransaction().commit();
        }
    }

    public void delete(Long id) {
        EntityManager entityManager = emf.createEntityManager();
        try {
            entityManager.getTransaction().begin();
            Settings entity = find(id);
            entityManager.remove(entity);
            entityManager.flush();
        } finally {
            entityManager.getTransaction().commit();
        }
    }

}
