/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.service;

import com.ncr.itm.ws.admin.Admin;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletConfig;
import javax.xml.ws.Endpoint;
import org.apache.cxf.BusFactory;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

/**
 *
 * @author nmrehman
 */
@Singleton
public class WebServiceServlet extends CXFNonSpringServlet {

    private static final long serialVersionUID = 1L;
    private final SamaService samaService;
    private final Admin admin;

    @Inject
    public WebServiceServlet(SamaService samaService, Admin admin) {
        this.samaService = samaService;
        this.admin = admin;
    }

    @Override
    protected void loadBus(ServletConfig sc) {
        super.loadBus(sc);
        BusFactory.setDefaultBus(getBus());
        //Endpoint.publish("/Data", samaService);
        Endpoint.publish("/admin", admin);
    }
}
