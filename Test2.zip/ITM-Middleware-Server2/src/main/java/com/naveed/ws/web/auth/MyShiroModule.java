/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.auth;

import org.apache.shiro.guice.ShiroModule;

/**
 *
 * @author Administrator
 */
public class MyShiroModule extends ShiroModule {

    @Override
    protected void configureShiro() {
        bindRealm().toInstance(new JpaAuthorizingRealm());
    }

    /*@Provides
     Ini loadShiroIni() {
     return //Ini.fromResourcePath("classpath:shiro.ini");
     }*/
}
