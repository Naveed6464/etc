/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.domain.entities;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Administrator
 */
@Entity
public class Report extends AbstractEntity {

    String accountNo;
    String email;
    String status;
    String pdfFileName;
    @Temporal(TemporalType.TIMESTAMP)
    Date date;
    Long batchId;
    String fileName;
    String username;
    
    public Report() {
    }

    public Report(String accountNo, String email, String status, Date date, String pdfFileName) {
        this.accountNo = accountNo;
        this.email = email;
        this.status = status;
        this.date = date;
        this.pdfFileName = pdfFileName;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPdfFileName() {
        return pdfFileName;
    }

    public void setPdfFileName(String pdfFileName) {
        this.pdfFileName = pdfFileName;
    }

}
