/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.ws.web.servlet;

import com.google.gson.Gson;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author nmrehman
 *
 */
@Singleton
public class StatementUploadHandler extends BaseServlet {

    Gson gson = new Gson();
    //@Inject
    //BatchService uploadsService;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //List<String> fileNames = new ArrayList<>();
        if (ServletFileUpload.isMultipartContent(request)) {
            try {
                String uploadDir = getServletContext().getInitParameter("UPLOAD_DIRECTORY");
                System.out.println("UPLOAD DIR >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   " + uploadDir);
                if (!new File(uploadDir).exists()) {
                    System.out.println("Creating Initial Directories! ");
                    new File(uploadDir).mkdirs();
                }
                List<FileItem> multiparts = new ServletFileUpload(
                        new DiskFileItemFactory()).parseRequest(request);

                for (FileItem item : multiparts) {
                    if (!item.isFormField()) {
                        String fileName = new File(item.getName()).getName();
//                        if (uploadsService.getBatchByFileName(fileName).isEmpty()) {
//                            if (fileName.contains("\\")) {
//                                fileName = fileName.substring(fileName.lastIndexOf("\\") + 1, fileName.length());
//                            }
//                            //fileNames.add(fileName);
//                            File file = new File(uploadDir + File.separator + fileName);
//                            uploadsService.save(new Batch(fileName));
//                            item.write(file);
//                            issueJson(response, HTTP_STATUS_OK, MESSAGE, "ok");
//                        } else {
//                            issueJson(response, HTTP_STATUS_NOT_FOUND, MESSAGE, "File already exists.");
//                        }
                    }
                }
            } catch (Exception ex) {
                issueJson(response, HTTP_STATUS_NOT_FOUND, MESSAGE, "File Upload Failed due to " + ex);
            }
        } else {
            issueJson(response, HTTP_STATUS_NOT_FOUND, MESSAGE, "Sorry this Servlet only handles file upload request");
        }

        /*if (!fileNames.isEmpty()) {
         response.setContentType("application/json");
         response.getWriter().write(gson.toJson(fileNames));
         } else {
         response.getWriter().write("Error");
         }*/
    }

}
