package com.naveed.demo;

import com.google.common.base.Splitter;
import java.util.Map;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
}
