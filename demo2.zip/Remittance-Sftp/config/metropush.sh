#sftp -o IdentityFile=/home/rmftpprd/.ssh/id_rsa alinma01@103.5.228.6
#PASSWD=alinma
############################
RUNDIR=/rmtsftp/rmtprd/remittance/bin
BankName=mbt
cd $RUNDIR
LOGFILEPATH=$RUNDIR/../log
LOGFILE=Sftp2$BankName.log`date +%y%m%d`
#
User=pin20001
HOST=222.127.150.108
SrcDir=../mbt/outward
DestDir=/Metrobank/RPD/Tie-up/Principal/INMASAR2/RPD_TRANS
mfile=*.TXT
cd $SrcDir
#
echo "Sftp outward for Metro bank started @ `date +%A\ %Y%m%d_%H:%M:%S`"  >> $LOGFILEPATH/$LOGFILE
echo "sftp "$User@$HOST >> $LOGFILEPATH/$LOGFILE
#
for file in $mfile
do
#sftp $User@$HOST <<EOF  | tee -a $LOGFILEPATH/$LOGFILE
sftp $User@$HOST <<EOF  2>> $LOGFILEPATH/$LOGFILE >> $LOGFILEPATH/$LOGFILE
        cd $DestDir
        put $file
        chmod 664 $file
	ls
        quit
EOF
echo "Moving file to Processed Status :"$file >> $LOGFILEPATH/$LOGFILE
mv "$file" "${file}_sent"
done
