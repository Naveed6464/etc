/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;

/**
 *
 * @author nmrehman
 */
public class PropoertyPasswordEncryptor {

    private static StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    private static final String PROPERTY_ENCRYPTION_PASSWORD = "Remittance@123";
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void printVersion() {
        String message = "Remittance-Sftp Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    public static void main(String[] args) {
        printVersion();
        //args = new String[]{"s8qU1mop"};
        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.PropoertyPasswordEncryptor <String argument to Encrypt>";
            System.out.println(message);
            System.exit(1);
        }
        encryptor.setPassword(PROPERTY_ENCRYPTION_PASSWORD);
        System.out.println(PropertyValueEncryptionUtils.encrypt(args[0], encryptor));
    }

    public void encrypt(String password) {
        encryptor.setPassword(PROPERTY_ENCRYPTION_PASSWORD);
        System.out.println(PropertyValueEncryptionUtils.encrypt(password, encryptor));
    }
}
