/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.core;

import com.inma.rmt.ftp.Ftp;
import com.inma.rmt.ftps.Ftps;
import com.inma.rmt.sftp.Sftp;

/**
 *
 * @author nmrehman
 */
public class ProviderFactory {

    public Provider getProvider(String providerType) {
        Provider provider = null;
        if (providerType.equals("SFTP") || providerType.equals("sftp")) {
            provider = new Sftp();
        } else if (providerType.equals("FTP") || providerType.equals("ftp")) {
            provider = new Ftp();
        } else if (providerType.equals("FTPS") || providerType.equals("ftps")) {
            provider = new Ftps();
        }
        return provider;
    }

}
