/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author nmrehman
 */
public class FileLastModifiedTime {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void main(String[] args) {
        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.Main <FileName or FileName with Full Path>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }
        File file = new File(args[0]);
        System.out.println(file.lastModified());
    }

}
