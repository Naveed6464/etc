/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt;

import com.inma.rmt.config.AppProperties;
import com.inma.rmt.core.ProviderFactory;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
public class Main {

    private static final AppProperties properties = AppProperties.getInstance();
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();
    protected final static Logger log = LoggerFactory.getLogger(Main.class);

    public static void printVersion() {
        String message = "Remittance-Sftp Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    public static void main(String[] args) {
        printVersion();
        //args = new String[]{"config.properties"};
        //PropoertyPasswordEncryptor encryptor = new PropoertyPasswordEncryptor();
        //encryptor.encrypt("s8qU1mop");

        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.Main <Property FileName or FileName with Full Path>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }
        properties.loadProperties(args[0]);
        if (properties.getOUTENABLE().equals("NO") || properties.getOUTENABLE().equals("No")) {
            log.error("Disabled Remittance Sftp Service...");
            return;
        }
        if (properties.isLoaded()) {
            if (!properties.isCOMMONS_LOG()) {
                System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
            }
            ProviderFactory factory = new ProviderFactory();

            if (properties.isRPUSH_ENABLE()) {
                factory.getProvider(properties.getRPUSH_PROT()).push();
            }

            if (properties.isRPULL_ENABLE()) {
                factory.getProvider(properties.getRPULL_PROT()).pull();
            }

            if (properties.isLS_ENABLE()) {
                factory.getProvider(properties.getRPULL_PROT()).ls();
            }
        }
    }
}
