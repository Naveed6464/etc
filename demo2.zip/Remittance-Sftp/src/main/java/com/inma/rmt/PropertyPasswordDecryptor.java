package com.inma.rmt;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;

/**
 *
 * @author nmrehman
 */
public class PropertyPasswordDecryptor {

    private static StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    private static final String PROPERTY_ENCRYPTION_PASSWORD = "Remittance@123";
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void printVersion() {
        String message = "Remittance-Sftp Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    public static void main(String[] args) {
        printVersion();
        //args = new String[]{"r123456"};
        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.PropertyPasswordDecryptor <String argument to Decrypt>";
            System.out.println(message);
            System.exit(1);
        }
        encryptor.setPassword(PROPERTY_ENCRYPTION_PASSWORD);
        System.out.println(PropertyValueEncryptionUtils.decrypt(args[0], encryptor));
    }

}
