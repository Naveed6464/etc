/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt;

import com.inma.rmt.core.BouncyCastleGnuPGEncryption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author nmrehman
 */
public class GnuPGEncryptor {

    protected static BouncyCastleGnuPGEncryption gpgEncryption = new BouncyCastleGnuPGEncryption();
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void printVersion() {
        String message = "Remittance-Sftp Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    public static void main(String[] args) {
        printVersion();        
        if (args.length != 2) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.GnuPGEncryptor <FileToEncrypt, PublicKey>";
            System.out.println(message);
            System.exit(1);
        }
        String fileName = args[0];
        //String outFilePath = args[1];
        String publicKey = args[1];
        String outFilePath = fileName + ".ENC";
        gpgEncryption.encryptFile(fileName, outFilePath, publicKey);
    }

}
