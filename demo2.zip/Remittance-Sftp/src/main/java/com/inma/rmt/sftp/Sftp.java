/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.sftp;

import com.inma.rmt.core.AbstractProvider;
import java.io.File;

import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.provider.sftp.IdentityInfo;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;

/**
 *
 * @author nmrehman
 */
public class Sftp extends AbstractProvider {

    @Override
    public String connection(Type type) {
        switch (type) {
            case PUSH:
                //String userInfo = properties.getRPUSH_USER() + ":" + properties.getRPUSH_PASSWORD();
                //URI uri = new URI("ftps", userInfo, properties.getRPUSH_HOST(), 22, properties.getRPUSH_REMOTE_DIR(), null, null);                
                if (properties.isRPUSH_PWD_FLAG()) {
                    return "sftp://" + properties.getRPUSH_USER() + ":" + properties.getRPUSH_PASSWORD() + "@" + properties.getRPUSH_HOST() + "/" + properties.getRPUSH_REMOTE_DIR();
                } else {
                    return "sftp://" + properties.getRPUSH_USER() + "@" + properties.getRPUSH_HOST() + "/" + properties.getRPUSH_REMOTE_DIR();
                }
            case PULL:
                if (properties.isRPULL_PWD_FLAG()) {
                    return "sftp://" + properties.getRPULL_USER() + ":" + properties.getRPULL_PASSWORD() + "@" + properties.getRPULL_HOST() + "/" + properties.getRPULL_REMOTE_DIR();
                } else {
                    return "sftp://" + properties.getRPULL_USER() + "@" + properties.getRPULL_HOST() + "/" + properties.getRPULL_REMOTE_DIR();
                }
        }
        return "";
    }

    @Override
    public FileSystemOptions options(Type type) {
        FileSystemOptions opts = new FileSystemOptions(); // Create SFTP options
        switch (type) {
            case PUSH:
                if (properties.isRPUSH_PWD_FLAG()) {
                    try {
                        SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no"); // SSH Key checking
                        SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home
                        SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000); // Timeout is count by Milliseconds
                    } catch (FileSystemException ex) {
                        log.error("Error while setting options" + ex);
                    }
                } else {
                    return optionsWithKey(type);
                }
                break;
            case PULL:
                if (properties.isRPULL_PWD_FLAG()) {
                    try {
                        SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no"); // SSH Key checking
                        SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home
                        SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000); // Timeout is count by Milliseconds
                    } catch (FileSystemException ex) {
                        log.error("Error while setting options" + ex);
                    }
                } else {
                    return optionsWithKey(type);
                }
                break;
        }
        return opts;
    }

    public FileSystemOptions optionsWithKey(Type type) {
        FileSystemOptions opts = new FileSystemOptions(); // Create SFTP options
        try {
            SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no"); // SSH Key checking
            //SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home
            //SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000); // Timeout is count by Milliseconds
            switch (type) {
                case PUSH:
                    if (properties.getRPUSH_SSL_KEY() != null && !properties.getRPUSH_SSL_KEY().isEmpty()) {
                        log.info("Connecting Sftp With Passwordless authentication....");
                        SftpFileSystemConfigBuilder.getInstance().setUserInfo(opts, new SftpPassphraseUserInfo(properties.getRPUSH_SSL_PHRASE()));
                        SftpFileSystemConfigBuilder.getInstance().setIdentityInfo(opts, new IdentityInfo(new File(properties.getRPULL_SSL_KEY())));
                    }
                    break;
                case PULL:
                    if (properties.getRPULL_SSL_KEY() != null && !properties.getRPULL_SSL_KEY().isEmpty()) {
                        log.info("Connecting Sftp With Passwordless authentication....");
                        SftpFileSystemConfigBuilder.getInstance().setUserInfo(opts, new SftpPassphraseUserInfo(properties.getRPULL_SSL_PHRASE()));
                        //SftpFileSystemConfigBuilder.getInstance().setIdentities(opts, new File[]{new File(properties.getRPULL_SSL_KEY())});
                        SftpFileSystemConfigBuilder.getInstance().setIdentityInfo(opts, new IdentityInfo(new File(properties.getRPULL_SSL_KEY())));
                    }
                    break;
            }
        } catch (FileSystemException ex) {
            log.error("Error while setting options with key" + ex);
        }
        return opts;
    }

}
