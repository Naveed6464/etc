/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import lombok.Data;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
@Data
public class AppProperties {

    final static Logger log = LoggerFactory.getLogger(AppProperties.class);

    private String bankName;
    private String OUTENABLE;
    private String LOG_LEVEL;
    private boolean COMMONS_LOG;
    private boolean LS_ENABLE;

    private String LOG_WRITE_DLM;
    private String LOG_WRITE_PATH;
    
    private String FROM_SYSTEM;

    private String ZIP_ENC_PASSWORD;
    private boolean ZIP_ENC_PASSWORD_ENC_FLAG;
    private String ZIP_FILE_EXT;

    private String GNUPG_ENC_PUBLIC_KEY;
    private String GNUPG_ENC_EXT;
    private String GNUPG_DEC_PRIVATE_KEY;
    private String GNUPG_DEC_PASSPHARASE;
    private boolean GNUPG_DEC_PASSPHARASE_ENC_FLAG;
    private String GNUPG_DEC_EXT;

    //RPSUH
    private String RPUSH_COMM_TYPE;
    private boolean RPUSH_ENABLE;
    private String RPUSH_PROT;
    private String RPUSH_HOST;
    private int RPUSH_PORT;
    private String RPUSH_USER;
    private String RPUSH_PASSWORD;
    private boolean RPUSH_PASSWORD_ENC;
    private boolean RPUSH_PWD_FLAG;
    private String RPUSH_FTPS_MODE;
    private String RPUSH_LCL_DIR;
    private String RPUSH_REMOTE_DIR;
    private boolean RPUSH_DEL_LOCAL;
    private String RPUSH_CFILE_EXT;
    private String RPUSH_MFILE_EXT;
    private boolean RPUSH_CFILE_ON_COMPL;
    private String RPUSH_BKP_DIR;
    private String RPUSH_SSL_KEY;
    private String RPUSH_SSL_PHRASE;
    private String RPUSH_ENC_KEY;
    private String RPUSH_ENC_PHRASE;
    private String RPUSH_ENC_EXT;
    private boolean RPUSH_GNUPG_ENC_FLAG;
    private boolean RPUSH_ZIP_ENC_FLAG;

    //RPULL    
    private String RPULL_COMM_TYPE;
    private boolean RPULL_ENABLE;
    private String RPULL_PROT;
    private String RPULL_HOST;
    private int RPULL_PORT;
    private String RPULL_USER;
    private String RPULL_PASSWORD;
    private boolean RPULL_PASSWORD_ENC;
    private boolean RPULL_PWD_FLAG;
    private String RPULL_FTPS_MODE;

    private String RPULL_LCL_DIR;
    private String RPULL_REMOTE_DIR;
    private boolean RPULL_DEL_REMOTE;
    private String RPULL_CFILE_EXT;
    private String RPULL_MFILE_EXT;
    private boolean RPULL_CFILE_ON_COMPL;
    private String RPULL_BKP_DIR;

    private String RPULL_SSL_KEY;
    private String RPULL_SSL_PHRASE;
    private String RPULL_ENC_KEY;
    private String RPULL_ENC_PHRASE;
    private String RPULL_ENC_EXT;
    private boolean RPULL_GNUPG_DECRYPT_FLAG;
    private boolean RPULL_ZIP_DCYPT_FLAG;
    private boolean loaded = false;
    StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    private static final String PROPERTY_ENCRYPTION_PASSWORD = "Remittance@123";

    //Creating Singleton Object
    private AppProperties() {
        encryptor.setPassword(PROPERTY_ENCRYPTION_PASSWORD);
    }

    private static final AppProperties PROPERTIES = new AppProperties();

    public static AppProperties getInstance() {
        return PROPERTIES;
    }

    public static AppProperties getInstance(String propFileName) {
        return PROPERTIES;
    }

    public void loadProperties(String fileName) {
        Properties prop = new Properties();
        InputStream input = null;
        try {
            input = new FileInputStream(fileName);
            prop.load(input);

            bankName = prop.getProperty("BankName", "");
            OUTENABLE = prop.getProperty("OUTENABLE", "NO");
            if (OUTENABLE.equals("NO")) {
                return;
            }

            LOG_LEVEL = prop.getProperty("LOG.LEVEL", "info");
            COMMONS_LOG = Boolean.parseBoolean(prop.getProperty("COMMONS.LOG", "false").trim());
            LS_ENABLE = Boolean.parseBoolean(prop.getProperty("LS.ENABLE", "false").trim());
            LOG_WRITE_DLM = prop.getProperty("LOG.WRITE.DLM", "|").trim();
            LOG_WRITE_PATH = prop.getProperty("LOG.WRITE.PATH", "output.txt");
            
            FROM_SYSTEM = prop.getProperty("FROM.SYSTEM", "SFTP");

            ZIP_ENC_PASSWORD = prop.getProperty("ZIP.ENC.PASSWORD", "").trim();
            ZIP_ENC_PASSWORD_ENC_FLAG = Boolean.parseBoolean(prop.getProperty("ZIP.ENC.PASSWORD.ENC.FLAG", "false").trim());
            ZIP_FILE_EXT = prop.getProperty("ZIP.FILE.EXT", "").trim();
            GNUPG_ENC_PUBLIC_KEY = prop.getProperty("GNUPG.ENC.PUBLIC.KEY");
            GNUPG_ENC_EXT = prop.getProperty("GNUPG.ENC.EXT", "").trim();

            GNUPG_DEC_PRIVATE_KEY = prop.getProperty("GNUPG.DEC.PRIVATE.KEY");
            GNUPG_DEC_PASSPHARASE = prop.getProperty("GNUPG.DEC.PASSPHARASE", "").trim();
            GNUPG_DEC_PASSPHARASE_ENC_FLAG = Boolean.parseBoolean(prop.getProperty("GNUPG.DEC.PASSPHARASE.ENC.FLAG", "false").trim());
            GNUPG_DEC_EXT = prop.getProperty("GNUPG.DEC.EXT", "").trim();

            //RPUSH
            RPUSH_COMM_TYPE = prop.getProperty("RPUSH.COMM.TYPE", "").trim();
            RPUSH_ENABLE = Boolean.parseBoolean(prop.getProperty("RPUSH.ENABLE", "false").trim());
            RPUSH_PROT = prop.getProperty("RPUSH.PROT");
            RPUSH_HOST = prop.getProperty("RPUSH.HOST");
            RPUSH_PORT = Integer.parseInt(prop.getProperty("RPUSH.PORT", "22"));
            RPUSH_USER = prop.getProperty("RPUSH.USER");
            RPUSH_PASSWORD = prop.getProperty("RPUSH.PASSWORD");
            RPUSH_PASSWORD_ENC = Boolean.parseBoolean(prop.getProperty("RPUSH.PASSWORD.ENC", "false").trim());
            RPUSH_PWD_FLAG = Boolean.parseBoolean(prop.getProperty("RPUSH.PWD.FLAG", "false").trim());
            RPUSH_FTPS_MODE = prop.getProperty("RPUSH.FTPS.MODE", "").trim();
            RPUSH_LCL_DIR = prop.getProperty("RPUSH.LCL.DIR");
            RPUSH_REMOTE_DIR = prop.getProperty("RPUSH.REMOTE.DIR");
            RPUSH_DEL_LOCAL = Boolean.parseBoolean(prop.getProperty("RPUSH.DEL.LOCAL", "false").trim());
            RPUSH_CFILE_EXT = prop.getProperty("RPUSH.CFILE.EXT", "").trim();
            RPUSH_MFILE_EXT = prop.getProperty("RPUSH.MFILE.EXT", "").trim();
            RPUSH_CFILE_ON_COMPL = Boolean.parseBoolean(prop.getProperty("RPUSH.COMP.FLAG", "false").trim());
            RPUSH_BKP_DIR = prop.getProperty("RPUSH.BKP.DIR", "").trim();
            RPUSH_SSL_KEY = prop.getProperty("RPUSH.SSL.KEY");
            RPUSH_SSL_PHRASE = prop.getProperty("RPUSH.SSL.PHRASE", "").trim();
            RPUSH_ENC_KEY = prop.getProperty("RPUSH.ENC.KEY");
            RPUSH_ENC_PHRASE = prop.getProperty("RPUSH.ENC.PHRASE", "").trim();
            RPUSH_ENC_EXT = prop.getProperty("RPUSH.ENC.EXT", "").trim();
            RPUSH_GNUPG_ENC_FLAG = Boolean.parseBoolean(prop.getProperty("RPUSH.GNUPG.ENC.FLAG", "false").trim());
            RPUSH_ZIP_ENC_FLAG = Boolean.parseBoolean(prop.getProperty("RPUSH.ZIP.ENC.FLAG", "false").trim());

            //RPULL
            RPULL_COMM_TYPE = prop.getProperty("RPULL.COMM.TYPE", "").trim();
            RPULL_ENABLE = Boolean.parseBoolean(prop.getProperty("RPULL.ENABLE", "false").trim());
            RPULL_PROT = prop.getProperty("RPULL.PROT");
            RPULL_HOST = prop.getProperty("RPULL.HOST");
            RPULL_PORT = Integer.parseInt(prop.getProperty("RPULL.PORT", "22").trim());
            RPULL_USER = prop.getProperty("RPULL.USER");
            RPULL_PASSWORD = prop.getProperty("RPULL.PASSWORD");
            RPULL_PASSWORD_ENC = Boolean.parseBoolean(prop.getProperty("RPULL.PASSWORD.ENC", "false").trim());
            RPULL_PWD_FLAG = Boolean.parseBoolean(prop.getProperty("RPULL.PWD.FLAG", "false").trim());
            RPULL_FTPS_MODE = prop.getProperty("RPULL.FTPS.MODE", "").trim();
            RPULL_LCL_DIR = prop.getProperty("RPULL.LCL.DIR");
            RPULL_REMOTE_DIR = prop.getProperty("RPULL.REMOTE.DIR");
            RPULL_DEL_REMOTE = Boolean.parseBoolean(prop.getProperty("RPULL.DEL.REMOTE", "false").trim());
            RPULL_CFILE_EXT = prop.getProperty("RPULL.CFILE.EXT", "").trim();
            RPULL_MFILE_EXT = prop.getProperty("RPULL.MFILE.EXT", "").trim();
            RPULL_CFILE_ON_COMPL = Boolean.parseBoolean(prop.getProperty("RPULL.COMP.FLAG", "false").trim());
            RPULL_BKP_DIR = prop.getProperty("RPULL.BKP.DIR", "").trim();
            RPULL_SSL_KEY = prop.getProperty("RPULL.SSL.KEY");
            RPULL_SSL_PHRASE = prop.getProperty("RPULL.SSL.PHRASE", "").trim();
            RPULL_ENC_KEY = prop.getProperty("RPULL.ENC.KEY");
            RPULL_ENC_PHRASE = prop.getProperty("RPULL.ENC.PHRASE", "").trim();
            RPULL_ENC_EXT = prop.getProperty("RPULL.ENC.EXT", "").trim();
            RPULL_GNUPG_DECRYPT_FLAG = Boolean.parseBoolean(prop.getProperty("RPULL.GNUPG.DECRYPT.FLAG", "false").trim());
            RPULL_ZIP_DCYPT_FLAG = Boolean.parseBoolean(prop.getProperty("RPULL.ZIP.DCYPT.FLAG", "false").trim());

            //System.out.println("RPUSH_PASSWORD " + RPUSH_PASSWORD + " " + PropertyValueEncryptionUtils.encrypt(RPUSH_PASSWORD, encryptor));
            if (RPUSH_PASSWORD_ENC) {
                RPUSH_PASSWORD = PropertyValueEncryptionUtils.decrypt(RPUSH_PASSWORD, encryptor);
            }
            if (RPULL_PASSWORD_ENC) {
                RPULL_PASSWORD = PropertyValueEncryptionUtils.decrypt(RPULL_PASSWORD, encryptor);
            }
            if (ZIP_ENC_PASSWORD_ENC_FLAG) {
                ZIP_ENC_PASSWORD = PropertyValueEncryptionUtils.decrypt(ZIP_ENC_PASSWORD, encryptor);
            }
            if (GNUPG_DEC_PASSPHARASE_ENC_FLAG) {
                GNUPG_DEC_PASSPHARASE = PropertyValueEncryptionUtils.decrypt(GNUPG_DEC_PASSPHARASE, encryptor);
            }

            if (RPULL_MFILE_EXT.startsWith(".")) {
                RPULL_MFILE_EXT = RPULL_MFILE_EXT.substring(1);
            }
            if (RPUSH_MFILE_EXT.startsWith(".")) {
                RPUSH_MFILE_EXT = RPUSH_MFILE_EXT.substring(1);
            }
            loaded = true;
        } catch (IOException ex) {
            log.error("Property File not found " + ex);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                }
            }
        }
    }
}
