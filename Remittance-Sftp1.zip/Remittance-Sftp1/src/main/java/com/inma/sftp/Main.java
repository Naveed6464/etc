package com.inma.sftp;

import com.inma.rmt.sftp.SftpPassphraseUserInfo;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.util.Properties;
import javax.net.ssl.KeyManager;
import javax.net.ssl.X509TrustManager;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.io.Util;
import org.apache.commons.net.util.TrustManagerUtils;
import org.apache.commons.vfs2.FileExtensionSelector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.VFS;
import org.apache.commons.vfs2.provider.ftp.FtpFileSystemConfigBuilder;
import org.apache.commons.vfs2.provider.ftps.FtpsFileSystemConfigBuilder;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;

public class Main {

    /**
     * @param args the command line arguments
     */
    /*private static String sftpClientHost;
     private static String sftpClientUsername;
     private static String sftpClientPassword;
     private static String sftpClientDIR;    
     private static String sftpRemoteHost;
     private static String sftpRemoteUsername;
     private static String sftpRemotePassword;
     private static String sftpRemotetDIR;*/
    private static String host;
    private static String user;
    private static String pass;
    private static String srcDir;
    private static String dstDir;
    private static String type;

    private static String remtoteType;
    private static String bankName;
    private static String keyPass;
    private static String keyFilePath;
    private static boolean noPass;
    private static String srcFilePattern;
    private static String dstFilePattern;

    private static FileSystemManager fsManager;

    public static void main(String[] args) throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        loadPropertyFile();
        //System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
        fsManager = VFS.getManager();
        if (type.equals("push") || type.equals("PUSH")) {
            if (remtoteType.equals("SFTP") || remtoteType.equals("sftp")) {
                push();
            } else if (remtoteType.equals("FTPS") || remtoteType.equals("ftps")) {
                pushFTPS();
            } else if (remtoteType.equals("FTP") || remtoteType.equals("ftp")) {
                pushFTP();
            }
        } else if (type.equals("pull") || type.equals("PULL")) {
            if (remtoteType.equals("SFTP") || remtoteType.equals("sftp")) {
                pull();
            } else if (remtoteType.equals("FTPS") || remtoteType.equals("ftps")) {
                pullFTPS();
            } else if (remtoteType.equals("FTP") || remtoteType.equals("ftp")) {
                pullFTP();
            }
        } else if (type.equals("list") || type.equals("ls")) {
            if (remtoteType.equals("SFTP") || remtoteType.equals("sftp")) {
                ls();
            } else if (remtoteType.equals("FTPS") || remtoteType.equals("ftps")) {
                lsFTPS();
            } else if (remtoteType.equals("FTP") || remtoteType.equals("ftp")) {
                lsFTP();
            }
        } else {
            System.out.println("Invalid type ");
        }
        System.out.println("Job Completed");
    }

    public static void push() throws FileSystemException {
        FileObject fileObjectRemote = fsManager.resolveFile(sftpConnection(), sftpOptions());
        FileObject fileObjectClient = fsManager.resolveFile(srcDir);
        for (FileObject file : fileObjectClient.findFiles(new FileExtensionSelector(srcFilePattern))) {
            System.out.println("Uploding the File --> " + file.getName().getBaseName());
            FileObject remoteFile = fileObjectRemote.resolveFile(file.getName().getBaseName());
            remoteFile.copyFrom(file, Selectors.SELECT_SELF);
            file.delete();
        }
    }

    public static void pull() throws FileSystemException {
        FileObject fileObjectRemote = fsManager.resolveFile(sftpConnection(), sftpOptions());
        FileObject fileObjectClient = fsManager.resolveFile(srcDir);
        for (FileObject file : fileObjectRemote.findFiles(new FileExtensionSelector(dstFilePattern))) {
            System.out.println("Downloading the File --> " + file.getName().getBaseName());
            FileObject clientFile = fileObjectClient.resolveFile(file.getName().getBaseName());
            clientFile.copyFrom(file, Selectors.SELECT_SELF);
            file.delete();
        }
    }

    public static void pushFTPS() throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        FileObject fileObjectRemote = fsManager.resolveFile(ftpsConnection(), ftpsOptions());
        FileObject fileObjectClient = fsManager.resolveFile(srcDir);
        for (FileObject file : fileObjectClient.getChildren()) {
            System.out.println("Uploding the File --> " + file.getName().getBaseName());
            FileObject remoteFile = fileObjectRemote.resolveFile(file.getName().getBaseName());
            remoteFile.copyFrom(file, Selectors.SELECT_SELF);
            file.delete();
        }
    }

    public static void pullFTPS() throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        FileObject fileObjectRemote = fsManager.resolveFile(ftpsConnection(), ftpsOptions());
        FileObject fileObjectClient = fsManager.resolveFile(srcDir);
        for (FileObject file : fileObjectRemote.getChildren()) {
            System.out.println("Downloading the File --> " + file.getName().getBaseName());
            FileObject clientFile = fileObjectClient.resolveFile(file.getName().getBaseName());
            clientFile.copyFrom(file, Selectors.SELECT_SELF);
            file.delete();
        }
    }

    public static void pushFTP() throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        FileObject fileObjectRemote = fsManager.resolveFile(ftpConnection(), ftpOptions());
        FileObject fileObjectClient = fsManager.resolveFile(srcDir);
        for (FileObject file : fileObjectClient.getChildren()) {
            System.out.println("Uploding the File --> " + file.getName().getBaseName());
            FileObject remoteFile = fileObjectRemote.resolveFile(file.getName().getBaseName());
            remoteFile.copyFrom(file, Selectors.SELECT_SELF);
            file.delete();
        }
    }

    public static void pullFTP() throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        FileObject fileObjectRemote = fsManager.resolveFile(ftpConnection(), ftpOptions());
        FileObject fileObjectClient = fsManager.resolveFile(srcDir);
        for (FileObject file : fileObjectRemote.getChildren()) {
            System.out.println("Downloading the File --> " + file.getName().getBaseName());
            FileObject clientFile = fileObjectClient.resolveFile(file.getName().getBaseName());
            clientFile.copyFrom(file, Selectors.SELECT_SELF);
            file.delete();
        }
    }

    public static void ls() throws FileSystemException {
        FileObject fileObjectRemote = fsManager.resolveFile(sftpConnection(), sftpOptions());
        for (FileObject file : fileObjectRemote.getChildren()) {
            System.out.println("File --> " + file.getName().getBaseName());
        }
    }

    public static void lsFTPS() throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        FileObject fileObjectRemote = fsManager.resolveFile(ftpsConnection(), ftpsOptions());
        for (FileObject file : fileObjectRemote.getChildren()) {
            System.out.println("File --> " + file.getName().getBaseName());
        }
    }

    public static void lsFTP() throws FileSystemException, IOException, GeneralSecurityException, URISyntaxException {
        FileObject fileObjectRemote = fsManager.resolveFile(ftpConnection(), ftpOptions());
        for (FileObject file : fileObjectRemote.getChildren()) {
            System.out.println("File --> " + file.getName().getBaseName());
        }
    }

    public static void downloadInwardFiles() throws FileSystemException {
        FileObject fileObjectRemote = fsManager.resolveFile(sftpConnection(), sftpOptions());
        FileObject fileObjectClient = fsManager.resolveFile(sftpConnection(), sftpOptions());
        for (FileObject remoteFile : fileObjectRemote.getChildren()) {
            System.out.println("Downloading Remittance Inward File --> " + remoteFile.getName().getBaseName());
            FileObject clientFile = fileObjectClient.resolveFile(remoteFile.getName().getBaseName());
            clientFile.copyFrom(remoteFile, Selectors.SELECT_SELF_AND_CHILDREN);
            System.out.println("File " + clientFile.isFile());
            remoteFile.delete();
        }
    }

    public static void uploadOutwardFiles() throws FileSystemException {
        FileObject fileObjectRemote = fsManager.resolveFile(sftpConnection(), sftpOptions());
        FileObject fileObjectClient = fsManager.resolveFile(sftpConnection(), sftpOptions());
        for (FileObject file : fileObjectClient.getChildren()) {
            System.out.println("Uploading Remittance Outward File --> " + file.getName().getBaseName());
            FileObject remoteFile = fileObjectRemote.resolveFile(file.getName().getBaseName());
            remoteFile.copyFrom(file, Selectors.SELECT_FILES);
            file.delete();
        }
    }

    // Establishing connection
    public static String sftpConnection(String host, String username, String password, String path) {
        return "sftp://" + username + ":" + password + "@" + host + "/" + path;
    }

    public static String sftpConnection() {
        if (!noPass) {
            return "sftp://" + user + ":" + pass + "@" + host + "/" + dstDir;
        } else {
            return "sftp://" + user + "@" + host + "/" + dstDir;
        }
    }

    public static String ftpConnection() throws URISyntaxException {
        if (!noPass) {
            String userInfo = user + ":" + pass;
            URI uri = new URI("ftp", userInfo, host, 22, dstDir, null, null);
            return uri.toString();//"ftps://" + user + ":" + pass + "@" + host + "/" + dstDir;
        } else {
            return "ftp://" + user + "@" + host + "/" + dstDir;
        }
    }

    public static String ftpsConnection() throws URISyntaxException {
        if (!noPass) {
            String userInfo = user + ":" + pass;
            URI uri = new URI("ftps", userInfo, host, 22, dstDir, null, null);
            return uri.toString();//"ftps://" + user + ":" + pass + "@" + host + "/" + dstDir;
        } else {
            return "ftps://" + user + "@" + host + "/" + dstDir;
        }
    }

    //  Method to setup default SFTP config:
    public static FileSystemOptions sftpOptions() throws FileSystemException {
        if (!noPass) {
            FileSystemOptions opts = new FileSystemOptions(); // Create SFTP options
            SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no"); // SSH Key checking       
            SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
            SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000); // Timeout is count by Milliseconds
            return opts;
        } else {
            return sftpOptionsWithKey();
        }
    }

    public static FileSystemOptions sftpOptionsWithKey() throws FileSystemException {
        FileSystemOptions opts = new FileSystemOptions(); // Create SFTP options
        SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no"); // SSH Key checking       
        SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
        SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000); // Timeout is count by Milliseconds
        if (keyFilePath != null) {
            SftpFileSystemConfigBuilder.getInstance().setUserInfo(opts, new SftpPassphraseUserInfo(keyPass));
            SftpFileSystemConfigBuilder.getInstance().setIdentities(opts, new File[]{new File(keyFilePath)});
        }
        return opts;
    }

    public static FileSystemOptions ftpOptions() throws FileSystemException, IOException, GeneralSecurityException {
        FileSystemOptions opts = new FileSystemOptions(); // Create FTPS options                 
        FtpFileSystemConfigBuilder.getInstance().setPassiveMode(opts, true);
        FtpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
        FtpFileSystemConfigBuilder.getInstance().setDataTimeout(opts, 10000); // Timeout is count by Milliseconds
        return opts;
    }

    //  Method to setup default SFTP config:
    public static FileSystemOptions ftpsOptions() throws FileSystemException, IOException, GeneralSecurityException {
        if (!noPass) {
            FileSystemOptions opts = new FileSystemOptions(); // Create FTPS options                 
            FtpsFileSystemConfigBuilder.getInstance().setPassiveMode(opts, true);
            FtpsFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
            FtpsFileSystemConfigBuilder.getInstance().setDataTimeout(opts, 10000); // Timeout is count by Milliseconds
            return opts;
        } else {
            return ftpsOptionsWithKey();
        }
    }

    public static FileSystemOptions ftpsOptionsWithKey() throws FileSystemException, IOException, GeneralSecurityException {
        FileSystemOptions opts = new FileSystemOptions();
        FtpsFileSystemConfigBuilder.getInstance().setPassiveMode(opts, true);
        FtpsFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true);
        FtpsFileSystemConfigBuilder.getInstance().setDataTimeout(opts, 10000);
        if (keyPass != null) {
            //KeyStore keyStore = loadStore("JKS", new File(""), "password");
            //X509TrustManager defaultTrustManager = TrustManagerUtils.getDefaultTrustManager(keyStore);
            KeyManager keyManager = org.apache.commons.net.util.KeyManagerUtils.createClientKeyManager(new File(keyFilePath), keyPass);
            //FtpsFileSystemConfigBuilder.getInstance().setTrustManager(opts, defaultTrustManager);
            FtpsFileSystemConfigBuilder.getInstance().setKeyManager(opts, keyManager);
        }
        return opts;
    }

    public void ftpClient() throws IOException {
        FTPClient client = new FTPClient();
        client.connect("10.0.2.42", 22);
        client.enterLocalPassiveMode();
        client.login("rmtsftp", "$123Rmtsftp");
        FTPFile[] files = client.listFiles("/arif/");
        for (FTPFile file : files) {
            System.out.println(file.getName());
        }
    }

    private static void loadPropertyFile() {
        Properties prop = new Properties();
        InputStream input = null;
        try {
            input = new FileInputStream("config.properties");
            prop.load(input);
            //sftpClientHost = prop.getProperty("sftpClientHost");
            //sftpClientUsername = prop.getProperty("sftpClientUsername");
            //sftpClientPassword = prop.getProperty("sftpClientPassword");              
            //sftpRemoteHost = prop.getProperty("sftpRemoteHost");
            //sftpRemoteUsername = prop.getProperty("sftpRemoteUsername");
            //sftpRemotePassword = prop.getProperty("sftpRemotePassword");            

            host = prop.getProperty("Host");
            user = prop.getProperty("User");
            pass = prop.getProperty("Pass");
            srcDir = prop.getProperty("SrcDir");
            dstDir = prop.getProperty("DstDir");
            type = prop.getProperty("Type");
            remtoteType = prop.getProperty("RemtoteType");
            bankName = prop.getProperty("BankName");
            keyPass = prop.getProperty("KeyPass");
            keyFilePath = prop.getProperty("KeyFilePath");
            noPass = Boolean.parseBoolean(prop.getProperty("NoPass"));
            srcFilePattern = prop.getProperty("SrcFilePattern");
            dstFilePattern = prop.getProperty("DstFilePattern");

            if (srcFilePattern.startsWith(".")) {
                srcFilePattern = srcFilePattern.substring(1);
            }
            if (dstFilePattern.startsWith(".")) {
                dstFilePattern = dstFilePattern.substring(1);
            }
        } catch (IOException ex) {
            System.out.println("Properties File not found " + ex);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                }
            }
        }
    }

    /**
     * http://stackoverflow.com/questions/19173394/how-do-i-configure-client-authentication-with-generated-certificate-in-apache-co
     */
    private static KeyStore loadStore(String storeType, File storePath, String storePass) throws KeyStoreException, IOException, GeneralSecurityException {
        KeyStore ks = KeyStore.getInstance(storeType);
        FileInputStream stream = null;
        try {
            stream = new FileInputStream(storePath);
            ks.load(stream, storePass.toCharArray());
        } finally {
            Util.closeQuietly(stream);
        }
        return ks;
    }
}
