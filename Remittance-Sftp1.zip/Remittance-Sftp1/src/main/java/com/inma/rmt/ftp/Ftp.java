/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ftp;

import com.inma.rmt.core.AbstractProvider;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.provider.ftp.FtpFileSystemConfigBuilder;

/**
 *
 * @author nmrehman
 */
public class Ftp extends AbstractProvider {

    @Override
    public String connection(Type type) {
        switch (type) {
            case PUSH:
                if (properties.isRPUSH_PWD_FLAG()) {
                    //return "ftp://" + properties.getRPUSH_USER() + ":" + properties.getRPUSH_PASSWORD() + "@" + properties.getRPUSH_HOST() + "/" + properties.getRPUSH_REMOTE_DIR();
                    try {
                        String userInfo = properties.getRPUSH_USER() + ":" + properties.getRPUSH_PASSWORD();
                        URI uri = new URI("ftp", userInfo, properties.getRPUSH_HOST(), properties.getRPULL_PORT(), properties.getRPUSH_REMOTE_DIR(), null, null);
                        return uri.toString();
                    } catch (URISyntaxException ex) {
                        log.error("Uri Exception : " + ex);
                    }
                } else {
                    return "ftp://" + properties.getRPUSH_USER() + "@" + properties.getRPUSH_HOST() + "/" + properties.getRPUSH_REMOTE_DIR();
                }
                break;
            case PULL:
                if (properties.isRPULL_PWD_FLAG()) {
                    //return "sftp://" + properties.getRPULL_USER() + ":" + properties.getRPULL_PASSWORD() + "@" + properties.getRPULL_HOST() + "/" + properties.getRPULL_REMOTE_DIR();
                    String userInfo = properties.getRPULL_USER() + ":" + properties.getRPULL_PASSWORD();
                    try {
                        URI uri = new URI("ftp", userInfo, properties.getRPULL_HOST(), properties.getRPULL_PORT(), properties.getRPULL_REMOTE_DIR(), null, null);
                        return uri.toString();
                    } catch (URISyntaxException ex) {
                        log.error("Uri Exception : " + ex);
                    }
                } else {
                    return "ftp://" + properties.getRPULL_USER() + "@" + properties.getRPULL_HOST() + "/" + properties.getRPULL_REMOTE_DIR();
                }
        }
        return "";
    }

    @Override
    public FileSystemOptions options(Type type) {
        FileSystemOptions opts = new FileSystemOptions(); // Create SFTP options
        switch (type) {
            case PUSH:
                if (properties.isRPUSH_PWD_FLAG()) {
                    FtpFileSystemConfigBuilder.getInstance().setPassiveMode(opts, true);
                    FtpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
                    FtpFileSystemConfigBuilder.getInstance().setDataTimeout(opts, 10000); // Timeout is count by Milliseconds
                }
                break;
            case PULL:
                if (properties.isRPULL_PWD_FLAG()) {
                    FtpFileSystemConfigBuilder.getInstance().setPassiveMode(opts, true);
                    FtpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
                    FtpFileSystemConfigBuilder.getInstance().setDataTimeout(opts, 10000); // Timeout is count by Milliseconds
                }
                break;
        }
        return opts;
    }

}
