/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ftps;

import com.inma.rmt.core.AbstractProvider;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import javax.net.ssl.KeyManager;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.provider.ftps.FtpsFileSystemConfigBuilder;
import org.apache.commons.vfs2.provider.ftps.FtpsMode;

/**
 *
 * @author nmrehman
 */
public class Ftps extends AbstractProvider {

    @Override
    public String connection(Type type) {
        switch (type) {
            case PUSH:
                try {
                    String userInfo = properties.getRPUSH_USER() + ":" + properties.getRPUSH_PASSWORD();
                    URI uri = new URI("ftps", userInfo, properties.getRPUSH_HOST(), properties.getRPULL_PORT(), properties.getRPUSH_REMOTE_DIR(), null, null);
                    //return "ftps://" + properties.getRPUSH_USER() + ":" + properties.getRPUSH_PASSWORD() + "@" + properties.getRPUSH_HOST() + "/" + properties.getRPUSH_REMOTE_DIR();
                    return uri.toString();
                } catch (URISyntaxException ex) {
                    log.error("Uri Exception : " + ex);
                }
                break;
            case PULL:
                String userInfo = properties.getRPULL_USER() + ":" + properties.getRPULL_PASSWORD();
                try {
                    URI uri = new URI("ftps", userInfo, properties.getRPULL_HOST(), properties.getRPULL_PORT(), properties.getRPULL_REMOTE_DIR(), null, null);
                    //return "ftps://" + userInfo + "@" + properties.getRPULL_HOST() + "/" + properties.getRPULL_REMOTE_DIR();
                    return uri.toString();
                } catch (Exception ex) {
                    log.error("Uri Exception : " + ex);
                }
        }
        return "";
    }

    @Override
    public FileSystemOptions options(Type type) {
        FileSystemOptions opts = new FileSystemOptions(); // Create SFTP options
        FtpsFileSystemConfigBuilder.getInstance().setPassiveMode(opts, true);
        FtpsFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true); // Root directory set to user home        
        FtpsFileSystemConfigBuilder.getInstance().setDataTimeout(opts, 10000); // Timeout is count by Milliseconds
        switch (type) {
            case PUSH:
                if (properties.getRPUSH_FTPS_MODE().equals("IMPLICIT")) {
                    FtpsFileSystemConfigBuilder.getInstance().setFtpsMode(opts, FtpsMode.IMPLICIT);
                } else if (properties.getRPUSH_FTPS_MODE().equals("EXPLICIT")) {
                    FtpsFileSystemConfigBuilder.getInstance().setFtpsMode(opts, FtpsMode.EXPLICIT);
                }
                if (!properties.isRPUSH_PWD_FLAG()) {
                    optionsWithKey(type, opts);
                }
                break;
            case PULL:
                if (properties.getRPULL_FTPS_MODE().equals("IMPLICIT")) {
                    FtpsFileSystemConfigBuilder.getInstance().setFtpsMode(opts, FtpsMode.IMPLICIT);
                } else if (properties.getRPULL_FTPS_MODE().equals("EXPLICIT")) {
                    FtpsFileSystemConfigBuilder.getInstance().setFtpsMode(opts, FtpsMode.EXPLICIT);
                }
                if (!properties.isRPULL_PWD_FLAG()) {
                    optionsWithKey(type, opts);
                }
                break;
        }
        return opts;
    }

    public FileSystemOptions optionsWithKey(Type type, FileSystemOptions opts) {
        switch (type) {
            case PUSH:
                if (properties.getRPUSH_SSL_KEY() != null) {
                    try {
                        //KeyStore keyStore = loadStore("JKS", new File(""), "password");
                        //X509TrustManager defaultTrustManager = TrustManagerUtils.getDefaultTrustManager(keyStore);
                        KeyManager keyManager = org.apache.commons.net.util.KeyManagerUtils.createClientKeyManager(new File(properties.getRPUSH_SSL_KEY()), properties.getRPUSH_SSL_PHRASE());
                        //FtpsFileSystemConfigBuilder.getInstance().setTrustManager(opts, defaultTrustManager);
                        FtpsFileSystemConfigBuilder.getInstance().setKeyManager(opts, keyManager);
                    } catch (IOException ex) {
                        log.error("IO Exception while setting Key  " + ex);
                    } catch (GeneralSecurityException ex) {
                        log.error("Security Exception while setting Key  " + ex);
                    }
                }
                break;
            case PULL:
                if (properties.getRPULL_SSL_KEY() != null) {
                    try {
                        //KeyStore keyStore = loadStore("JKS", new File(""), "password");
                        //X509TrustManager defaultTrustManager = TrustManagerUtils.getDefaultTrustManager(keyStore);
                        KeyManager keyManager = org.apache.commons.net.util.KeyManagerUtils.createClientKeyManager(new File(properties.getRPULL_SSL_KEY()), properties.getRPULL_SSL_PHRASE());
                        //FtpsFileSystemConfigBuilder.getInstance().setTrustManager(opts, defaultTrustManager);
                        FtpsFileSystemConfigBuilder.getInstance().setKeyManager(opts, keyManager);
                    } catch (IOException ex) {
                        log.error("IO Exception while setting Key  " + ex);
                    } catch (GeneralSecurityException ex) {
                        log.error("Security Exception while setting Key  " + ex);
                    }
                }
                break;
        }
        return opts;
    }

}
