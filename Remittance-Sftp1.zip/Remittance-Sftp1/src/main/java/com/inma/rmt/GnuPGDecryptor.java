/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt;

import com.inma.rmt.core.BouncyCastleGnuPGEncryption;
import java.io.File;
import java.security.NoSuchProviderException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author nmrehman
 */
public class GnuPGDecryptor {

    protected static BouncyCastleGnuPGEncryption gpgEncryption = new BouncyCastleGnuPGEncryption();
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void printVersion() {
        String message = "Remittance-Sftp Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    public static void main(String[] args) throws NoSuchProviderException {
        printVersion();
        if (args.length != 4) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.GnuPGDecryptor <FileToEncrypt, PrivateKey, PublicKey, Password>";
            System.out.println(message);
            System.exit(1);
        }
        String fileName = args[0];
        String privateKey = args[1];
        String publicKey = args[2];
        String password = args[3];
        String outFilePath = "output";
        File file = new File(outFilePath + "/");
        file.mkdirs();
        gpgEncryption.decryptFile(fileName, outFilePath, privateKey, publicKey, password);
    }
}
