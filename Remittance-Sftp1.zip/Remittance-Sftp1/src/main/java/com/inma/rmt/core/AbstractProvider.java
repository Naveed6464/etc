/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.core;

import com.inma.rmt.config.AppProperties;
import java.net.URISyntaxException;
import org.apache.commons.vfs2.FileExtensionSelector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.VFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
public abstract class AbstractProvider implements Provider {

    protected final static Logger log = LoggerFactory.getLogger(AbstractProvider.class);

    protected AppProperties properties = AppProperties.getInstance();
    protected FileSystemManager fsManager;
    protected BouncyCastleGnuPGEncryption gpgEncryption = new BouncyCastleGnuPGEncryption();
    protected ZipEncryption zipEncryption = new ZipEncryption();

    public AbstractProvider() {
        try {
            fsManager = VFS.getManager();
        } catch (FileSystemException ex) {
            log.error("Not able initiate VFS manger");
        }
    }

    @Override
    public void pull() {
        try {
            if (!properties.getRPULL_COMM_TYPE().equals("JAVA")) {
                System.out.println("Invalid Communction Channel. Kindly check the properties file!");
                return;
            }
            Type pull = Type.PULL;
            FileObject fileObjectRemote = fsManager.resolveFile(connection(pull), options(pull));
            FileObject fileObjectClient = fsManager.resolveFile(properties.getRPULL_LCL_DIR());
            for (FileObject file : fileObjectRemote.findFiles(new FileExtensionSelector(properties.getRPULL_MFILE_EXT()))) {
                log.info("Downloading the remittance file " + file.getName().getBaseName());

                FileObject clientFile = fileObjectClient.resolveFile(file.getName().getBaseName());
                clientFile.copyFrom(file, Selectors.SELECT_SELF);

                if (properties.isRPULL_GNUPG_DECRYPT_FLAG()) {
                    try {
                        log.info("Decrypting the GnuPG file " + file.getName().getBaseName());
                        gpgEncryption.decryptFile(clientFile.getURL().toURI().getPath(), properties.getRPULL_LCL_DIR(),
                                properties.getGNUPG_DEC_PRIVATE_KEY(), properties.getGNUPG_ENC_PUBLIC_KEY(), properties.getGNUPG_DEC_PASSPHARASE());
                    } catch (URISyntaxException ex) {
                        log.error("Exception on GnuPG file name : " + ex);
                    }
                } else if (properties.isRPULL_ZIP_DCYPT_FLAG()) {
                    try {
                        log.info("Decrypting the ZIP file " + file.getName().getBaseName());
                        zipEncryption.decrypt(clientFile.getURL().toURI().getPath(), properties.getZIP_ENC_PASSWORD(), properties.getRPULL_LCL_DIR());
                    } catch (URISyntaxException ex) {
                        log.error("Exception on ZIP file name : " + ex);
                    }
                }
                if (properties.isRPULL_DEL_REMOTE()) {
                    /*if (!properties.getRPULL_BKP_DIR().isEmpty()) { //InFuture We will add this feature
                     FileObject fileObjectBkp = fsManager.resolveFile(properties.getRPULL_BKP_DIR() + "/" + file.getName().getBaseName() + "_SENT");
                     fileObjectBkp.copyFrom(file, Selectors.SELECT_SELF);
                     }*/
                    file.delete();
                    String fileName = file.getName().getBaseName();
                    String cFileName = fileName.replace("." + file.getName().getExtension(), properties.getRPULL_CFILE_EXT());
                    FileObject cFile = fileObjectRemote.resolveFile(cFileName);
                    if (cFile.exists()) {
                        cFile.delete();
                    }
                }
                if (properties.isRPULL_CFILE_ON_COMPL()) {
                    FileObject tochFile = fileObjectClient.resolveFile(file.getName().getBaseName() + properties.getRPULL_CFILE_EXT());
                    tochFile.createFile();
                }
            }
        } catch (FileSystemException ex) {
            log.error("Exception while pulling the file" + ex);
        }
    }

    @Override
    public void push() {
        try {
            if (!properties.getRPUSH_COMM_TYPE().equals("JAVA")) {
                System.out.println("Invalid Communction Channel. Kindly check the properties file!");
                return;
            }
            Type push = Type.PUSH;
            FileObject fileObjectRemote = fsManager.resolveFile(connection(push), options(push));
            FileObject fileObjectClient = fsManager.resolveFile(properties.getRPUSH_LCL_DIR());
            for (FileObject file : fileObjectClient.findFiles(new FileExtensionSelector(properties.getRPUSH_MFILE_EXT()))) {
                log.info("Uploading the File --> " + file.getName().getBaseName());

                if (properties.isRPUSH_GNUPG_ENC_FLAG()) {
                    try {
                        log.info("Encrypting the GnuPG file " + file.getName().getBaseName());
                        gpgEncryption.encryptFile(file.getURL().toURI().getPath(), file.getURL().toURI().getPath() + properties.getGNUPG_ENC_EXT(), properties.getGNUPG_ENC_PUBLIC_KEY());

                        String encFileName = file.getName().getBaseName() + properties.getGNUPG_ENC_EXT();
                        FileObject encFileObject = fileObjectClient.resolveFile(encFileName);
                        FileObject remoteFile = fileObjectRemote.resolveFile(encFileName);
                        remoteFile.copyFrom(encFileObject, Selectors.SELECT_SELF);
                        if (properties.isRPUSH_DEL_LOCAL()) {
                            encFileObject.delete();
                        }
                    } catch (URISyntaxException ex) {
                        log.error("Exception on GnuPG file name : " + ex);
                    }
                } else if (properties.isRPUSH_ZIP_ENC_FLAG()) {
                    try {
                        log.info("Encrypting the ZIP file " + file.getName().getBaseName());
                        String zipFileName = file.getName().getBaseName() + properties.getZIP_FILE_EXT();
                        zipEncryption.encrypt(properties.getRPUSH_LCL_DIR() + zipFileName, properties.getZIP_ENC_PASSWORD(), file.getURL().toURI().getPath());

                        FileObject zipFileObject = fileObjectClient.resolveFile(zipFileName); //Copy Zip File                        
                        FileObject remoteFile = fileObjectRemote.resolveFile(zipFileName);
                        remoteFile.copyFrom(zipFileObject, Selectors.SELECT_SELF);
                        if (properties.isRPUSH_DEL_LOCAL()) {
                            zipFileObject.delete();
                        }
                    } catch (URISyntaxException ex) {
                        log.error("Exception on ZIP file name : " + ex);
                    }
                } else {
                    FileObject remoteFile = fileObjectRemote.resolveFile(file.getName().getBaseName());
                    remoteFile.copyFrom(file, Selectors.SELECT_SELF);
                }

                if (properties.isRPUSH_DEL_LOCAL()) {
                    if (!properties.getRPUSH_BKP_DIR().isEmpty()) {
                        FileObject fileObjectBkp = fsManager.resolveFile(properties.getRPUSH_BKP_DIR() + "/" + file.getName().getBaseName() + "_SENT");
                        fileObjectBkp.copyFrom(file, Selectors.SELECT_SELF);
                    }
                    file.delete();
                }

                if (properties.isRPUSH_CFILE_ON_COMPL()) {
                    FileObject tochFile = fileObjectRemote.resolveFile(file.getName().getBaseName() + properties.getRPUSH_CFILE_EXT());
                    tochFile.createFile();
                }
            }
        } catch (FileSystemException ex) {
            log.error("Exception while pushing the file" + ex);
        }
    }

    @Override
    public void ls() {
        try {
            Type pull = Type.PULL;
            FileObject fileObjectRemote = fsManager.resolveFile(connection(pull), options(pull));
            for (FileObject file : fileObjectRemote.getChildren()) {
                System.out.println("File --> " + file.getName().getBaseName());
            }
        } catch (FileSystemException ex) {
            log.error("Exception while listing the file: " + ex);
        }
    }

}
