####################################################
##                                                ##
##  Remittance-SFTP start up script for UN*X      ##
##                                                ## 
####################################################
#### Naveed 
#### 30/12/2015

DEFAULT_JVM_OPTS=""

APP_NAME="Remittance-Sftp"

#export PATH=/usr/java7_64/bin:$PATH
#JAVA_HOME=/usr/java7_64/bin
APP_HOME=/home/rmftpprd/java/Remittance-Sftp


CLASSPATH=$APP_HOME/lib/Remittance-Sftp.jar:$APP_HOME/lib/commons-vfs2-2.1-SNAPSHOT.jar:$APP_HOME/lib/commons-net-3.4.jar:$APP_HOME/lib/commons-httpclient-3.1.jar:$APP_HOME/lib/jsch-0.1.53.jar:$APP_HOME/lib/zip4j-1.3.2.jar:$APP_HOME/lib/javadbf-0.4.0.jar:$APP_HOME/lib/slf4j-api-1.7.13.jar:$APP_HOME/lib/logback-classic-1.1.3.jar:$APP_HOME/lib/commons-logging-1.2.jar:$APP_HOME/lib/commons-codec-1.2.jar:$APP_HOME/lib/logback-core-1.1.3.jar

exec java -classpath "$CLASSPATH" com.inma.rmt.GnuPGEncryptor $1 $2 $3