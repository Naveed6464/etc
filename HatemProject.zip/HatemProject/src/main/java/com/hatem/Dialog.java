package com.hatem;

import java.util.ArrayList;

import org.json.JSONException;


public class Dialog {

	private static String [] lettersDecodeds;


	public class Answer {
		String Answer;
		int id;
	}
		
	
	public static String convertHexToString(String hex){

		  StringBuilder sb = new StringBuilder();
		  StringBuilder temp = new StringBuilder();

		  //49204c6f7665204a617661 split into two characters 49, 20, 4c...
		  for( int i=0; i<hex.length()-1; i+=2 ){

		      //grab the hex in pairs
		      String output = hex.substring(i, (i + 2));
		      //convert hex to decimal
		      int decimal = Integer.parseInt(output, 16);
		      //convert the decimal to character
		      sb.append((char)decimal);

		      temp.append(decimal);
		  }
		  System.out.println("Decimal : " + temp.toString());

		  return sb.toString();
	  }
		
	
	public static String getLastword(String quest){
		String words[];
		
		words = quest.split(" ");
		
		
		return words[words.length-1];
	}
	
	public static String choose(String question){
		String quest = getLastword(question);
		System.out.println(quest);
		System.out.println(question.contains("ذكر"));
		if (question.contains("ذكر")){
			
			
			
			
			RequetteSparql jena = new RequetteSparql();
    		
    		String rsultQuery = "";
    		
    		rsultQuery = jena.getInfo(quest);
    		System.out.println(rsultQuery);
    		String result = "";
			try {
				result = jena.getResult(rsultQuery);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		System.out.println(result);
    		return result;
			
			
		}else if (question.contains("عاش")){
RequetteSparql jena = new RequetteSparql();
    		
    		String rsultQuery = "";
    		
    		rsultQuery = jena.getPlace("");
    		System.out.println(rsultQuery);
    		String result = "";
			try {
				result = jena.getResultlived(rsultQuery, quest);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		System.out.println(result);
    		return result;
		}
		
		
		else if (question.contains("اولاد")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getChild("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultchild(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		else if (question.contains("اب")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getParent("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultparent(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		else if (question.contains("اجداد")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getGParent("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultgparent(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		else if (question.contains("قبيلة")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getMemberof("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultmemberof(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		else if (question.contains("معنى")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getCom("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultcom(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		else if (question.contains("عدو")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getEnemy("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultenemy(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		
		else if (question.contains("زوج")){
			RequetteSparql jena = new RequetteSparql();
			    		
			    		String rsultQuery = "";
			    		
			    		rsultQuery = jena.getEpousse("");
			    		System.out.println(rsultQuery);
			    		String result = "";
						try {
							result = jena.getResultepousse(rsultQuery, quest);
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    		System.out.println(result);
			    		return result;
					}
		
		else return ""; //fin
	}
	
	
	
	
	
	public static String textEncode(String decoded){
		lettersDecodeds = null;
		lettersDecodeds[1] = "%D8%A7";
		lettersDecodeds[2] = "%D8%A8";
		lettersDecodeds[3] = "%D8%AA";
		lettersDecodeds[4] = "%D8%AB";
		lettersDecodeds[5] = "%D8%AC";
		lettersDecodeds[6] = "%D8%AD";
		lettersDecodeds[7] = "";
		lettersDecodeds[8] = "";
		lettersDecodeds[9] = "";
		lettersDecodeds[10] = "";
		
		
		
		
		
		
		//--------------------------------------------------
		
		
		
		String []lettersEncoded = null;
		lettersEncoded[1] = "ا";
		lettersEncoded[2] = "ب";
		lettersEncoded[3] = "ت";
		lettersEncoded[4] = "ث";
		lettersEncoded[5] = "ج";
		lettersEncoded[6] = "ح";
		lettersEncoded[7] = "";
		lettersEncoded[8] = "";
		lettersEncoded[9] = "";
		lettersEncoded[10] = "";
		
		
		
		//-----------------------------------------------------------
		
		
		
		//decoded.replaceAll("%D8%A7", "ا").replaceAll("%D8%A8", "ب");
		
		
		String encoded = decoded;
		
		
		
		System.out.println(encoded);
		return encoded;
	}
	
	
	public static String text(String input){
		String output="";
		output = input.replaceAll("%D8%A3", "أ").replaceAll("%D8%9F","؟").replaceAll("%D8%A6", "ئ").replaceAll("%D8%A7", "ا").replaceAll("%D8%A8", "ب").replaceAll("%D8%AA", "ت").replaceAll("%D8%AB", "ث").replaceAll("%D8%AC", "ج").replaceAll("%D8%AD", "ح").replaceAll("%D8%AE", "خ").replaceAll("%D8%AF", "د").replaceAll("%D8%B0", "ذ").replaceAll("%D8%B1", "ر").replaceAll("%D8%B2", "ز").replaceAll("%D8%B3", "س").replaceAll("%D8%B4", "ش").replaceAll("%D8%B5", "ص").replaceAll("%D8%B6", "ض").replaceAll("%D8%B7", "ط").replaceAll("%D8%B8", "ظ").replaceAll("%D8%B9", "ع").replaceAll("%D8%BA", "غ").replaceAll("%D9%81", "ف").replaceAll("%D9%82", "ق").replaceAll("%D9%83", "ك").replaceAll("%D9%84", "ل").replaceAll("%D9%85", "م").replaceAll("%D9%86", "ن").replaceAll("%D9%87", "ه").replaceAll("%D9%88", "و").replaceAll("%D9%8A", "ي").replaceAll("%D8%A9", "ة").replaceAll("%D9%89", "ى");
		
		System.out.println(getLastword(output));
		
		return output;
	}
		
	
	Dialog(){
	
		
		
	}
	
	
	public String getFather(String son){
		String father = "";
		
		
		
		return father;
	}
	
	
	
	
	
}
