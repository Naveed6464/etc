package com.hatem;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.json.JSONException;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;


public class Main 
{
	
	
	/**
	 * Traverse the Ontology to find all given concepts
	 * @throws IOException 
	 * @throws TemplateException 
	 */

	public static void main(String[] args) throws IOException, TemplateException 
	{
		
		
		
		
		
		
  HttpServer server = HttpServer.create(new InetSocketAddress(81), 0);
  
  server.createContext("/assets", new StaticFileServer());
  server.createContext("/less", new StaticFileServer());
  server.createContext("/css", new StaticFileServer());
  server.createContext("/fonts", new StaticFileServer());
  server.createContext("/js", new StaticFileServer());
  server.createContext("/images", new StaticFileServer());
  server.createContext("/index.jsp", new StaticFileServer());
  server.createContext("/contacts.jsp", new StaticFileServer());
  server.createContext("/membership.jsp", new StaticFileServer());
  server.createContext("/mission.jsp", new StaticFileServer());
  server.createContext("/quran", new MyHandler());
  server.start();
	
	}
	
	 static class MyHandler implements HttpHandler {
		 String quest = "";
		 boolean onWait = false;
		 String reserve = "";
		 Map<String, Object> input = new HashMap<String, Object>();
		 List<Message> messages = new ArrayList<Message>();
	        public void handle(HttpExchange t) throws IOException {

	            Configuration cfg = new Configuration();

	            cfg.setIncompatibleImprovements(new Version(2, 3, 20));
	            cfg.setDefaultEncoding("UTF-8");
	            cfg.setLocale(Locale.US);
	            cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

	            

//--------------------------------------------------------------------------------------------------------------------------------------------
	            
	            
	            
	            
	            
	            if (t.getRequestBody().available() != 0){
	            InputStreamReader isr =  new InputStreamReader(t.getRequestBody(),"UTF-8");
	            BufferedReader br = new BufferedReader(isr);
	            
	           
	            
	            
	            // From now on, the right way of moving from bytes to utf-8 characters:

	            int b;
	            StringBuilder buf = new StringBuilder(512);
	            while ((b = br.read()) != -1) {
	                buf.append((char) b);
	            }

	            br.close();
	            isr.close();
	            quest = buf.toString().substring(6).replace("+", " ");
	            
	            }
	            
	            
	            
	            
	            
	            //messages.add(new MessageObject("USER", quest));
	            System.out.println(quest);
	            
	            
	            if(Dialog.text(quest).endsWith("عاش")){
	            	
	            	onWait = true;
	            	reserve = Dialog.text(quest);
	            	messages.add(new Message("السؤال", reserve));
	            	quest = "";
	            	messages.add(new Message("الجواب", "عاش من ؟"));
	            }
	            
	            else if(Dialog.text(quest).endsWith("ذكر")){
	            	
	            	onWait = true;
	            	reserve = Dialog.text(quest);
	            	messages.add(new Message("السؤال", reserve));
	            	quest = "";
	            	messages.add(new Message("الجواب", "ذكر من ؟"));
	            }
	            
 else if(Dialog.text(quest).endsWith("اب")){
	            	
	            	onWait = true;
	            	reserve = Dialog.text(quest);
	            	messages.add(new Message("السؤال", reserve));
	            	quest = "";
	            	messages.add(new Message("الجواب", "اب من ؟"));
	            }
	            
 else if(Dialog.text(quest).endsWith("اولاد")){
 	
 	onWait = true;
 	reserve = Dialog.text(quest);
 	messages.add(new Message("السؤال", reserve));
 	quest = "";
 	messages.add(new Message("الجواب", "اولاد من ؟"));
 }
	            
	            
 else if(Dialog.text(quest).endsWith("اجداد")){
 	
 	onWait = true;
 	reserve = Dialog.text(quest);
 	messages.add(new Message("السؤال", reserve));
 	quest = "";
 	messages.add(new Message("الجواب", "اجداد من ؟"));
 }
	            
                else if(Dialog.text(quest).endsWith("يقع")){
	            	
	            	onWait = true;
	            	reserve = Dialog.text(quest);
	            	messages.add(new Message("السؤال", reserve));
	            	quest = "";
	            	messages.add(new Message("الجواب", "يقع  من ؟"));
	            }
	            
	            if(onWait){
	            	if(!quest.equals("")){
	            		onWait = false;
	            		quest = reserve + " " +quest;
	            	}
	            }
	            
	            
	            
	            
	            if (quest != ""){
	            System.out.println(Dialog.text(quest));	
	      	  //System.out.println("ASCII : " + dialogManager.textEncode(quest));
	            
	            }
	            
	            quest = Dialog.text(quest);
	            //quest = "";
	            
	            if (quest != "")
	            {
	            	messages.add(new Message("السؤال", quest));
	            
	    		
	    		
	    		String result="";
	    		result = Dialog.choose(quest);
	    		
	    		if(result == "") result = "لا يوجد اجابة";
	    		messages.add(new Message("الجواب", result));
	            }
	            
	            
	            
	            

	           
//--------------------------------------------------------------------------------------------------------------------------------------------
	            
	            input.put("messages", messages);

	            Template template = cfg.getTemplate("mission.jsp");
	            
	            // Write output to the console
	            Writer consoleWriter = new OutputStreamWriter(System.out);
	            try {
					template.process(input, consoleWriter);
				} catch (TemplateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	            
	            
	            
	            // For the sake of example, also write output into a file:
	            Writer fileWriter = new FileWriter(new File("output.html"));
	            
	            try {
	                try {
						template.process(input, fileWriter);
					} catch (TemplateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            } finally {
	                fileWriter.close();
	            }
	            
	            
	            String response = readFile("output.html", StandardCharsets.UTF_8);
	            
	            
	            //t.getResponseHeaders().set("Content-Type", "application/json");
	            t.sendResponseHeaders(200, response.getBytes("UTF-8").length);
	            
	            OutputStream os = t.getResponseBody();
	            os.write(response.getBytes());
	            os.close();
	        }
	        static String readFile(String path, Charset encoding) 
	        		  throws IOException 
	        		{
	        		  byte[] encoded = Files.readAllBytes(Paths.get(path));
	        		  return new String(encoded, encoding);
	        		}
	    }
 
}


class StaticFileServer implements HttpHandler {

    
    public void handle(HttpExchange exchange) throws IOException {
        String fileId = exchange.getRequestURI().getPath();
        File file = getFile("."+fileId);
        if (file == null) {
            String response = "Error 404 File not found.";
            exchange.sendResponseHeaders(404, response.length());
            OutputStream output = exchange.getResponseBody();
            output.write(response.getBytes());
            output.flush();
            output.close();
        } else {
            exchange.sendResponseHeaders(200, 0);
            OutputStream output = exchange.getResponseBody();
            FileInputStream fs = new FileInputStream(file);
            final byte[] buffer = new byte[0x10000];
            int count = 0;
            while ((count = fs.read(buffer)) >= 0) {
                output.write(buffer, 0, count);
            }
            output.flush();
            output.close();
            fs.close();
        }
    }

    private File getFile(String fileId) {
        // TODO retrieve the file associated with the id
    	File file = new File(fileId);
    	System.out.println(file.exists());
        return file;
    }
}

