package com.hatem;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.jena.atlas.json.*;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.sparql.algebra.optimize.TransformFilterPlacement.Placement;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RequetteSparql {
	private OntModel model;
	public RequetteSparql(){
		 model = ModelFactory.createOntologyModel();
		 readOntology( "C:\\quran.owl", model );
		//readOntology( "C:\\quran_data_full.owl", model );
	}
    /**
     * Start from a class, then recurse down to the sub-classes.
     * Use occurs check to prevent getting stuck in a loop
     * @param oc OntClass to traverse from
     * @param occurs stores visited nodes
     * @param depth indicates the graph "depth" 
     * @return list of concepts / entities which were visited when recursing through the hierarchy (avoid loops)
     */
public static void traverse( OntClass oc, List<OntClass> occurs, int depth )
{
	if( oc == null ) return;

	// if end reached abort (Thing == root, Nothing == deadlock)
	if( oc.getLocalName() == null || oc.getLocalName().equals( "Nothing" ) ) return;
	
	// print depth times "\t" to retrieve a explorer tree like output
	for( int i = 0; i < depth; i++ ) { System.out.print("\t"); }
	
	// print out the OntClass
	System.out.println( oc.toString() );
	
    // check if we already visited this OntClass (avoid loops in graphs)
    if ( oc.canAs( OntClass.class ) && !occurs.contains( oc ) ) 
    {
    	// for every subClass, traverse down
        for ( Iterator<OntClass> i = oc.listSubClasses( true );  i.hasNext(); ) 
        {
            OntClass subClass = i.next();
            	                
            // push this expression on the occurs list before we recurse to avoid loops
            occurs.add( oc );
            // traverse down and increase depth (used for logging tabs)
            traverse( subClass, occurs, depth + 1 );
            // after traversing the path, remove from occurs list
            occurs.remove( oc );
        }
    }
	
}

public static void traverseStart( OntModel model, OntClass ontClass ) 
{
	// if ontClass is specified we only traverse down that branch
	if( ontClass != null )
	{
		RequetteSparql.traverse(ontClass, new ArrayList<OntClass>(), 0);
		return;
	}
	
    // create an iterator over the root classes
    Iterator<OntClass> i = 	model.listHierarchyRootClasses();
    
    // traverse through all roots
    while (i.hasNext()) 
    {
    	OntClass tmp = i.next();
        RequetteSparql.traverse( tmp, new ArrayList<OntClass>(), 0 );
    }
}

private void readOntology( String file, OntModel model )
{
	InputStream in = null;
	try
	{
		in = new FileInputStream( file );
		model.read(in, "RDF/XML");
		in.close();
	} catch (IOException e) 
	{
		e.printStackTrace();
	} 
}





/*****************************************coran_livre******************************************************************/
public String getInfo(String Place){
	
	String queryString ="PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						+ "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+ "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+ "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+ "PREFIX qur: <http://quranontology.com/Resource/>"
+ "SELECT Distinct ?verse ?text  ?word1 ?wordText1"
+ "WHERE { "
+ "?verse rdf:type qur:Verse."
+ "?verse rdfs:label ?textSimple."
+ "?verse qur:DisplayText ?text."
+ "?word1 qur:IsPartOf ?verse."
+ "?word1 rdfs:label ?wordText1."
+ "?word1 qur:WordLemma ?wordLema1."
+ "?word1 qur:WordRoot ?wordRoot1."
+ "FILTER(?wordText1 = \""+ Place +"\"@ar || ?wordLema1 = \"" + Place +"\"@ar || ?wordRoot1 = \"" + Place + "\"@ar)}";
	
	return queryString;
}

public String getResult(String queryString) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustInfo(jsonStr);
}

public String adjustInfo(String jsonString) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        list.add(tsmresponse.getJSONObject(i).getJSONObject("text").getString("value"));
    }

    System.out.println(list);
    
    String finalAdjust = "";
    finalAdjust += " ذكر المصطلح  ";
    finalAdjust += list.size() + " مرة ";
    for (int i=0; i<list.size(); i++){
    	finalAdjust += "</br></br></br> " + list.get(i);
    }
	return finalAdjust;
}

/**********************************************************************************************************************/

/*********************************************place_livedin************************************************************/
public String getPlace(String place){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?place ?place_labelAr"
+"WHERE { ?person qur:LivedIn ?place."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?place rdfs:label ?place_labelAr."
+"qur:LivedIn rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?place_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultlived(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustLived(jsonStr, person);
}

public String adjustLived(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("place").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/


/**********************************************child******************************************************************/
public String getChild(String child){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
						 +"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
						 +"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
						 +"PREFIX qur: <http://quranontology.com/Resource/>"
						 +"SELECT  ?parent ?parent_labelAr  ?prop_labelAr ?child ?child_labelAr"
						 +"WHERE { ?parent qur:HasChild ?child."
						 +"OPTIONAL {?parent  rdfs:label ?parent_labelAr."
						 +"?child rdfs:label ?child_labelAr."
						 +"qur:HasChild rdfs:label ?prop_labelAr."
						 +"FILTER(langMatches(lang(?parent_labelAr), \"ar\"))."
						 +"FILTER(langMatches(lang(?child_labelAr), \"ar\"))."
						 +"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
						 +"}}"
						 +"LIMIT 200";
	
	return queryString;
}

public String getResultchild(String queryString, String parent) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustChild(jsonStr, parent);


}

public String adjustChild(String jsonString, String parent) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(parent);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("parent_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("parent_labelAr").getString("value").equals(parent))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("child").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";

    	
    	
    }
	return finalAdjust;
}
/*********************************************************************************************************************/


/*********************************************parent************************************************************/
public String getParent(String parent){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?parent ?parent_labelAr"
+"WHERE { ?person qur:HasParent ?parent."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?parent rdfs:label ?parent_labelAr."
+"qur:HasParent rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?parent_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultparent(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustParent(jsonStr, person);
}

public String adjustParent(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("parent").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/


/*********************************************Grand_parent************************************************************/
public String getGParent(String gparent){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?gparent ?gparent_labelAr"
+"WHERE { ?person qur:HasGrandParent ?gparent."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?gparent rdfs:label ?gparent_labelAr."
+"qur:HasGrandParent rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?gparent_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultgparent(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustGParent(jsonStr, person);
}

public String adjustGParent(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("gparent").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/


/*********************************************Member_of************************************************************/
public String getMemberof(String memberof){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?memberof ?memberof_labelAr"
+"WHERE { ?person qur:MemberOf ?memberof."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?memberof rdfs:label ?memberof_labelAr."
+"qur:MemberOf rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?memberof_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultmemberof(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustMemberof(jsonStr, person);
}

public String adjustMemberof(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("memberof").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/

/***************************************************Comment************************************************************/
public String getCom(String com){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?com ?com_labelAr"
+"WHERE { ?person rdfs:comment ?com."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?com rdfs:label ?com_labelAr."
+"rdfs:comment rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?com_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultcom(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustCom(jsonStr, person);
}

public String adjustCom(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("com").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/

/******************************************************Enemy************************************************************/
public String getEnemy(String enemy){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?enemy ?enemy_labelAr"
+"WHERE { ?person qur:EnemyWith ?enemy."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?enemy rdfs:label ?enemy_labelAr."
+"qur:EnemyWith rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?enemy_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultenemy(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustEnemy(jsonStr, person);
}

public String adjustEnemy(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("enemy").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/

/**************************************************Epousse************************************************************/
public String getEpousse(String epousse){
	String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>"
						 + "PREFIX owl: <http://www.w3.org/2002/07/owl#>"
+"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>"
+"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>"
+"PREFIX qur: <http://quranontology.com/Resource/>"
+"SELECT  ?person ?person_labelAr  ?prop_labelAr ?epousse ?epousse_labelAr"
+"WHERE { ?person qur:HasSpouse ?epousse."
+"OPTIONAL {?person  rdfs:label ?person_labelAr."
+"?epousse rdfs:label ?epousse_labelAr."
+"qur:HasSpouse rdfs:label ?prop_labelAr."
+"FILTER(langMatches(lang(?person_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?epousse_labelAr), \"ar\"))."
+"FILTER(langMatches(lang(?prop_labelAr), \"ar\"))."
+"}}"
+"LIMIT 200";
	
	return queryString;
}

public String getResultepousse(String queryString, String person) throws JSONException{
    org.apache.jena.query.Query query = QueryFactory.create(queryString);
   System.out.println("----------------------");
   System.out.println("Query Result Sheet");
   System.out.println("----------------------");
   QueryExecution qe = QueryExecutionFactory.create(query, model);
   System.out.println( "Query executed");
   ResultSet resultSet = qe.execSelect();
   
// write to a ByteArrayOutputStream
   ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
   
   
   ResultSetFormatter.outputAsJSON(outputStream, resultSet);
   qe.close(); 
// and turn that into a String
String jsonStr = new String(outputStream.toByteArray());
//JsonObject jsonObj = new JsonObject();
//jsonObj = JSON.read(jsonStr);

return adjustEpousse(jsonStr, person);
}

public String adjustEpousse(String jsonString, String person) throws JSONException{
	
	
	JSONObject jsonObject = new JSONObject(jsonString);
    JSONObject myResponse = jsonObject.getJSONObject("results");
    JSONArray tsmresponse = (JSONArray) myResponse.get("bindings");

    ArrayList<String> list = new ArrayList<String>();

    System.out.println(jsonString);
    System.out.println(person);
    for(int i=0; i<tsmresponse.length(); i++){
    	
        System.out.println(tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value"));
    	if (tsmresponse.getJSONObject(i).getJSONObject("person_labelAr").getString("value").equals(person))
    		list.add(tsmresponse.getJSONObject(i).getJSONObject("epousse").getString("value"));
    }

    System.out.println(list);

    if (list.size() == 0) return "";
    String finalAdjust = "";

    for (int i=0; i<list.size(); i++){
    	ArrayList<String> getPlaceFromLink = new ArrayList<String>(Arrays.asList(list.get(i).split("/")));
    	
    	finalAdjust += "<a href=\""+ list.get(i) +"\">" + getPlaceFromLink.get(getPlaceFromLink.size()-1) + "</a> </br>";
    	
    	
    }
	return finalAdjust;
}

/*********************************************************************************************************************/





} //fin
