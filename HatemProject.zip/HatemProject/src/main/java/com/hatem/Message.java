package com.hatem;


public class Message {

    private String writer;
    private String message;

    public Message(String name, String message) {
        this.writer = name;
        this.message = message;
    }

    public String getWriter() {
        return writer;
    }

    public String getMessage() {
        return message;
    }

}
