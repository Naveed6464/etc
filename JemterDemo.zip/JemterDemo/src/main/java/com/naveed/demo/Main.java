package com.naveed.demo;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.jmeter.assertions.DurationAssertion;
import org.apache.jmeter.assertions.JSONPathAssertion;
import org.apache.jmeter.assertions.ResponseAssertion;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerProxy;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.testelement.TestPlan;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        String jmeterHome = "C:\\Apps\\Tools\\apache-jmeter-5.1.1";
        String slash = System.getProperty("file.separator");
        StandardJMeterEngine jmeter = new StandardJMeterEngine();
        
        JMeterUtils.setJMeterHome(jmeterHome);
        JMeterUtils.loadJMeterProperties(jmeterHome + slash + "bin" + slash + "jmeter.properties");        
        JMeterUtils.initLocale();
        System.setProperty("http.proxyScheme", "http");
        System.setProperty("http.proxyHost", "proxy.alinma.internal");
        System.setProperty("http.proxyPort", "8080");        

        HashTree testPlanTree = new HashTree();
        
        HTTPSamplerProxy examplecomSampler = new HTTPSamplerProxy();
        examplecomSampler.setDomain("dummy.restapiexample.com");
//        examplecomSampler.setPort(80);
        examplecomSampler.setPath("/api/v1/employee/4930");
        examplecomSampler.setMethod("GET");
        examplecomSampler.setName("Open example.com");
        
        LoopController loopController = new LoopController();
        loopController.setLoops(1);
        loopController.setFirst(true);
        loopController.initialize();

        org.apache.jmeter.threads.ThreadGroup threadGroup = new org.apache.jmeter.threads.ThreadGroup();
        threadGroup.setName("Example Thread Group");
        threadGroup.setNumThreads(1);
        threadGroup.setRampUp(1);
        threadGroup.setSamplerController(loopController);
        
        TestPlan testPlan = new TestPlan("Create JMeter Script From Java Code");        
        testPlan.setUserDefinedVariables((Arguments) new ArgumentsPanel().createTestElement());

        // Construct Test Plan from previously initialized elements
        testPlanTree.add(testPlan);
        HashTree threadGroupHashTree = testPlanTree.add(testPlan, threadGroup);
        threadGroupHashTree.add(examplecomSampler);
        
        DurationAssertion durationAssertion = new DurationAssertion();
        durationAssertion.setName("Duration Assertion 3s per request");
        durationAssertion.setAllowedDuration(3000);

        ResponseAssertion responseAssertion = new ResponseAssertion();
        responseAssertion.setTestFieldResponseCode();
        responseAssertion.setToContainsType();
        responseAssertion.addTestString("200|302");
        
        JSONPathAssertion jsonAssertion = new JSONPathAssertion();
        jsonAssertion.setJsonPath("$.employee_age");
        jsonAssertion.setExpectedValue("40");
        jsonAssertion.setEnabled(true);
        jsonAssertion.setJsonValidationBool(true);
        
        threadGroupHashTree.add(examplecomSampler, durationAssertion);
        threadGroupHashTree.add(examplecomSampler, responseAssertion);
        threadGroupHashTree.add(examplecomSampler, jsonAssertion);
        
        SaveService.saveTree(testPlanTree, new FileOutputStream("example.jmx"));
        
        Summariser summer = null;
        String summariserName = JMeterUtils.getPropDefault("summariser.name", "summary");
        if (summariserName.length() > 0) {
            summer = new Summariser(summariserName);
        }

        String logFile = "example.jtl";
        ResultCollector logger = new ResultCollector(summer);
        logger.setFilename(logFile);
        testPlanTree.add(testPlanTree.getArray()[0], logger);

        // Run Test Plan
        jmeter.configure(testPlanTree);
        jmeter.run();        
    }

}
