package com.naveed.fursan.pdf.extract;

import java.io.IOException;
import java.util.List;

/**
 *
 * @author naveedurrahman.com
 */
public class Main {

    public static void main(String[] args) throws IOException {
        PdfExtractor extractor = new PdfExtractor();
        List<AgentAnalysis> extracted = extractor.extract("sample.pdf");        
        for (AgentAnalysis analysis : extracted) {
            System.out.println(">> " + analysis);
        }
        System.out.println("<<<<>>>>> " + extracted.size());
    }
}