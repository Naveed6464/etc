/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.prop.ency;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.PropertyValueEncryptionUtils;

/**
 *
 * <h1> PropoertyPasswordEncryptor </h1>
 *
 * PropoertyPasswordEncryptor implements Encryption logic.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class PropoertyPasswordEncryptor {

    private static StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
    private static final String PROPERTY_ENCRYPTION_PASSWORD = "Remittance@123";
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void printVersion() {
        String message = "Remittance-Sftp Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    public static void main(String[] args) {
        printVersion();
        //args = new String[]{"s8qU1mop"};
        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.PropoertyPasswordEncryptor <String argument to Encrypt>";
            System.out.println(message);
            System.exit(1);
        }
        encryptor.setPassword(PROPERTY_ENCRYPTION_PASSWORD);
        System.out.println(PropertyValueEncryptionUtils.encrypt(args[0], encryptor));
    }

    /**
     *
     * This method is used to encrypt a given string.
     *
     * @param password
     * @return encrypted String
     */
    public static String encrypt(String password) {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(PROPERTY_ENCRYPTION_PASSWORD);
        return PropertyValueEncryptionUtils.encrypt(password, encryptor);
    }
}
