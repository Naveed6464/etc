package com.rmt.ws.service;

import com.inma.rmt.ws.core.GenericWSClient;


/**
 *
 * @author nmrehman
 */
public class ExampleService extends GenericWSClient { //<T24WebServicesImpl> {

    @Override
    public void initRequestParams(String requestParams) {

    }

    @Override
    public String invoke(String serviceMethodName) {
        return toJson(new Service("TestService", "Success"));
    }
}
