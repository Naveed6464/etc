/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.core;

import com.inma.rmt.ws.util.ReflectionUtil;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * <h1> GenericRPCClient </h1>
 *
 * GenericRPCClient implements Generic web service for SOAP 1.0 using Axis
 * Framework.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @param <T>
 * @since 2016-06-19
 */
public abstract class GenericRPCClient<T> implements IWSClient {

    final static Logger log = LoggerFactory.getLogger(GenericRPCClient.class);

    String clientAddress;
    String serviceMethodName;

    Gson gson = new Gson();

    protected Class<T> serviceClass = (Class<T>) ReflectionUtil.getTypeArguments(GenericRPCClient.class, this.getClass()).get(0);

    /**
     *
     * This method initializes web service URL address
     *
     * @param address
     */
    @Override
    public void initialize(String address) {
        this.clientAddress = address;
    }

    /**
     *
     * This method is used to set service method name during initialization
     *
     * @param serviceMethodName
     */
    @Override
    public void setServiceMethodName(String serviceMethodName) {
        this.serviceMethodName = serviceMethodName;
    }

    public String getServiceMethodName() {
        return serviceMethodName;
    }

    public Gson getGSON() {
        return gson;
    }

    /**
     *
     * This method is used to convert incoming object to JSON message.
     *
     * @param src
     * @return
     */
    public String toJson(Object src) {
        return gson.toJson(src);
    }

    /**
     *
     *
     * This method is used to convert incoming object to JSON message with given
     * class.
     *
     * @param <T>
     * @param json
     * @param clz
     * @return
     */
    public <T> T fromJson(String json, Class<T> clz) {
        return gson.fromJson(json, clz);
    }

    public URL getURL() {
        try {
            return new URL(clientAddress);
        } catch (MalformedURLException ex) {
            log.error("MalformedURLException : " + ex);
        }
        return null;
    }

    /**
     *
     * This method is used to initiate the instance of the generic service
     * class.
     *
     * @return
     */
    public T create() {
        try {
            return serviceClass.newInstance();
        } catch (InstantiationException | IllegalAccessException ex) {
            log.error("Exception While Instantiating Web Service");
        }
        return null;
    }

    /**
     *
     * This method is used to set properties of object dynamically using
     * reflection.
     *
     * @param <T>
     * @param fields
     * @param clz
     * @return
     */
    public <T> T populatedFields(Map<String, String> fields, Class<T> clz) {
        Object object = null;
        try {
            object = clz.newInstance();
            for (Map.Entry<String, String> entry : fields.entrySet()) {
                BeanUtils.setProperty(object, entry.getKey(), entry.getValue());
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException ex) {
            log.info("Exception While Populating Fields.");
        }
        return (T) object;
    }

    /**
     *
     * This method is used to set properties of object dynamically using
     * reflection.
     *
     * @param <T>
     * @param strFields
     * @param clz
     * @return
     */
    public <T> T populateFields(String strFields, Class<T> clz) {
        Map<String, String> fields = new HashMap<>();
        Iterable<String> split = Splitter.on(',').trimResults().omitEmptyStrings().split(strFields);
        for (String str : split) {
            fields.put(str.substring(0, str.indexOf(":")), str.substring(str.indexOf(":") + 1));
        }
        return populatedFields(fields, clz);
    }

    /**
     *
     * This method is generic implementation split function using Google Guava's
     * String split function.
     *
     * @param str
     * @param on
     * @return
     */
    public List<String> split(String str, String on) {
        return Lists.newArrayList(Splitter.on(on).trimResults().omitEmptyStrings().split(str));
    }

    /**
     *
     * This method is generic which need to be implemented on every cover class.
     *
     * @param serviceMethodName
     * @return
     */
    @Override
    public abstract String invoke(String serviceMethodName);

    /**
     *
     * This method is generic which need to be implemented on every cover class.
     *
     * @param requestParams
     */
    @Override
    public abstract void initRequestParams(String requestParams);
}
