/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.post;

import com.google.common.base.Splitter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * <h1> GenericWSPost </h1>
 *
 * GenericWSPost implements Generic web service for HTTP POST,GET,PUT,DELETE
 * using HTTP Client Framework.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class GenericWSPost {

    protected final static Logger log = LoggerFactory.getLogger(GenericWSPost.class);

    /**
     *
     * This is method is a generic implementation of HTTP POST.
     *
     * @param url
     * @param content
     * @param header
     * @return
     * @throws UnsupportedEncodingException
     * @throws IOException
     */
    public String post(String url, String content, String header) throws UnsupportedEncodingException, IOException {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpEntity entity = new ByteArrayEntity(content.getBytes("UTF-8"));
        HttpPost httpPost = new HttpPost(url);
        //httpPost.addHeader("Content-Type", "text/xml;charset=UTF-8");
        Map<String, String> split = Splitter.on(" ").withKeyValueSeparator("!!").split(header);
        for (Map.Entry<String, String> entry : split.entrySet()) {
            String value = entry.getValue().replaceAll("\'", "\"");
            //value = value.replaceAll("#", ";");
            //value = value.replaceAll("@", "=");
            //System.out.println(entry.getKey() + " ::: " + value);
            httpPost.addHeader(entry.getKey(), value);
        }
        httpPost.setEntity(entity);
        CloseableHttpResponse response = httpclient.execute(httpPost);
        String result = EntityUtils.toString(response.getEntity());
        return result;
    }

    /**
     *
     * This is method is a generic implementation of HTTP GET.
     *
     * @param url
     * @param header
     * @return
     * @throws UnsupportedEncodingException
     * @throws IOException
     */
    public String get(String url, String header) throws UnsupportedEncodingException, IOException {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(url);
        //httpGet.addHeader("Content-Type", "text/xml;charset=UTF-8");
        //httpGet.addHeader("SOAPAction", header);
        Map<String, String> split = Splitter.on(" ").withKeyValueSeparator("!!").split(header);
        for (Map.Entry<String, String> entry : split.entrySet()) {
            String value = entry.getValue().replaceAll("\'", "\"");
            httpGet.addHeader(entry.getKey(), value);
        }
        CloseableHttpResponse response = httpclient.execute(httpGet);
        String result = EntityUtils.toString(response.getEntity());
        return result;
    }

    /**
     *
     * This is method is a generic implementation of HTTP PUT.
     *
     * @param url
     * @param header
     * @return
     * @throws IOException
     */
    public String put(String url, String header) throws IOException {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPut httpPut = new HttpPut(url);
        Map<String, String> split = Splitter.on(" ").withKeyValueSeparator("!!").split(header);
        for (Map.Entry<String, String> entry : split.entrySet()) {
            String value = entry.getValue().replaceAll("\'", "\"");
            httpPut.addHeader(entry.getKey(), value);
        }
        CloseableHttpResponse response = httpclient.execute(httpPut);
        String result = EntityUtils.toString(response.getEntity());
        return result;
    }

    /**
     *
     * This is method is a generic implementation of HTTP DELETE.
     *
     * @param header
     * @throws IOException
     */
    public void delete(String header) throws IOException {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpDelete httpDelete = new HttpDelete();
        Map<String, String> split = Splitter.on(" ").withKeyValueSeparator("!!").split(header);
        for (Map.Entry<String, String> entry : split.entrySet()) {
            String value = entry.getValue().replaceAll("\'", "\"");
            httpDelete.addHeader(entry.getKey(), value);
        }
        httpclient.execute(httpDelete);
    }
}
