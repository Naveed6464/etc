package com.inma.rmt.xml.parser;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * <h1> Main </h1>
 *
 * Main Bootstrap Application for XML Parser.
 *
 * Usage: java -cp &lt;jar files path&gt; com.inma.rmt.xml.parser.Main
 * &lt;FieldNames, XML Message&gt;
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class Main {

    protected final static Logger log = LoggerFactory.getLogger(Main.class);
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    private static final String fieldNamesArgs = "a:Description#a:ErrorNumber#a:status#a:AlkuraimiExpressNumber#a:agentReferance";
    private static final String fieldNamesArgsUBL = "StatusCode#StatusDesc#RqUID";

    private static final String xmlArgs = "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\">\n"
            + "   <s:Body>\n"
            + "      <SendRemittanceResponse xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns=\"http://tempuri.org/\">\n"
            + "         <SendRemittanceResult xmlns:a=\"http://schemas.datacontract.org/2004/07/KRM\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">\n"
            + "            <a:Description>Operation Can not be complete pleaes check alkuraimi bank</a:Description>\n"
            + "            <a:ErrorNumber>3201</a:ErrorNumber>\n"
            + "            <a:status>false</a:status>\n"
            + "            <a:AlkuraimiExpressNumber>0</a:AlkuraimiExpressNumber>\n"
            + "            <a:agentReferance>0</a:agentReferance>\n"
            + "         </SendRemittanceResult>\n"
            + "      </SendRemittanceResponse>\n"
            + "   </s:Body>\n"
            + "</s:Envelope>";

    private static final String xmlArgsUBL = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"
            + "   <soapenv:Body>\n"
            + "      <NS1:Opr_GetStatusResponse xmlns:NS1=\"http://localhost/UBL_HRC_API/\">\n"
            + "         <ns1 xmlns:ns1=\"http://localhost/UBL_HRC_API/\"/>\n"
            + "         <NS1:part><![CDATA[<ns0:IFX xmlns:ns0=\"http://UBL_HRC_API_GetStatus_IFX_GetStatus_Out\"><SignonRs><ClientDt>06/15/2016 17:42:12 PM</ClientDt></SignonRs><BankSvcRs><GetStatusRs><RqUID>76bb87b6-94d9-4ef5-84cd-8bedc81ce99fTR10</RqUID><Response><StatusCode>1</StatusCode><StatusDesc>Pending</StatusDesc></Response></GetStatusRs></BankSvcRs></ns0:IFX>]]></NS1:part>\n"
            + "      </NS1:Opr_GetStatusResponse>\n"
            + "   </soapenv:Body>\n"
            + "</soapenv:Envelope>";

    public static void main(String[] args) {
        //args = new String[]{fieldNamesArgs, xmlArgs};
        if (args.length != 2) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.xml.parser.Main <FieldNames, XML Message>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }
        String fieldNamesArg = args[0];
        String xml = args[1];
        xml = xml.replace("<![CDATA[", "").replace("]]>", "");
        System.out.println(new SimpleXMLParser().parse(xml, fieldNamesArg));
    }
}