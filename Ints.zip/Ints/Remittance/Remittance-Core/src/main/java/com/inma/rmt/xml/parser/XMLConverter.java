/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.xml.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * <h1> XMLConverter </h1>
 *
 * XMLConverter implements Generic implementation of XML Parser using Core Java
 * API.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class XMLConverter {

    public XMLConverter() {
    }

    private static String FIELD_NAME_DELIMITER = "*";
    private static String FIELD_DELIMITER = "*";
    private static String SUBVALUE_DELIMITER = "#";

    /**
     *
     * This method does the implementation of xml parsing.
     *
     * @param arg
     * @return
     */
    public String convert(String arg) {
        String response = "";
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            String[] args = arg.split("\\#");
            String prefix = args[0];
            String fieldNames = args[1];

            FIELD_NAME_DELIMITER = args[2];
            FIELD_DELIMITER = args[3];
            SUBVALUE_DELIMITER = args[4];

            String xml = args[5];

            String[] fields = fieldNames.split("\\" + FIELD_NAME_DELIMITER);
            String fieldValueList = "";
            System.out.println("XML " + xml);
            Document document = builder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
            for (int fldIdx = 0; fldIdx < fields.length; fldIdx++) {
                XPathFactory xPathfactory = XPathFactory.newInstance();
                XPath xpath = xPathfactory.newXPath();
                XPathExpression expr = xpath.compile(prefix + fields[fldIdx]);
                NodeList nl = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
                String fieldValue = "";
                for (int i = 0; i < nl.getLength(); i++) {
                    Node node = nl.item(i);
                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                        Element firstElement = (Element) node;
                        fieldValue += firstElement.getTextContent();
                        if (i != nl.getLength() - 1) {
                            fieldValue += SUBVALUE_DELIMITER;
                        }
                    }
                }
                fieldValueList += fieldValue;
                if (fldIdx != fields.length - 1) {
                    fieldValueList += FIELD_DELIMITER;
                }
            }
            response = fieldValueList;
        } catch (ParserConfigurationException | SAXException | IOException | XPathExpressionException ex) {
            response = "Error " + ex;
        }
        return response;
    }

}
