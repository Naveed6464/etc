/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.core;

/**
 *
 * <h1> IWSClient </h1>
 *
 * IWSClient is generic interface to implement web service implementation.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public interface IWSClient {

    public void initialize(String address);

    public void setServiceMethodName(String serviceMethodName);

    public void initRequestParams(String requestParams);

    public String invoke(String serviceMethodName);
}
