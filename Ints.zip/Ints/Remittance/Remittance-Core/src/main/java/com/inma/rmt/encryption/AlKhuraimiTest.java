/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.encryption;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;
import java.util.TimeZone;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * <h1> AlKhuraimiTest </h1>
 *
 * AlKhuraimiTest test implementation for Al Khuraimi Encryption.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class AlKhuraimiTest {

    private static String encryptPassword(String password) {
        password = password.toUpperCase();
        String sha1 = "";
        try {
            MessageDigest crypt = MessageDigest.getInstance("SHA-1");
            crypt.reset();
            crypt.update(password.getBytes("UTF-8"));
            sha1 = byteToHex(crypt.digest());
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
        }
        return sha1;
    }

    private static String byteToHex(final byte[] hash) {
        Formatter formatter = new Formatter();
        for (byte b : hash) {
            formatter.format("%02x", b);
        }
        String result = formatter.toString();
        formatter.close();
        return result;
    }

    public static String getDatetime() {
        Date someDate = new Date();
        TimeZone utc = TimeZone.getTimeZone("UTC");
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");
        df.setTimeZone(utc);
        String s = df.format(someDate);

        return s;
    }

    public static String HashedPassword(String UserName, String Password, String timestamp) {
        String password = encryptPassword(Password).toUpperCase();
        // String converted = Base64.encodeToString(password.getBytes(), Base64.DEFAULT);
        String userName = UserName;
        String TimeStamp = timestamp;
        String str = DatatypeConverter.printBase64Binary(password.getBytes());
        String HashedPasswrod = (userName + str + TimeStamp).toUpperCase();
        String HashedPasswrod2 = encryptPassword(HashedPasswrod).toUpperCase();
        return HashedPasswrod2;
    }

    public static void demo() {
        String password = "123456krm";
        String userName = "abdulrahman";
        String TimeStamp = "20160418060031";
        String hashedpassword = HashedPassword(userName, password, TimeStamp);
        System.out.println(hashedpassword);
        System.out.println(getDatetime());
    }

    public static void demo2() {
        String password = "ANM-USR2016";
        String userName = "ANM-USR";
        //String timeStamp = "20160511145044";
        String hashedpassword = HashedPassword(userName, password, getDatetime());
        System.out.println(hashedpassword);
        System.out.println(getDatetime());
    }

    public static void main(String[] args) {
        String password = "123456krm";
        String userName = "abdulrahman";
        String TimeStamp = "20150830074954";
        String hashedpassword = HashedPassword(userName, password, TimeStamp);
        System.out.println(hashedpassword);
        System.out.println(getDatetime());
    }

}
