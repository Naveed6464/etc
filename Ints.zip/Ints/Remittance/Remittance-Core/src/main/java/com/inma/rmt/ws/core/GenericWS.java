/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.core;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
public class GenericWS {

    final static org.slf4j.Logger log = LoggerFactory.getLogger(GenericWS.class);

    public String invoke(String customizedClassName, String url, String serviceMethodName, String requestParams) {
        String response = "ERROR IN PRCOCESSING";
        try {
            Class clz = Class.forName(customizedClassName);
            Object obj = clz.newInstance();
            Method setServiceMthdNameMethod = clz.getMethod("setServiceMethodName", new Class[]{String.class});
            setServiceMthdNameMethod.invoke(obj, serviceMethodName);            
            Method initMethod = clz.getMethod("initialize", new Class[]{String.class});
            initMethod.invoke(obj, url);
            Method requestMethod = clz.getMethod("initRequestParams", new Class[]{String.class});
            requestMethod.invoke(obj, requestParams);
            Method invokeMethod = clz.getMethod("invoke", new Class[]{String.class});
            response = (String) invokeMethod.invoke(obj, serviceMethodName);
        } catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | InstantiationException ex) {
            ex.printStackTrace();
            log.error("Exception While invoking Webservice. " + ex);
        }
        return response;
    }

}
