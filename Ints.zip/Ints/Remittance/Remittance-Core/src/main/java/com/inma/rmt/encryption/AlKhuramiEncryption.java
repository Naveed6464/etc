/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.encryption;

import com.google.common.base.Charsets;
import com.google.common.hash.Hashing;
import com.google.common.io.BaseEncoding;
import java.io.UnsupportedEncodingException;

/**
 *
 * <h1> AlKhuramiEncryption </h1>
 *
 * AlKhuramiEncryption implementation for Al Khuraimi Encryption.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class AlKhuramiEncryption {

    /**
     *
     * This method implements base64HashPassword conversion for a given string.
     *
     * @param password
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String base64HashPassword(String password) throws UnsupportedEncodingException {
        return BaseEncoding.base64().encode(hash(password).getBytes("UTF-8"));
    }

    /**
     *
     * This method implements hash sha1 algorithm conversion for a given string.
     *
     * @param text
     * @return
     */
    public static String hash(String text) {
        return Hashing.sha1().hashString(text.toUpperCase(), Charsets.UTF_8).toString().toUpperCase();
    }

    /**
     *
     * This method implements encryption logic for Alkuraimi bank with username,
     * password and timestamp.
     *
     * @param userName
     * @param password
     * @param timestamp
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String getHashPassword(String userName, String password, String timestamp) throws UnsupportedEncodingException {
        return hash(userName + base64HashPassword(password) + timestamp);
    }
}
