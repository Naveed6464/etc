package com.inma.rmt.encryption;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 *
 * <h1> Main </h1>
 *
 * Main Bootstrap Application for Web service User Authentication Encryption.
 *
 * Usage: java -cp &lt;jar files path&gt; com.inma.rmt.encryption.Main
 * &lt;Username, Password, Timestamp&gt;
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class Main {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void printVersion() {
        String message = "Remittance-WebServices Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }
    //private static final DateFormat kuraimiDateFormat = new SimpleDateFormat("yyyyMMddhhmmss");

    public static void main(String[] args) throws UnsupportedEncodingException {        
        //args = new String[]{"ANM-USR", "ANM-USR2016"};
        if (args.length < 2) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.encryption.Main <Username, Password, Timestamp>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }
        String userName = args[0];
        String password = args[1];
        String timestamp = "";//20150830074954
        if (args.length == 2) {
            timestamp = getDatetime();//kuraimiDateFormat.format(new Date());            
        } else {
            timestamp = args[2];
        }
        System.out.println(timestamp + "#" + AlKhuramiEncryption.getHashPassword(userName, password, timestamp));
    }

    public static String getDatetime() {
        Date someDate = new Date();
        TimeZone utc = TimeZone.getTimeZone("UTC");
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddhhmmss");
        df.setTimeZone(utc);
        String s = df.format(someDate);
        return s;
    }
}
