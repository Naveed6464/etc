package com.inma.rmt.xml.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * <h1> XMLConvertMain </h1>
 *
 * XMLConvertMain Bootstrap Application for XML Parser using Core Java API.
 *
 * Usage: java -cp &lt;jar files path&gt; com.inma.rmt.xml.parser.XMLConvertMain
 * &lt;FieldNames, XML Message&gt;
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class XMLConvertMain {

    private static String FIELD_NAME_DELIMITER = "*";
    private static String FIELD_DELIMITER = "*";
    private static String SUBVALUE_DELIMITER = "#";

    /**
     * @param args the command line arguments
     * @throws javax.xml.parsers.ParserConfigurationException
     * @throws org.xml.sax.SAXException
     * @throws java.io.IOException
     * @throws javax.xml.xpath.XPathExpressionException
     */
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {

        if (args.length == 0) {
            System.out.println("Proper Usage is: com.inma.rmt.xml.parser.Main ");
            System.out.println("arg[0]=FieldName-Prefix, arg[1]=FieldNames, arg[2]=FieldName-Delimiter, arg[3]=Field-Delimiter, arg[4]=SubValue-Delimiter, arg[5]=XML-String,");
            System.exit(0);
        }

        System.out.println("0 " + args[0]);
        System.out.println("1 " + args[1]);
        System.out.println("2 " + args[2]);
        System.out.println("3 " + args[3]);
        System.out.println("4 " + args[4]);
        System.out.println("5 " + args[5]);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        //String prefix = "/MCIContractDtlsInqRs/Body/";
        //String fieldNames = "OwnersList/OwnerInfo/POINum*OwnersList/OwnerInfo/IdExpDt";
        //String xml = "";
        String prefix = args[0];
        String fieldNames = args[1];

        FIELD_NAME_DELIMITER = args[2];
        FIELD_DELIMITER = args[3];
        SUBVALUE_DELIMITER = args[4];

        String xml = args[5];

        String[] fields = fieldNames.split("\\" + FIELD_NAME_DELIMITER);
        String fieldValueList = "";
        System.out.println("XML " + xml);
        Document document = builder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        for (int fldIdx = 0; fldIdx < fields.length; fldIdx++) {
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(prefix + fields[fldIdx]);
            NodeList nl = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
            String fieldValue = "";
            for (int i = 0; i < nl.getLength(); i++) {
                Node node = nl.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element firstElement = (Element) node;
                    fieldValue += firstElement.getTextContent();
                    if (i != nl.getLength() - 1) {
                        fieldValue += SUBVALUE_DELIMITER;
                    }
                }
            }
            fieldValueList += fieldValue;
            if (fldIdx != fields.length - 1) {
                fieldValueList += FIELD_DELIMITER;
            }
        }
        System.out.println(fieldValueList);
    }
}
