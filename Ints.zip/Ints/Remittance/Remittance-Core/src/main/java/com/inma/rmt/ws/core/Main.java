/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.core;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * <h1> Main </h1>
 *
 * Main Bootstrap Application for Web service for SOAP 1.1 and SOAP 1.2 using
 * Apache CXF Framework.
 *
 * Usage: java -cp &lt;jar files path&gt; com.inma.rmt.ws.core.Main
 * &lt;ServiceClassName, URL, Service Method Name, Request JSON Message&gt;
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class Main {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();
    protected final static Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        if (args.length != 4) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.ws.core.Main <ServiceClassName, URL, Service Method Name, Request JSON Message>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }
        String customizedClassName = args[0];
        String url = args[1];
        String serviceMethodName = args[2];
        String requestParams = args[3];
        GenericWS genericWs = new GenericWS();
        String response = genericWs.invoke(customizedClassName, url, serviceMethodName, requestParams);
        System.out.println(response);
    }

}
