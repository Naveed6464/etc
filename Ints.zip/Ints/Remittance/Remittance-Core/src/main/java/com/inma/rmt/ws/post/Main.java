package com.inma.rmt.ws.post;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * <h1> Main </h1>
 *
 * Main Bootstrap Application for Web service Application Invocation using HTTP
 * POST .
 *
 * Usage: java -cp &lt;jar files path&gt; com.inma.rmt.ws.core.Main &lt;URL,
 * Header, XML/JSON REQ Message&gt;
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class Main {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();
    protected final static Logger log = LoggerFactory.getLogger(Main.class);

    private static final String msg = "";

    public static void printVersion() {
        String message = "Remittance-DataPower Version 1.0";
        System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //printVersion();
        //args = new String[]{"http://192.168.202.2:3005/KRMAgentService", "Content-Type!!application/soap+xml;charset=UTF-8;action='http://tempuri.org/IKRMAgentService/SendRemittance'", msg};
        if (args.length != 3) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.ws.core.Main <URL, Header, XML/JSON REQ Message>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }

        String url = args[0];
        String header = args[1];
        String xml = args[2];

        xml = xml.replaceAll("\"", "");
        xml = xml.replaceAll("\'", "\"");

        GenericWSPost genericWS = new GenericWSPost();
        try {
            String response = genericWS.post(url, xml, header);
            System.out.println(response); //Print response in output stream
        } catch (Exception ex) {
            log.error("Error while Sending : " + ex);
        }
    }
}
