/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.xml.parser;

import com.google.common.base.Joiner;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * <h1> SimpleXMLParser </h1>
 *
 * SimpleXMLParser implements Generic implementation of XML Parser using JSoup
 * Framework.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2016-06-19
 */
public class SimpleXMLParser {

    /**
     *
     * This method parses given xml and return required field values.
     *
     * @param xml
     * @param fieldNamesArg
     * @return
     */
    public String parse(String xml, String fieldNamesArg) {
        Document doc = Jsoup.parse(xml);
        String[] fieldNames = fieldNamesArg.split("#");
        ArrayList<String> fieldValues = new ArrayList<>();
        for (String fieldName : fieldNames) {
            fieldValues.add(doc.getElementsByTag(fieldName).text());
        }
        Joiner joiner = Joiner.on('#').skipNulls();
        return joiner.join(fieldValues);
    }

    /**
     *
     * This method does the xml parsing using XPATH fieldNames
     *
     * @param xml
     * @param fieldNamesArg
     * @return
     */
    public String withXpath(String xml, String fieldNamesArg) {
        //http://stackoverflow.com/questions/24749788/xpath-expression-with-jsoup         
        //Elements tds = doc.select("SendRemittanceResult > a|agentReferance"); // | is for namespace  //https://jsoup.org/apidocs/org/jsoup/select/Selector.html
        Document doc = Jsoup.parse(xml);
        String[] fieldNames = fieldNamesArg.split("#");
        ArrayList<String> fieldValues = new ArrayList<>();
        for (String fieldName : fieldNames) {
            Elements tds = doc.select(fieldName);
            if (tds != null && tds.size() > 0) {
                String fieldVal = "";
                for (Element elem : tds) {
                    //System.out.println(elem.toString() + " >>> " + elem.text());
                    fieldVal += elem.text() + "**";
                }
                fieldValues.add(fieldVal);
            }
        }
        Joiner joiner = Joiner.on('#').skipNulls();
        return joiner.join(fieldValues);
    }
}
