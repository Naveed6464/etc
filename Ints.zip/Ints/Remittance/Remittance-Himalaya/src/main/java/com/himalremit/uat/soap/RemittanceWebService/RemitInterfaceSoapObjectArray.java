/**
 * RemitInterfaceSoapObjectArray.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.RemittanceWebService;

public class RemitInterfaceSoapObjectArray  implements java.io.Serializable {
    private java.lang.String transactionNumber;

    private java.lang.String transactionDate;

    private java.lang.String transactionLCY;

    private java.lang.String transactionLCYAmount;

    private java.lang.String transactionChargesInLCY;

    private java.lang.String rateOfTransaction;

    private java.lang.String amountToPayInFCY;

    private java.lang.String currencyCodeInPCY;

    private java.lang.String bankName;

    private java.lang.String bankBranch;

    private java.lang.String correspondentBankCode;

    private java.lang.String correspondentBranchCode;

    private java.lang.String remitterName;

    private java.lang.String remitterAddress1;

    private java.lang.String remitterAddress2;

    private java.lang.String remitterAddress3;

    private java.lang.String remitterCity;

    private java.lang.String remitterState;

    private java.lang.String remitterCountry;

    private java.lang.String remitterPhoneNumber;

    private java.lang.String remitterPinCode;

    private java.lang.String beneficiaryName;

    private java.lang.String beneficiaryCareOfName;

    private java.lang.String beneficiaryAccountNumber;

    private java.lang.String beneficiaryAccountDetail;

    private java.lang.String beneficiaryAddress1;

    private java.lang.String beneficiaryAddress2;

    private java.lang.String beneficiaryAddress3;

    private java.lang.String beneficiaryCountry;

    private java.lang.String beneficiaryCity;

    private java.lang.String beneficiaryPhoneNumber;

    private java.lang.String beneficiaryPin;

    private java.lang.String transactionMethod;

    private java.lang.String beneficiaryIdentity;

    private java.lang.String benificiaryIDNo;

    private java.lang.String agentID;

    private java.lang.String token_value;

    private java.lang.String sessionID;

    private java.lang.String message;

    public RemitInterfaceSoapObjectArray() {
    }

    public RemitInterfaceSoapObjectArray(
           java.lang.String transactionNumber,
           java.lang.String transactionDate,
           java.lang.String transactionLCY,
           java.lang.String transactionLCYAmount,
           java.lang.String transactionChargesInLCY,
           java.lang.String rateOfTransaction,
           java.lang.String amountToPayInFCY,
           java.lang.String currencyCodeInPCY,
           java.lang.String bankName,
           java.lang.String bankBranch,
           java.lang.String correspondentBankCode,
           java.lang.String correspondentBranchCode,
           java.lang.String remitterName,
           java.lang.String remitterAddress1,
           java.lang.String remitterAddress2,
           java.lang.String remitterAddress3,
           java.lang.String remitterCity,
           java.lang.String remitterState,
           java.lang.String remitterCountry,
           java.lang.String remitterPhoneNumber,
           java.lang.String remitterPinCode,
           java.lang.String beneficiaryName,
           java.lang.String beneficiaryCareOfName,
           java.lang.String beneficiaryAccountNumber,
           java.lang.String beneficiaryAccountDetail,
           java.lang.String beneficiaryAddress1,
           java.lang.String beneficiaryAddress2,
           java.lang.String beneficiaryAddress3,
           java.lang.String beneficiaryCountry,
           java.lang.String beneficiaryCity,
           java.lang.String beneficiaryPhoneNumber,
           java.lang.String beneficiaryPin,
           java.lang.String transactionMethod,
           java.lang.String beneficiaryIdentity,
           java.lang.String benificiaryIDNo,
           java.lang.String agentID,
           java.lang.String token_value,
           java.lang.String sessionID,
           java.lang.String message) {
           this.transactionNumber = transactionNumber;
           this.transactionDate = transactionDate;
           this.transactionLCY = transactionLCY;
           this.transactionLCYAmount = transactionLCYAmount;
           this.transactionChargesInLCY = transactionChargesInLCY;
           this.rateOfTransaction = rateOfTransaction;
           this.amountToPayInFCY = amountToPayInFCY;
           this.currencyCodeInPCY = currencyCodeInPCY;
           this.bankName = bankName;
           this.bankBranch = bankBranch;
           this.correspondentBankCode = correspondentBankCode;
           this.correspondentBranchCode = correspondentBranchCode;
           this.remitterName = remitterName;
           this.remitterAddress1 = remitterAddress1;
           this.remitterAddress2 = remitterAddress2;
           this.remitterAddress3 = remitterAddress3;
           this.remitterCity = remitterCity;
           this.remitterState = remitterState;
           this.remitterCountry = remitterCountry;
           this.remitterPhoneNumber = remitterPhoneNumber;
           this.remitterPinCode = remitterPinCode;
           this.beneficiaryName = beneficiaryName;
           this.beneficiaryCareOfName = beneficiaryCareOfName;
           this.beneficiaryAccountNumber = beneficiaryAccountNumber;
           this.beneficiaryAccountDetail = beneficiaryAccountDetail;
           this.beneficiaryAddress1 = beneficiaryAddress1;
           this.beneficiaryAddress2 = beneficiaryAddress2;
           this.beneficiaryAddress3 = beneficiaryAddress3;
           this.beneficiaryCountry = beneficiaryCountry;
           this.beneficiaryCity = beneficiaryCity;
           this.beneficiaryPhoneNumber = beneficiaryPhoneNumber;
           this.beneficiaryPin = beneficiaryPin;
           this.transactionMethod = transactionMethod;
           this.beneficiaryIdentity = beneficiaryIdentity;
           this.benificiaryIDNo = benificiaryIDNo;
           this.agentID = agentID;
           this.token_value = token_value;
           this.sessionID = sessionID;
           this.message = message;
    }


    /**
     * Gets the transactionNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @return transactionNumber
     */
    public java.lang.String getTransactionNumber() {
        return transactionNumber;
    }


    /**
     * Sets the transactionNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @param transactionNumber
     */
    public void setTransactionNumber(java.lang.String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }


    /**
     * Gets the transactionDate value for this RemitInterfaceSoapObjectArray.
     * 
     * @return transactionDate
     */
    public java.lang.String getTransactionDate() {
        return transactionDate;
    }


    /**
     * Sets the transactionDate value for this RemitInterfaceSoapObjectArray.
     * 
     * @param transactionDate
     */
    public void setTransactionDate(java.lang.String transactionDate) {
        this.transactionDate = transactionDate;
    }


    /**
     * Gets the transactionLCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @return transactionLCY
     */
    public java.lang.String getTransactionLCY() {
        return transactionLCY;
    }


    /**
     * Sets the transactionLCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @param transactionLCY
     */
    public void setTransactionLCY(java.lang.String transactionLCY) {
        this.transactionLCY = transactionLCY;
    }


    /**
     * Gets the transactionLCYAmount value for this RemitInterfaceSoapObjectArray.
     * 
     * @return transactionLCYAmount
     */
    public java.lang.String getTransactionLCYAmount() {
        return transactionLCYAmount;
    }


    /**
     * Sets the transactionLCYAmount value for this RemitInterfaceSoapObjectArray.
     * 
     * @param transactionLCYAmount
     */
    public void setTransactionLCYAmount(java.lang.String transactionLCYAmount) {
        this.transactionLCYAmount = transactionLCYAmount;
    }


    /**
     * Gets the transactionChargesInLCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @return transactionChargesInLCY
     */
    public java.lang.String getTransactionChargesInLCY() {
        return transactionChargesInLCY;
    }


    /**
     * Sets the transactionChargesInLCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @param transactionChargesInLCY
     */
    public void setTransactionChargesInLCY(java.lang.String transactionChargesInLCY) {
        this.transactionChargesInLCY = transactionChargesInLCY;
    }


    /**
     * Gets the rateOfTransaction value for this RemitInterfaceSoapObjectArray.
     * 
     * @return rateOfTransaction
     */
    public java.lang.String getRateOfTransaction() {
        return rateOfTransaction;
    }


    /**
     * Sets the rateOfTransaction value for this RemitInterfaceSoapObjectArray.
     * 
     * @param rateOfTransaction
     */
    public void setRateOfTransaction(java.lang.String rateOfTransaction) {
        this.rateOfTransaction = rateOfTransaction;
    }


    /**
     * Gets the amountToPayInFCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @return amountToPayInFCY
     */
    public java.lang.String getAmountToPayInFCY() {
        return amountToPayInFCY;
    }


    /**
     * Sets the amountToPayInFCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @param amountToPayInFCY
     */
    public void setAmountToPayInFCY(java.lang.String amountToPayInFCY) {
        this.amountToPayInFCY = amountToPayInFCY;
    }


    /**
     * Gets the currencyCodeInPCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @return currencyCodeInPCY
     */
    public java.lang.String getCurrencyCodeInPCY() {
        return currencyCodeInPCY;
    }


    /**
     * Sets the currencyCodeInPCY value for this RemitInterfaceSoapObjectArray.
     * 
     * @param currencyCodeInPCY
     */
    public void setCurrencyCodeInPCY(java.lang.String currencyCodeInPCY) {
        this.currencyCodeInPCY = currencyCodeInPCY;
    }


    /**
     * Gets the bankName value for this RemitInterfaceSoapObjectArray.
     * 
     * @return bankName
     */
    public java.lang.String getBankName() {
        return bankName;
    }


    /**
     * Sets the bankName value for this RemitInterfaceSoapObjectArray.
     * 
     * @param bankName
     */
    public void setBankName(java.lang.String bankName) {
        this.bankName = bankName;
    }


    /**
     * Gets the bankBranch value for this RemitInterfaceSoapObjectArray.
     * 
     * @return bankBranch
     */
    public java.lang.String getBankBranch() {
        return bankBranch;
    }


    /**
     * Sets the bankBranch value for this RemitInterfaceSoapObjectArray.
     * 
     * @param bankBranch
     */
    public void setBankBranch(java.lang.String bankBranch) {
        this.bankBranch = bankBranch;
    }


    /**
     * Gets the correspondentBankCode value for this RemitInterfaceSoapObjectArray.
     * 
     * @return correspondentBankCode
     */
    public java.lang.String getCorrespondentBankCode() {
        return correspondentBankCode;
    }


    /**
     * Sets the correspondentBankCode value for this RemitInterfaceSoapObjectArray.
     * 
     * @param correspondentBankCode
     */
    public void setCorrespondentBankCode(java.lang.String correspondentBankCode) {
        this.correspondentBankCode = correspondentBankCode;
    }


    /**
     * Gets the correspondentBranchCode value for this RemitInterfaceSoapObjectArray.
     * 
     * @return correspondentBranchCode
     */
    public java.lang.String getCorrespondentBranchCode() {
        return correspondentBranchCode;
    }


    /**
     * Sets the correspondentBranchCode value for this RemitInterfaceSoapObjectArray.
     * 
     * @param correspondentBranchCode
     */
    public void setCorrespondentBranchCode(java.lang.String correspondentBranchCode) {
        this.correspondentBranchCode = correspondentBranchCode;
    }


    /**
     * Gets the remitterName value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterName
     */
    public java.lang.String getRemitterName() {
        return remitterName;
    }


    /**
     * Sets the remitterName value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterName
     */
    public void setRemitterName(java.lang.String remitterName) {
        this.remitterName = remitterName;
    }


    /**
     * Gets the remitterAddress1 value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterAddress1
     */
    public java.lang.String getRemitterAddress1() {
        return remitterAddress1;
    }


    /**
     * Sets the remitterAddress1 value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterAddress1
     */
    public void setRemitterAddress1(java.lang.String remitterAddress1) {
        this.remitterAddress1 = remitterAddress1;
    }


    /**
     * Gets the remitterAddress2 value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterAddress2
     */
    public java.lang.String getRemitterAddress2() {
        return remitterAddress2;
    }


    /**
     * Sets the remitterAddress2 value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterAddress2
     */
    public void setRemitterAddress2(java.lang.String remitterAddress2) {
        this.remitterAddress2 = remitterAddress2;
    }


    /**
     * Gets the remitterAddress3 value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterAddress3
     */
    public java.lang.String getRemitterAddress3() {
        return remitterAddress3;
    }


    /**
     * Sets the remitterAddress3 value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterAddress3
     */
    public void setRemitterAddress3(java.lang.String remitterAddress3) {
        this.remitterAddress3 = remitterAddress3;
    }


    /**
     * Gets the remitterCity value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterCity
     */
    public java.lang.String getRemitterCity() {
        return remitterCity;
    }


    /**
     * Sets the remitterCity value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterCity
     */
    public void setRemitterCity(java.lang.String remitterCity) {
        this.remitterCity = remitterCity;
    }


    /**
     * Gets the remitterState value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterState
     */
    public java.lang.String getRemitterState() {
        return remitterState;
    }


    /**
     * Sets the remitterState value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterState
     */
    public void setRemitterState(java.lang.String remitterState) {
        this.remitterState = remitterState;
    }


    /**
     * Gets the remitterCountry value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterCountry
     */
    public java.lang.String getRemitterCountry() {
        return remitterCountry;
    }


    /**
     * Sets the remitterCountry value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterCountry
     */
    public void setRemitterCountry(java.lang.String remitterCountry) {
        this.remitterCountry = remitterCountry;
    }


    /**
     * Gets the remitterPhoneNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterPhoneNumber
     */
    public java.lang.String getRemitterPhoneNumber() {
        return remitterPhoneNumber;
    }


    /**
     * Sets the remitterPhoneNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterPhoneNumber
     */
    public void setRemitterPhoneNumber(java.lang.String remitterPhoneNumber) {
        this.remitterPhoneNumber = remitterPhoneNumber;
    }


    /**
     * Gets the remitterPinCode value for this RemitInterfaceSoapObjectArray.
     * 
     * @return remitterPinCode
     */
    public java.lang.String getRemitterPinCode() {
        return remitterPinCode;
    }


    /**
     * Sets the remitterPinCode value for this RemitInterfaceSoapObjectArray.
     * 
     * @param remitterPinCode
     */
    public void setRemitterPinCode(java.lang.String remitterPinCode) {
        this.remitterPinCode = remitterPinCode;
    }


    /**
     * Gets the beneficiaryName value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryName
     */
    public java.lang.String getBeneficiaryName() {
        return beneficiaryName;
    }


    /**
     * Sets the beneficiaryName value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryName
     */
    public void setBeneficiaryName(java.lang.String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }


    /**
     * Gets the beneficiaryCareOfName value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryCareOfName
     */
    public java.lang.String getBeneficiaryCareOfName() {
        return beneficiaryCareOfName;
    }


    /**
     * Sets the beneficiaryCareOfName value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryCareOfName
     */
    public void setBeneficiaryCareOfName(java.lang.String beneficiaryCareOfName) {
        this.beneficiaryCareOfName = beneficiaryCareOfName;
    }


    /**
     * Gets the beneficiaryAccountNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryAccountNumber
     */
    public java.lang.String getBeneficiaryAccountNumber() {
        return beneficiaryAccountNumber;
    }


    /**
     * Sets the beneficiaryAccountNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryAccountNumber
     */
    public void setBeneficiaryAccountNumber(java.lang.String beneficiaryAccountNumber) {
        this.beneficiaryAccountNumber = beneficiaryAccountNumber;
    }


    /**
     * Gets the beneficiaryAccountDetail value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryAccountDetail
     */
    public java.lang.String getBeneficiaryAccountDetail() {
        return beneficiaryAccountDetail;
    }


    /**
     * Sets the beneficiaryAccountDetail value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryAccountDetail
     */
    public void setBeneficiaryAccountDetail(java.lang.String beneficiaryAccountDetail) {
        this.beneficiaryAccountDetail = beneficiaryAccountDetail;
    }


    /**
     * Gets the beneficiaryAddress1 value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryAddress1
     */
    public java.lang.String getBeneficiaryAddress1() {
        return beneficiaryAddress1;
    }


    /**
     * Sets the beneficiaryAddress1 value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryAddress1
     */
    public void setBeneficiaryAddress1(java.lang.String beneficiaryAddress1) {
        this.beneficiaryAddress1 = beneficiaryAddress1;
    }


    /**
     * Gets the beneficiaryAddress2 value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryAddress2
     */
    public java.lang.String getBeneficiaryAddress2() {
        return beneficiaryAddress2;
    }


    /**
     * Sets the beneficiaryAddress2 value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryAddress2
     */
    public void setBeneficiaryAddress2(java.lang.String beneficiaryAddress2) {
        this.beneficiaryAddress2 = beneficiaryAddress2;
    }


    /**
     * Gets the beneficiaryAddress3 value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryAddress3
     */
    public java.lang.String getBeneficiaryAddress3() {
        return beneficiaryAddress3;
    }


    /**
     * Sets the beneficiaryAddress3 value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryAddress3
     */
    public void setBeneficiaryAddress3(java.lang.String beneficiaryAddress3) {
        this.beneficiaryAddress3 = beneficiaryAddress3;
    }


    /**
     * Gets the beneficiaryCountry value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryCountry
     */
    public java.lang.String getBeneficiaryCountry() {
        return beneficiaryCountry;
    }


    /**
     * Sets the beneficiaryCountry value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryCountry
     */
    public void setBeneficiaryCountry(java.lang.String beneficiaryCountry) {
        this.beneficiaryCountry = beneficiaryCountry;
    }


    /**
     * Gets the beneficiaryCity value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryCity
     */
    public java.lang.String getBeneficiaryCity() {
        return beneficiaryCity;
    }


    /**
     * Sets the beneficiaryCity value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryCity
     */
    public void setBeneficiaryCity(java.lang.String beneficiaryCity) {
        this.beneficiaryCity = beneficiaryCity;
    }


    /**
     * Gets the beneficiaryPhoneNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryPhoneNumber
     */
    public java.lang.String getBeneficiaryPhoneNumber() {
        return beneficiaryPhoneNumber;
    }


    /**
     * Sets the beneficiaryPhoneNumber value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryPhoneNumber
     */
    public void setBeneficiaryPhoneNumber(java.lang.String beneficiaryPhoneNumber) {
        this.beneficiaryPhoneNumber = beneficiaryPhoneNumber;
    }


    /**
     * Gets the beneficiaryPin value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryPin
     */
    public java.lang.String getBeneficiaryPin() {
        return beneficiaryPin;
    }


    /**
     * Sets the beneficiaryPin value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryPin
     */
    public void setBeneficiaryPin(java.lang.String beneficiaryPin) {
        this.beneficiaryPin = beneficiaryPin;
    }


    /**
     * Gets the transactionMethod value for this RemitInterfaceSoapObjectArray.
     * 
     * @return transactionMethod
     */
    public java.lang.String getTransactionMethod() {
        return transactionMethod;
    }


    /**
     * Sets the transactionMethod value for this RemitInterfaceSoapObjectArray.
     * 
     * @param transactionMethod
     */
    public void setTransactionMethod(java.lang.String transactionMethod) {
        this.transactionMethod = transactionMethod;
    }


    /**
     * Gets the beneficiaryIdentity value for this RemitInterfaceSoapObjectArray.
     * 
     * @return beneficiaryIdentity
     */
    public java.lang.String getBeneficiaryIdentity() {
        return beneficiaryIdentity;
    }


    /**
     * Sets the beneficiaryIdentity value for this RemitInterfaceSoapObjectArray.
     * 
     * @param beneficiaryIdentity
     */
    public void setBeneficiaryIdentity(java.lang.String beneficiaryIdentity) {
        this.beneficiaryIdentity = beneficiaryIdentity;
    }


    /**
     * Gets the benificiaryIDNo value for this RemitInterfaceSoapObjectArray.
     * 
     * @return benificiaryIDNo
     */
    public java.lang.String getBenificiaryIDNo() {
        return benificiaryIDNo;
    }


    /**
     * Sets the benificiaryIDNo value for this RemitInterfaceSoapObjectArray.
     * 
     * @param benificiaryIDNo
     */
    public void setBenificiaryIDNo(java.lang.String benificiaryIDNo) {
        this.benificiaryIDNo = benificiaryIDNo;
    }


    /**
     * Gets the agentID value for this RemitInterfaceSoapObjectArray.
     * 
     * @return agentID
     */
    public java.lang.String getAgentID() {
        return agentID;
    }


    /**
     * Sets the agentID value for this RemitInterfaceSoapObjectArray.
     * 
     * @param agentID
     */
    public void setAgentID(java.lang.String agentID) {
        this.agentID = agentID;
    }


    /**
     * Gets the token_value value for this RemitInterfaceSoapObjectArray.
     * 
     * @return token_value
     */
    public java.lang.String getToken_value() {
        return token_value;
    }


    /**
     * Sets the token_value value for this RemitInterfaceSoapObjectArray.
     * 
     * @param token_value
     */
    public void setToken_value(java.lang.String token_value) {
        this.token_value = token_value;
    }


    /**
     * Gets the sessionID value for this RemitInterfaceSoapObjectArray.
     * 
     * @return sessionID
     */
    public java.lang.String getSessionID() {
        return sessionID;
    }


    /**
     * Sets the sessionID value for this RemitInterfaceSoapObjectArray.
     * 
     * @param sessionID
     */
    public void setSessionID(java.lang.String sessionID) {
        this.sessionID = sessionID;
    }


    /**
     * Gets the message value for this RemitInterfaceSoapObjectArray.
     * 
     * @return message
     */
    public java.lang.String getMessage() {
        return message;
    }


    /**
     * Sets the message value for this RemitInterfaceSoapObjectArray.
     * 
     * @param message
     */
    public void setMessage(java.lang.String message) {
        this.message = message;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RemitInterfaceSoapObjectArray)) return false;
        RemitInterfaceSoapObjectArray other = (RemitInterfaceSoapObjectArray) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionNumber==null && other.getTransactionNumber()==null) || 
             (this.transactionNumber!=null &&
              this.transactionNumber.equals(other.getTransactionNumber()))) &&
            ((this.transactionDate==null && other.getTransactionDate()==null) || 
             (this.transactionDate!=null &&
              this.transactionDate.equals(other.getTransactionDate()))) &&
            ((this.transactionLCY==null && other.getTransactionLCY()==null) || 
             (this.transactionLCY!=null &&
              this.transactionLCY.equals(other.getTransactionLCY()))) &&
            ((this.transactionLCYAmount==null && other.getTransactionLCYAmount()==null) || 
             (this.transactionLCYAmount!=null &&
              this.transactionLCYAmount.equals(other.getTransactionLCYAmount()))) &&
            ((this.transactionChargesInLCY==null && other.getTransactionChargesInLCY()==null) || 
             (this.transactionChargesInLCY!=null &&
              this.transactionChargesInLCY.equals(other.getTransactionChargesInLCY()))) &&
            ((this.rateOfTransaction==null && other.getRateOfTransaction()==null) || 
             (this.rateOfTransaction!=null &&
              this.rateOfTransaction.equals(other.getRateOfTransaction()))) &&
            ((this.amountToPayInFCY==null && other.getAmountToPayInFCY()==null) || 
             (this.amountToPayInFCY!=null &&
              this.amountToPayInFCY.equals(other.getAmountToPayInFCY()))) &&
            ((this.currencyCodeInPCY==null && other.getCurrencyCodeInPCY()==null) || 
             (this.currencyCodeInPCY!=null &&
              this.currencyCodeInPCY.equals(other.getCurrencyCodeInPCY()))) &&
            ((this.bankName==null && other.getBankName()==null) || 
             (this.bankName!=null &&
              this.bankName.equals(other.getBankName()))) &&
            ((this.bankBranch==null && other.getBankBranch()==null) || 
             (this.bankBranch!=null &&
              this.bankBranch.equals(other.getBankBranch()))) &&
            ((this.correspondentBankCode==null && other.getCorrespondentBankCode()==null) || 
             (this.correspondentBankCode!=null &&
              this.correspondentBankCode.equals(other.getCorrespondentBankCode()))) &&
            ((this.correspondentBranchCode==null && other.getCorrespondentBranchCode()==null) || 
             (this.correspondentBranchCode!=null &&
              this.correspondentBranchCode.equals(other.getCorrespondentBranchCode()))) &&
            ((this.remitterName==null && other.getRemitterName()==null) || 
             (this.remitterName!=null &&
              this.remitterName.equals(other.getRemitterName()))) &&
            ((this.remitterAddress1==null && other.getRemitterAddress1()==null) || 
             (this.remitterAddress1!=null &&
              this.remitterAddress1.equals(other.getRemitterAddress1()))) &&
            ((this.remitterAddress2==null && other.getRemitterAddress2()==null) || 
             (this.remitterAddress2!=null &&
              this.remitterAddress2.equals(other.getRemitterAddress2()))) &&
            ((this.remitterAddress3==null && other.getRemitterAddress3()==null) || 
             (this.remitterAddress3!=null &&
              this.remitterAddress3.equals(other.getRemitterAddress3()))) &&
            ((this.remitterCity==null && other.getRemitterCity()==null) || 
             (this.remitterCity!=null &&
              this.remitterCity.equals(other.getRemitterCity()))) &&
            ((this.remitterState==null && other.getRemitterState()==null) || 
             (this.remitterState!=null &&
              this.remitterState.equals(other.getRemitterState()))) &&
            ((this.remitterCountry==null && other.getRemitterCountry()==null) || 
             (this.remitterCountry!=null &&
              this.remitterCountry.equals(other.getRemitterCountry()))) &&
            ((this.remitterPhoneNumber==null && other.getRemitterPhoneNumber()==null) || 
             (this.remitterPhoneNumber!=null &&
              this.remitterPhoneNumber.equals(other.getRemitterPhoneNumber()))) &&
            ((this.remitterPinCode==null && other.getRemitterPinCode()==null) || 
             (this.remitterPinCode!=null &&
              this.remitterPinCode.equals(other.getRemitterPinCode()))) &&
            ((this.beneficiaryName==null && other.getBeneficiaryName()==null) || 
             (this.beneficiaryName!=null &&
              this.beneficiaryName.equals(other.getBeneficiaryName()))) &&
            ((this.beneficiaryCareOfName==null && other.getBeneficiaryCareOfName()==null) || 
             (this.beneficiaryCareOfName!=null &&
              this.beneficiaryCareOfName.equals(other.getBeneficiaryCareOfName()))) &&
            ((this.beneficiaryAccountNumber==null && other.getBeneficiaryAccountNumber()==null) || 
             (this.beneficiaryAccountNumber!=null &&
              this.beneficiaryAccountNumber.equals(other.getBeneficiaryAccountNumber()))) &&
            ((this.beneficiaryAccountDetail==null && other.getBeneficiaryAccountDetail()==null) || 
             (this.beneficiaryAccountDetail!=null &&
              this.beneficiaryAccountDetail.equals(other.getBeneficiaryAccountDetail()))) &&
            ((this.beneficiaryAddress1==null && other.getBeneficiaryAddress1()==null) || 
             (this.beneficiaryAddress1!=null &&
              this.beneficiaryAddress1.equals(other.getBeneficiaryAddress1()))) &&
            ((this.beneficiaryAddress2==null && other.getBeneficiaryAddress2()==null) || 
             (this.beneficiaryAddress2!=null &&
              this.beneficiaryAddress2.equals(other.getBeneficiaryAddress2()))) &&
            ((this.beneficiaryAddress3==null && other.getBeneficiaryAddress3()==null) || 
             (this.beneficiaryAddress3!=null &&
              this.beneficiaryAddress3.equals(other.getBeneficiaryAddress3()))) &&
            ((this.beneficiaryCountry==null && other.getBeneficiaryCountry()==null) || 
             (this.beneficiaryCountry!=null &&
              this.beneficiaryCountry.equals(other.getBeneficiaryCountry()))) &&
            ((this.beneficiaryCity==null && other.getBeneficiaryCity()==null) || 
             (this.beneficiaryCity!=null &&
              this.beneficiaryCity.equals(other.getBeneficiaryCity()))) &&
            ((this.beneficiaryPhoneNumber==null && other.getBeneficiaryPhoneNumber()==null) || 
             (this.beneficiaryPhoneNumber!=null &&
              this.beneficiaryPhoneNumber.equals(other.getBeneficiaryPhoneNumber()))) &&
            ((this.beneficiaryPin==null && other.getBeneficiaryPin()==null) || 
             (this.beneficiaryPin!=null &&
              this.beneficiaryPin.equals(other.getBeneficiaryPin()))) &&
            ((this.transactionMethod==null && other.getTransactionMethod()==null) || 
             (this.transactionMethod!=null &&
              this.transactionMethod.equals(other.getTransactionMethod()))) &&
            ((this.beneficiaryIdentity==null && other.getBeneficiaryIdentity()==null) || 
             (this.beneficiaryIdentity!=null &&
              this.beneficiaryIdentity.equals(other.getBeneficiaryIdentity()))) &&
            ((this.benificiaryIDNo==null && other.getBenificiaryIDNo()==null) || 
             (this.benificiaryIDNo!=null &&
              this.benificiaryIDNo.equals(other.getBenificiaryIDNo()))) &&
            ((this.agentID==null && other.getAgentID()==null) || 
             (this.agentID!=null &&
              this.agentID.equals(other.getAgentID()))) &&
            ((this.token_value==null && other.getToken_value()==null) || 
             (this.token_value!=null &&
              this.token_value.equals(other.getToken_value()))) &&
            ((this.sessionID==null && other.getSessionID()==null) || 
             (this.sessionID!=null &&
              this.sessionID.equals(other.getSessionID()))) &&
            ((this.message==null && other.getMessage()==null) || 
             (this.message!=null &&
              this.message.equals(other.getMessage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionNumber() != null) {
            _hashCode += getTransactionNumber().hashCode();
        }
        if (getTransactionDate() != null) {
            _hashCode += getTransactionDate().hashCode();
        }
        if (getTransactionLCY() != null) {
            _hashCode += getTransactionLCY().hashCode();
        }
        if (getTransactionLCYAmount() != null) {
            _hashCode += getTransactionLCYAmount().hashCode();
        }
        if (getTransactionChargesInLCY() != null) {
            _hashCode += getTransactionChargesInLCY().hashCode();
        }
        if (getRateOfTransaction() != null) {
            _hashCode += getRateOfTransaction().hashCode();
        }
        if (getAmountToPayInFCY() != null) {
            _hashCode += getAmountToPayInFCY().hashCode();
        }
        if (getCurrencyCodeInPCY() != null) {
            _hashCode += getCurrencyCodeInPCY().hashCode();
        }
        if (getBankName() != null) {
            _hashCode += getBankName().hashCode();
        }
        if (getBankBranch() != null) {
            _hashCode += getBankBranch().hashCode();
        }
        if (getCorrespondentBankCode() != null) {
            _hashCode += getCorrespondentBankCode().hashCode();
        }
        if (getCorrespondentBranchCode() != null) {
            _hashCode += getCorrespondentBranchCode().hashCode();
        }
        if (getRemitterName() != null) {
            _hashCode += getRemitterName().hashCode();
        }
        if (getRemitterAddress1() != null) {
            _hashCode += getRemitterAddress1().hashCode();
        }
        if (getRemitterAddress2() != null) {
            _hashCode += getRemitterAddress2().hashCode();
        }
        if (getRemitterAddress3() != null) {
            _hashCode += getRemitterAddress3().hashCode();
        }
        if (getRemitterCity() != null) {
            _hashCode += getRemitterCity().hashCode();
        }
        if (getRemitterState() != null) {
            _hashCode += getRemitterState().hashCode();
        }
        if (getRemitterCountry() != null) {
            _hashCode += getRemitterCountry().hashCode();
        }
        if (getRemitterPhoneNumber() != null) {
            _hashCode += getRemitterPhoneNumber().hashCode();
        }
        if (getRemitterPinCode() != null) {
            _hashCode += getRemitterPinCode().hashCode();
        }
        if (getBeneficiaryName() != null) {
            _hashCode += getBeneficiaryName().hashCode();
        }
        if (getBeneficiaryCareOfName() != null) {
            _hashCode += getBeneficiaryCareOfName().hashCode();
        }
        if (getBeneficiaryAccountNumber() != null) {
            _hashCode += getBeneficiaryAccountNumber().hashCode();
        }
        if (getBeneficiaryAccountDetail() != null) {
            _hashCode += getBeneficiaryAccountDetail().hashCode();
        }
        if (getBeneficiaryAddress1() != null) {
            _hashCode += getBeneficiaryAddress1().hashCode();
        }
        if (getBeneficiaryAddress2() != null) {
            _hashCode += getBeneficiaryAddress2().hashCode();
        }
        if (getBeneficiaryAddress3() != null) {
            _hashCode += getBeneficiaryAddress3().hashCode();
        }
        if (getBeneficiaryCountry() != null) {
            _hashCode += getBeneficiaryCountry().hashCode();
        }
        if (getBeneficiaryCity() != null) {
            _hashCode += getBeneficiaryCity().hashCode();
        }
        if (getBeneficiaryPhoneNumber() != null) {
            _hashCode += getBeneficiaryPhoneNumber().hashCode();
        }
        if (getBeneficiaryPin() != null) {
            _hashCode += getBeneficiaryPin().hashCode();
        }
        if (getTransactionMethod() != null) {
            _hashCode += getTransactionMethod().hashCode();
        }
        if (getBeneficiaryIdentity() != null) {
            _hashCode += getBeneficiaryIdentity().hashCode();
        }
        if (getBenificiaryIDNo() != null) {
            _hashCode += getBenificiaryIDNo().hashCode();
        }
        if (getAgentID() != null) {
            _hashCode += getAgentID().hashCode();
        }
        if (getToken_value() != null) {
            _hashCode += getToken_value().hashCode();
        }
        if (getSessionID() != null) {
            _hashCode += getSessionID().hashCode();
        }
        if (getMessage() != null) {
            _hashCode += getMessage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RemitInterfaceSoapObjectArray.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/RemittanceWebService", "RemitInterfaceSoapObjectArray"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionLCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionLCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionLCYAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionLCYAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionChargesInLCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionChargesInLCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rateOfTransaction");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RateOfTransaction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amountToPayInFCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AmountToPayInFCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCodeInPCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CurrencyCodeInPCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BankName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankBranch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BankBranch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondentBankCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrespondentBankCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondentBranchCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrespondentBranchCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterAddress1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterAddress1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterAddress2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterAddress2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterAddress3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterAddress3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterCity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterCity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterState");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterPhoneNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterPhoneNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterPinCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterPinCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryCareOfName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryCareOfName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryAccountNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryAccountNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryAccountDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryAccountDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryAddress1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryAddress1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryAddress2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryAddress2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryAddress3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryAddress3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryCity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryCity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryPhoneNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryPhoneNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryPin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryPin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryIdentity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryIdentity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("benificiaryIDNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BenificiaryIDNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("agentID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AgentID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("token_value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "token_value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sessionID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SessionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
