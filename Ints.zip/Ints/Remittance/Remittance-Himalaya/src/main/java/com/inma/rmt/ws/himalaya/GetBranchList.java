/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.himalremit.uat.soap.BankDetailsWebService.BankDetailsRequest;
import com.himalremit.uat.soap.BankDetailsWebService.BankDetailsResponse;
import com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServiceLocator;
import com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServicePortType;
import com.inma.rmt.ws.core.GenericRPCClient;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.rpc.ServiceException;

/**
 *
 * @author nmrehman
 */
public class GetBranchList extends GenericRPCClient<BankDetailsWebServiceLocator> {

    BankDetailsRequest request;

    @Override
    public void initRequestParams(String requestParams) {
        request = fromJson(requestParams, BankDetailsRequest.class);
    }

    @Override
    public String invoke(String serviceMethodName) {
        try {
            BankDetailsWebServicePortType webService = create().getBankDetailsWebServicePort();//getURL()
            BankDetailsResponse bankDetails = webService.getBankDetails(request);
            return toJson(bankDetails);
        } catch (RemoteException | ServiceException ex) {
            Logger.getLogger(GetBranchList.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Error";
    }

}
