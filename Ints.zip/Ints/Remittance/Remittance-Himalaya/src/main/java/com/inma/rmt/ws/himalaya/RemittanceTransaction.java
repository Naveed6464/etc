/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.himalremit.uat.soap.RemittanceWebService.RemitInterfaceSoapObject;
import com.himalremit.uat.soap.RemittanceWebService.RemitInterfaceSoapObjectArray;
import com.himalremit.uat.soap.RemittanceWebService.RemittanceWebServiceLocator;
import com.himalremit.uat.soap.RemittanceWebService.RemittanceWebServicePortType;
import com.inma.rmt.ws.core.GenericRPCClient;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.rpc.ServiceException;

/**
 *
 * @author nmrehman
 */
public class RemittanceTransaction extends GenericRPCClient<RemittanceWebServiceLocator> {

    RemitInterfaceSoapObjectArray remitInterfaceSoapObjectArray;    

    @Override
    public void initRequestParams(String requestParams) {
        if (getServiceMethodName().equals("remitInterfaceAPI")) {
            remitInterfaceSoapObjectArray = fromJson(requestParams, RemitInterfaceSoapObjectArray.class);
        } 
    }

    @Override
    public String invoke(String serviceMethodName) {
        try {
            RemittanceWebServicePortType webService = create().getRemittanceWebServicePort();//getURL()
            switch (serviceMethodName) {
                case "remitInterfaceAPI":
                    RemitInterfaceSoapObject remitInterfaceAPI = webService.remitInterfaceAPI(remitInterfaceSoapObjectArray);
                    return toJson(remitInterfaceAPI);                
            }
            return "Error: No WebService Method Found";
        } catch (RemoteException | ServiceException ex) {
            Logger.getLogger(RemittanceTransaction.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR";
    }

}
