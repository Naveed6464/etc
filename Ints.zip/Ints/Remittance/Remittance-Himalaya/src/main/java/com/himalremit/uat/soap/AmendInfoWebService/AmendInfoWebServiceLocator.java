/**
 * AmendInfoWebServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.AmendInfoWebService;

public class AmendInfoWebServiceLocator extends org.apache.axis.client.Service implements com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebService {

    public AmendInfoWebServiceLocator() {
    }


    public AmendInfoWebServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AmendInfoWebServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for AmendInfoWebServicePort
    private java.lang.String AmendInfoWebServicePort_address = "http://192.168.202.2:3003/Himalayan/amendInfo";

    public java.lang.String getAmendInfoWebServicePortAddress() {
        return AmendInfoWebServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AmendInfoWebServicePortWSDDServiceName = "AmendInfoWebServicePort";

    public java.lang.String getAmendInfoWebServicePortWSDDServiceName() {
        return AmendInfoWebServicePortWSDDServiceName;
    }

    public void setAmendInfoWebServicePortWSDDServiceName(java.lang.String name) {
        AmendInfoWebServicePortWSDDServiceName = name;
    }

    public com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServicePortType getAmendInfoWebServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AmendInfoWebServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAmendInfoWebServicePort(endpoint);
    }

    public com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServicePortType getAmendInfoWebServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServiceBindingStub _stub = new com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServiceBindingStub(portAddress, this);
            _stub.setPortName(getAmendInfoWebServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAmendInfoWebServicePortEndpointAddress(java.lang.String address) {
        AmendInfoWebServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServicePortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServiceBindingStub _stub = new com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServiceBindingStub(new java.net.URL(AmendInfoWebServicePort_address), this);
                _stub.setPortName(getAmendInfoWebServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("AmendInfoWebServicePort".equals(inputPortName)) {
            return getAmendInfoWebServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://uat.himalremit.com/soap/AmendInfoWebService", "AmendInfoWebService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/AmendInfoWebService", "AmendInfoWebServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("AmendInfoWebServicePort".equals(portName)) {
            setAmendInfoWebServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
