/**
 * SoapResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.AmendInfoWebService;

public class SoapResponse  implements java.io.Serializable {
    private java.lang.String transactionNumber;

    private java.lang.String beneficiaryName;

    private java.lang.String userAgentID;

    private java.lang.String agentID;

    private java.lang.String token_value;

    public SoapResponse() {
    }

    public SoapResponse(
           java.lang.String transactionNumber,
           java.lang.String beneficiaryName,
           java.lang.String userAgentID,
           java.lang.String agentID,
           java.lang.String token_value) {
           this.transactionNumber = transactionNumber;
           this.beneficiaryName = beneficiaryName;
           this.userAgentID = userAgentID;
           this.agentID = agentID;
           this.token_value = token_value;
    }


    /**
     * Gets the transactionNumber value for this SoapResponse.
     * 
     * @return transactionNumber
     */
    public java.lang.String getTransactionNumber() {
        return transactionNumber;
    }


    /**
     * Sets the transactionNumber value for this SoapResponse.
     * 
     * @param transactionNumber
     */
    public void setTransactionNumber(java.lang.String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }


    /**
     * Gets the beneficiaryName value for this SoapResponse.
     * 
     * @return beneficiaryName
     */
    public java.lang.String getBeneficiaryName() {
        return beneficiaryName;
    }


    /**
     * Sets the beneficiaryName value for this SoapResponse.
     * 
     * @param beneficiaryName
     */
    public void setBeneficiaryName(java.lang.String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }


    /**
     * Gets the userAgentID value for this SoapResponse.
     * 
     * @return userAgentID
     */
    public java.lang.String getUserAgentID() {
        return userAgentID;
    }


    /**
     * Sets the userAgentID value for this SoapResponse.
     * 
     * @param userAgentID
     */
    public void setUserAgentID(java.lang.String userAgentID) {
        this.userAgentID = userAgentID;
    }


    /**
     * Gets the agentID value for this SoapResponse.
     * 
     * @return agentID
     */
    public java.lang.String getAgentID() {
        return agentID;
    }


    /**
     * Sets the agentID value for this SoapResponse.
     * 
     * @param agentID
     */
    public void setAgentID(java.lang.String agentID) {
        this.agentID = agentID;
    }


    /**
     * Gets the token_value value for this SoapResponse.
     * 
     * @return token_value
     */
    public java.lang.String getToken_value() {
        return token_value;
    }


    /**
     * Sets the token_value value for this SoapResponse.
     * 
     * @param token_value
     */
    public void setToken_value(java.lang.String token_value) {
        this.token_value = token_value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SoapResponse)) return false;
        SoapResponse other = (SoapResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionNumber==null && other.getTransactionNumber()==null) || 
             (this.transactionNumber!=null &&
              this.transactionNumber.equals(other.getTransactionNumber()))) &&
            ((this.beneficiaryName==null && other.getBeneficiaryName()==null) || 
             (this.beneficiaryName!=null &&
              this.beneficiaryName.equals(other.getBeneficiaryName()))) &&
            ((this.userAgentID==null && other.getUserAgentID()==null) || 
             (this.userAgentID!=null &&
              this.userAgentID.equals(other.getUserAgentID()))) &&
            ((this.agentID==null && other.getAgentID()==null) || 
             (this.agentID!=null &&
              this.agentID.equals(other.getAgentID()))) &&
            ((this.token_value==null && other.getToken_value()==null) || 
             (this.token_value!=null &&
              this.token_value.equals(other.getToken_value())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionNumber() != null) {
            _hashCode += getTransactionNumber().hashCode();
        }
        if (getBeneficiaryName() != null) {
            _hashCode += getBeneficiaryName().hashCode();
        }
        if (getUserAgentID() != null) {
            _hashCode += getUserAgentID().hashCode();
        }
        if (getAgentID() != null) {
            _hashCode += getAgentID().hashCode();
        }
        if (getToken_value() != null) {
            _hashCode += getToken_value().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SoapResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/AmendInfoWebService", "SoapResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userAgentID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "UserAgentID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("agentID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AgentID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("token_value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "token_value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
