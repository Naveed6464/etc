/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServiceLocator;
import com.himalremit.uat.soap.AmendInfoWebService.AmendInfoWebServicePortType;
import com.himalremit.uat.soap.AmendInfoWebService.SoapRequest;
import com.himalremit.uat.soap.AmendInfoWebService.SoapResponse;
import com.inma.rmt.ws.core.GenericRPCClient;
import com.inma.rmt.ws.core.GenericWSClient;
import java.rmi.RemoteException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.rpc.ServiceException;

/**
 *
 * @author nmrehman
 */
public class AmendmentRequest extends GenericRPCClient<AmendInfoWebServiceLocator> {

    SoapResponse soapResponse;

    @Override
    public void initRequestParams(String requestParams) {
        soapResponse = fromJson(requestParams, SoapResponse.class);
    }

    @Override
    public String invoke(String requestParams) {
        try {
            AmendInfoWebServicePortType webService = create().getAmendInfoWebServicePort();//getURL()
            SoapRequest response = webService.updateBeneInfo(soapResponse);
            return toJson(response);
        } catch (RemoteException | ServiceException ex) {
            Logger.getLogger(AmendmentRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR";
    }

}
