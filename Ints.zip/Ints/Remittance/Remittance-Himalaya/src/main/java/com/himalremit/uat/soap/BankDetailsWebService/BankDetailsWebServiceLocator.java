/**
 * BankDetailsWebServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.BankDetailsWebService;

public class BankDetailsWebServiceLocator extends org.apache.axis.client.Service implements com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebService {

    public BankDetailsWebServiceLocator() {
    }


    public BankDetailsWebServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public BankDetailsWebServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BankDetailsWebServicePort
    private java.lang.String BankDetailsWebServicePort_address = "http://192.168.202.2:3003/Himalayan/getBankDetails";

    public java.lang.String getBankDetailsWebServicePortAddress() {
        return BankDetailsWebServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BankDetailsWebServicePortWSDDServiceName = "BankDetailsWebServicePort";

    public java.lang.String getBankDetailsWebServicePortWSDDServiceName() {
        return BankDetailsWebServicePortWSDDServiceName;
    }

    public void setBankDetailsWebServicePortWSDDServiceName(java.lang.String name) {
        BankDetailsWebServicePortWSDDServiceName = name;
    }

    public com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServicePortType getBankDetailsWebServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BankDetailsWebServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBankDetailsWebServicePort(endpoint);
    }

    public com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServicePortType getBankDetailsWebServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServiceBindingStub _stub = new com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServiceBindingStub(portAddress, this);
            _stub.setPortName(getBankDetailsWebServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBankDetailsWebServicePortEndpointAddress(java.lang.String address) {
        BankDetailsWebServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServicePortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServiceBindingStub _stub = new com.himalremit.uat.soap.BankDetailsWebService.BankDetailsWebServiceBindingStub(new java.net.URL(BankDetailsWebServicePort_address), this);
                _stub.setPortName(getBankDetailsWebServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BankDetailsWebServicePort".equals(inputPortName)) {
            return getBankDetailsWebServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://uat.himalremit.com/soap/BankDetailsWebService", "BankDetailsWebService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/BankDetailsWebService", "BankDetailsWebServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BankDetailsWebServicePort".equals(portName)) {
            setBankDetailsWebServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
