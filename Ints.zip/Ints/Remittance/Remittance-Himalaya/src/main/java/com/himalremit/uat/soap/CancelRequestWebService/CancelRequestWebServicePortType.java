/**
 * CancelRequestWebServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.CancelRequestWebService;

public interface CancelRequestWebServicePortType extends java.rmi.Remote {
    public com.himalremit.uat.soap.CancelRequestWebService.CancelOperationResObj cancelOperation(com.himalremit.uat.soap.CancelRequestWebService.CancelReqObjArray soapObjects) throws java.rmi.RemoteException;
}
