/**
 * TxnStatusWebServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.TxnStatusWebService;

public interface TxnStatusWebServicePortType extends java.rmi.Remote {
    public com.himalremit.uat.soap.TxnStatusWebService.SettlementReportRes getSettlementReport(com.himalremit.uat.soap.TxnStatusWebService.SettlementReportReq soapObjects) throws java.rmi.RemoteException;
    public com.himalremit.uat.soap.TxnStatusWebService.TxnStatusSoapObject getTxnStatus(com.himalremit.uat.soap.TxnStatusWebService.TxnStatusSoapObjectArray soapObjects) throws java.rmi.RemoteException;
}
