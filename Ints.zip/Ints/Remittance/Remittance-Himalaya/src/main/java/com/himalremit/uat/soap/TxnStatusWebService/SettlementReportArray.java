/**
 * SettlementReportArray.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.TxnStatusWebService;

public class SettlementReportArray  implements java.io.Serializable {
    private java.lang.String transactionNumber;

    private java.lang.String transactionDate;

    private java.lang.String transactionLCY;

    private java.lang.String transactionLCYAmount;

    private java.lang.String rateOfTransaction;

    private java.lang.String amountToPayInFCY;

    private java.lang.String currencyCodeInPCY;

    private java.lang.String transactionMethod;

    private java.lang.String correspondentBankCode;

    private java.lang.String correspondentBranchCode;

    private java.lang.String remitterName;

    private java.lang.String remitterPhoneNumber;

    private java.lang.String beneficiaryName;

    private java.lang.String beneficiaryPhoneNumber;

    private java.lang.String postedDate;

    private java.lang.String settledDate;

    private java.lang.String txnStatus;

    public SettlementReportArray() {
    }

    public SettlementReportArray(
           java.lang.String transactionNumber,
           java.lang.String transactionDate,
           java.lang.String transactionLCY,
           java.lang.String transactionLCYAmount,
           java.lang.String rateOfTransaction,
           java.lang.String amountToPayInFCY,
           java.lang.String currencyCodeInPCY,
           java.lang.String transactionMethod,
           java.lang.String correspondentBankCode,
           java.lang.String correspondentBranchCode,
           java.lang.String remitterName,
           java.lang.String remitterPhoneNumber,
           java.lang.String beneficiaryName,
           java.lang.String beneficiaryPhoneNumber,
           java.lang.String postedDate,
           java.lang.String settledDate,
           java.lang.String txnStatus) {
           this.transactionNumber = transactionNumber;
           this.transactionDate = transactionDate;
           this.transactionLCY = transactionLCY;
           this.transactionLCYAmount = transactionLCYAmount;
           this.rateOfTransaction = rateOfTransaction;
           this.amountToPayInFCY = amountToPayInFCY;
           this.currencyCodeInPCY = currencyCodeInPCY;
           this.transactionMethod = transactionMethod;
           this.correspondentBankCode = correspondentBankCode;
           this.correspondentBranchCode = correspondentBranchCode;
           this.remitterName = remitterName;
           this.remitterPhoneNumber = remitterPhoneNumber;
           this.beneficiaryName = beneficiaryName;
           this.beneficiaryPhoneNumber = beneficiaryPhoneNumber;
           this.postedDate = postedDate;
           this.settledDate = settledDate;
           this.txnStatus = txnStatus;
    }


    /**
     * Gets the transactionNumber value for this SettlementReportArray.
     * 
     * @return transactionNumber
     */
    public java.lang.String getTransactionNumber() {
        return transactionNumber;
    }


    /**
     * Sets the transactionNumber value for this SettlementReportArray.
     * 
     * @param transactionNumber
     */
    public void setTransactionNumber(java.lang.String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }


    /**
     * Gets the transactionDate value for this SettlementReportArray.
     * 
     * @return transactionDate
     */
    public java.lang.String getTransactionDate() {
        return transactionDate;
    }


    /**
     * Sets the transactionDate value for this SettlementReportArray.
     * 
     * @param transactionDate
     */
    public void setTransactionDate(java.lang.String transactionDate) {
        this.transactionDate = transactionDate;
    }


    /**
     * Gets the transactionLCY value for this SettlementReportArray.
     * 
     * @return transactionLCY
     */
    public java.lang.String getTransactionLCY() {
        return transactionLCY;
    }


    /**
     * Sets the transactionLCY value for this SettlementReportArray.
     * 
     * @param transactionLCY
     */
    public void setTransactionLCY(java.lang.String transactionLCY) {
        this.transactionLCY = transactionLCY;
    }


    /**
     * Gets the transactionLCYAmount value for this SettlementReportArray.
     * 
     * @return transactionLCYAmount
     */
    public java.lang.String getTransactionLCYAmount() {
        return transactionLCYAmount;
    }


    /**
     * Sets the transactionLCYAmount value for this SettlementReportArray.
     * 
     * @param transactionLCYAmount
     */
    public void setTransactionLCYAmount(java.lang.String transactionLCYAmount) {
        this.transactionLCYAmount = transactionLCYAmount;
    }


    /**
     * Gets the rateOfTransaction value for this SettlementReportArray.
     * 
     * @return rateOfTransaction
     */
    public java.lang.String getRateOfTransaction() {
        return rateOfTransaction;
    }


    /**
     * Sets the rateOfTransaction value for this SettlementReportArray.
     * 
     * @param rateOfTransaction
     */
    public void setRateOfTransaction(java.lang.String rateOfTransaction) {
        this.rateOfTransaction = rateOfTransaction;
    }


    /**
     * Gets the amountToPayInFCY value for this SettlementReportArray.
     * 
     * @return amountToPayInFCY
     */
    public java.lang.String getAmountToPayInFCY() {
        return amountToPayInFCY;
    }


    /**
     * Sets the amountToPayInFCY value for this SettlementReportArray.
     * 
     * @param amountToPayInFCY
     */
    public void setAmountToPayInFCY(java.lang.String amountToPayInFCY) {
        this.amountToPayInFCY = amountToPayInFCY;
    }


    /**
     * Gets the currencyCodeInPCY value for this SettlementReportArray.
     * 
     * @return currencyCodeInPCY
     */
    public java.lang.String getCurrencyCodeInPCY() {
        return currencyCodeInPCY;
    }


    /**
     * Sets the currencyCodeInPCY value for this SettlementReportArray.
     * 
     * @param currencyCodeInPCY
     */
    public void setCurrencyCodeInPCY(java.lang.String currencyCodeInPCY) {
        this.currencyCodeInPCY = currencyCodeInPCY;
    }


    /**
     * Gets the transactionMethod value for this SettlementReportArray.
     * 
     * @return transactionMethod
     */
    public java.lang.String getTransactionMethod() {
        return transactionMethod;
    }


    /**
     * Sets the transactionMethod value for this SettlementReportArray.
     * 
     * @param transactionMethod
     */
    public void setTransactionMethod(java.lang.String transactionMethod) {
        this.transactionMethod = transactionMethod;
    }


    /**
     * Gets the correspondentBankCode value for this SettlementReportArray.
     * 
     * @return correspondentBankCode
     */
    public java.lang.String getCorrespondentBankCode() {
        return correspondentBankCode;
    }


    /**
     * Sets the correspondentBankCode value for this SettlementReportArray.
     * 
     * @param correspondentBankCode
     */
    public void setCorrespondentBankCode(java.lang.String correspondentBankCode) {
        this.correspondentBankCode = correspondentBankCode;
    }


    /**
     * Gets the correspondentBranchCode value for this SettlementReportArray.
     * 
     * @return correspondentBranchCode
     */
    public java.lang.String getCorrespondentBranchCode() {
        return correspondentBranchCode;
    }


    /**
     * Sets the correspondentBranchCode value for this SettlementReportArray.
     * 
     * @param correspondentBranchCode
     */
    public void setCorrespondentBranchCode(java.lang.String correspondentBranchCode) {
        this.correspondentBranchCode = correspondentBranchCode;
    }


    /**
     * Gets the remitterName value for this SettlementReportArray.
     * 
     * @return remitterName
     */
    public java.lang.String getRemitterName() {
        return remitterName;
    }


    /**
     * Sets the remitterName value for this SettlementReportArray.
     * 
     * @param remitterName
     */
    public void setRemitterName(java.lang.String remitterName) {
        this.remitterName = remitterName;
    }


    /**
     * Gets the remitterPhoneNumber value for this SettlementReportArray.
     * 
     * @return remitterPhoneNumber
     */
    public java.lang.String getRemitterPhoneNumber() {
        return remitterPhoneNumber;
    }


    /**
     * Sets the remitterPhoneNumber value for this SettlementReportArray.
     * 
     * @param remitterPhoneNumber
     */
    public void setRemitterPhoneNumber(java.lang.String remitterPhoneNumber) {
        this.remitterPhoneNumber = remitterPhoneNumber;
    }


    /**
     * Gets the beneficiaryName value for this SettlementReportArray.
     * 
     * @return beneficiaryName
     */
    public java.lang.String getBeneficiaryName() {
        return beneficiaryName;
    }


    /**
     * Sets the beneficiaryName value for this SettlementReportArray.
     * 
     * @param beneficiaryName
     */
    public void setBeneficiaryName(java.lang.String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }


    /**
     * Gets the beneficiaryPhoneNumber value for this SettlementReportArray.
     * 
     * @return beneficiaryPhoneNumber
     */
    public java.lang.String getBeneficiaryPhoneNumber() {
        return beneficiaryPhoneNumber;
    }


    /**
     * Sets the beneficiaryPhoneNumber value for this SettlementReportArray.
     * 
     * @param beneficiaryPhoneNumber
     */
    public void setBeneficiaryPhoneNumber(java.lang.String beneficiaryPhoneNumber) {
        this.beneficiaryPhoneNumber = beneficiaryPhoneNumber;
    }


    /**
     * Gets the postedDate value for this SettlementReportArray.
     * 
     * @return postedDate
     */
    public java.lang.String getPostedDate() {
        return postedDate;
    }


    /**
     * Sets the postedDate value for this SettlementReportArray.
     * 
     * @param postedDate
     */
    public void setPostedDate(java.lang.String postedDate) {
        this.postedDate = postedDate;
    }


    /**
     * Gets the settledDate value for this SettlementReportArray.
     * 
     * @return settledDate
     */
    public java.lang.String getSettledDate() {
        return settledDate;
    }


    /**
     * Sets the settledDate value for this SettlementReportArray.
     * 
     * @param settledDate
     */
    public void setSettledDate(java.lang.String settledDate) {
        this.settledDate = settledDate;
    }


    /**
     * Gets the txnStatus value for this SettlementReportArray.
     * 
     * @return txnStatus
     */
    public java.lang.String getTxnStatus() {
        return txnStatus;
    }


    /**
     * Sets the txnStatus value for this SettlementReportArray.
     * 
     * @param txnStatus
     */
    public void setTxnStatus(java.lang.String txnStatus) {
        this.txnStatus = txnStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SettlementReportArray)) return false;
        SettlementReportArray other = (SettlementReportArray) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionNumber==null && other.getTransactionNumber()==null) || 
             (this.transactionNumber!=null &&
              this.transactionNumber.equals(other.getTransactionNumber()))) &&
            ((this.transactionDate==null && other.getTransactionDate()==null) || 
             (this.transactionDate!=null &&
              this.transactionDate.equals(other.getTransactionDate()))) &&
            ((this.transactionLCY==null && other.getTransactionLCY()==null) || 
             (this.transactionLCY!=null &&
              this.transactionLCY.equals(other.getTransactionLCY()))) &&
            ((this.transactionLCYAmount==null && other.getTransactionLCYAmount()==null) || 
             (this.transactionLCYAmount!=null &&
              this.transactionLCYAmount.equals(other.getTransactionLCYAmount()))) &&
            ((this.rateOfTransaction==null && other.getRateOfTransaction()==null) || 
             (this.rateOfTransaction!=null &&
              this.rateOfTransaction.equals(other.getRateOfTransaction()))) &&
            ((this.amountToPayInFCY==null && other.getAmountToPayInFCY()==null) || 
             (this.amountToPayInFCY!=null &&
              this.amountToPayInFCY.equals(other.getAmountToPayInFCY()))) &&
            ((this.currencyCodeInPCY==null && other.getCurrencyCodeInPCY()==null) || 
             (this.currencyCodeInPCY!=null &&
              this.currencyCodeInPCY.equals(other.getCurrencyCodeInPCY()))) &&
            ((this.transactionMethod==null && other.getTransactionMethod()==null) || 
             (this.transactionMethod!=null &&
              this.transactionMethod.equals(other.getTransactionMethod()))) &&
            ((this.correspondentBankCode==null && other.getCorrespondentBankCode()==null) || 
             (this.correspondentBankCode!=null &&
              this.correspondentBankCode.equals(other.getCorrespondentBankCode()))) &&
            ((this.correspondentBranchCode==null && other.getCorrespondentBranchCode()==null) || 
             (this.correspondentBranchCode!=null &&
              this.correspondentBranchCode.equals(other.getCorrespondentBranchCode()))) &&
            ((this.remitterName==null && other.getRemitterName()==null) || 
             (this.remitterName!=null &&
              this.remitterName.equals(other.getRemitterName()))) &&
            ((this.remitterPhoneNumber==null && other.getRemitterPhoneNumber()==null) || 
             (this.remitterPhoneNumber!=null &&
              this.remitterPhoneNumber.equals(other.getRemitterPhoneNumber()))) &&
            ((this.beneficiaryName==null && other.getBeneficiaryName()==null) || 
             (this.beneficiaryName!=null &&
              this.beneficiaryName.equals(other.getBeneficiaryName()))) &&
            ((this.beneficiaryPhoneNumber==null && other.getBeneficiaryPhoneNumber()==null) || 
             (this.beneficiaryPhoneNumber!=null &&
              this.beneficiaryPhoneNumber.equals(other.getBeneficiaryPhoneNumber()))) &&
            ((this.postedDate==null && other.getPostedDate()==null) || 
             (this.postedDate!=null &&
              this.postedDate.equals(other.getPostedDate()))) &&
            ((this.settledDate==null && other.getSettledDate()==null) || 
             (this.settledDate!=null &&
              this.settledDate.equals(other.getSettledDate()))) &&
            ((this.txnStatus==null && other.getTxnStatus()==null) || 
             (this.txnStatus!=null &&
              this.txnStatus.equals(other.getTxnStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionNumber() != null) {
            _hashCode += getTransactionNumber().hashCode();
        }
        if (getTransactionDate() != null) {
            _hashCode += getTransactionDate().hashCode();
        }
        if (getTransactionLCY() != null) {
            _hashCode += getTransactionLCY().hashCode();
        }
        if (getTransactionLCYAmount() != null) {
            _hashCode += getTransactionLCYAmount().hashCode();
        }
        if (getRateOfTransaction() != null) {
            _hashCode += getRateOfTransaction().hashCode();
        }
        if (getAmountToPayInFCY() != null) {
            _hashCode += getAmountToPayInFCY().hashCode();
        }
        if (getCurrencyCodeInPCY() != null) {
            _hashCode += getCurrencyCodeInPCY().hashCode();
        }
        if (getTransactionMethod() != null) {
            _hashCode += getTransactionMethod().hashCode();
        }
        if (getCorrespondentBankCode() != null) {
            _hashCode += getCorrespondentBankCode().hashCode();
        }
        if (getCorrespondentBranchCode() != null) {
            _hashCode += getCorrespondentBranchCode().hashCode();
        }
        if (getRemitterName() != null) {
            _hashCode += getRemitterName().hashCode();
        }
        if (getRemitterPhoneNumber() != null) {
            _hashCode += getRemitterPhoneNumber().hashCode();
        }
        if (getBeneficiaryName() != null) {
            _hashCode += getBeneficiaryName().hashCode();
        }
        if (getBeneficiaryPhoneNumber() != null) {
            _hashCode += getBeneficiaryPhoneNumber().hashCode();
        }
        if (getPostedDate() != null) {
            _hashCode += getPostedDate().hashCode();
        }
        if (getSettledDate() != null) {
            _hashCode += getSettledDate().hashCode();
        }
        if (getTxnStatus() != null) {
            _hashCode += getTxnStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SettlementReportArray.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/TxnStatusWebService", "SettlementReportArray"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionLCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionLCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionLCYAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionLCYAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rateOfTransaction");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RateOfTransaction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amountToPayInFCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AmountToPayInFCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCodeInPCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CurrencyCodeInPCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondentBankCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrespondentBankCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondentBranchCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrespondentBranchCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterPhoneNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterPhoneNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryPhoneNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryPhoneNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PostedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("settledDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SettledDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("txnStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TxnStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
