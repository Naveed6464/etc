/**
 * RemittanceWebServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.RemittanceWebService;

public interface RemittanceWebServicePortType extends java.rmi.Remote {
    public com.himalremit.uat.soap.RemittanceWebService.ErrorSoapObject errorHandler(com.himalremit.uat.soap.RemittanceWebService.ErrorSoapObjectArray soapObjects) throws java.rmi.RemoteException;
    public com.himalremit.uat.soap.RemittanceWebService.RemitInterfaceSoapObject remitInterfaceAPI(com.himalremit.uat.soap.RemittanceWebService.RemitInterfaceSoapObjectArray soapObjects) throws java.rmi.RemoteException;
}
