/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.himalremit.uat.soap.CancelRequestWebService.CancelOperationResObj;
import com.himalremit.uat.soap.CancelRequestWebService.CancelReqObjArray;
import com.himalremit.uat.soap.CancelRequestWebService.CancelRequestWebServiceLocator;
import com.himalremit.uat.soap.CancelRequestWebService.CancelRequestWebServicePortType;
import com.inma.rmt.ws.core.GenericRPCClient;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.rpc.ServiceException;

/**
 *
 * @author nmrehman
 */
public class CancellationRequest extends GenericRPCClient<CancelRequestWebServiceLocator> {

    CancelReqObjArray cancelReqObjArray;

    @Override
    public void initRequestParams(String requestParams) {
        cancelReqObjArray = fromJson(requestParams, CancelReqObjArray.class);
    }

    @Override
    public String invoke(String serviceMethodName) {
        try {
            CancelRequestWebServicePortType webService = create().getCancelRequestWebServicePort();//getURL()
            CancelOperationResObj cancelOperation = webService.cancelOperation(cancelReqObjArray);
            return toJson(cancelOperation);
        } catch (ServiceException | RemoteException ex) {
            Logger.getLogger(CancellationRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR";
    }

}
