/**
 * TxnStatusWebServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.TxnStatusWebService;

public class TxnStatusWebServiceLocator extends org.apache.axis.client.Service implements com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebService {

    public TxnStatusWebServiceLocator() {
    }


    public TxnStatusWebServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public TxnStatusWebServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for TxnStatusWebServicePort
    private java.lang.String TxnStatusWebServicePort_address = "http://192.168.202.2:3003/Himalayan/getTrxStatus";

    public java.lang.String getTxnStatusWebServicePortAddress() {
        return TxnStatusWebServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String TxnStatusWebServicePortWSDDServiceName = "TxnStatusWebServicePort";

    public java.lang.String getTxnStatusWebServicePortWSDDServiceName() {
        return TxnStatusWebServicePortWSDDServiceName;
    }

    public void setTxnStatusWebServicePortWSDDServiceName(java.lang.String name) {
        TxnStatusWebServicePortWSDDServiceName = name;
    }

    public com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServicePortType getTxnStatusWebServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(TxnStatusWebServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getTxnStatusWebServicePort(endpoint);
    }

    public com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServicePortType getTxnStatusWebServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServiceBindingStub _stub = new com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServiceBindingStub(portAddress, this);
            _stub.setPortName(getTxnStatusWebServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setTxnStatusWebServicePortEndpointAddress(java.lang.String address) {
        TxnStatusWebServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServicePortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServiceBindingStub _stub = new com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServiceBindingStub(new java.net.URL(TxnStatusWebServicePort_address), this);
                _stub.setPortName(getTxnStatusWebServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("TxnStatusWebServicePort".equals(inputPortName)) {
            return getTxnStatusWebServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://uat.himalremit.com/soap/TxnStatusWebService", "TxnStatusWebService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/TxnStatusWebService", "TxnStatusWebServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("TxnStatusWebServicePort".equals(portName)) {
            setTxnStatusWebServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
