/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.google.gson.Gson;
import com.himalremit.uat.soap.AmendInfoWebService.SoapRequest;
import com.himalremit.uat.soap.AmendInfoWebService.SoapResponse;

import com.himalremit.uat.soap.BankDetailsWebService.BankDetailsRequest;
import com.himalremit.uat.soap.GetRateHRIWebService.GetRateHRIobjArray;

/**
 *
 * @author nmrehman
 */
public class Test {

    private static Gson gson = new Gson();

    public static void main(String[] args) {
        GetRateHRIobjArray rateHRIobjArray = new GetRateHRIobjArray("LY3ho6Rk", "83");
        printJson(rateHRIobjArray);
        
    }

    private static String toJson(Object obj) {
        return gson.toJson(obj);
    }

    private static void printJson(Object object) {
        System.out.println(toJson(object));
    }

}
