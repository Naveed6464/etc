/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.himalremit.uat.soap.GetRateHRIWebService.ErrorSoapObject;
import com.himalremit.uat.soap.GetRateHRIWebService.ErrorSoapObjectArray;
import com.himalremit.uat.soap.GetRateHRIWebService.GetRateHRIWebServiceLocator;
import com.himalremit.uat.soap.GetRateHRIWebService.GetRateHRIWebServicePortType;
import com.himalremit.uat.soap.GetRateHRIWebService.GetRateHRIobj;
import com.himalremit.uat.soap.GetRateHRIWebService.GetRateHRIobjArray;
import com.inma.rmt.ws.core.GenericRPCClient;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.rpc.ServiceException;

/**
 *
 * @author nmrehman
 */
public class GetRate extends GenericRPCClient<GetRateHRIWebServiceLocator> {

    GetRateHRIobjArray request;
    ErrorSoapObjectArray errorSoapObjectArray;

    @Override
    public void initRequestParams(String requestParams) {
        if (getServiceMethodName().equals("getRateHRI")) {
            request = fromJson(requestParams, GetRateHRIobjArray.class);
        } else {
            errorSoapObjectArray = fromJson(requestParams, ErrorSoapObjectArray.class);
        }
    }

    @Override
    public String invoke(String serviceMethodName) {
        try {
            //GetRateHRIWebServicePortType webService = create().getGetRateHRIWebServicePort(getURL());                       
            GetRateHRIWebServicePortType webService = create().getGetRateHRIWebServicePort();
            switch (serviceMethodName) {
                case "getRateHRI":
                    GetRateHRIobj rateHRI = webService.getRateHRI(request);
                    return toJson(rateHRI);
                case "errorHandler":
                    ErrorSoapObject errorHandler = webService.errorHandler(errorSoapObjectArray);
                    return toJson(errorHandler);
            }
            return "Error: No WebService Method Found";
        } catch (RemoteException | ServiceException ex) {
            Logger.getLogger(GetRate.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR";
    }

}
