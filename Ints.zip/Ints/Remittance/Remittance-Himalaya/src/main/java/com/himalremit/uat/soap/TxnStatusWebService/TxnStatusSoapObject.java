/**
 * TxnStatusSoapObject.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.himalremit.uat.soap.TxnStatusWebService;

public class TxnStatusSoapObject  implements java.io.Serializable {
    private java.lang.String transactionNumber;

    private java.lang.String transactionDate;

    private java.lang.String transactionLCY;

    private java.lang.String transactionLCYAmount;

    private java.lang.String rateOfTransaction;

    private java.lang.String amountToPayInFCY;

    private java.lang.String currencyCodeInPCY;

    private java.lang.String transactionMethod;

    private java.lang.String correspondentBankCode;

    private java.lang.String correspondentBranchCode;

    private java.lang.String remitterName;

    private java.lang.String remitterPhoneNumber;

    private java.lang.String beneficiaryName;

    private java.lang.String beneficiaryPhoneNumber;

    private java.lang.String postedDate;

    private java.lang.String status;

    private java.lang.String statusDesc;

    private java.lang.String code;

    public TxnStatusSoapObject() {
    }

    public TxnStatusSoapObject(
           java.lang.String transactionNumber,
           java.lang.String transactionDate,
           java.lang.String transactionLCY,
           java.lang.String transactionLCYAmount,
           java.lang.String rateOfTransaction,
           java.lang.String amountToPayInFCY,
           java.lang.String currencyCodeInPCY,
           java.lang.String transactionMethod,
           java.lang.String correspondentBankCode,
           java.lang.String correspondentBranchCode,
           java.lang.String remitterName,
           java.lang.String remitterPhoneNumber,
           java.lang.String beneficiaryName,
           java.lang.String beneficiaryPhoneNumber,
           java.lang.String postedDate,
           java.lang.String status,
           java.lang.String statusDesc,
           java.lang.String code) {
           this.transactionNumber = transactionNumber;
           this.transactionDate = transactionDate;
           this.transactionLCY = transactionLCY;
           this.transactionLCYAmount = transactionLCYAmount;
           this.rateOfTransaction = rateOfTransaction;
           this.amountToPayInFCY = amountToPayInFCY;
           this.currencyCodeInPCY = currencyCodeInPCY;
           this.transactionMethod = transactionMethod;
           this.correspondentBankCode = correspondentBankCode;
           this.correspondentBranchCode = correspondentBranchCode;
           this.remitterName = remitterName;
           this.remitterPhoneNumber = remitterPhoneNumber;
           this.beneficiaryName = beneficiaryName;
           this.beneficiaryPhoneNumber = beneficiaryPhoneNumber;
           this.postedDate = postedDate;
           this.status = status;
           this.statusDesc = statusDesc;
           this.code = code;
    }


    /**
     * Gets the transactionNumber value for this TxnStatusSoapObject.
     * 
     * @return transactionNumber
     */
    public java.lang.String getTransactionNumber() {
        return transactionNumber;
    }


    /**
     * Sets the transactionNumber value for this TxnStatusSoapObject.
     * 
     * @param transactionNumber
     */
    public void setTransactionNumber(java.lang.String transactionNumber) {
        this.transactionNumber = transactionNumber;
    }


    /**
     * Gets the transactionDate value for this TxnStatusSoapObject.
     * 
     * @return transactionDate
     */
    public java.lang.String getTransactionDate() {
        return transactionDate;
    }


    /**
     * Sets the transactionDate value for this TxnStatusSoapObject.
     * 
     * @param transactionDate
     */
    public void setTransactionDate(java.lang.String transactionDate) {
        this.transactionDate = transactionDate;
    }


    /**
     * Gets the transactionLCY value for this TxnStatusSoapObject.
     * 
     * @return transactionLCY
     */
    public java.lang.String getTransactionLCY() {
        return transactionLCY;
    }


    /**
     * Sets the transactionLCY value for this TxnStatusSoapObject.
     * 
     * @param transactionLCY
     */
    public void setTransactionLCY(java.lang.String transactionLCY) {
        this.transactionLCY = transactionLCY;
    }


    /**
     * Gets the transactionLCYAmount value for this TxnStatusSoapObject.
     * 
     * @return transactionLCYAmount
     */
    public java.lang.String getTransactionLCYAmount() {
        return transactionLCYAmount;
    }


    /**
     * Sets the transactionLCYAmount value for this TxnStatusSoapObject.
     * 
     * @param transactionLCYAmount
     */
    public void setTransactionLCYAmount(java.lang.String transactionLCYAmount) {
        this.transactionLCYAmount = transactionLCYAmount;
    }


    /**
     * Gets the rateOfTransaction value for this TxnStatusSoapObject.
     * 
     * @return rateOfTransaction
     */
    public java.lang.String getRateOfTransaction() {
        return rateOfTransaction;
    }


    /**
     * Sets the rateOfTransaction value for this TxnStatusSoapObject.
     * 
     * @param rateOfTransaction
     */
    public void setRateOfTransaction(java.lang.String rateOfTransaction) {
        this.rateOfTransaction = rateOfTransaction;
    }


    /**
     * Gets the amountToPayInFCY value for this TxnStatusSoapObject.
     * 
     * @return amountToPayInFCY
     */
    public java.lang.String getAmountToPayInFCY() {
        return amountToPayInFCY;
    }


    /**
     * Sets the amountToPayInFCY value for this TxnStatusSoapObject.
     * 
     * @param amountToPayInFCY
     */
    public void setAmountToPayInFCY(java.lang.String amountToPayInFCY) {
        this.amountToPayInFCY = amountToPayInFCY;
    }


    /**
     * Gets the currencyCodeInPCY value for this TxnStatusSoapObject.
     * 
     * @return currencyCodeInPCY
     */
    public java.lang.String getCurrencyCodeInPCY() {
        return currencyCodeInPCY;
    }


    /**
     * Sets the currencyCodeInPCY value for this TxnStatusSoapObject.
     * 
     * @param currencyCodeInPCY
     */
    public void setCurrencyCodeInPCY(java.lang.String currencyCodeInPCY) {
        this.currencyCodeInPCY = currencyCodeInPCY;
    }


    /**
     * Gets the transactionMethod value for this TxnStatusSoapObject.
     * 
     * @return transactionMethod
     */
    public java.lang.String getTransactionMethod() {
        return transactionMethod;
    }


    /**
     * Sets the transactionMethod value for this TxnStatusSoapObject.
     * 
     * @param transactionMethod
     */
    public void setTransactionMethod(java.lang.String transactionMethod) {
        this.transactionMethod = transactionMethod;
    }


    /**
     * Gets the correspondentBankCode value for this TxnStatusSoapObject.
     * 
     * @return correspondentBankCode
     */
    public java.lang.String getCorrespondentBankCode() {
        return correspondentBankCode;
    }


    /**
     * Sets the correspondentBankCode value for this TxnStatusSoapObject.
     * 
     * @param correspondentBankCode
     */
    public void setCorrespondentBankCode(java.lang.String correspondentBankCode) {
        this.correspondentBankCode = correspondentBankCode;
    }


    /**
     * Gets the correspondentBranchCode value for this TxnStatusSoapObject.
     * 
     * @return correspondentBranchCode
     */
    public java.lang.String getCorrespondentBranchCode() {
        return correspondentBranchCode;
    }


    /**
     * Sets the correspondentBranchCode value for this TxnStatusSoapObject.
     * 
     * @param correspondentBranchCode
     */
    public void setCorrespondentBranchCode(java.lang.String correspondentBranchCode) {
        this.correspondentBranchCode = correspondentBranchCode;
    }


    /**
     * Gets the remitterName value for this TxnStatusSoapObject.
     * 
     * @return remitterName
     */
    public java.lang.String getRemitterName() {
        return remitterName;
    }


    /**
     * Sets the remitterName value for this TxnStatusSoapObject.
     * 
     * @param remitterName
     */
    public void setRemitterName(java.lang.String remitterName) {
        this.remitterName = remitterName;
    }


    /**
     * Gets the remitterPhoneNumber value for this TxnStatusSoapObject.
     * 
     * @return remitterPhoneNumber
     */
    public java.lang.String getRemitterPhoneNumber() {
        return remitterPhoneNumber;
    }


    /**
     * Sets the remitterPhoneNumber value for this TxnStatusSoapObject.
     * 
     * @param remitterPhoneNumber
     */
    public void setRemitterPhoneNumber(java.lang.String remitterPhoneNumber) {
        this.remitterPhoneNumber = remitterPhoneNumber;
    }


    /**
     * Gets the beneficiaryName value for this TxnStatusSoapObject.
     * 
     * @return beneficiaryName
     */
    public java.lang.String getBeneficiaryName() {
        return beneficiaryName;
    }


    /**
     * Sets the beneficiaryName value for this TxnStatusSoapObject.
     * 
     * @param beneficiaryName
     */
    public void setBeneficiaryName(java.lang.String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }


    /**
     * Gets the beneficiaryPhoneNumber value for this TxnStatusSoapObject.
     * 
     * @return beneficiaryPhoneNumber
     */
    public java.lang.String getBeneficiaryPhoneNumber() {
        return beneficiaryPhoneNumber;
    }


    /**
     * Sets the beneficiaryPhoneNumber value for this TxnStatusSoapObject.
     * 
     * @param beneficiaryPhoneNumber
     */
    public void setBeneficiaryPhoneNumber(java.lang.String beneficiaryPhoneNumber) {
        this.beneficiaryPhoneNumber = beneficiaryPhoneNumber;
    }


    /**
     * Gets the postedDate value for this TxnStatusSoapObject.
     * 
     * @return postedDate
     */
    public java.lang.String getPostedDate() {
        return postedDate;
    }


    /**
     * Sets the postedDate value for this TxnStatusSoapObject.
     * 
     * @param postedDate
     */
    public void setPostedDate(java.lang.String postedDate) {
        this.postedDate = postedDate;
    }


    /**
     * Gets the status value for this TxnStatusSoapObject.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this TxnStatusSoapObject.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the statusDesc value for this TxnStatusSoapObject.
     * 
     * @return statusDesc
     */
    public java.lang.String getStatusDesc() {
        return statusDesc;
    }


    /**
     * Sets the statusDesc value for this TxnStatusSoapObject.
     * 
     * @param statusDesc
     */
    public void setStatusDesc(java.lang.String statusDesc) {
        this.statusDesc = statusDesc;
    }


    /**
     * Gets the code value for this TxnStatusSoapObject.
     * 
     * @return code
     */
    public java.lang.String getCode() {
        return code;
    }


    /**
     * Sets the code value for this TxnStatusSoapObject.
     * 
     * @param code
     */
    public void setCode(java.lang.String code) {
        this.code = code;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TxnStatusSoapObject)) return false;
        TxnStatusSoapObject other = (TxnStatusSoapObject) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionNumber==null && other.getTransactionNumber()==null) || 
             (this.transactionNumber!=null &&
              this.transactionNumber.equals(other.getTransactionNumber()))) &&
            ((this.transactionDate==null && other.getTransactionDate()==null) || 
             (this.transactionDate!=null &&
              this.transactionDate.equals(other.getTransactionDate()))) &&
            ((this.transactionLCY==null && other.getTransactionLCY()==null) || 
             (this.transactionLCY!=null &&
              this.transactionLCY.equals(other.getTransactionLCY()))) &&
            ((this.transactionLCYAmount==null && other.getTransactionLCYAmount()==null) || 
             (this.transactionLCYAmount!=null &&
              this.transactionLCYAmount.equals(other.getTransactionLCYAmount()))) &&
            ((this.rateOfTransaction==null && other.getRateOfTransaction()==null) || 
             (this.rateOfTransaction!=null &&
              this.rateOfTransaction.equals(other.getRateOfTransaction()))) &&
            ((this.amountToPayInFCY==null && other.getAmountToPayInFCY()==null) || 
             (this.amountToPayInFCY!=null &&
              this.amountToPayInFCY.equals(other.getAmountToPayInFCY()))) &&
            ((this.currencyCodeInPCY==null && other.getCurrencyCodeInPCY()==null) || 
             (this.currencyCodeInPCY!=null &&
              this.currencyCodeInPCY.equals(other.getCurrencyCodeInPCY()))) &&
            ((this.transactionMethod==null && other.getTransactionMethod()==null) || 
             (this.transactionMethod!=null &&
              this.transactionMethod.equals(other.getTransactionMethod()))) &&
            ((this.correspondentBankCode==null && other.getCorrespondentBankCode()==null) || 
             (this.correspondentBankCode!=null &&
              this.correspondentBankCode.equals(other.getCorrespondentBankCode()))) &&
            ((this.correspondentBranchCode==null && other.getCorrespondentBranchCode()==null) || 
             (this.correspondentBranchCode!=null &&
              this.correspondentBranchCode.equals(other.getCorrespondentBranchCode()))) &&
            ((this.remitterName==null && other.getRemitterName()==null) || 
             (this.remitterName!=null &&
              this.remitterName.equals(other.getRemitterName()))) &&
            ((this.remitterPhoneNumber==null && other.getRemitterPhoneNumber()==null) || 
             (this.remitterPhoneNumber!=null &&
              this.remitterPhoneNumber.equals(other.getRemitterPhoneNumber()))) &&
            ((this.beneficiaryName==null && other.getBeneficiaryName()==null) || 
             (this.beneficiaryName!=null &&
              this.beneficiaryName.equals(other.getBeneficiaryName()))) &&
            ((this.beneficiaryPhoneNumber==null && other.getBeneficiaryPhoneNumber()==null) || 
             (this.beneficiaryPhoneNumber!=null &&
              this.beneficiaryPhoneNumber.equals(other.getBeneficiaryPhoneNumber()))) &&
            ((this.postedDate==null && other.getPostedDate()==null) || 
             (this.postedDate!=null &&
              this.postedDate.equals(other.getPostedDate()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.statusDesc==null && other.getStatusDesc()==null) || 
             (this.statusDesc!=null &&
              this.statusDesc.equals(other.getStatusDesc()))) &&
            ((this.code==null && other.getCode()==null) || 
             (this.code!=null &&
              this.code.equals(other.getCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionNumber() != null) {
            _hashCode += getTransactionNumber().hashCode();
        }
        if (getTransactionDate() != null) {
            _hashCode += getTransactionDate().hashCode();
        }
        if (getTransactionLCY() != null) {
            _hashCode += getTransactionLCY().hashCode();
        }
        if (getTransactionLCYAmount() != null) {
            _hashCode += getTransactionLCYAmount().hashCode();
        }
        if (getRateOfTransaction() != null) {
            _hashCode += getRateOfTransaction().hashCode();
        }
        if (getAmountToPayInFCY() != null) {
            _hashCode += getAmountToPayInFCY().hashCode();
        }
        if (getCurrencyCodeInPCY() != null) {
            _hashCode += getCurrencyCodeInPCY().hashCode();
        }
        if (getTransactionMethod() != null) {
            _hashCode += getTransactionMethod().hashCode();
        }
        if (getCorrespondentBankCode() != null) {
            _hashCode += getCorrespondentBankCode().hashCode();
        }
        if (getCorrespondentBranchCode() != null) {
            _hashCode += getCorrespondentBranchCode().hashCode();
        }
        if (getRemitterName() != null) {
            _hashCode += getRemitterName().hashCode();
        }
        if (getRemitterPhoneNumber() != null) {
            _hashCode += getRemitterPhoneNumber().hashCode();
        }
        if (getBeneficiaryName() != null) {
            _hashCode += getBeneficiaryName().hashCode();
        }
        if (getBeneficiaryPhoneNumber() != null) {
            _hashCode += getBeneficiaryPhoneNumber().hashCode();
        }
        if (getPostedDate() != null) {
            _hashCode += getPostedDate().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getStatusDesc() != null) {
            _hashCode += getStatusDesc().hashCode();
        }
        if (getCode() != null) {
            _hashCode += getCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TxnStatusSoapObject.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://uat.himalremit.com/soap/TxnStatusWebService", "TxnStatusSoapObject"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionLCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionLCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionLCYAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionLCYAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rateOfTransaction");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RateOfTransaction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amountToPayInFCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AmountToPayInFCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCodeInPCY");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CurrencyCodeInPCY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondentBankCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrespondentBankCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correspondentBranchCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrespondentBranchCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remitterPhoneNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "RemitterPhoneNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beneficiaryPhoneNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BeneficiaryPhoneNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("postedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PostedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "StatusDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("code");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
