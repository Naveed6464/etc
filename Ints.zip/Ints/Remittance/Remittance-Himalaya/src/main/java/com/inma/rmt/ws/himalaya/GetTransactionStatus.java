/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws.himalaya;

import com.himalremit.uat.soap.TxnStatusWebService.SettlementReportReq;
import com.himalremit.uat.soap.TxnStatusWebService.SettlementReportRes;
import com.himalremit.uat.soap.TxnStatusWebService.TxnStatusSoapObject;
import com.himalremit.uat.soap.TxnStatusWebService.TxnStatusSoapObjectArray;
import com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServiceLocator;
import com.himalremit.uat.soap.TxnStatusWebService.TxnStatusWebServicePortType;
import com.inma.rmt.ws.core.GenericRPCClient;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.rpc.ServiceException;

/**
 *
 * @author nmrehman
 */
public class GetTransactionStatus extends GenericRPCClient<TxnStatusWebServiceLocator> {

    SettlementReportReq settlementReportReq;

    TxnStatusSoapObjectArray txnStatusSoapObjectArray;

    @Override
    public void initRequestParams(String requestParams) {
        if (getServiceMethodName().equals("getSettlementReport")) {
            settlementReportReq = fromJson(requestParams, SettlementReportReq.class);
        } else {
            txnStatusSoapObjectArray = fromJson(requestParams, TxnStatusSoapObjectArray.class);
        }
    }

    @Override
    public String invoke(String serviceMethodName) {
        try {
            TxnStatusWebServicePortType webService = create().getTxnStatusWebServicePort();//getURL()
            switch (serviceMethodName) {
                case "getSettlementReport":
                    SettlementReportRes settlementReport = webService.getSettlementReport(settlementReportReq);
                    return toJson(settlementReport);
                case "getTxnStatus":
                    TxnStatusSoapObject txnStatus = webService.getTxnStatus(txnStatusSoapObjectArray);
                    return toJson(txnStatus);
            }
            return "Error: No WebService Method Found";
        } catch (RemoteException | ServiceException ex) {
            Logger.getLogger(GetTransactionStatus.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR";
    }

}
