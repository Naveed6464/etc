/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.ws;

import com.inma.rmt.ws.ft.FUNDSTRANSFERTESTWSType;
import com.inma.rmt.ws.ft.FUNDSTRANSFERType;
import com.inma.rmt.ws.ft.OfsFunction;
import com.inma.rmt.ws.ft.Status;
import com.inma.rmt.ws.ft.T24WebServicesImpl;
import com.inma.rmt.ws.ft.WebRequestCommon;
import com.inma.rmt.ws.core.GenericWSClient;
import java.util.List;
import javax.xml.ws.Holder;

/**
 *
 * @author nmrehman
 */
public class T24FT extends GenericWSClient<T24WebServicesImpl> {

    WebRequestCommon webRequestCommon;
    FUNDSTRANSFERTESTWSType fundstransfertestwsType;
    Holder<Status> status = new Holder<>();
    Holder<FUNDSTRANSFERType> holder = new Holder<>();

    @Override
    public void initRequestParams(String requestParams) {
        List<String> params = split(requestParams, "#");
        webRequestCommon = getGSON().fromJson(params.get(0), WebRequestCommon.class);
        fundstransfertestwsType = getGSON().fromJson(params.get(1), FUNDSTRANSFERTESTWSType.class);
    }

    @Override
    public String invoke(String serviceMethodName) {
        T24WebServicesImpl t24WebServicesImpl = create();
        FUNDSTRANSFERTESTWSType response = null;
        switch (serviceMethodName) {
            case "webservicefttest":
                t24WebServicesImpl.webservicefttest(webRequestCommon, new OfsFunction(), fundstransfertestwsType, status, holder);
                break;
        }
        return "{" + toJson(status.value) + "," + toJson(holder.value) + "}";
    }

}
