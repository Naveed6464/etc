
package com.inma.rmt.ws.ft;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WEBSERVICEFTTEST_Validate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WEBSERVICEFTTEST_Validate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="WebRequestCommon" type="{T24WebServicesImpl}webRequestCommon" minOccurs="0"/>
 *         &lt;element name="OfsFunction" type="{T24WebServicesImpl}ofsFunction" minOccurs="0"/>
 *         &lt;element name="FUNDSTRANSFERTESTWSType" type="{T24WebServicesImpl}FUNDSTRANSFERTESTWSType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "webservicetestvalidate1", name = "WEBSERVICEFTTEST_Validate", propOrder = {
    "webRequestCommon",
    "ofsFunction",
    "fundstransfertestwsType"
})
public class WEBSERVICEFTTESTValidate {

    @XmlElement(name = "WebRequestCommon")
    protected WebRequestCommon webRequestCommon;
    @XmlElement(name = "OfsFunction")
    protected OfsFunction ofsFunction;
    @XmlElement(name = "FUNDSTRANSFERTESTWSType")
    protected FUNDSTRANSFERTESTWSType fundstransfertestwsType;

    /**
     * Gets the value of the webRequestCommon property.
     * 
     * @return
     *     possible object is
     *     {@link WebRequestCommon }
     *     
     */
    public WebRequestCommon getWebRequestCommon() {
        return webRequestCommon;
    }

    /**
     * Sets the value of the webRequestCommon property.
     * 
     * @param value
     *     allowed object is
     *     {@link WebRequestCommon }
     *     
     */
    public void setWebRequestCommon(WebRequestCommon value) {
        this.webRequestCommon = value;
    }

    /**
     * Gets the value of the ofsFunction property.
     * 
     * @return
     *     possible object is
     *     {@link OfsFunction }
     *     
     */
    public OfsFunction getOfsFunction() {
        return ofsFunction;
    }

    /**
     * Sets the value of the ofsFunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link OfsFunction }
     *     
     */
    public void setOfsFunction(OfsFunction value) {
        this.ofsFunction = value;
    }

    /**
     * Gets the value of the fundstransfertestwsType property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERTESTWSType }
     *     
     */
    public FUNDSTRANSFERTESTWSType getFUNDSTRANSFERTESTWSType() {
        return fundstransfertestwsType;
    }

    /**
     * Sets the value of the fundstransfertestwsType property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERTESTWSType }
     *     
     */
    public void setFUNDSTRANSFERTESTWSType(FUNDSTRANSFERTESTWSType value) {
        this.fundstransfertestwsType = value;
    }

}
