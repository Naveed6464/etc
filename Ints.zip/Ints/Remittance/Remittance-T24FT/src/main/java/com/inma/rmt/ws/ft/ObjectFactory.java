
package com.inma.rmt.ws.ft;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.inma.demo.ws.ft package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _WEBSERVICEFTTESTValidate_QNAME = new QName("T24WebServicesImpl", "WEBSERVICEFTTEST_Validate");
    private final static QName _WEBSERVICEFTTESTResponse_QNAME = new QName("T24WebServicesImpl", "WEBSERVICEFTTESTResponse");
    private final static QName _WEBSERVICEFTTESTValidateResponse_QNAME = new QName("T24WebServicesImpl", "WEBSERVICEFTTEST_ValidateResponse");
    private final static QName _WEBSERVICEFTTEST_QNAME = new QName("T24WebServicesImpl", "WEBSERVICEFTTEST");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.inma.demo.ws.ft
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERTESTWSType }
     * 
     */
    public FUNDSTRANSFERTESTWSType createFUNDSTRANSFERTESTWSType() {
        return new FUNDSTRANSFERTESTWSType();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERTESTWSType.GCOMMISSIONTYPE }
     * 
     */
    public FUNDSTRANSFERTESTWSType.GCOMMISSIONTYPE createFUNDSTRANSFERTESTWSTypeGCOMMISSIONTYPE() {
        return new FUNDSTRANSFERTESTWSType.GCOMMISSIONTYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType }
     * 
     */
    public FUNDSTRANSFERType createFUNDSTRANSFERType() {
        return new FUNDSTRANSFERType();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSNDTOPARAR }
     * 
     */
    public FUNDSTRANSFERType.GSNDTOPARAR createFUNDSTRANSFERTypeGSNDTOPARAR() {
        return new FUNDSTRANSFERType.GSNDTOPARAR();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GMSGTYPE }
     * 
     */
    public FUNDSTRANSFERType.GMSGTYPE createFUNDSTRANSFERTypeGMSGTYPE() {
        return new FUNDSTRANSFERType.GMSGTYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSENDTOPARTY }
     * 
     */
    public FUNDSTRANSFERType.GSENDTOPARTY createFUNDSTRANSFERTypeGSENDTOPARTY() {
        return new FUNDSTRANSFERType.GSENDTOPARTY();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY }
     * 
     */
    public FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY createFUNDSTRANSFERTypeGSENDTOPARTYMSENDTOPARTY() {
        return new FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GRELATEDMSG }
     * 
     */
    public FUNDSTRANSFERType.GRELATEDMSG createFUNDSTRANSFERTypeGRELATEDMSG() {
        return new FUNDSTRANSFERType.GRELATEDMSG();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG }
     * 
     */
    public FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG createFUNDSTRANSFERTypeGRELATEDMSGMRELATEDMSG() {
        return new FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GTAXTYPE }
     * 
     */
    public FUNDSTRANSFERType.GTAXTYPE createFUNDSTRANSFERTypeGTAXTYPE() {
        return new FUNDSTRANSFERType.GTAXTYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GCHARGETYPE }
     * 
     */
    public FUNDSTRANSFERType.GCHARGETYPE createFUNDSTRANSFERTypeGCHARGETYPE() {
        return new FUNDSTRANSFERType.GCHARGETYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GCOMMISSIONTYPE }
     * 
     */
    public FUNDSTRANSFERType.GCOMMISSIONTYPE createFUNDSTRANSFERTypeGCOMMISSIONTYPE() {
        return new FUNDSTRANSFERType.GCOMMISSIONTYPE();
    }

    /**
     * Create an instance of {@link AnyTypeArray }
     * 
     */
    public AnyTypeArray createAnyTypeArray() {
        return new AnyTypeArray();
    }

    /**
     * Create an instance of {@link WEBSERVICEFTTESTValidate }
     * 
     */
    public WEBSERVICEFTTESTValidate createWEBSERVICEFTTESTValidate() {
        return new WEBSERVICEFTTESTValidate();
    }

    /**
     * Create an instance of {@link WEBSERVICEFTTESTResponse }
     * 
     */
    public WEBSERVICEFTTESTResponse createWEBSERVICEFTTESTResponse() {
        return new WEBSERVICEFTTESTResponse();
    }

    /**
     * Create an instance of {@link WEBSERVICEFTTEST }
     * 
     */
    public WEBSERVICEFTTEST createWEBSERVICEFTTEST() {
        return new WEBSERVICEFTTEST();
    }

    /**
     * Create an instance of {@link WEBSERVICEFTTESTValidateResponse }
     * 
     */
    public WEBSERVICEFTTESTValidateResponse createWEBSERVICEFTTESTValidateResponse() {
        return new WEBSERVICEFTTESTValidateResponse();
    }

    /**
     * Create an instance of {@link WebRequestCommon }
     * 
     */
    public WebRequestCommon createWebRequestCommon() {
        return new WebRequestCommon();
    }

    /**
     * Create an instance of {@link OfsFunction }
     * 
     */
    public OfsFunction createOfsFunction() {
        return new OfsFunction();
    }

    /**
     * Create an instance of {@link Status }
     * 
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERTESTWSType.GORDERINGCUST }
     * 
     */
    public FUNDSTRANSFERTESTWSType.GORDERINGCUST createFUNDSTRANSFERTESTWSTypeGORDERINGCUST() {
        return new FUNDSTRANSFERTESTWSType.GORDERINGCUST();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERTESTWSType.GPAYMENTDETAILS }
     * 
     */
    public FUNDSTRANSFERTESTWSType.GPAYMENTDETAILS createFUNDSTRANSFERTESTWSTypeGPAYMENTDETAILS() {
        return new FUNDSTRANSFERTESTWSType.GPAYMENTDETAILS();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERTESTWSType.GCOMMISSIONTYPE.MCOMMISSIONTYPE }
     * 
     */
    public FUNDSTRANSFERTESTWSType.GCOMMISSIONTYPE.MCOMMISSIONTYPE createFUNDSTRANSFERTESTWSTypeGCOMMISSIONTYPEMCOMMISSIONTYPE() {
        return new FUNDSTRANSFERTESTWSType.GCOMMISSIONTYPE.MCOMMISSIONTYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GORDERINGCUST }
     * 
     */
    public FUNDSTRANSFERType.GORDERINGCUST createFUNDSTRANSFERTypeGORDERINGCUST() {
        return new FUNDSTRANSFERType.GORDERINGCUST();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINORDERINGCUS }
     * 
     */
    public FUNDSTRANSFERType.GINORDERINGCUS createFUNDSTRANSFERTypeGINORDERINGCUS() {
        return new FUNDSTRANSFERType.GINORDERINGCUS();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GORDERINGBANK }
     * 
     */
    public FUNDSTRANSFERType.GORDERINGBANK createFUNDSTRANSFERTypeGORDERINGBANK() {
        return new FUNDSTRANSFERType.GORDERINGBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINORDERINGBK }
     * 
     */
    public FUNDSTRANSFERType.GINORDERINGBK createFUNDSTRANSFERTypeGINORDERINGBK() {
        return new FUNDSTRANSFERType.GINORDERINGBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GACCTWITHBANK }
     * 
     */
    public FUNDSTRANSFERType.GACCTWITHBANK createFUNDSTRANSFERTypeGACCTWITHBANK() {
        return new FUNDSTRANSFERType.GACCTWITHBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GACCTWITHBK }
     * 
     */
    public FUNDSTRANSFERType.GACCTWITHBK createFUNDSTRANSFERTypeGACCTWITHBK() {
        return new FUNDSTRANSFERType.GACCTWITHBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GBENCUSTOMER }
     * 
     */
    public FUNDSTRANSFERType.GBENCUSTOMER createFUNDSTRANSFERTypeGBENCUSTOMER() {
        return new FUNDSTRANSFERType.GBENCUSTOMER();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINBENCUSTOMER }
     * 
     */
    public FUNDSTRANSFERType.GINBENCUSTOMER createFUNDSTRANSFERTypeGINBENCUSTOMER() {
        return new FUNDSTRANSFERType.GINBENCUSTOMER();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GBENBANK }
     * 
     */
    public FUNDSTRANSFERType.GBENBANK createFUNDSTRANSFERTypeGBENBANK() {
        return new FUNDSTRANSFERType.GBENBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINBENBANK }
     * 
     */
    public FUNDSTRANSFERType.GINBENBANK createFUNDSTRANSFERTypeGINBENBANK() {
        return new FUNDSTRANSFERType.GINBENBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GPAYMENTDETAILS }
     * 
     */
    public FUNDSTRANSFERType.GPAYMENTDETAILS createFUNDSTRANSFERTypeGPAYMENTDETAILS() {
        return new FUNDSTRANSFERType.GPAYMENTDETAILS();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINPAYDETAILS }
     * 
     */
    public FUNDSTRANSFERType.GINPAYDETAILS createFUNDSTRANSFERTypeGINPAYDETAILS() {
        return new FUNDSTRANSFERType.GINPAYDETAILS();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GRECCORRBANK }
     * 
     */
    public FUNDSTRANSFERType.GRECCORRBANK createFUNDSTRANSFERTypeGRECCORRBANK() {
        return new FUNDSTRANSFERType.GRECCORRBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINTERMEDBANK }
     * 
     */
    public FUNDSTRANSFERType.GINTERMEDBANK createFUNDSTRANSFERTypeGINTERMEDBANK() {
        return new FUNDSTRANSFERType.GINTERMEDBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GININTMEDBANK }
     * 
     */
    public FUNDSTRANSFERType.GININTMEDBANK createFUNDSTRANSFERTypeGININTMEDBANK() {
        return new FUNDSTRANSFERType.GININTMEDBANK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GBKTOBKINFO }
     * 
     */
    public FUNDSTRANSFERType.GBKTOBKINFO createFUNDSTRANSFERTypeGBKTOBKINFO() {
        return new FUNDSTRANSFERType.GBKTOBKINFO();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINBKTOBK }
     * 
     */
    public FUNDSTRANSFERType.GINBKTOBK createFUNDSTRANSFERTypeGINBKTOBK() {
        return new FUNDSTRANSFERType.GINBKTOBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GFREETEXTMSGTO }
     * 
     */
    public FUNDSTRANSFERType.GFREETEXTMSGTO createFUNDSTRANSFERTypeGFREETEXTMSGTO() {
        return new FUNDSTRANSFERType.GFREETEXTMSGTO();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GMESSAGE }
     * 
     */
    public FUNDSTRANSFERType.GMESSAGE createFUNDSTRANSFERTypeGMESSAGE() {
        return new FUNDSTRANSFERType.GMESSAGE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINRECCORRBK }
     * 
     */
    public FUNDSTRANSFERType.GINRECCORRBK createFUNDSTRANSFERTypeGINRECCORRBK() {
        return new FUNDSTRANSFERType.GINRECCORRBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINSENDCORRBK }
     * 
     */
    public FUNDSTRANSFERType.GINSENDCORRBK createFUNDSTRANSFERTypeGINSENDCORRBK() {
        return new FUNDSTRANSFERType.GINSENDCORRBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GDELIVERYOUTREF }
     * 
     */
    public FUNDSTRANSFERType.GDELIVERYOUTREF createFUNDSTRANSFERTypeGDELIVERYOUTREF() {
        return new FUNDSTRANSFERType.GDELIVERYOUTREF();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINREASONOVE }
     * 
     */
    public FUNDSTRANSFERType.GINREASONOVE createFUNDSTRANSFERTypeGINREASONOVE() {
        return new FUNDSTRANSFERType.GINREASONOVE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINSTRCTNCODE }
     * 
     */
    public FUNDSTRANSFERType.GINSTRCTNCODE createFUNDSTRANSFERTypeGINSTRCTNCODE() {
        return new FUNDSTRANSFERType.GINSTRCTNCODE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINTIMEIND }
     * 
     */
    public FUNDSTRANSFERType.GINTIMEIND createFUNDSTRANSFERTypeGINTIMEIND() {
        return new FUNDSTRANSFERType.GINTIMEIND();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GININSTRCODE }
     * 
     */
    public FUNDSTRANSFERType.GININSTRCODE createFUNDSTRANSFERTypeGININSTRCODE() {
        return new FUNDSTRANSFERType.GININSTRCODE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINPROCESSERR }
     * 
     */
    public FUNDSTRANSFERType.GINPROCESSERR createFUNDSTRANSFERTypeGINPROCESSERR() {
        return new FUNDSTRANSFERType.GINPROCESSERR();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINSWIFTMSG }
     * 
     */
    public FUNDSTRANSFERType.GINSWIFTMSG createFUNDSTRANSFERTypeGINSWIFTMSG() {
        return new FUNDSTRANSFERType.GINSWIFTMSG();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GININTERMEDBK }
     * 
     */
    public FUNDSTRANSFERType.GININTERMEDBK createFUNDSTRANSFERTypeGININTERMEDBK() {
        return new FUNDSTRANSFERType.GININTERMEDBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GIN3RDREIMBBK }
     * 
     */
    public FUNDSTRANSFERType.GIN3RDREIMBBK createFUNDSTRANSFERTypeGIN3RDREIMBBK() {
        return new FUNDSTRANSFERType.GIN3RDREIMBBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GEXTENDINFO }
     * 
     */
    public FUNDSTRANSFERType.GEXTENDINFO createFUNDSTRANSFERTypeGEXTENDINFO() {
        return new FUNDSTRANSFERType.GEXTENDINFO();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINSENDCHG }
     * 
     */
    public FUNDSTRANSFERType.GINSENDCHG createFUNDSTRANSFERTypeGINSENDCHG() {
        return new FUNDSTRANSFERType.GINSENDCHG();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSIGNATORY }
     * 
     */
    public FUNDSTRANSFERType.GSIGNATORY createFUNDSTRANSFERTypeGSIGNATORY() {
        return new FUNDSTRANSFERType.GSIGNATORY();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GCARDTXNDETAIL }
     * 
     */
    public FUNDSTRANSFERType.GCARDTXNDETAIL createFUNDSTRANSFERTypeGCARDTXNDETAIL() {
        return new FUNDSTRANSFERType.GCARDTXNDETAIL();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINCORDBK }
     * 
     */
    public FUNDSTRANSFERType.GINCORDBK createFUNDSTRANSFERTypeGINCORDBK() {
        return new FUNDSTRANSFERType.GINCORDBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINCINTMEDBK }
     * 
     */
    public FUNDSTRANSFERType.GINCINTMEDBK createFUNDSTRANSFERTypeGINCINTMEDBK() {
        return new FUNDSTRANSFERType.GINCINTMEDBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINCACCWITBK }
     * 
     */
    public FUNDSTRANSFERType.GINCACCWITBK createFUNDSTRANSFERTypeGINCACCWITBK() {
        return new FUNDSTRANSFERType.GINCACCWITBK();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINCBKTBKIN }
     * 
     */
    public FUNDSTRANSFERType.GINCBKTBKIN createFUNDSTRANSFERTypeGINCBKTBKIN() {
        return new FUNDSTRANSFERType.GINCBKTBKIN();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSTMTNOS }
     * 
     */
    public FUNDSTRANSFERType.GSTMTNOS createFUNDSTRANSFERTypeGSTMTNOS() {
        return new FUNDSTRANSFERType.GSTMTNOS();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GOVERRIDE }
     * 
     */
    public FUNDSTRANSFERType.GOVERRIDE createFUNDSTRANSFERTypeGOVERRIDE() {
        return new FUNDSTRANSFERType.GOVERRIDE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GINPUTTER }
     * 
     */
    public FUNDSTRANSFERType.GINPUTTER createFUNDSTRANSFERTypeGINPUTTER() {
        return new FUNDSTRANSFERType.GINPUTTER();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GDATETIME }
     * 
     */
    public FUNDSTRANSFERType.GDATETIME createFUNDSTRANSFERTypeGDATETIME() {
        return new FUNDSTRANSFERType.GDATETIME();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GCHEQUEBENEFICI }
     * 
     */
    public FUNDSTRANSFERType.GCHEQUEBENEFICI createFUNDSTRANSFERTypeGCHEQUEBENEFICI() {
        return new FUNDSTRANSFERType.GCHEQUEBENEFICI();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GBAJELNOTES }
     * 
     */
    public FUNDSTRANSFERType.GBAJELNOTES createFUNDSTRANSFERTypeGBAJELNOTES() {
        return new FUNDSTRANSFERType.GBAJELNOTES();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GORDCUSTAR }
     * 
     */
    public FUNDSTRANSFERType.GORDCUSTAR createFUNDSTRANSFERTypeGORDCUSTAR() {
        return new FUNDSTRANSFERType.GORDCUSTAR();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GBENCUSTAR }
     * 
     */
    public FUNDSTRANSFERType.GBENCUSTAR createFUNDSTRANSFERTypeGBENCUSTAR() {
        return new FUNDSTRANSFERType.GBENCUSTAR();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GPAYDETSAR }
     * 
     */
    public FUNDSTRANSFERType.GPAYDETSAR createFUNDSTRANSFERTypeGPAYDETSAR() {
        return new FUNDSTRANSFERType.GPAYDETSAR();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSIMESSAGE }
     * 
     */
    public FUNDSTRANSFERType.GSIMESSAGE createFUNDSTRANSFERTypeGSIMESSAGE() {
        return new FUNDSTRANSFERType.GSIMESSAGE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR }
     * 
     */
    public FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR createFUNDSTRANSFERTypeGSNDTOPARARMSNDTOPARAR() {
        return new FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE }
     * 
     */
    public FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE createFUNDSTRANSFERTypeGMSGTYPEMMSGTYPE() {
        return new FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT }
     * 
     */
    public FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT createFUNDSTRANSFERTypeGSENDTOPARTYMSENDTOPARTYSgBKTOBKOUT() {
        return new FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND }
     * 
     */
    public FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND createFUNDSTRANSFERTypeGRELATEDMSGMRELATEDMSGSgTIMEIND() {
        return new FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE }
     * 
     */
    public FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE createFUNDSTRANSFERTypeGTAXTYPEMTAXTYPE() {
        return new FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE }
     * 
     */
    public FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE createFUNDSTRANSFERTypeGCHARGETYPEMCHARGETYPE() {
        return new FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE();
    }

    /**
     * Create an instance of {@link FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE }
     * 
     */
    public FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE createFUNDSTRANSFERTypeGCOMMISSIONTYPEMCOMMISSIONTYPE() {
        return new FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WEBSERVICEFTTESTValidate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "T24WebServicesImpl", name = "WEBSERVICEFTTEST_Validate")
    public JAXBElement<WEBSERVICEFTTESTValidate> createWEBSERVICEFTTESTValidate(WEBSERVICEFTTESTValidate value) {
        return new JAXBElement<WEBSERVICEFTTESTValidate>(_WEBSERVICEFTTESTValidate_QNAME, WEBSERVICEFTTESTValidate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WEBSERVICEFTTESTResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "T24WebServicesImpl", name = "WEBSERVICEFTTESTResponse")
    public JAXBElement<WEBSERVICEFTTESTResponse> createWEBSERVICEFTTESTResponse(WEBSERVICEFTTESTResponse value) {
        return new JAXBElement<WEBSERVICEFTTESTResponse>(_WEBSERVICEFTTESTResponse_QNAME, WEBSERVICEFTTESTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WEBSERVICEFTTESTValidateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "T24WebServicesImpl", name = "WEBSERVICEFTTEST_ValidateResponse")
    public JAXBElement<WEBSERVICEFTTESTValidateResponse> createWEBSERVICEFTTESTValidateResponse(WEBSERVICEFTTESTValidateResponse value) {
        return new JAXBElement<WEBSERVICEFTTESTValidateResponse>(_WEBSERVICEFTTESTValidateResponse_QNAME, WEBSERVICEFTTESTValidateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WEBSERVICEFTTEST }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "T24WebServicesImpl", name = "WEBSERVICEFTTEST")
    public JAXBElement<WEBSERVICEFTTEST> createWEBSERVICEFTTEST(WEBSERVICEFTTEST value) {
        return new JAXBElement<WEBSERVICEFTTEST>(_WEBSERVICEFTTEST_QNAME, WEBSERVICEFTTEST.class, null, value);
    }

}
