@javax.xml.bind.annotation.XmlSchema(namespace = "T24WebServicesImpl")
package com.inma.rmt.ws.ft;
