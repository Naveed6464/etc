
package com.inma.rmt.ws.ft;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import lombok.ToString;


/**
 * <p>Java class for FUNDSTRANSFERType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FUNDSTRANSFERType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TRANSACTIONTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INDEBITACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CURRENCYMKTDR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITCURRENCY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITAMOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITVALUEDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INDEBITVDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITTHEIRREF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREDITTHEIRREF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREDITACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CURRENCYMKTCR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREDITCURRENCY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREDITAMOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREDITVALUEDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TREASURYRATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NEGDEALERREFNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PROCESSINGDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gORDERINGCUST" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ORDERINGCUST" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINORDERINGCUS" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INORDERINGCUS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gORDERINGBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ORDERINGBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINORDERINGBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INORDERINGBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gACCTWITHBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ACCTWITHBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gACCTWITHBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ACCTWITHBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BENACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INBENACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gBENCUSTOMER" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BENCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINBENCUSTOMER" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INBENCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gBENBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BENBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINBENBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INBENBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CHEQUENUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gPAYMENTDETAILS" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PAYMENTDETAILS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINPAYDETAILS" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INPAYDETAILS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BCBANKSORTCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RECEIVERBANK" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gRECCORRBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="RECCORRBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINTERMEDBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INTERMEDBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gININTMEDBANK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ININTMEDBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="MAILING" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PAYMETHOD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BENOURCHARGES" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INBENOURCHARGES" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHARGESACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHARGECOMDISPLAY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COMMISSIONCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gCOMMISSIONTYPE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mCOMMISSIONTYPE" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="COMMISSIONTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="COMMISSIONAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="COMMISSIONFOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CHARGECODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gCHARGETYPE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mCHARGETYPE" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="CHARGETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="CHARGEAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="CHARGEFOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CUSTOMERSPREAD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BASECURRENCY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PROFITCENTRECUST" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PROFITCENTREDEPT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RETURNTODEPT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PRIORITYTXN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gBKTOBKINFO" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BKTOBKINFO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINBKTOBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INBKTOBKINFO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="EXPOSUREDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FEDFUNDS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POSITIONTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NOOFBATCHITEMS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gFREETEXTMSGTO" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="FREETEXTMSGTO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gMESSAGE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="MESSAGE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gTAXTYPE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mTAXTYPE" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="TAXTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="TAXAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AMOUNTDEBITED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AMOUNTCREDITED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTALCHARGEAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTALTAXAMOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUSTOMERRATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gINRECCORRBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INRECCORRBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INWARDPAYTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gINSENDCORRBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INSENDCORRBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TELEXFROMCUST" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DELIVERYINREF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gDELIVERYOUTREF" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DELIVERYOUTREF" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CREDITCOMPCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITCOMPCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DELIVERYMKR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORDCUSTCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACCTWITHBKACNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOCAMTDEBITED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOCAMTCREDITED" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOCTOTTAXAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOCALCHARGEAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOCPOSCHGSAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MKTGEXCHPROFIT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RATEINPUTMKR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUSTGROUPLEVEL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEBITCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CREDITCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SENDPAYMENTYN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DRADVICEREQDYN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CRADVICEREQDYN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEALMARKET" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHARGEDCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gINREASONOVE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INREASONOVE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DEALERDESK" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RECALCFWDRATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RETURNCHEQUE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DRAWNACCOUNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACCOUNTINGDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gINSTRCTNCODE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INSTRCTNCODE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="COLLREMBK" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EXPECTEDRECSID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTRECCOMM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTRECCOMMLCL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTRECCHG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTRECCHGLCL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHEQTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gRELATEDMSG" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mRELATEDMSG" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="RELATEDMSG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="sgTIMEIND" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="TIMEIND" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                     &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINTIMEIND" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INTIMEIND" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gSENDTOPARTY" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mSENDTOPARTY" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="SENDTOPARTY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="sgBKTOBKOUT" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="BKTOBKOUT" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                     &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="MESSAGETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="REVERSALMKR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RELATEDREF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gININSTRCODE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ININSTRCODE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINPROCESSERR" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INPROCESSERR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINSWIFTMSG" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INSWIFTMSG" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ACCTWITHBANKACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INACCTBANKACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RECCORRBANKACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INRECCORRACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INTERMEDBANKACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ININTERMEDACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INSTRUCTEDAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gININTERMEDBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ININTERMEDBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INEXCHRATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RATEFIXING" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COVERMETHOD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gIN3RDREIMBBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="IN3RDREIMBBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="IN3RDREIMBACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MT103TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EXTENDFORMAT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gEXTENDINFO" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="EXTENDINFO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RATEFIXINGIND" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INWSENDBIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gINSENDCHG" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INSENDCHG" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="INRECCHG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACCHGREQID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTRECCHGCRCCY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TOTSNDCHGCRCCY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHGADVICEMSG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EXPECTEDCOVERID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NETTINGSTATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AUTHDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BKOPERATIONCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AMINFLOWRATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PARENTTXNID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ROUNDTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BENEFICIARYID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gMSGTYPE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mMSGTYPE" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="MSGTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="MSGDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gSIGNATORY" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SIGNATORY" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CARDNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gCARDTXNDETAIL" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CARDTXNDETAIL" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINCORDBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INCORDBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINCINTMEDBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INCINTMEDBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINCACCWITBK" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INCACCWITBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gINCBKTBKIN" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INCBKTBKIN" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="TFSREFERENCE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHEQUEDRAWN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISSUECHEQUETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STOCKNUMBER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PAYEENAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STOCKREGISTER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SERIESID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED20" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED19" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED18" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED17" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED16" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED15" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED14" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED13" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED12" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED11" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED10" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED9" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RESERVED1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gSTMTNOS" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="STMTNOS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gOVERRIDE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="OVERRIDE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="RECORDSTATUS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CURRNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gINPUTTER" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="INPUTTER" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gDATETIME" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DATETIME" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="AUTHORISER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DEPTCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AUDITORCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AUDITDATETIME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISCONID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LASTVERSION" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISCUSTID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISSUPPLIER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOANTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CMATXNREF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ICRCONID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BENCOUNTRY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHQTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TXNTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUSTPAYNOT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ORDCUSTACC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FTPURPOSE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BILLERID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BILLNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CARDNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="QPEMPLOYER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="QPKEY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SARIEBENBANK" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHQPURPOSE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CHEQUESENDER" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gCHEQUE.BENEFICI" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="CHEQUEBENEFICI" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BAJCMDTYDTL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BAJSELLQTY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BAJMKTPRICE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BAJLDREF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BAJCMDTYCODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BATRFCHRGS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BATRFAMNT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gBAJEL.NOTES" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BAJELNOTES" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="BROKERLIMIT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SIGLE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LOFACDETAIL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="INMAMSGTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MSGPRIORITY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUSTTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUSTNATNLTY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PAYMTPURPOSE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PAYROLL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ISRPRID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CARDACCTNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATMNO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gORD.CUST.AR" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ORDCUSTAR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gBEN.CUST.AR" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="BENCUSTAR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gPAY.DETS.AR" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="PAYDETSAR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="gSND.TO.PAR.AR" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="mSND.TO.PAR.AR" maxOccurs="unbounded" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="SNDTOPARAR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                             &lt;element name="BKTOBKAR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                           &lt;/sequence>
 *                           &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="SICODE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gSI.MESSAGE" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="SIMESSAGE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *                 &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="SITFIELD1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SITFIELD8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="id" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FUNDSTRANSFERType", propOrder = {
    "transactiontype",
    "debitacctno",
    "indebitacctno",
    "currencymktdr",
    "debitcurrency",
    "debitamount",
    "debitvaluedate",
    "indebitvdate",
    "debittheirref",
    "credittheirref",
    "creditacctno",
    "currencymktcr",
    "creditcurrency",
    "creditamount",
    "creditvaluedate",
    "treasuryrate",
    "negdealerrefno",
    "processingdate",
    "gorderingcust",
    "ginorderingcus",
    "gorderingbank",
    "ginorderingbk",
    "gacctwithbank",
    "gacctwithbk",
    "benacctno",
    "inbenacctno",
    "gbencustomer",
    "ginbencustomer",
    "gbenbank",
    "ginbenbank",
    "chequenumber",
    "gpaymentdetails",
    "ginpaydetails",
    "bcbanksortcode",
    "receiverbank",
    "greccorrbank",
    "gintermedbank",
    "ginintmedbank",
    "mailing",
    "paymethod",
    "benourcharges",
    "inbenourcharges",
    "chargesacctno",
    "chargecomdisplay",
    "commissioncode",
    "gcommissiontype",
    "chargecode",
    "gchargetype",
    "customerspread",
    "basecurrency",
    "profitcentrecust",
    "profitcentredept",
    "returntodept",
    "prioritytxn",
    "gbktobkinfo",
    "ginbktobk",
    "exposuredate",
    "fedfunds",
    "positiontype",
    "noofbatchitems",
    "gfreetextmsgto",
    "gmessage",
    "gtaxtype",
    "amountdebited",
    "amountcredited",
    "totalchargeamt",
    "totaltaxamount",
    "customerrate",
    "ginreccorrbk",
    "inwardpaytype",
    "ginsendcorrbk",
    "telexfromcust",
    "deliveryinref",
    "gdeliveryoutref",
    "creditcompcode",
    "debitcompcode",
    "status",
    "deliverymkr",
    "ordcustcode",
    "acctwithbkacno",
    "locamtdebited",
    "locamtcredited",
    "loctottaxamt",
    "localchargeamt",
    "locposchgsamt",
    "mktgexchprofit",
    "rateinputmkr",
    "custgrouplevel",
    "debitcustomer",
    "creditcustomer",
    "sendpaymentyn",
    "dradvicereqdyn",
    "cradvicereqdyn",
    "dealmarket",
    "chargedcustomer",
    "ginreasonove",
    "dealerdesk",
    "recalcfwdrate",
    "returncheque",
    "drawnaccount",
    "accountingdate",
    "ginstrctncode",
    "collrembk",
    "expectedrecsid",
    "totreccomm",
    "totreccommlcl",
    "totrecchg",
    "totrecchglcl",
    "cheqtype",
    "grelatedmsg",
    "gintimeind",
    "gsendtoparty",
    "reversalmkr",
    "relatedref",
    "gininstrcode",
    "ginprocesserr",
    "ginswiftmsg",
    "acctwithbankacc",
    "inacctbankacc",
    "reccorrbankacc",
    "inreccorracc",
    "intermedbankacc",
    "inintermedacc",
    "instructedamt",
    "ginintermedbk",
    "inexchrate",
    "ratefixing",
    "covermethod",
    "gin3RDREIMBBK",
    "in3RDREIMBACC",
    "mt103TYPE",
    "extendformat",
    "gextendinfo",
    "ratefixingind",
    "inwsendbic",
    "ginsendchg",
    "inrecchg",
    "acchgreqid",
    "totrecchgcrccy",
    "totsndchgcrccy",
    "chgadvicemsg",
    "expectedcoverid",
    "nettingstatus",
    "authdate",
    "bkoperationcode",
    "aminflowrate",
    "parenttxnid",
    "roundtype",
    "beneficiaryid",
    "gmsgtype",
    "gsignatory",
    "cardnumber",
    "gcardtxndetail",
    "gincordbk",
    "gincintmedbk",
    "gincaccwitbk",
    "gincbktbkin",
    "tfsreference",
    "chequedrawn",
    "issuechequetype",
    "stocknumber",
    "payeename",
    "stockregister",
    "seriesid",
    "reserved20",
    "reserved19",
    "reserved18",
    "reserved17",
    "reserved16",
    "reserved15",
    "reserved14",
    "reserved13",
    "reserved12",
    "reserved11",
    "reserved10",
    "reserved9",
    "reserved8",
    "reserved7",
    "reserved6",
    "reserved5",
    "reserved4",
    "reserved3",
    "reserved2",
    "reserved1",
    "gstmtnos",
    "goverride",
    "recordstatus",
    "currno",
    "ginputter",
    "gdatetime",
    "authoriser",
    "cocode",
    "deptcode",
    "auditorcode",
    "auditdatetime",
    "isconid",
    "lastversion",
    "iscustid",
    "issupplier",
    "loantype",
    "cmatxnref",
    "icrconid",
    "bencountry",
    "chqtype",
    "txntype",
    "custpaynot",
    "ordcustacc",
    "ftpurpose",
    "billerid",
    "billno",
    "cardno",
    "qpemployer",
    "qpkey",
    "sariebenbank",
    "chqpurpose",
    "chequesender",
    "gchequebenefici",
    "bajcmdtydtl",
    "bajsellqty",
    "bajmktprice",
    "bajldref",
    "bajcmdtycode",
    "batrfchrgs",
    "batrfamnt",
    "gbajelnotes",
    "brokerlimit",
    "sigle",
    "lofacdetail",
    "inmamsgtype",
    "msgpriority",
    "custtype",
    "custnatnlty",
    "paymtpurpose",
    "payroll",
    "isrprid",
    "cardacctno",
    "atmno",
    "gordcustar",
    "gbencustar",
    "gpaydetsar",
    "gsndtoparar",
    "sicode",
    "gsimessage",
    "sitfield1",
    "sitfield2",
    "sitfield3",
    "sitfield4",
    "sitfield5",
    "sitfield6",
    "sitfield7",
    "sitfield8"
})
@ToString
public class FUNDSTRANSFERType {

    @XmlElement(name = "TRANSACTIONTYPE")
    protected String transactiontype;
    @XmlElement(name = "DEBITACCTNO")
    protected String debitacctno;
    @XmlElement(name = "INDEBITACCTNO")
    protected String indebitacctno;
    @XmlElement(name = "CURRENCYMKTDR")
    protected String currencymktdr;
    @XmlElement(name = "DEBITCURRENCY")
    protected String debitcurrency;
    @XmlElement(name = "DEBITAMOUNT")
    protected String debitamount;
    @XmlElement(name = "DEBITVALUEDATE")
    protected String debitvaluedate;
    @XmlElement(name = "INDEBITVDATE")
    protected String indebitvdate;
    @XmlElement(name = "DEBITTHEIRREF")
    protected String debittheirref;
    @XmlElement(name = "CREDITTHEIRREF")
    protected String credittheirref;
    @XmlElement(name = "CREDITACCTNO")
    protected String creditacctno;
    @XmlElement(name = "CURRENCYMKTCR")
    protected String currencymktcr;
    @XmlElement(name = "CREDITCURRENCY")
    protected String creditcurrency;
    @XmlElement(name = "CREDITAMOUNT")
    protected String creditamount;
    @XmlElement(name = "CREDITVALUEDATE")
    protected String creditvaluedate;
    @XmlElement(name = "TREASURYRATE")
    protected String treasuryrate;
    @XmlElement(name = "NEGDEALERREFNO")
    protected String negdealerrefno;
    @XmlElement(name = "PROCESSINGDATE")
    protected String processingdate;
    @XmlElement(name = "gORDERINGCUST")
    protected FUNDSTRANSFERType.GORDERINGCUST gorderingcust;
    @XmlElement(name = "gINORDERINGCUS")
    protected FUNDSTRANSFERType.GINORDERINGCUS ginorderingcus;
    @XmlElement(name = "gORDERINGBANK")
    protected FUNDSTRANSFERType.GORDERINGBANK gorderingbank;
    @XmlElement(name = "gINORDERINGBK")
    protected FUNDSTRANSFERType.GINORDERINGBK ginorderingbk;
    @XmlElement(name = "gACCTWITHBANK")
    protected FUNDSTRANSFERType.GACCTWITHBANK gacctwithbank;
    @XmlElement(name = "gACCTWITHBK")
    protected FUNDSTRANSFERType.GACCTWITHBK gacctwithbk;
    @XmlElement(name = "BENACCTNO")
    protected String benacctno;
    @XmlElement(name = "INBENACCTNO")
    protected String inbenacctno;
    @XmlElement(name = "gBENCUSTOMER")
    protected FUNDSTRANSFERType.GBENCUSTOMER gbencustomer;
    @XmlElement(name = "gINBENCUSTOMER")
    protected FUNDSTRANSFERType.GINBENCUSTOMER ginbencustomer;
    @XmlElement(name = "gBENBANK")
    protected FUNDSTRANSFERType.GBENBANK gbenbank;
    @XmlElement(name = "gINBENBANK")
    protected FUNDSTRANSFERType.GINBENBANK ginbenbank;
    @XmlElement(name = "CHEQUENUMBER")
    protected String chequenumber;
    @XmlElement(name = "gPAYMENTDETAILS")
    protected FUNDSTRANSFERType.GPAYMENTDETAILS gpaymentdetails;
    @XmlElement(name = "gINPAYDETAILS")
    protected FUNDSTRANSFERType.GINPAYDETAILS ginpaydetails;
    @XmlElement(name = "BCBANKSORTCODE")
    protected String bcbanksortcode;
    @XmlElement(name = "RECEIVERBANK")
    protected String receiverbank;
    @XmlElement(name = "gRECCORRBANK")
    protected FUNDSTRANSFERType.GRECCORRBANK greccorrbank;
    @XmlElement(name = "gINTERMEDBANK")
    protected FUNDSTRANSFERType.GINTERMEDBANK gintermedbank;
    @XmlElement(name = "gININTMEDBANK")
    protected FUNDSTRANSFERType.GININTMEDBANK ginintmedbank;
    @XmlElement(name = "MAILING")
    protected String mailing;
    @XmlElement(name = "PAYMETHOD")
    protected String paymethod;
    @XmlElement(name = "BENOURCHARGES")
    protected String benourcharges;
    @XmlElement(name = "INBENOURCHARGES")
    protected String inbenourcharges;
    @XmlElement(name = "CHARGESACCTNO")
    protected String chargesacctno;
    @XmlElement(name = "CHARGECOMDISPLAY")
    protected String chargecomdisplay;
    @XmlElement(name = "COMMISSIONCODE")
    protected String commissioncode;
    @XmlElement(name = "gCOMMISSIONTYPE")
    protected FUNDSTRANSFERType.GCOMMISSIONTYPE gcommissiontype;
    @XmlElement(name = "CHARGECODE")
    protected String chargecode;
    @XmlElement(name = "gCHARGETYPE")
    protected FUNDSTRANSFERType.GCHARGETYPE gchargetype;
    @XmlElement(name = "CUSTOMERSPREAD")
    protected String customerspread;
    @XmlElement(name = "BASECURRENCY")
    protected String basecurrency;
    @XmlElement(name = "PROFITCENTRECUST")
    protected String profitcentrecust;
    @XmlElement(name = "PROFITCENTREDEPT")
    protected String profitcentredept;
    @XmlElement(name = "RETURNTODEPT")
    protected String returntodept;
    @XmlElement(name = "PRIORITYTXN")
    protected String prioritytxn;
    @XmlElement(name = "gBKTOBKINFO")
    protected FUNDSTRANSFERType.GBKTOBKINFO gbktobkinfo;
    @XmlElement(name = "gINBKTOBK")
    protected FUNDSTRANSFERType.GINBKTOBK ginbktobk;
    @XmlElement(name = "EXPOSUREDATE")
    protected String exposuredate;
    @XmlElement(name = "FEDFUNDS")
    protected String fedfunds;
    @XmlElement(name = "POSITIONTYPE")
    protected String positiontype;
    @XmlElement(name = "NOOFBATCHITEMS")
    protected String noofbatchitems;
    @XmlElement(name = "gFREETEXTMSGTO")
    protected FUNDSTRANSFERType.GFREETEXTMSGTO gfreetextmsgto;
    @XmlElement(name = "gMESSAGE")
    protected FUNDSTRANSFERType.GMESSAGE gmessage;
    @XmlElement(name = "gTAXTYPE")
    protected FUNDSTRANSFERType.GTAXTYPE gtaxtype;
    @XmlElement(name = "AMOUNTDEBITED")
    protected String amountdebited;
    @XmlElement(name = "AMOUNTCREDITED")
    protected String amountcredited;
    @XmlElement(name = "TOTALCHARGEAMT")
    protected String totalchargeamt;
    @XmlElement(name = "TOTALTAXAMOUNT")
    protected String totaltaxamount;
    @XmlElement(name = "CUSTOMERRATE")
    protected String customerrate;
    @XmlElement(name = "gINRECCORRBK")
    protected FUNDSTRANSFERType.GINRECCORRBK ginreccorrbk;
    @XmlElement(name = "INWARDPAYTYPE")
    protected String inwardpaytype;
    @XmlElement(name = "gINSENDCORRBK")
    protected FUNDSTRANSFERType.GINSENDCORRBK ginsendcorrbk;
    @XmlElement(name = "TELEXFROMCUST")
    protected String telexfromcust;
    @XmlElement(name = "DELIVERYINREF")
    protected String deliveryinref;
    @XmlElement(name = "gDELIVERYOUTREF")
    protected FUNDSTRANSFERType.GDELIVERYOUTREF gdeliveryoutref;
    @XmlElement(name = "CREDITCOMPCODE")
    protected String creditcompcode;
    @XmlElement(name = "DEBITCOMPCODE")
    protected String debitcompcode;
    @XmlElement(name = "STATUS")
    protected String status;
    @XmlElement(name = "DELIVERYMKR")
    protected String deliverymkr;
    @XmlElement(name = "ORDCUSTCODE")
    protected String ordcustcode;
    @XmlElement(name = "ACCTWITHBKACNO")
    protected String acctwithbkacno;
    @XmlElement(name = "LOCAMTDEBITED")
    protected String locamtdebited;
    @XmlElement(name = "LOCAMTCREDITED")
    protected String locamtcredited;
    @XmlElement(name = "LOCTOTTAXAMT")
    protected String loctottaxamt;
    @XmlElement(name = "LOCALCHARGEAMT")
    protected String localchargeamt;
    @XmlElement(name = "LOCPOSCHGSAMT")
    protected String locposchgsamt;
    @XmlElement(name = "MKTGEXCHPROFIT")
    protected String mktgexchprofit;
    @XmlElement(name = "RATEINPUTMKR")
    protected String rateinputmkr;
    @XmlElement(name = "CUSTGROUPLEVEL")
    protected String custgrouplevel;
    @XmlElement(name = "DEBITCUSTOMER")
    protected String debitcustomer;
    @XmlElement(name = "CREDITCUSTOMER")
    protected String creditcustomer;
    @XmlElement(name = "SENDPAYMENTYN")
    protected String sendpaymentyn;
    @XmlElement(name = "DRADVICEREQDYN")
    protected String dradvicereqdyn;
    @XmlElement(name = "CRADVICEREQDYN")
    protected String cradvicereqdyn;
    @XmlElement(name = "DEALMARKET")
    protected String dealmarket;
    @XmlElement(name = "CHARGEDCUSTOMER")
    protected String chargedcustomer;
    @XmlElement(name = "gINREASONOVE")
    protected FUNDSTRANSFERType.GINREASONOVE ginreasonove;
    @XmlElement(name = "DEALERDESK")
    protected String dealerdesk;
    @XmlElement(name = "RECALCFWDRATE")
    protected String recalcfwdrate;
    @XmlElement(name = "RETURNCHEQUE")
    protected String returncheque;
    @XmlElement(name = "DRAWNACCOUNT")
    protected String drawnaccount;
    @XmlElement(name = "ACCOUNTINGDATE")
    protected String accountingdate;
    @XmlElement(name = "gINSTRCTNCODE")
    protected FUNDSTRANSFERType.GINSTRCTNCODE ginstrctncode;
    @XmlElement(name = "COLLREMBK")
    protected String collrembk;
    @XmlElement(name = "EXPECTEDRECSID")
    protected String expectedrecsid;
    @XmlElement(name = "TOTRECCOMM")
    protected String totreccomm;
    @XmlElement(name = "TOTRECCOMMLCL")
    protected String totreccommlcl;
    @XmlElement(name = "TOTRECCHG")
    protected String totrecchg;
    @XmlElement(name = "TOTRECCHGLCL")
    protected String totrecchglcl;
    @XmlElement(name = "CHEQTYPE")
    protected String cheqtype;
    @XmlElement(name = "gRELATEDMSG")
    protected FUNDSTRANSFERType.GRELATEDMSG grelatedmsg;
    @XmlElement(name = "gINTIMEIND")
    protected FUNDSTRANSFERType.GINTIMEIND gintimeind;
    @XmlElement(name = "gSENDTOPARTY")
    protected FUNDSTRANSFERType.GSENDTOPARTY gsendtoparty;
    @XmlElement(name = "REVERSALMKR")
    protected String reversalmkr;
    @XmlElement(name = "RELATEDREF")
    protected String relatedref;
    @XmlElement(name = "gININSTRCODE")
    protected FUNDSTRANSFERType.GININSTRCODE gininstrcode;
    @XmlElement(name = "gINPROCESSERR")
    protected FUNDSTRANSFERType.GINPROCESSERR ginprocesserr;
    @XmlElement(name = "gINSWIFTMSG")
    protected FUNDSTRANSFERType.GINSWIFTMSG ginswiftmsg;
    @XmlElement(name = "ACCTWITHBANKACC")
    protected String acctwithbankacc;
    @XmlElement(name = "INACCTBANKACC")
    protected String inacctbankacc;
    @XmlElement(name = "RECCORRBANKACC")
    protected String reccorrbankacc;
    @XmlElement(name = "INRECCORRACC")
    protected String inreccorracc;
    @XmlElement(name = "INTERMEDBANKACC")
    protected String intermedbankacc;
    @XmlElement(name = "ININTERMEDACC")
    protected String inintermedacc;
    @XmlElement(name = "INSTRUCTEDAMT")
    protected String instructedamt;
    @XmlElement(name = "gININTERMEDBK")
    protected FUNDSTRANSFERType.GININTERMEDBK ginintermedbk;
    @XmlElement(name = "INEXCHRATE")
    protected String inexchrate;
    @XmlElement(name = "RATEFIXING")
    protected String ratefixing;
    @XmlElement(name = "COVERMETHOD")
    protected String covermethod;
    @XmlElement(name = "gIN3RDREIMBBK")
    protected FUNDSTRANSFERType.GIN3RDREIMBBK gin3RDREIMBBK;
    @XmlElement(name = "IN3RDREIMBACC")
    protected String in3RDREIMBACC;
    @XmlElement(name = "MT103TYPE")
    protected String mt103TYPE;
    @XmlElement(name = "EXTENDFORMAT")
    protected String extendformat;
    @XmlElement(name = "gEXTENDINFO")
    protected FUNDSTRANSFERType.GEXTENDINFO gextendinfo;
    @XmlElement(name = "RATEFIXINGIND")
    protected String ratefixingind;
    @XmlElement(name = "INWSENDBIC")
    protected String inwsendbic;
    @XmlElement(name = "gINSENDCHG")
    protected FUNDSTRANSFERType.GINSENDCHG ginsendchg;
    @XmlElement(name = "INRECCHG")
    protected String inrecchg;
    @XmlElement(name = "ACCHGREQID")
    protected String acchgreqid;
    @XmlElement(name = "TOTRECCHGCRCCY")
    protected String totrecchgcrccy;
    @XmlElement(name = "TOTSNDCHGCRCCY")
    protected String totsndchgcrccy;
    @XmlElement(name = "CHGADVICEMSG")
    protected String chgadvicemsg;
    @XmlElement(name = "EXPECTEDCOVERID")
    protected String expectedcoverid;
    @XmlElement(name = "NETTINGSTATUS")
    protected String nettingstatus;
    @XmlElement(name = "AUTHDATE")
    protected String authdate;
    @XmlElement(name = "BKOPERATIONCODE")
    protected String bkoperationcode;
    @XmlElement(name = "AMINFLOWRATE")
    protected String aminflowrate;
    @XmlElement(name = "PARENTTXNID")
    protected String parenttxnid;
    @XmlElement(name = "ROUNDTYPE")
    protected String roundtype;
    @XmlElement(name = "BENEFICIARYID")
    protected String beneficiaryid;
    @XmlElement(name = "gMSGTYPE")
    protected FUNDSTRANSFERType.GMSGTYPE gmsgtype;
    @XmlElement(name = "gSIGNATORY")
    protected FUNDSTRANSFERType.GSIGNATORY gsignatory;
    @XmlElement(name = "CARDNUMBER")
    protected String cardnumber;
    @XmlElement(name = "gCARDTXNDETAIL")
    protected FUNDSTRANSFERType.GCARDTXNDETAIL gcardtxndetail;
    @XmlElement(name = "gINCORDBK")
    protected FUNDSTRANSFERType.GINCORDBK gincordbk;
    @XmlElement(name = "gINCINTMEDBK")
    protected FUNDSTRANSFERType.GINCINTMEDBK gincintmedbk;
    @XmlElement(name = "gINCACCWITBK")
    protected FUNDSTRANSFERType.GINCACCWITBK gincaccwitbk;
    @XmlElement(name = "gINCBKTBKIN")
    protected FUNDSTRANSFERType.GINCBKTBKIN gincbktbkin;
    @XmlElement(name = "TFSREFERENCE")
    protected String tfsreference;
    @XmlElement(name = "CHEQUEDRAWN")
    protected String chequedrawn;
    @XmlElement(name = "ISSUECHEQUETYPE")
    protected String issuechequetype;
    @XmlElement(name = "STOCKNUMBER")
    protected String stocknumber;
    @XmlElement(name = "PAYEENAME")
    protected String payeename;
    @XmlElement(name = "STOCKREGISTER")
    protected String stockregister;
    @XmlElement(name = "SERIESID")
    protected String seriesid;
    @XmlElement(name = "RESERVED20")
    protected String reserved20;
    @XmlElement(name = "RESERVED19")
    protected String reserved19;
    @XmlElement(name = "RESERVED18")
    protected String reserved18;
    @XmlElement(name = "RESERVED17")
    protected String reserved17;
    @XmlElement(name = "RESERVED16")
    protected String reserved16;
    @XmlElement(name = "RESERVED15")
    protected String reserved15;
    @XmlElement(name = "RESERVED14")
    protected String reserved14;
    @XmlElement(name = "RESERVED13")
    protected String reserved13;
    @XmlElement(name = "RESERVED12")
    protected String reserved12;
    @XmlElement(name = "RESERVED11")
    protected String reserved11;
    @XmlElement(name = "RESERVED10")
    protected String reserved10;
    @XmlElement(name = "RESERVED9")
    protected String reserved9;
    @XmlElement(name = "RESERVED8")
    protected String reserved8;
    @XmlElement(name = "RESERVED7")
    protected String reserved7;
    @XmlElement(name = "RESERVED6")
    protected String reserved6;
    @XmlElement(name = "RESERVED5")
    protected String reserved5;
    @XmlElement(name = "RESERVED4")
    protected String reserved4;
    @XmlElement(name = "RESERVED3")
    protected String reserved3;
    @XmlElement(name = "RESERVED2")
    protected String reserved2;
    @XmlElement(name = "RESERVED1")
    protected String reserved1;
    @XmlElement(name = "gSTMTNOS")
    protected FUNDSTRANSFERType.GSTMTNOS gstmtnos;
    @XmlElement(name = "gOVERRIDE")
    protected FUNDSTRANSFERType.GOVERRIDE goverride;
    @XmlElement(name = "RECORDSTATUS")
    protected String recordstatus;
    @XmlElement(name = "CURRNO")
    protected String currno;
    @XmlElement(name = "gINPUTTER")
    protected FUNDSTRANSFERType.GINPUTTER ginputter;
    @XmlElement(name = "gDATETIME")
    protected FUNDSTRANSFERType.GDATETIME gdatetime;
    @XmlElement(name = "AUTHORISER")
    protected String authoriser;
    @XmlElement(name = "COCODE")
    protected String cocode;
    @XmlElement(name = "DEPTCODE")
    protected String deptcode;
    @XmlElement(name = "AUDITORCODE")
    protected String auditorcode;
    @XmlElement(name = "AUDITDATETIME")
    protected String auditdatetime;
    @XmlElement(name = "ISCONID")
    protected String isconid;
    @XmlElement(name = "LASTVERSION")
    protected String lastversion;
    @XmlElement(name = "ISCUSTID")
    protected String iscustid;
    @XmlElement(name = "ISSUPPLIER")
    protected String issupplier;
    @XmlElement(name = "LOANTYPE")
    protected String loantype;
    @XmlElement(name = "CMATXNREF")
    protected String cmatxnref;
    @XmlElement(name = "ICRCONID")
    protected String icrconid;
    @XmlElement(name = "BENCOUNTRY")
    protected String bencountry;
    @XmlElement(name = "CHQTYPE")
    protected String chqtype;
    @XmlElement(name = "TXNTYPE")
    protected String txntype;
    @XmlElement(name = "CUSTPAYNOT")
    protected String custpaynot;
    @XmlElement(name = "ORDCUSTACC")
    protected String ordcustacc;
    @XmlElement(name = "FTPURPOSE")
    protected String ftpurpose;
    @XmlElement(name = "BILLERID")
    protected String billerid;
    @XmlElement(name = "BILLNO")
    protected String billno;
    @XmlElement(name = "CARDNO")
    protected String cardno;
    @XmlElement(name = "QPEMPLOYER")
    protected String qpemployer;
    @XmlElement(name = "QPKEY")
    protected String qpkey;
    @XmlElement(name = "SARIEBENBANK")
    protected String sariebenbank;
    @XmlElement(name = "CHQPURPOSE")
    protected String chqpurpose;
    @XmlElement(name = "CHEQUESENDER")
    protected String chequesender;
    @XmlElement(name = "gCHEQUE.BENEFICI")
    protected FUNDSTRANSFERType.GCHEQUEBENEFICI gchequebenefici;
    @XmlElement(name = "BAJCMDTYDTL")
    protected String bajcmdtydtl;
    @XmlElement(name = "BAJSELLQTY")
    protected String bajsellqty;
    @XmlElement(name = "BAJMKTPRICE")
    protected String bajmktprice;
    @XmlElement(name = "BAJLDREF")
    protected String bajldref;
    @XmlElement(name = "BAJCMDTYCODE")
    protected String bajcmdtycode;
    @XmlElement(name = "BATRFCHRGS")
    protected String batrfchrgs;
    @XmlElement(name = "BATRFAMNT")
    protected String batrfamnt;
    @XmlElement(name = "gBAJEL.NOTES")
    protected FUNDSTRANSFERType.GBAJELNOTES gbajelnotes;
    @XmlElement(name = "BROKERLIMIT")
    protected String brokerlimit;
    @XmlElement(name = "SIGLE")
    protected String sigle;
    @XmlElement(name = "LOFACDETAIL")
    protected String lofacdetail;
    @XmlElement(name = "INMAMSGTYPE")
    protected String inmamsgtype;
    @XmlElement(name = "MSGPRIORITY")
    protected String msgpriority;
    @XmlElement(name = "CUSTTYPE")
    protected String custtype;
    @XmlElement(name = "CUSTNATNLTY")
    protected String custnatnlty;
    @XmlElement(name = "PAYMTPURPOSE")
    protected String paymtpurpose;
    @XmlElement(name = "PAYROLL")
    protected String payroll;
    @XmlElement(name = "ISRPRID")
    protected String isrprid;
    @XmlElement(name = "CARDACCTNO")
    protected String cardacctno;
    @XmlElement(name = "ATMNO")
    protected String atmno;
    @XmlElement(name = "gORD.CUST.AR")
    protected FUNDSTRANSFERType.GORDCUSTAR gordcustar;
    @XmlElement(name = "gBEN.CUST.AR")
    protected FUNDSTRANSFERType.GBENCUSTAR gbencustar;
    @XmlElement(name = "gPAY.DETS.AR")
    protected FUNDSTRANSFERType.GPAYDETSAR gpaydetsar;
    @XmlElement(name = "gSND.TO.PAR.AR")
    protected FUNDSTRANSFERType.GSNDTOPARAR gsndtoparar;
    @XmlElement(name = "SICODE")
    protected String sicode;
    @XmlElement(name = "gSI.MESSAGE")
    protected FUNDSTRANSFERType.GSIMESSAGE gsimessage;
    @XmlElement(name = "SITFIELD1")
    protected String sitfield1;
    @XmlElement(name = "SITFIELD2")
    protected String sitfield2;
    @XmlElement(name = "SITFIELD3")
    protected String sitfield3;
    @XmlElement(name = "SITFIELD4")
    protected String sitfield4;
    @XmlElement(name = "SITFIELD5")
    protected String sitfield5;
    @XmlElement(name = "SITFIELD6")
    protected String sitfield6;
    @XmlElement(name = "SITFIELD7")
    protected String sitfield7;
    @XmlElement(name = "SITFIELD8")
    protected String sitfield8;
    @XmlAttribute(name = "id")
    protected String id;

    /**
     * Gets the value of the transactiontype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTRANSACTIONTYPE() {
        return transactiontype;
    }

    /**
     * Sets the value of the transactiontype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTRANSACTIONTYPE(String value) {
        this.transactiontype = value;
    }

    /**
     * Gets the value of the debitacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITACCTNO() {
        return debitacctno;
    }

    /**
     * Sets the value of the debitacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITACCTNO(String value) {
        this.debitacctno = value;
    }

    /**
     * Gets the value of the indebitacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINDEBITACCTNO() {
        return indebitacctno;
    }

    /**
     * Sets the value of the indebitacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINDEBITACCTNO(String value) {
        this.indebitacctno = value;
    }

    /**
     * Gets the value of the currencymktdr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCURRENCYMKTDR() {
        return currencymktdr;
    }

    /**
     * Sets the value of the currencymktdr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCURRENCYMKTDR(String value) {
        this.currencymktdr = value;
    }

    /**
     * Gets the value of the debitcurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITCURRENCY() {
        return debitcurrency;
    }

    /**
     * Sets the value of the debitcurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITCURRENCY(String value) {
        this.debitcurrency = value;
    }

    /**
     * Gets the value of the debitamount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITAMOUNT() {
        return debitamount;
    }

    /**
     * Sets the value of the debitamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITAMOUNT(String value) {
        this.debitamount = value;
    }

    /**
     * Gets the value of the debitvaluedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITVALUEDATE() {
        return debitvaluedate;
    }

    /**
     * Sets the value of the debitvaluedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITVALUEDATE(String value) {
        this.debitvaluedate = value;
    }

    /**
     * Gets the value of the indebitvdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINDEBITVDATE() {
        return indebitvdate;
    }

    /**
     * Sets the value of the indebitvdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINDEBITVDATE(String value) {
        this.indebitvdate = value;
    }

    /**
     * Gets the value of the debittheirref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITTHEIRREF() {
        return debittheirref;
    }

    /**
     * Sets the value of the debittheirref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITTHEIRREF(String value) {
        this.debittheirref = value;
    }

    /**
     * Gets the value of the credittheirref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITTHEIRREF() {
        return credittheirref;
    }

    /**
     * Sets the value of the credittheirref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITTHEIRREF(String value) {
        this.credittheirref = value;
    }

    /**
     * Gets the value of the creditacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITACCTNO() {
        return creditacctno;
    }

    /**
     * Sets the value of the creditacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITACCTNO(String value) {
        this.creditacctno = value;
    }

    /**
     * Gets the value of the currencymktcr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCURRENCYMKTCR() {
        return currencymktcr;
    }

    /**
     * Sets the value of the currencymktcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCURRENCYMKTCR(String value) {
        this.currencymktcr = value;
    }

    /**
     * Gets the value of the creditcurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITCURRENCY() {
        return creditcurrency;
    }

    /**
     * Sets the value of the creditcurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITCURRENCY(String value) {
        this.creditcurrency = value;
    }

    /**
     * Gets the value of the creditamount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITAMOUNT() {
        return creditamount;
    }

    /**
     * Sets the value of the creditamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITAMOUNT(String value) {
        this.creditamount = value;
    }

    /**
     * Gets the value of the creditvaluedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITVALUEDATE() {
        return creditvaluedate;
    }

    /**
     * Sets the value of the creditvaluedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITVALUEDATE(String value) {
        this.creditvaluedate = value;
    }

    /**
     * Gets the value of the treasuryrate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTREASURYRATE() {
        return treasuryrate;
    }

    /**
     * Sets the value of the treasuryrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTREASURYRATE(String value) {
        this.treasuryrate = value;
    }

    /**
     * Gets the value of the negdealerrefno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNEGDEALERREFNO() {
        return negdealerrefno;
    }

    /**
     * Sets the value of the negdealerrefno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNEGDEALERREFNO(String value) {
        this.negdealerrefno = value;
    }

    /**
     * Gets the value of the processingdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROCESSINGDATE() {
        return processingdate;
    }

    /**
     * Sets the value of the processingdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROCESSINGDATE(String value) {
        this.processingdate = value;
    }

    /**
     * Gets the value of the gorderingcust property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GORDERINGCUST }
     *     
     */
    public FUNDSTRANSFERType.GORDERINGCUST getGORDERINGCUST() {
        return gorderingcust;
    }

    /**
     * Sets the value of the gorderingcust property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GORDERINGCUST }
     *     
     */
    public void setGORDERINGCUST(FUNDSTRANSFERType.GORDERINGCUST value) {
        this.gorderingcust = value;
    }

    /**
     * Gets the value of the ginorderingcus property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINORDERINGCUS }
     *     
     */
    public FUNDSTRANSFERType.GINORDERINGCUS getGINORDERINGCUS() {
        return ginorderingcus;
    }

    /**
     * Sets the value of the ginorderingcus property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINORDERINGCUS }
     *     
     */
    public void setGINORDERINGCUS(FUNDSTRANSFERType.GINORDERINGCUS value) {
        this.ginorderingcus = value;
    }

    /**
     * Gets the value of the gorderingbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GORDERINGBANK }
     *     
     */
    public FUNDSTRANSFERType.GORDERINGBANK getGORDERINGBANK() {
        return gorderingbank;
    }

    /**
     * Sets the value of the gorderingbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GORDERINGBANK }
     *     
     */
    public void setGORDERINGBANK(FUNDSTRANSFERType.GORDERINGBANK value) {
        this.gorderingbank = value;
    }

    /**
     * Gets the value of the ginorderingbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINORDERINGBK }
     *     
     */
    public FUNDSTRANSFERType.GINORDERINGBK getGINORDERINGBK() {
        return ginorderingbk;
    }

    /**
     * Sets the value of the ginorderingbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINORDERINGBK }
     *     
     */
    public void setGINORDERINGBK(FUNDSTRANSFERType.GINORDERINGBK value) {
        this.ginorderingbk = value;
    }

    /**
     * Gets the value of the gacctwithbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GACCTWITHBANK }
     *     
     */
    public FUNDSTRANSFERType.GACCTWITHBANK getGACCTWITHBANK() {
        return gacctwithbank;
    }

    /**
     * Sets the value of the gacctwithbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GACCTWITHBANK }
     *     
     */
    public void setGACCTWITHBANK(FUNDSTRANSFERType.GACCTWITHBANK value) {
        this.gacctwithbank = value;
    }

    /**
     * Gets the value of the gacctwithbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GACCTWITHBK }
     *     
     */
    public FUNDSTRANSFERType.GACCTWITHBK getGACCTWITHBK() {
        return gacctwithbk;
    }

    /**
     * Sets the value of the gacctwithbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GACCTWITHBK }
     *     
     */
    public void setGACCTWITHBK(FUNDSTRANSFERType.GACCTWITHBK value) {
        this.gacctwithbk = value;
    }

    /**
     * Gets the value of the benacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBENACCTNO() {
        return benacctno;
    }

    /**
     * Sets the value of the benacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBENACCTNO(String value) {
        this.benacctno = value;
    }

    /**
     * Gets the value of the inbenacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINBENACCTNO() {
        return inbenacctno;
    }

    /**
     * Sets the value of the inbenacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINBENACCTNO(String value) {
        this.inbenacctno = value;
    }

    /**
     * Gets the value of the gbencustomer property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GBENCUSTOMER }
     *     
     */
    public FUNDSTRANSFERType.GBENCUSTOMER getGBENCUSTOMER() {
        return gbencustomer;
    }

    /**
     * Sets the value of the gbencustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GBENCUSTOMER }
     *     
     */
    public void setGBENCUSTOMER(FUNDSTRANSFERType.GBENCUSTOMER value) {
        this.gbencustomer = value;
    }

    /**
     * Gets the value of the ginbencustomer property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINBENCUSTOMER }
     *     
     */
    public FUNDSTRANSFERType.GINBENCUSTOMER getGINBENCUSTOMER() {
        return ginbencustomer;
    }

    /**
     * Sets the value of the ginbencustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINBENCUSTOMER }
     *     
     */
    public void setGINBENCUSTOMER(FUNDSTRANSFERType.GINBENCUSTOMER value) {
        this.ginbencustomer = value;
    }

    /**
     * Gets the value of the gbenbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GBENBANK }
     *     
     */
    public FUNDSTRANSFERType.GBENBANK getGBENBANK() {
        return gbenbank;
    }

    /**
     * Sets the value of the gbenbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GBENBANK }
     *     
     */
    public void setGBENBANK(FUNDSTRANSFERType.GBENBANK value) {
        this.gbenbank = value;
    }

    /**
     * Gets the value of the ginbenbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINBENBANK }
     *     
     */
    public FUNDSTRANSFERType.GINBENBANK getGINBENBANK() {
        return ginbenbank;
    }

    /**
     * Sets the value of the ginbenbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINBENBANK }
     *     
     */
    public void setGINBENBANK(FUNDSTRANSFERType.GINBENBANK value) {
        this.ginbenbank = value;
    }

    /**
     * Gets the value of the chequenumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHEQUENUMBER() {
        return chequenumber;
    }

    /**
     * Sets the value of the chequenumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHEQUENUMBER(String value) {
        this.chequenumber = value;
    }

    /**
     * Gets the value of the gpaymentdetails property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GPAYMENTDETAILS }
     *     
     */
    public FUNDSTRANSFERType.GPAYMENTDETAILS getGPAYMENTDETAILS() {
        return gpaymentdetails;
    }

    /**
     * Sets the value of the gpaymentdetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GPAYMENTDETAILS }
     *     
     */
    public void setGPAYMENTDETAILS(FUNDSTRANSFERType.GPAYMENTDETAILS value) {
        this.gpaymentdetails = value;
    }

    /**
     * Gets the value of the ginpaydetails property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINPAYDETAILS }
     *     
     */
    public FUNDSTRANSFERType.GINPAYDETAILS getGINPAYDETAILS() {
        return ginpaydetails;
    }

    /**
     * Sets the value of the ginpaydetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINPAYDETAILS }
     *     
     */
    public void setGINPAYDETAILS(FUNDSTRANSFERType.GINPAYDETAILS value) {
        this.ginpaydetails = value;
    }

    /**
     * Gets the value of the bcbanksortcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBCBANKSORTCODE() {
        return bcbanksortcode;
    }

    /**
     * Sets the value of the bcbanksortcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBCBANKSORTCODE(String value) {
        this.bcbanksortcode = value;
    }

    /**
     * Gets the value of the receiverbank property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECEIVERBANK() {
        return receiverbank;
    }

    /**
     * Sets the value of the receiverbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECEIVERBANK(String value) {
        this.receiverbank = value;
    }

    /**
     * Gets the value of the greccorrbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GRECCORRBANK }
     *     
     */
    public FUNDSTRANSFERType.GRECCORRBANK getGRECCORRBANK() {
        return greccorrbank;
    }

    /**
     * Sets the value of the greccorrbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GRECCORRBANK }
     *     
     */
    public void setGRECCORRBANK(FUNDSTRANSFERType.GRECCORRBANK value) {
        this.greccorrbank = value;
    }

    /**
     * Gets the value of the gintermedbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINTERMEDBANK }
     *     
     */
    public FUNDSTRANSFERType.GINTERMEDBANK getGINTERMEDBANK() {
        return gintermedbank;
    }

    /**
     * Sets the value of the gintermedbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINTERMEDBANK }
     *     
     */
    public void setGINTERMEDBANK(FUNDSTRANSFERType.GINTERMEDBANK value) {
        this.gintermedbank = value;
    }

    /**
     * Gets the value of the ginintmedbank property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GININTMEDBANK }
     *     
     */
    public FUNDSTRANSFERType.GININTMEDBANK getGININTMEDBANK() {
        return ginintmedbank;
    }

    /**
     * Sets the value of the ginintmedbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GININTMEDBANK }
     *     
     */
    public void setGININTMEDBANK(FUNDSTRANSFERType.GININTMEDBANK value) {
        this.ginintmedbank = value;
    }

    /**
     * Gets the value of the mailing property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMAILING() {
        return mailing;
    }

    /**
     * Sets the value of the mailing property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMAILING(String value) {
        this.mailing = value;
    }

    /**
     * Gets the value of the paymethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPAYMETHOD() {
        return paymethod;
    }

    /**
     * Sets the value of the paymethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPAYMETHOD(String value) {
        this.paymethod = value;
    }

    /**
     * Gets the value of the benourcharges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBENOURCHARGES() {
        return benourcharges;
    }

    /**
     * Sets the value of the benourcharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBENOURCHARGES(String value) {
        this.benourcharges = value;
    }

    /**
     * Gets the value of the inbenourcharges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINBENOURCHARGES() {
        return inbenourcharges;
    }

    /**
     * Sets the value of the inbenourcharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINBENOURCHARGES(String value) {
        this.inbenourcharges = value;
    }

    /**
     * Gets the value of the chargesacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHARGESACCTNO() {
        return chargesacctno;
    }

    /**
     * Sets the value of the chargesacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHARGESACCTNO(String value) {
        this.chargesacctno = value;
    }

    /**
     * Gets the value of the chargecomdisplay property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHARGECOMDISPLAY() {
        return chargecomdisplay;
    }

    /**
     * Sets the value of the chargecomdisplay property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHARGECOMDISPLAY(String value) {
        this.chargecomdisplay = value;
    }

    /**
     * Gets the value of the commissioncode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMISSIONCODE() {
        return commissioncode;
    }

    /**
     * Sets the value of the commissioncode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMISSIONCODE(String value) {
        this.commissioncode = value;
    }

    /**
     * Gets the value of the gcommissiontype property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GCOMMISSIONTYPE }
     *     
     */
    public FUNDSTRANSFERType.GCOMMISSIONTYPE getGCOMMISSIONTYPE() {
        return gcommissiontype;
    }

    /**
     * Sets the value of the gcommissiontype property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GCOMMISSIONTYPE }
     *     
     */
    public void setGCOMMISSIONTYPE(FUNDSTRANSFERType.GCOMMISSIONTYPE value) {
        this.gcommissiontype = value;
    }

    /**
     * Gets the value of the chargecode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHARGECODE() {
        return chargecode;
    }

    /**
     * Sets the value of the chargecode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHARGECODE(String value) {
        this.chargecode = value;
    }

    /**
     * Gets the value of the gchargetype property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GCHARGETYPE }
     *     
     */
    public FUNDSTRANSFERType.GCHARGETYPE getGCHARGETYPE() {
        return gchargetype;
    }

    /**
     * Sets the value of the gchargetype property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GCHARGETYPE }
     *     
     */
    public void setGCHARGETYPE(FUNDSTRANSFERType.GCHARGETYPE value) {
        this.gchargetype = value;
    }

    /**
     * Gets the value of the customerspread property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTOMERSPREAD() {
        return customerspread;
    }

    /**
     * Sets the value of the customerspread property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTOMERSPREAD(String value) {
        this.customerspread = value;
    }

    /**
     * Gets the value of the basecurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBASECURRENCY() {
        return basecurrency;
    }

    /**
     * Sets the value of the basecurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBASECURRENCY(String value) {
        this.basecurrency = value;
    }

    /**
     * Gets the value of the profitcentrecust property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROFITCENTRECUST() {
        return profitcentrecust;
    }

    /**
     * Sets the value of the profitcentrecust property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROFITCENTRECUST(String value) {
        this.profitcentrecust = value;
    }

    /**
     * Gets the value of the profitcentredept property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROFITCENTREDEPT() {
        return profitcentredept;
    }

    /**
     * Sets the value of the profitcentredept property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROFITCENTREDEPT(String value) {
        this.profitcentredept = value;
    }

    /**
     * Gets the value of the returntodept property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRETURNTODEPT() {
        return returntodept;
    }

    /**
     * Sets the value of the returntodept property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRETURNTODEPT(String value) {
        this.returntodept = value;
    }

    /**
     * Gets the value of the prioritytxn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRIORITYTXN() {
        return prioritytxn;
    }

    /**
     * Sets the value of the prioritytxn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRIORITYTXN(String value) {
        this.prioritytxn = value;
    }

    /**
     * Gets the value of the gbktobkinfo property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GBKTOBKINFO }
     *     
     */
    public FUNDSTRANSFERType.GBKTOBKINFO getGBKTOBKINFO() {
        return gbktobkinfo;
    }

    /**
     * Sets the value of the gbktobkinfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GBKTOBKINFO }
     *     
     */
    public void setGBKTOBKINFO(FUNDSTRANSFERType.GBKTOBKINFO value) {
        this.gbktobkinfo = value;
    }

    /**
     * Gets the value of the ginbktobk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINBKTOBK }
     *     
     */
    public FUNDSTRANSFERType.GINBKTOBK getGINBKTOBK() {
        return ginbktobk;
    }

    /**
     * Sets the value of the ginbktobk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINBKTOBK }
     *     
     */
    public void setGINBKTOBK(FUNDSTRANSFERType.GINBKTOBK value) {
        this.ginbktobk = value;
    }

    /**
     * Gets the value of the exposuredate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEXPOSUREDATE() {
        return exposuredate;
    }

    /**
     * Sets the value of the exposuredate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEXPOSUREDATE(String value) {
        this.exposuredate = value;
    }

    /**
     * Gets the value of the fedfunds property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFEDFUNDS() {
        return fedfunds;
    }

    /**
     * Sets the value of the fedfunds property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFEDFUNDS(String value) {
        this.fedfunds = value;
    }

    /**
     * Gets the value of the positiontype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOSITIONTYPE() {
        return positiontype;
    }

    /**
     * Sets the value of the positiontype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOSITIONTYPE(String value) {
        this.positiontype = value;
    }

    /**
     * Gets the value of the noofbatchitems property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNOOFBATCHITEMS() {
        return noofbatchitems;
    }

    /**
     * Sets the value of the noofbatchitems property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNOOFBATCHITEMS(String value) {
        this.noofbatchitems = value;
    }

    /**
     * Gets the value of the gfreetextmsgto property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GFREETEXTMSGTO }
     *     
     */
    public FUNDSTRANSFERType.GFREETEXTMSGTO getGFREETEXTMSGTO() {
        return gfreetextmsgto;
    }

    /**
     * Sets the value of the gfreetextmsgto property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GFREETEXTMSGTO }
     *     
     */
    public void setGFREETEXTMSGTO(FUNDSTRANSFERType.GFREETEXTMSGTO value) {
        this.gfreetextmsgto = value;
    }

    /**
     * Gets the value of the gmessage property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GMESSAGE }
     *     
     */
    public FUNDSTRANSFERType.GMESSAGE getGMESSAGE() {
        return gmessage;
    }

    /**
     * Sets the value of the gmessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GMESSAGE }
     *     
     */
    public void setGMESSAGE(FUNDSTRANSFERType.GMESSAGE value) {
        this.gmessage = value;
    }

    /**
     * Gets the value of the gtaxtype property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GTAXTYPE }
     *     
     */
    public FUNDSTRANSFERType.GTAXTYPE getGTAXTYPE() {
        return gtaxtype;
    }

    /**
     * Sets the value of the gtaxtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GTAXTYPE }
     *     
     */
    public void setGTAXTYPE(FUNDSTRANSFERType.GTAXTYPE value) {
        this.gtaxtype = value;
    }

    /**
     * Gets the value of the amountdebited property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAMOUNTDEBITED() {
        return amountdebited;
    }

    /**
     * Sets the value of the amountdebited property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAMOUNTDEBITED(String value) {
        this.amountdebited = value;
    }

    /**
     * Gets the value of the amountcredited property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAMOUNTCREDITED() {
        return amountcredited;
    }

    /**
     * Sets the value of the amountcredited property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAMOUNTCREDITED(String value) {
        this.amountcredited = value;
    }

    /**
     * Gets the value of the totalchargeamt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTALCHARGEAMT() {
        return totalchargeamt;
    }

    /**
     * Sets the value of the totalchargeamt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTALCHARGEAMT(String value) {
        this.totalchargeamt = value;
    }

    /**
     * Gets the value of the totaltaxamount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTALTAXAMOUNT() {
        return totaltaxamount;
    }

    /**
     * Sets the value of the totaltaxamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTALTAXAMOUNT(String value) {
        this.totaltaxamount = value;
    }

    /**
     * Gets the value of the customerrate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTOMERRATE() {
        return customerrate;
    }

    /**
     * Sets the value of the customerrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTOMERRATE(String value) {
        this.customerrate = value;
    }

    /**
     * Gets the value of the ginreccorrbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINRECCORRBK }
     *     
     */
    public FUNDSTRANSFERType.GINRECCORRBK getGINRECCORRBK() {
        return ginreccorrbk;
    }

    /**
     * Sets the value of the ginreccorrbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINRECCORRBK }
     *     
     */
    public void setGINRECCORRBK(FUNDSTRANSFERType.GINRECCORRBK value) {
        this.ginreccorrbk = value;
    }

    /**
     * Gets the value of the inwardpaytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINWARDPAYTYPE() {
        return inwardpaytype;
    }

    /**
     * Sets the value of the inwardpaytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINWARDPAYTYPE(String value) {
        this.inwardpaytype = value;
    }

    /**
     * Gets the value of the ginsendcorrbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINSENDCORRBK }
     *     
     */
    public FUNDSTRANSFERType.GINSENDCORRBK getGINSENDCORRBK() {
        return ginsendcorrbk;
    }

    /**
     * Sets the value of the ginsendcorrbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINSENDCORRBK }
     *     
     */
    public void setGINSENDCORRBK(FUNDSTRANSFERType.GINSENDCORRBK value) {
        this.ginsendcorrbk = value;
    }

    /**
     * Gets the value of the telexfromcust property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTELEXFROMCUST() {
        return telexfromcust;
    }

    /**
     * Sets the value of the telexfromcust property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTELEXFROMCUST(String value) {
        this.telexfromcust = value;
    }

    /**
     * Gets the value of the deliveryinref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDELIVERYINREF() {
        return deliveryinref;
    }

    /**
     * Sets the value of the deliveryinref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDELIVERYINREF(String value) {
        this.deliveryinref = value;
    }

    /**
     * Gets the value of the gdeliveryoutref property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GDELIVERYOUTREF }
     *     
     */
    public FUNDSTRANSFERType.GDELIVERYOUTREF getGDELIVERYOUTREF() {
        return gdeliveryoutref;
    }

    /**
     * Sets the value of the gdeliveryoutref property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GDELIVERYOUTREF }
     *     
     */
    public void setGDELIVERYOUTREF(FUNDSTRANSFERType.GDELIVERYOUTREF value) {
        this.gdeliveryoutref = value;
    }

    /**
     * Gets the value of the creditcompcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITCOMPCODE() {
        return creditcompcode;
    }

    /**
     * Sets the value of the creditcompcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITCOMPCODE(String value) {
        this.creditcompcode = value;
    }

    /**
     * Gets the value of the debitcompcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITCOMPCODE() {
        return debitcompcode;
    }

    /**
     * Sets the value of the debitcompcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITCOMPCODE(String value) {
        this.debitcompcode = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATUS() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATUS(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the deliverymkr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDELIVERYMKR() {
        return deliverymkr;
    }

    /**
     * Sets the value of the deliverymkr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDELIVERYMKR(String value) {
        this.deliverymkr = value;
    }

    /**
     * Gets the value of the ordcustcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORDCUSTCODE() {
        return ordcustcode;
    }

    /**
     * Sets the value of the ordcustcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORDCUSTCODE(String value) {
        this.ordcustcode = value;
    }

    /**
     * Gets the value of the acctwithbkacno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTWITHBKACNO() {
        return acctwithbkacno;
    }

    /**
     * Sets the value of the acctwithbkacno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTWITHBKACNO(String value) {
        this.acctwithbkacno = value;
    }

    /**
     * Gets the value of the locamtdebited property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCAMTDEBITED() {
        return locamtdebited;
    }

    /**
     * Sets the value of the locamtdebited property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCAMTDEBITED(String value) {
        this.locamtdebited = value;
    }

    /**
     * Gets the value of the locamtcredited property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCAMTCREDITED() {
        return locamtcredited;
    }

    /**
     * Sets the value of the locamtcredited property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCAMTCREDITED(String value) {
        this.locamtcredited = value;
    }

    /**
     * Gets the value of the loctottaxamt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCTOTTAXAMT() {
        return loctottaxamt;
    }

    /**
     * Sets the value of the loctottaxamt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCTOTTAXAMT(String value) {
        this.loctottaxamt = value;
    }

    /**
     * Gets the value of the localchargeamt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCALCHARGEAMT() {
        return localchargeamt;
    }

    /**
     * Sets the value of the localchargeamt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCALCHARGEAMT(String value) {
        this.localchargeamt = value;
    }

    /**
     * Gets the value of the locposchgsamt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCPOSCHGSAMT() {
        return locposchgsamt;
    }

    /**
     * Sets the value of the locposchgsamt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCPOSCHGSAMT(String value) {
        this.locposchgsamt = value;
    }

    /**
     * Gets the value of the mktgexchprofit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMKTGEXCHPROFIT() {
        return mktgexchprofit;
    }

    /**
     * Sets the value of the mktgexchprofit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMKTGEXCHPROFIT(String value) {
        this.mktgexchprofit = value;
    }

    /**
     * Gets the value of the rateinputmkr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRATEINPUTMKR() {
        return rateinputmkr;
    }

    /**
     * Sets the value of the rateinputmkr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRATEINPUTMKR(String value) {
        this.rateinputmkr = value;
    }

    /**
     * Gets the value of the custgrouplevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTGROUPLEVEL() {
        return custgrouplevel;
    }

    /**
     * Sets the value of the custgrouplevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTGROUPLEVEL(String value) {
        this.custgrouplevel = value;
    }

    /**
     * Gets the value of the debitcustomer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEBITCUSTOMER() {
        return debitcustomer;
    }

    /**
     * Sets the value of the debitcustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEBITCUSTOMER(String value) {
        this.debitcustomer = value;
    }

    /**
     * Gets the value of the creditcustomer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCREDITCUSTOMER() {
        return creditcustomer;
    }

    /**
     * Sets the value of the creditcustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCREDITCUSTOMER(String value) {
        this.creditcustomer = value;
    }

    /**
     * Gets the value of the sendpaymentyn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSENDPAYMENTYN() {
        return sendpaymentyn;
    }

    /**
     * Sets the value of the sendpaymentyn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSENDPAYMENTYN(String value) {
        this.sendpaymentyn = value;
    }

    /**
     * Gets the value of the dradvicereqdyn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDRADVICEREQDYN() {
        return dradvicereqdyn;
    }

    /**
     * Sets the value of the dradvicereqdyn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDRADVICEREQDYN(String value) {
        this.dradvicereqdyn = value;
    }

    /**
     * Gets the value of the cradvicereqdyn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCRADVICEREQDYN() {
        return cradvicereqdyn;
    }

    /**
     * Sets the value of the cradvicereqdyn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCRADVICEREQDYN(String value) {
        this.cradvicereqdyn = value;
    }

    /**
     * Gets the value of the dealmarket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEALMARKET() {
        return dealmarket;
    }

    /**
     * Sets the value of the dealmarket property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEALMARKET(String value) {
        this.dealmarket = value;
    }

    /**
     * Gets the value of the chargedcustomer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHARGEDCUSTOMER() {
        return chargedcustomer;
    }

    /**
     * Sets the value of the chargedcustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHARGEDCUSTOMER(String value) {
        this.chargedcustomer = value;
    }

    /**
     * Gets the value of the ginreasonove property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINREASONOVE }
     *     
     */
    public FUNDSTRANSFERType.GINREASONOVE getGINREASONOVE() {
        return ginreasonove;
    }

    /**
     * Sets the value of the ginreasonove property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINREASONOVE }
     *     
     */
    public void setGINREASONOVE(FUNDSTRANSFERType.GINREASONOVE value) {
        this.ginreasonove = value;
    }

    /**
     * Gets the value of the dealerdesk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEALERDESK() {
        return dealerdesk;
    }

    /**
     * Sets the value of the dealerdesk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEALERDESK(String value) {
        this.dealerdesk = value;
    }

    /**
     * Gets the value of the recalcfwdrate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECALCFWDRATE() {
        return recalcfwdrate;
    }

    /**
     * Sets the value of the recalcfwdrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECALCFWDRATE(String value) {
        this.recalcfwdrate = value;
    }

    /**
     * Gets the value of the returncheque property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRETURNCHEQUE() {
        return returncheque;
    }

    /**
     * Sets the value of the returncheque property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRETURNCHEQUE(String value) {
        this.returncheque = value;
    }

    /**
     * Gets the value of the drawnaccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDRAWNACCOUNT() {
        return drawnaccount;
    }

    /**
     * Sets the value of the drawnaccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDRAWNACCOUNT(String value) {
        this.drawnaccount = value;
    }

    /**
     * Gets the value of the accountingdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTINGDATE() {
        return accountingdate;
    }

    /**
     * Sets the value of the accountingdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTINGDATE(String value) {
        this.accountingdate = value;
    }

    /**
     * Gets the value of the ginstrctncode property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINSTRCTNCODE }
     *     
     */
    public FUNDSTRANSFERType.GINSTRCTNCODE getGINSTRCTNCODE() {
        return ginstrctncode;
    }

    /**
     * Sets the value of the ginstrctncode property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINSTRCTNCODE }
     *     
     */
    public void setGINSTRCTNCODE(FUNDSTRANSFERType.GINSTRCTNCODE value) {
        this.ginstrctncode = value;
    }

    /**
     * Gets the value of the collrembk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOLLREMBK() {
        return collrembk;
    }

    /**
     * Sets the value of the collrembk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOLLREMBK(String value) {
        this.collrembk = value;
    }

    /**
     * Gets the value of the expectedrecsid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEXPECTEDRECSID() {
        return expectedrecsid;
    }

    /**
     * Sets the value of the expectedrecsid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEXPECTEDRECSID(String value) {
        this.expectedrecsid = value;
    }

    /**
     * Gets the value of the totreccomm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTRECCOMM() {
        return totreccomm;
    }

    /**
     * Sets the value of the totreccomm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTRECCOMM(String value) {
        this.totreccomm = value;
    }

    /**
     * Gets the value of the totreccommlcl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTRECCOMMLCL() {
        return totreccommlcl;
    }

    /**
     * Sets the value of the totreccommlcl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTRECCOMMLCL(String value) {
        this.totreccommlcl = value;
    }

    /**
     * Gets the value of the totrecchg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTRECCHG() {
        return totrecchg;
    }

    /**
     * Sets the value of the totrecchg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTRECCHG(String value) {
        this.totrecchg = value;
    }

    /**
     * Gets the value of the totrecchglcl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTRECCHGLCL() {
        return totrecchglcl;
    }

    /**
     * Sets the value of the totrecchglcl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTRECCHGLCL(String value) {
        this.totrecchglcl = value;
    }

    /**
     * Gets the value of the cheqtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHEQTYPE() {
        return cheqtype;
    }

    /**
     * Sets the value of the cheqtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHEQTYPE(String value) {
        this.cheqtype = value;
    }

    /**
     * Gets the value of the grelatedmsg property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GRELATEDMSG }
     *     
     */
    public FUNDSTRANSFERType.GRELATEDMSG getGRELATEDMSG() {
        return grelatedmsg;
    }

    /**
     * Sets the value of the grelatedmsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GRELATEDMSG }
     *     
     */
    public void setGRELATEDMSG(FUNDSTRANSFERType.GRELATEDMSG value) {
        this.grelatedmsg = value;
    }

    /**
     * Gets the value of the gintimeind property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINTIMEIND }
     *     
     */
    public FUNDSTRANSFERType.GINTIMEIND getGINTIMEIND() {
        return gintimeind;
    }

    /**
     * Sets the value of the gintimeind property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINTIMEIND }
     *     
     */
    public void setGINTIMEIND(FUNDSTRANSFERType.GINTIMEIND value) {
        this.gintimeind = value;
    }

    /**
     * Gets the value of the gsendtoparty property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GSENDTOPARTY }
     *     
     */
    public FUNDSTRANSFERType.GSENDTOPARTY getGSENDTOPARTY() {
        return gsendtoparty;
    }

    /**
     * Sets the value of the gsendtoparty property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GSENDTOPARTY }
     *     
     */
    public void setGSENDTOPARTY(FUNDSTRANSFERType.GSENDTOPARTY value) {
        this.gsendtoparty = value;
    }

    /**
     * Gets the value of the reversalmkr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREVERSALMKR() {
        return reversalmkr;
    }

    /**
     * Sets the value of the reversalmkr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREVERSALMKR(String value) {
        this.reversalmkr = value;
    }

    /**
     * Gets the value of the relatedref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRELATEDREF() {
        return relatedref;
    }

    /**
     * Sets the value of the relatedref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRELATEDREF(String value) {
        this.relatedref = value;
    }

    /**
     * Gets the value of the gininstrcode property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GININSTRCODE }
     *     
     */
    public FUNDSTRANSFERType.GININSTRCODE getGININSTRCODE() {
        return gininstrcode;
    }

    /**
     * Sets the value of the gininstrcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GININSTRCODE }
     *     
     */
    public void setGININSTRCODE(FUNDSTRANSFERType.GININSTRCODE value) {
        this.gininstrcode = value;
    }

    /**
     * Gets the value of the ginprocesserr property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINPROCESSERR }
     *     
     */
    public FUNDSTRANSFERType.GINPROCESSERR getGINPROCESSERR() {
        return ginprocesserr;
    }

    /**
     * Sets the value of the ginprocesserr property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINPROCESSERR }
     *     
     */
    public void setGINPROCESSERR(FUNDSTRANSFERType.GINPROCESSERR value) {
        this.ginprocesserr = value;
    }

    /**
     * Gets the value of the ginswiftmsg property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINSWIFTMSG }
     *     
     */
    public FUNDSTRANSFERType.GINSWIFTMSG getGINSWIFTMSG() {
        return ginswiftmsg;
    }

    /**
     * Sets the value of the ginswiftmsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINSWIFTMSG }
     *     
     */
    public void setGINSWIFTMSG(FUNDSTRANSFERType.GINSWIFTMSG value) {
        this.ginswiftmsg = value;
    }

    /**
     * Gets the value of the acctwithbankacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTWITHBANKACC() {
        return acctwithbankacc;
    }

    /**
     * Sets the value of the acctwithbankacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTWITHBANKACC(String value) {
        this.acctwithbankacc = value;
    }

    /**
     * Gets the value of the inacctbankacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINACCTBANKACC() {
        return inacctbankacc;
    }

    /**
     * Sets the value of the inacctbankacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINACCTBANKACC(String value) {
        this.inacctbankacc = value;
    }

    /**
     * Gets the value of the reccorrbankacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECCORRBANKACC() {
        return reccorrbankacc;
    }

    /**
     * Sets the value of the reccorrbankacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECCORRBANKACC(String value) {
        this.reccorrbankacc = value;
    }

    /**
     * Gets the value of the inreccorracc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINRECCORRACC() {
        return inreccorracc;
    }

    /**
     * Sets the value of the inreccorracc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINRECCORRACC(String value) {
        this.inreccorracc = value;
    }

    /**
     * Gets the value of the intermedbankacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINTERMEDBANKACC() {
        return intermedbankacc;
    }

    /**
     * Sets the value of the intermedbankacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINTERMEDBANKACC(String value) {
        this.intermedbankacc = value;
    }

    /**
     * Gets the value of the inintermedacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getININTERMEDACC() {
        return inintermedacc;
    }

    /**
     * Sets the value of the inintermedacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setININTERMEDACC(String value) {
        this.inintermedacc = value;
    }

    /**
     * Gets the value of the instructedamt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINSTRUCTEDAMT() {
        return instructedamt;
    }

    /**
     * Sets the value of the instructedamt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINSTRUCTEDAMT(String value) {
        this.instructedamt = value;
    }

    /**
     * Gets the value of the ginintermedbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GININTERMEDBK }
     *     
     */
    public FUNDSTRANSFERType.GININTERMEDBK getGININTERMEDBK() {
        return ginintermedbk;
    }

    /**
     * Sets the value of the ginintermedbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GININTERMEDBK }
     *     
     */
    public void setGININTERMEDBK(FUNDSTRANSFERType.GININTERMEDBK value) {
        this.ginintermedbk = value;
    }

    /**
     * Gets the value of the inexchrate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINEXCHRATE() {
        return inexchrate;
    }

    /**
     * Sets the value of the inexchrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINEXCHRATE(String value) {
        this.inexchrate = value;
    }

    /**
     * Gets the value of the ratefixing property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRATEFIXING() {
        return ratefixing;
    }

    /**
     * Sets the value of the ratefixing property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRATEFIXING(String value) {
        this.ratefixing = value;
    }

    /**
     * Gets the value of the covermethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOVERMETHOD() {
        return covermethod;
    }

    /**
     * Sets the value of the covermethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOVERMETHOD(String value) {
        this.covermethod = value;
    }

    /**
     * Gets the value of the gin3RDREIMBBK property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GIN3RDREIMBBK }
     *     
     */
    public FUNDSTRANSFERType.GIN3RDREIMBBK getGIN3RDREIMBBK() {
        return gin3RDREIMBBK;
    }

    /**
     * Sets the value of the gin3RDREIMBBK property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GIN3RDREIMBBK }
     *     
     */
    public void setGIN3RDREIMBBK(FUNDSTRANSFERType.GIN3RDREIMBBK value) {
        this.gin3RDREIMBBK = value;
    }

    /**
     * Gets the value of the in3RDREIMBACC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIN3RDREIMBACC() {
        return in3RDREIMBACC;
    }

    /**
     * Sets the value of the in3RDREIMBACC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIN3RDREIMBACC(String value) {
        this.in3RDREIMBACC = value;
    }

    /**
     * Gets the value of the mt103TYPE property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMT103TYPE() {
        return mt103TYPE;
    }

    /**
     * Sets the value of the mt103TYPE property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMT103TYPE(String value) {
        this.mt103TYPE = value;
    }

    /**
     * Gets the value of the extendformat property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEXTENDFORMAT() {
        return extendformat;
    }

    /**
     * Sets the value of the extendformat property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEXTENDFORMAT(String value) {
        this.extendformat = value;
    }

    /**
     * Gets the value of the gextendinfo property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GEXTENDINFO }
     *     
     */
    public FUNDSTRANSFERType.GEXTENDINFO getGEXTENDINFO() {
        return gextendinfo;
    }

    /**
     * Sets the value of the gextendinfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GEXTENDINFO }
     *     
     */
    public void setGEXTENDINFO(FUNDSTRANSFERType.GEXTENDINFO value) {
        this.gextendinfo = value;
    }

    /**
     * Gets the value of the ratefixingind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRATEFIXINGIND() {
        return ratefixingind;
    }

    /**
     * Sets the value of the ratefixingind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRATEFIXINGIND(String value) {
        this.ratefixingind = value;
    }

    /**
     * Gets the value of the inwsendbic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINWSENDBIC() {
        return inwsendbic;
    }

    /**
     * Sets the value of the inwsendbic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINWSENDBIC(String value) {
        this.inwsendbic = value;
    }

    /**
     * Gets the value of the ginsendchg property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINSENDCHG }
     *     
     */
    public FUNDSTRANSFERType.GINSENDCHG getGINSENDCHG() {
        return ginsendchg;
    }

    /**
     * Sets the value of the ginsendchg property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINSENDCHG }
     *     
     */
    public void setGINSENDCHG(FUNDSTRANSFERType.GINSENDCHG value) {
        this.ginsendchg = value;
    }

    /**
     * Gets the value of the inrecchg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINRECCHG() {
        return inrecchg;
    }

    /**
     * Sets the value of the inrecchg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINRECCHG(String value) {
        this.inrecchg = value;
    }

    /**
     * Gets the value of the acchgreqid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCHGREQID() {
        return acchgreqid;
    }

    /**
     * Sets the value of the acchgreqid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCHGREQID(String value) {
        this.acchgreqid = value;
    }

    /**
     * Gets the value of the totrecchgcrccy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTRECCHGCRCCY() {
        return totrecchgcrccy;
    }

    /**
     * Sets the value of the totrecchgcrccy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTRECCHGCRCCY(String value) {
        this.totrecchgcrccy = value;
    }

    /**
     * Gets the value of the totsndchgcrccy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOTSNDCHGCRCCY() {
        return totsndchgcrccy;
    }

    /**
     * Sets the value of the totsndchgcrccy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOTSNDCHGCRCCY(String value) {
        this.totsndchgcrccy = value;
    }

    /**
     * Gets the value of the chgadvicemsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHGADVICEMSG() {
        return chgadvicemsg;
    }

    /**
     * Sets the value of the chgadvicemsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHGADVICEMSG(String value) {
        this.chgadvicemsg = value;
    }

    /**
     * Gets the value of the expectedcoverid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEXPECTEDCOVERID() {
        return expectedcoverid;
    }

    /**
     * Sets the value of the expectedcoverid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEXPECTEDCOVERID(String value) {
        this.expectedcoverid = value;
    }

    /**
     * Gets the value of the nettingstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNETTINGSTATUS() {
        return nettingstatus;
    }

    /**
     * Sets the value of the nettingstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNETTINGSTATUS(String value) {
        this.nettingstatus = value;
    }

    /**
     * Gets the value of the authdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUTHDATE() {
        return authdate;
    }

    /**
     * Sets the value of the authdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUTHDATE(String value) {
        this.authdate = value;
    }

    /**
     * Gets the value of the bkoperationcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBKOPERATIONCODE() {
        return bkoperationcode;
    }

    /**
     * Sets the value of the bkoperationcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBKOPERATIONCODE(String value) {
        this.bkoperationcode = value;
    }

    /**
     * Gets the value of the aminflowrate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAMINFLOWRATE() {
        return aminflowrate;
    }

    /**
     * Sets the value of the aminflowrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAMINFLOWRATE(String value) {
        this.aminflowrate = value;
    }

    /**
     * Gets the value of the parenttxnid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARENTTXNID() {
        return parenttxnid;
    }

    /**
     * Sets the value of the parenttxnid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARENTTXNID(String value) {
        this.parenttxnid = value;
    }

    /**
     * Gets the value of the roundtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROUNDTYPE() {
        return roundtype;
    }

    /**
     * Sets the value of the roundtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROUNDTYPE(String value) {
        this.roundtype = value;
    }

    /**
     * Gets the value of the beneficiaryid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBENEFICIARYID() {
        return beneficiaryid;
    }

    /**
     * Sets the value of the beneficiaryid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBENEFICIARYID(String value) {
        this.beneficiaryid = value;
    }

    /**
     * Gets the value of the gmsgtype property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GMSGTYPE }
     *     
     */
    public FUNDSTRANSFERType.GMSGTYPE getGMSGTYPE() {
        return gmsgtype;
    }

    /**
     * Sets the value of the gmsgtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GMSGTYPE }
     *     
     */
    public void setGMSGTYPE(FUNDSTRANSFERType.GMSGTYPE value) {
        this.gmsgtype = value;
    }

    /**
     * Gets the value of the gsignatory property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GSIGNATORY }
     *     
     */
    public FUNDSTRANSFERType.GSIGNATORY getGSIGNATORY() {
        return gsignatory;
    }

    /**
     * Sets the value of the gsignatory property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GSIGNATORY }
     *     
     */
    public void setGSIGNATORY(FUNDSTRANSFERType.GSIGNATORY value) {
        this.gsignatory = value;
    }

    /**
     * Gets the value of the cardnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCARDNUMBER() {
        return cardnumber;
    }

    /**
     * Sets the value of the cardnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCARDNUMBER(String value) {
        this.cardnumber = value;
    }

    /**
     * Gets the value of the gcardtxndetail property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GCARDTXNDETAIL }
     *     
     */
    public FUNDSTRANSFERType.GCARDTXNDETAIL getGCARDTXNDETAIL() {
        return gcardtxndetail;
    }

    /**
     * Sets the value of the gcardtxndetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GCARDTXNDETAIL }
     *     
     */
    public void setGCARDTXNDETAIL(FUNDSTRANSFERType.GCARDTXNDETAIL value) {
        this.gcardtxndetail = value;
    }

    /**
     * Gets the value of the gincordbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINCORDBK }
     *     
     */
    public FUNDSTRANSFERType.GINCORDBK getGINCORDBK() {
        return gincordbk;
    }

    /**
     * Sets the value of the gincordbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINCORDBK }
     *     
     */
    public void setGINCORDBK(FUNDSTRANSFERType.GINCORDBK value) {
        this.gincordbk = value;
    }

    /**
     * Gets the value of the gincintmedbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINCINTMEDBK }
     *     
     */
    public FUNDSTRANSFERType.GINCINTMEDBK getGINCINTMEDBK() {
        return gincintmedbk;
    }

    /**
     * Sets the value of the gincintmedbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINCINTMEDBK }
     *     
     */
    public void setGINCINTMEDBK(FUNDSTRANSFERType.GINCINTMEDBK value) {
        this.gincintmedbk = value;
    }

    /**
     * Gets the value of the gincaccwitbk property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINCACCWITBK }
     *     
     */
    public FUNDSTRANSFERType.GINCACCWITBK getGINCACCWITBK() {
        return gincaccwitbk;
    }

    /**
     * Sets the value of the gincaccwitbk property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINCACCWITBK }
     *     
     */
    public void setGINCACCWITBK(FUNDSTRANSFERType.GINCACCWITBK value) {
        this.gincaccwitbk = value;
    }

    /**
     * Gets the value of the gincbktbkin property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINCBKTBKIN }
     *     
     */
    public FUNDSTRANSFERType.GINCBKTBKIN getGINCBKTBKIN() {
        return gincbktbkin;
    }

    /**
     * Sets the value of the gincbktbkin property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINCBKTBKIN }
     *     
     */
    public void setGINCBKTBKIN(FUNDSTRANSFERType.GINCBKTBKIN value) {
        this.gincbktbkin = value;
    }

    /**
     * Gets the value of the tfsreference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTFSREFERENCE() {
        return tfsreference;
    }

    /**
     * Sets the value of the tfsreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTFSREFERENCE(String value) {
        this.tfsreference = value;
    }

    /**
     * Gets the value of the chequedrawn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHEQUEDRAWN() {
        return chequedrawn;
    }

    /**
     * Sets the value of the chequedrawn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHEQUEDRAWN(String value) {
        this.chequedrawn = value;
    }

    /**
     * Gets the value of the issuechequetype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISSUECHEQUETYPE() {
        return issuechequetype;
    }

    /**
     * Sets the value of the issuechequetype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISSUECHEQUETYPE(String value) {
        this.issuechequetype = value;
    }

    /**
     * Gets the value of the stocknumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTOCKNUMBER() {
        return stocknumber;
    }

    /**
     * Sets the value of the stocknumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTOCKNUMBER(String value) {
        this.stocknumber = value;
    }

    /**
     * Gets the value of the payeename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPAYEENAME() {
        return payeename;
    }

    /**
     * Sets the value of the payeename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPAYEENAME(String value) {
        this.payeename = value;
    }

    /**
     * Gets the value of the stockregister property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTOCKREGISTER() {
        return stockregister;
    }

    /**
     * Sets the value of the stockregister property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTOCKREGISTER(String value) {
        this.stockregister = value;
    }

    /**
     * Gets the value of the seriesid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSERIESID() {
        return seriesid;
    }

    /**
     * Sets the value of the seriesid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSERIESID(String value) {
        this.seriesid = value;
    }

    /**
     * Gets the value of the reserved20 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED20() {
        return reserved20;
    }

    /**
     * Sets the value of the reserved20 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED20(String value) {
        this.reserved20 = value;
    }

    /**
     * Gets the value of the reserved19 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED19() {
        return reserved19;
    }

    /**
     * Sets the value of the reserved19 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED19(String value) {
        this.reserved19 = value;
    }

    /**
     * Gets the value of the reserved18 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED18() {
        return reserved18;
    }

    /**
     * Sets the value of the reserved18 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED18(String value) {
        this.reserved18 = value;
    }

    /**
     * Gets the value of the reserved17 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED17() {
        return reserved17;
    }

    /**
     * Sets the value of the reserved17 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED17(String value) {
        this.reserved17 = value;
    }

    /**
     * Gets the value of the reserved16 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED16() {
        return reserved16;
    }

    /**
     * Sets the value of the reserved16 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED16(String value) {
        this.reserved16 = value;
    }

    /**
     * Gets the value of the reserved15 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED15() {
        return reserved15;
    }

    /**
     * Sets the value of the reserved15 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED15(String value) {
        this.reserved15 = value;
    }

    /**
     * Gets the value of the reserved14 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED14() {
        return reserved14;
    }

    /**
     * Sets the value of the reserved14 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED14(String value) {
        this.reserved14 = value;
    }

    /**
     * Gets the value of the reserved13 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED13() {
        return reserved13;
    }

    /**
     * Sets the value of the reserved13 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED13(String value) {
        this.reserved13 = value;
    }

    /**
     * Gets the value of the reserved12 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED12() {
        return reserved12;
    }

    /**
     * Sets the value of the reserved12 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED12(String value) {
        this.reserved12 = value;
    }

    /**
     * Gets the value of the reserved11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED11() {
        return reserved11;
    }

    /**
     * Sets the value of the reserved11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED11(String value) {
        this.reserved11 = value;
    }

    /**
     * Gets the value of the reserved10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED10() {
        return reserved10;
    }

    /**
     * Sets the value of the reserved10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED10(String value) {
        this.reserved10 = value;
    }

    /**
     * Gets the value of the reserved9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED9() {
        return reserved9;
    }

    /**
     * Sets the value of the reserved9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED9(String value) {
        this.reserved9 = value;
    }

    /**
     * Gets the value of the reserved8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED8() {
        return reserved8;
    }

    /**
     * Sets the value of the reserved8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED8(String value) {
        this.reserved8 = value;
    }

    /**
     * Gets the value of the reserved7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED7() {
        return reserved7;
    }

    /**
     * Sets the value of the reserved7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED7(String value) {
        this.reserved7 = value;
    }

    /**
     * Gets the value of the reserved6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED6() {
        return reserved6;
    }

    /**
     * Sets the value of the reserved6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED6(String value) {
        this.reserved6 = value;
    }

    /**
     * Gets the value of the reserved5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED5() {
        return reserved5;
    }

    /**
     * Sets the value of the reserved5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED5(String value) {
        this.reserved5 = value;
    }

    /**
     * Gets the value of the reserved4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED4() {
        return reserved4;
    }

    /**
     * Sets the value of the reserved4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED4(String value) {
        this.reserved4 = value;
    }

    /**
     * Gets the value of the reserved3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED3() {
        return reserved3;
    }

    /**
     * Sets the value of the reserved3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED3(String value) {
        this.reserved3 = value;
    }

    /**
     * Gets the value of the reserved2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED2() {
        return reserved2;
    }

    /**
     * Sets the value of the reserved2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED2(String value) {
        this.reserved2 = value;
    }

    /**
     * Gets the value of the reserved1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESERVED1() {
        return reserved1;
    }

    /**
     * Sets the value of the reserved1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESERVED1(String value) {
        this.reserved1 = value;
    }

    /**
     * Gets the value of the gstmtnos property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GSTMTNOS }
     *     
     */
    public FUNDSTRANSFERType.GSTMTNOS getGSTMTNOS() {
        return gstmtnos;
    }

    /**
     * Sets the value of the gstmtnos property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GSTMTNOS }
     *     
     */
    public void setGSTMTNOS(FUNDSTRANSFERType.GSTMTNOS value) {
        this.gstmtnos = value;
    }

    /**
     * Gets the value of the goverride property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GOVERRIDE }
     *     
     */
    public FUNDSTRANSFERType.GOVERRIDE getGOVERRIDE() {
        return goverride;
    }

    /**
     * Sets the value of the goverride property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GOVERRIDE }
     *     
     */
    public void setGOVERRIDE(FUNDSTRANSFERType.GOVERRIDE value) {
        this.goverride = value;
    }

    /**
     * Gets the value of the recordstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRECORDSTATUS() {
        return recordstatus;
    }

    /**
     * Sets the value of the recordstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRECORDSTATUS(String value) {
        this.recordstatus = value;
    }

    /**
     * Gets the value of the currno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCURRNO() {
        return currno;
    }

    /**
     * Sets the value of the currno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCURRNO(String value) {
        this.currno = value;
    }

    /**
     * Gets the value of the ginputter property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GINPUTTER }
     *     
     */
    public FUNDSTRANSFERType.GINPUTTER getGINPUTTER() {
        return ginputter;
    }

    /**
     * Sets the value of the ginputter property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GINPUTTER }
     *     
     */
    public void setGINPUTTER(FUNDSTRANSFERType.GINPUTTER value) {
        this.ginputter = value;
    }

    /**
     * Gets the value of the gdatetime property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GDATETIME }
     *     
     */
    public FUNDSTRANSFERType.GDATETIME getGDATETIME() {
        return gdatetime;
    }

    /**
     * Sets the value of the gdatetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GDATETIME }
     *     
     */
    public void setGDATETIME(FUNDSTRANSFERType.GDATETIME value) {
        this.gdatetime = value;
    }

    /**
     * Gets the value of the authoriser property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUTHORISER() {
        return authoriser;
    }

    /**
     * Sets the value of the authoriser property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUTHORISER(String value) {
        this.authoriser = value;
    }

    /**
     * Gets the value of the cocode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOCODE() {
        return cocode;
    }

    /**
     * Sets the value of the cocode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOCODE(String value) {
        this.cocode = value;
    }

    /**
     * Gets the value of the deptcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDEPTCODE() {
        return deptcode;
    }

    /**
     * Sets the value of the deptcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDEPTCODE(String value) {
        this.deptcode = value;
    }

    /**
     * Gets the value of the auditorcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUDITORCODE() {
        return auditorcode;
    }

    /**
     * Sets the value of the auditorcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUDITORCODE(String value) {
        this.auditorcode = value;
    }

    /**
     * Gets the value of the auditdatetime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAUDITDATETIME() {
        return auditdatetime;
    }

    /**
     * Sets the value of the auditdatetime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAUDITDATETIME(String value) {
        this.auditdatetime = value;
    }

    /**
     * Gets the value of the isconid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISCONID() {
        return isconid;
    }

    /**
     * Sets the value of the isconid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISCONID(String value) {
        this.isconid = value;
    }

    /**
     * Gets the value of the lastversion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTVERSION() {
        return lastversion;
    }

    /**
     * Sets the value of the lastversion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTVERSION(String value) {
        this.lastversion = value;
    }

    /**
     * Gets the value of the iscustid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISCUSTID() {
        return iscustid;
    }

    /**
     * Sets the value of the iscustid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISCUSTID(String value) {
        this.iscustid = value;
    }

    /**
     * Gets the value of the issupplier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISSUPPLIER() {
        return issupplier;
    }

    /**
     * Sets the value of the issupplier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISSUPPLIER(String value) {
        this.issupplier = value;
    }

    /**
     * Gets the value of the loantype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOANTYPE() {
        return loantype;
    }

    /**
     * Sets the value of the loantype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOANTYPE(String value) {
        this.loantype = value;
    }

    /**
     * Gets the value of the cmatxnref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCMATXNREF() {
        return cmatxnref;
    }

    /**
     * Sets the value of the cmatxnref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCMATXNREF(String value) {
        this.cmatxnref = value;
    }

    /**
     * Gets the value of the icrconid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getICRCONID() {
        return icrconid;
    }

    /**
     * Sets the value of the icrconid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setICRCONID(String value) {
        this.icrconid = value;
    }

    /**
     * Gets the value of the bencountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBENCOUNTRY() {
        return bencountry;
    }

    /**
     * Sets the value of the bencountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBENCOUNTRY(String value) {
        this.bencountry = value;
    }

    /**
     * Gets the value of the chqtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHQTYPE() {
        return chqtype;
    }

    /**
     * Sets the value of the chqtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHQTYPE(String value) {
        this.chqtype = value;
    }

    /**
     * Gets the value of the txntype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTXNTYPE() {
        return txntype;
    }

    /**
     * Sets the value of the txntype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTXNTYPE(String value) {
        this.txntype = value;
    }

    /**
     * Gets the value of the custpaynot property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTPAYNOT() {
        return custpaynot;
    }

    /**
     * Sets the value of the custpaynot property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTPAYNOT(String value) {
        this.custpaynot = value;
    }

    /**
     * Gets the value of the ordcustacc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORDCUSTACC() {
        return ordcustacc;
    }

    /**
     * Sets the value of the ordcustacc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORDCUSTACC(String value) {
        this.ordcustacc = value;
    }

    /**
     * Gets the value of the ftpurpose property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFTPURPOSE() {
        return ftpurpose;
    }

    /**
     * Sets the value of the ftpurpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFTPURPOSE(String value) {
        this.ftpurpose = value;
    }

    /**
     * Gets the value of the billerid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBILLERID() {
        return billerid;
    }

    /**
     * Sets the value of the billerid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBILLERID(String value) {
        this.billerid = value;
    }

    /**
     * Gets the value of the billno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBILLNO() {
        return billno;
    }

    /**
     * Sets the value of the billno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBILLNO(String value) {
        this.billno = value;
    }

    /**
     * Gets the value of the cardno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCARDNO() {
        return cardno;
    }

    /**
     * Sets the value of the cardno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCARDNO(String value) {
        this.cardno = value;
    }

    /**
     * Gets the value of the qpemployer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQPEMPLOYER() {
        return qpemployer;
    }

    /**
     * Sets the value of the qpemployer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQPEMPLOYER(String value) {
        this.qpemployer = value;
    }

    /**
     * Gets the value of the qpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQPKEY() {
        return qpkey;
    }

    /**
     * Sets the value of the qpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQPKEY(String value) {
        this.qpkey = value;
    }

    /**
     * Gets the value of the sariebenbank property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSARIEBENBANK() {
        return sariebenbank;
    }

    /**
     * Sets the value of the sariebenbank property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSARIEBENBANK(String value) {
        this.sariebenbank = value;
    }

    /**
     * Gets the value of the chqpurpose property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHQPURPOSE() {
        return chqpurpose;
    }

    /**
     * Sets the value of the chqpurpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHQPURPOSE(String value) {
        this.chqpurpose = value;
    }

    /**
     * Gets the value of the chequesender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHEQUESENDER() {
        return chequesender;
    }

    /**
     * Sets the value of the chequesender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHEQUESENDER(String value) {
        this.chequesender = value;
    }

    /**
     * Gets the value of the gchequebenefici property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GCHEQUEBENEFICI }
     *     
     */
    public FUNDSTRANSFERType.GCHEQUEBENEFICI getGCHEQUEBENEFICI() {
        return gchequebenefici;
    }

    /**
     * Sets the value of the gchequebenefici property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GCHEQUEBENEFICI }
     *     
     */
    public void setGCHEQUEBENEFICI(FUNDSTRANSFERType.GCHEQUEBENEFICI value) {
        this.gchequebenefici = value;
    }

    /**
     * Gets the value of the bajcmdtydtl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBAJCMDTYDTL() {
        return bajcmdtydtl;
    }

    /**
     * Sets the value of the bajcmdtydtl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBAJCMDTYDTL(String value) {
        this.bajcmdtydtl = value;
    }

    /**
     * Gets the value of the bajsellqty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBAJSELLQTY() {
        return bajsellqty;
    }

    /**
     * Sets the value of the bajsellqty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBAJSELLQTY(String value) {
        this.bajsellqty = value;
    }

    /**
     * Gets the value of the bajmktprice property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBAJMKTPRICE() {
        return bajmktprice;
    }

    /**
     * Sets the value of the bajmktprice property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBAJMKTPRICE(String value) {
        this.bajmktprice = value;
    }

    /**
     * Gets the value of the bajldref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBAJLDREF() {
        return bajldref;
    }

    /**
     * Sets the value of the bajldref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBAJLDREF(String value) {
        this.bajldref = value;
    }

    /**
     * Gets the value of the bajcmdtycode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBAJCMDTYCODE() {
        return bajcmdtycode;
    }

    /**
     * Sets the value of the bajcmdtycode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBAJCMDTYCODE(String value) {
        this.bajcmdtycode = value;
    }

    /**
     * Gets the value of the batrfchrgs property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBATRFCHRGS() {
        return batrfchrgs;
    }

    /**
     * Sets the value of the batrfchrgs property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBATRFCHRGS(String value) {
        this.batrfchrgs = value;
    }

    /**
     * Gets the value of the batrfamnt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBATRFAMNT() {
        return batrfamnt;
    }

    /**
     * Sets the value of the batrfamnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBATRFAMNT(String value) {
        this.batrfamnt = value;
    }

    /**
     * Gets the value of the gbajelnotes property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GBAJELNOTES }
     *     
     */
    public FUNDSTRANSFERType.GBAJELNOTES getGBAJELNOTES() {
        return gbajelnotes;
    }

    /**
     * Sets the value of the gbajelnotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GBAJELNOTES }
     *     
     */
    public void setGBAJELNOTES(FUNDSTRANSFERType.GBAJELNOTES value) {
        this.gbajelnotes = value;
    }

    /**
     * Gets the value of the brokerlimit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBROKERLIMIT() {
        return brokerlimit;
    }

    /**
     * Sets the value of the brokerlimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBROKERLIMIT(String value) {
        this.brokerlimit = value;
    }

    /**
     * Gets the value of the sigle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSIGLE() {
        return sigle;
    }

    /**
     * Sets the value of the sigle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSIGLE(String value) {
        this.sigle = value;
    }

    /**
     * Gets the value of the lofacdetail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOFACDETAIL() {
        return lofacdetail;
    }

    /**
     * Sets the value of the lofacdetail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOFACDETAIL(String value) {
        this.lofacdetail = value;
    }

    /**
     * Gets the value of the inmamsgtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getINMAMSGTYPE() {
        return inmamsgtype;
    }

    /**
     * Sets the value of the inmamsgtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setINMAMSGTYPE(String value) {
        this.inmamsgtype = value;
    }

    /**
     * Gets the value of the msgpriority property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSGPRIORITY() {
        return msgpriority;
    }

    /**
     * Sets the value of the msgpriority property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSGPRIORITY(String value) {
        this.msgpriority = value;
    }

    /**
     * Gets the value of the custtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTTYPE() {
        return custtype;
    }

    /**
     * Sets the value of the custtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTTYPE(String value) {
        this.custtype = value;
    }

    /**
     * Gets the value of the custnatnlty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTNATNLTY() {
        return custnatnlty;
    }

    /**
     * Sets the value of the custnatnlty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTNATNLTY(String value) {
        this.custnatnlty = value;
    }

    /**
     * Gets the value of the paymtpurpose property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPAYMTPURPOSE() {
        return paymtpurpose;
    }

    /**
     * Sets the value of the paymtpurpose property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPAYMTPURPOSE(String value) {
        this.paymtpurpose = value;
    }

    /**
     * Gets the value of the payroll property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPAYROLL() {
        return payroll;
    }

    /**
     * Sets the value of the payroll property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPAYROLL(String value) {
        this.payroll = value;
    }

    /**
     * Gets the value of the isrprid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISRPRID() {
        return isrprid;
    }

    /**
     * Sets the value of the isrprid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISRPRID(String value) {
        this.isrprid = value;
    }

    /**
     * Gets the value of the cardacctno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCARDACCTNO() {
        return cardacctno;
    }

    /**
     * Sets the value of the cardacctno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCARDACCTNO(String value) {
        this.cardacctno = value;
    }

    /**
     * Gets the value of the atmno property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMNO() {
        return atmno;
    }

    /**
     * Sets the value of the atmno property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMNO(String value) {
        this.atmno = value;
    }

    /**
     * Gets the value of the gordcustar property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GORDCUSTAR }
     *     
     */
    public FUNDSTRANSFERType.GORDCUSTAR getGORDCUSTAR() {
        return gordcustar;
    }

    /**
     * Sets the value of the gordcustar property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GORDCUSTAR }
     *     
     */
    public void setGORDCUSTAR(FUNDSTRANSFERType.GORDCUSTAR value) {
        this.gordcustar = value;
    }

    /**
     * Gets the value of the gbencustar property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GBENCUSTAR }
     *     
     */
    public FUNDSTRANSFERType.GBENCUSTAR getGBENCUSTAR() {
        return gbencustar;
    }

    /**
     * Sets the value of the gbencustar property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GBENCUSTAR }
     *     
     */
    public void setGBENCUSTAR(FUNDSTRANSFERType.GBENCUSTAR value) {
        this.gbencustar = value;
    }

    /**
     * Gets the value of the gpaydetsar property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GPAYDETSAR }
     *     
     */
    public FUNDSTRANSFERType.GPAYDETSAR getGPAYDETSAR() {
        return gpaydetsar;
    }

    /**
     * Sets the value of the gpaydetsar property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GPAYDETSAR }
     *     
     */
    public void setGPAYDETSAR(FUNDSTRANSFERType.GPAYDETSAR value) {
        this.gpaydetsar = value;
    }

    /**
     * Gets the value of the gsndtoparar property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GSNDTOPARAR }
     *     
     */
    public FUNDSTRANSFERType.GSNDTOPARAR getGSNDTOPARAR() {
        return gsndtoparar;
    }

    /**
     * Sets the value of the gsndtoparar property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GSNDTOPARAR }
     *     
     */
    public void setGSNDTOPARAR(FUNDSTRANSFERType.GSNDTOPARAR value) {
        this.gsndtoparar = value;
    }

    /**
     * Gets the value of the sicode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSICODE() {
        return sicode;
    }

    /**
     * Sets the value of the sicode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSICODE(String value) {
        this.sicode = value;
    }

    /**
     * Gets the value of the gsimessage property.
     * 
     * @return
     *     possible object is
     *     {@link FUNDSTRANSFERType.GSIMESSAGE }
     *     
     */
    public FUNDSTRANSFERType.GSIMESSAGE getGSIMESSAGE() {
        return gsimessage;
    }

    /**
     * Sets the value of the gsimessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link FUNDSTRANSFERType.GSIMESSAGE }
     *     
     */
    public void setGSIMESSAGE(FUNDSTRANSFERType.GSIMESSAGE value) {
        this.gsimessage = value;
    }

    /**
     * Gets the value of the sitfield1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD1() {
        return sitfield1;
    }

    /**
     * Sets the value of the sitfield1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD1(String value) {
        this.sitfield1 = value;
    }

    /**
     * Gets the value of the sitfield2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD2() {
        return sitfield2;
    }

    /**
     * Sets the value of the sitfield2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD2(String value) {
        this.sitfield2 = value;
    }

    /**
     * Gets the value of the sitfield3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD3() {
        return sitfield3;
    }

    /**
     * Sets the value of the sitfield3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD3(String value) {
        this.sitfield3 = value;
    }

    /**
     * Gets the value of the sitfield4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD4() {
        return sitfield4;
    }

    /**
     * Sets the value of the sitfield4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD4(String value) {
        this.sitfield4 = value;
    }

    /**
     * Gets the value of the sitfield5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD5() {
        return sitfield5;
    }

    /**
     * Sets the value of the sitfield5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD5(String value) {
        this.sitfield5 = value;
    }

    /**
     * Gets the value of the sitfield6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD6() {
        return sitfield6;
    }

    /**
     * Sets the value of the sitfield6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD6(String value) {
        this.sitfield6 = value;
    }

    /**
     * Gets the value of the sitfield7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD7() {
        return sitfield7;
    }

    /**
     * Sets the value of the sitfield7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD7(String value) {
        this.sitfield7 = value;
    }

    /**
     * Gets the value of the sitfield8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITFIELD8() {
        return sitfield8;
    }

    /**
     * Sets the value of the sitfield8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITFIELD8(String value) {
        this.sitfield8 = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ACCTWITHBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "acctwithbank"
    })
    public static class GACCTWITHBANK {

        @XmlElement(name = "ACCTWITHBANK")
        protected List<String> acctwithbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the acctwithbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the acctwithbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getACCTWITHBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getACCTWITHBANK() {
            if (acctwithbank == null) {
                acctwithbank = new ArrayList<String>();
            }
            return this.acctwithbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ACCTWITHBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "acctwithbk"
    })
    public static class GACCTWITHBK {

        @XmlElement(name = "ACCTWITHBK")
        protected List<String> acctwithbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the acctwithbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the acctwithbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getACCTWITHBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getACCTWITHBK() {
            if (acctwithbk == null) {
                acctwithbk = new ArrayList<String>();
            }
            return this.acctwithbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BAJELNOTES" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bajelnotes"
    })
    public static class GBAJELNOTES {

        @XmlElement(name = "BAJELNOTES")
        protected List<String> bajelnotes;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the bajelnotes property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bajelnotes property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBAJELNOTES().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getBAJELNOTES() {
            if (bajelnotes == null) {
                bajelnotes = new ArrayList<String>();
            }
            return this.bajelnotes;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BENBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "benbank"
    })
    public static class GBENBANK {

        @XmlElement(name = "BENBANK")
        protected List<String> benbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the benbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the benbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBENBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getBENBANK() {
            if (benbank == null) {
                benbank = new ArrayList<String>();
            }
            return this.benbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BENCUSTAR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bencustar"
    })
    public static class GBENCUSTAR {

        @XmlElement(name = "BENCUSTAR")
        protected List<String> bencustar;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the bencustar property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bencustar property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBENCUSTAR().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getBENCUSTAR() {
            if (bencustar == null) {
                bencustar = new ArrayList<String>();
            }
            return this.bencustar;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BENCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bencustomer"
    })
    public static class GBENCUSTOMER {

        @XmlElement(name = "BENCUSTOMER")
        protected List<String> bencustomer;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the bencustomer property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bencustomer property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBENCUSTOMER().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getBENCUSTOMER() {
            if (bencustomer == null) {
                bencustomer = new ArrayList<String>();
            }
            return this.bencustomer;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="BKTOBKINFO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bktobkinfo"
    })
    public static class GBKTOBKINFO {

        @XmlElement(name = "BKTOBKINFO")
        protected List<String> bktobkinfo;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the bktobkinfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bktobkinfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBKTOBKINFO().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getBKTOBKINFO() {
            if (bktobkinfo == null) {
                bktobkinfo = new ArrayList<String>();
            }
            return this.bktobkinfo;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CARDTXNDETAIL" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "cardtxndetail"
    })
    public static class GCARDTXNDETAIL {

        @XmlElement(name = "CARDTXNDETAIL")
        protected List<String> cardtxndetail;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the cardtxndetail property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the cardtxndetail property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCARDTXNDETAIL().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getCARDTXNDETAIL() {
            if (cardtxndetail == null) {
                cardtxndetail = new ArrayList<String>();
            }
            return this.cardtxndetail;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mCHARGETYPE" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="CHARGETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="CHARGEAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="CHARGEFOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "mchargetype"
    })
    public static class GCHARGETYPE {

        @XmlElement(name = "mCHARGETYPE")
        protected List<FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE> mchargetype;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the mchargetype property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the mchargetype property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMCHARGETYPE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE> getMCHARGETYPE() {
            if (mchargetype == null) {
                mchargetype = new ArrayList<FUNDSTRANSFERType.GCHARGETYPE.MCHARGETYPE>();
            }
            return this.mchargetype;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="CHARGETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="CHARGEAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="CHARGEFOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "chargetype",
            "chargeamt",
            "chargefor"
        })
        public static class MCHARGETYPE {

            @XmlElement(name = "CHARGETYPE")
            protected String chargetype;
            @XmlElement(name = "CHARGEAMT")
            protected String chargeamt;
            @XmlElement(name = "CHARGEFOR")
            protected String chargefor;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the chargetype property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCHARGETYPE() {
                return chargetype;
            }

            /**
             * Sets the value of the chargetype property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCHARGETYPE(String value) {
                this.chargetype = value;
            }

            /**
             * Gets the value of the chargeamt property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCHARGEAMT() {
                return chargeamt;
            }

            /**
             * Sets the value of the chargeamt property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCHARGEAMT(String value) {
                this.chargeamt = value;
            }

            /**
             * Gets the value of the chargefor property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCHARGEFOR() {
                return chargefor;
            }

            /**
             * Sets the value of the chargefor property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCHARGEFOR(String value) {
                this.chargefor = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="CHEQUEBENEFICI" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "chequebenefici"
    })
    public static class GCHEQUEBENEFICI {

        @XmlElement(name = "CHEQUEBENEFICI")
        protected List<String> chequebenefici;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the chequebenefici property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the chequebenefici property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCHEQUEBENEFICI().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getCHEQUEBENEFICI() {
            if (chequebenefici == null) {
                chequebenefici = new ArrayList<String>();
            }
            return this.chequebenefici;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mCOMMISSIONTYPE" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="COMMISSIONTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="COMMISSIONAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="COMMISSIONFOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "mcommissiontype"
    })
    public static class GCOMMISSIONTYPE {

        @XmlElement(name = "mCOMMISSIONTYPE")
        protected List<FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE> mcommissiontype;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the mcommissiontype property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the mcommissiontype property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMCOMMISSIONTYPE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE> getMCOMMISSIONTYPE() {
            if (mcommissiontype == null) {
                mcommissiontype = new ArrayList<FUNDSTRANSFERType.GCOMMISSIONTYPE.MCOMMISSIONTYPE>();
            }
            return this.mcommissiontype;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="COMMISSIONTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="COMMISSIONAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="COMMISSIONFOR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "commissiontype",
            "commissionamt",
            "commissionfor"
        })
        public static class MCOMMISSIONTYPE {

            @XmlElement(name = "COMMISSIONTYPE")
            protected String commissiontype;
            @XmlElement(name = "COMMISSIONAMT")
            protected String commissionamt;
            @XmlElement(name = "COMMISSIONFOR")
            protected String commissionfor;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the commissiontype property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCOMMISSIONTYPE() {
                return commissiontype;
            }

            /**
             * Sets the value of the commissiontype property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCOMMISSIONTYPE(String value) {
                this.commissiontype = value;
            }

            /**
             * Gets the value of the commissionamt property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCOMMISSIONAMT() {
                return commissionamt;
            }

            /**
             * Sets the value of the commissionamt property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCOMMISSIONAMT(String value) {
                this.commissionamt = value;
            }

            /**
             * Gets the value of the commissionfor property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCOMMISSIONFOR() {
                return commissionfor;
            }

            /**
             * Sets the value of the commissionfor property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCOMMISSIONFOR(String value) {
                this.commissionfor = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DATETIME" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "datetime"
    })
    public static class GDATETIME {

        @XmlElement(name = "DATETIME")
        protected List<String> datetime;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the datetime property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the datetime property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDATETIME().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getDATETIME() {
            if (datetime == null) {
                datetime = new ArrayList<String>();
            }
            return this.datetime;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DELIVERYOUTREF" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "deliveryoutref"
    })
    public static class GDELIVERYOUTREF {

        @XmlElement(name = "DELIVERYOUTREF")
        protected List<String> deliveryoutref;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the deliveryoutref property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the deliveryoutref property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDELIVERYOUTREF().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getDELIVERYOUTREF() {
            if (deliveryoutref == null) {
                deliveryoutref = new ArrayList<String>();
            }
            return this.deliveryoutref;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="EXTENDINFO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "extendinfo"
    })
    public static class GEXTENDINFO {

        @XmlElement(name = "EXTENDINFO")
        protected List<String> extendinfo;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the extendinfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the extendinfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEXTENDINFO().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getEXTENDINFO() {
            if (extendinfo == null) {
                extendinfo = new ArrayList<String>();
            }
            return this.extendinfo;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="FREETEXTMSGTO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "freetextmsgto"
    })
    public static class GFREETEXTMSGTO {

        @XmlElement(name = "FREETEXTMSGTO")
        protected List<String> freetextmsgto;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the freetextmsgto property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the freetextmsgto property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getFREETEXTMSGTO().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getFREETEXTMSGTO() {
            if (freetextmsgto == null) {
                freetextmsgto = new ArrayList<String>();
            }
            return this.freetextmsgto;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="IN3RDREIMBBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "in3RDREIMBBK"
    })
    public static class GIN3RDREIMBBK {

        @XmlElement(name = "IN3RDREIMBBK")
        protected List<String> in3RDREIMBBK;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the in3RDREIMBBK property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the in3RDREIMBBK property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIN3RDREIMBBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getIN3RDREIMBBK() {
            if (in3RDREIMBBK == null) {
                in3RDREIMBBK = new ArrayList<String>();
            }
            return this.in3RDREIMBBK;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INBENBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inbenbank"
    })
    public static class GINBENBANK {

        @XmlElement(name = "INBENBANK")
        protected List<String> inbenbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inbenbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inbenbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINBENBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINBENBANK() {
            if (inbenbank == null) {
                inbenbank = new ArrayList<String>();
            }
            return this.inbenbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INBENCUSTOMER" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inbencustomer"
    })
    public static class GINBENCUSTOMER {

        @XmlElement(name = "INBENCUSTOMER")
        protected List<String> inbencustomer;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inbencustomer property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inbencustomer property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINBENCUSTOMER().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINBENCUSTOMER() {
            if (inbencustomer == null) {
                inbencustomer = new ArrayList<String>();
            }
            return this.inbencustomer;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INBKTOBKINFO" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inbktobkinfo"
    })
    public static class GINBKTOBK {

        @XmlElement(name = "INBKTOBKINFO")
        protected List<String> inbktobkinfo;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inbktobkinfo property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inbktobkinfo property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINBKTOBKINFO().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINBKTOBKINFO() {
            if (inbktobkinfo == null) {
                inbktobkinfo = new ArrayList<String>();
            }
            return this.inbktobkinfo;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INCACCWITBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "incaccwitbk"
    })
    public static class GINCACCWITBK {

        @XmlElement(name = "INCACCWITBK")
        protected List<String> incaccwitbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the incaccwitbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the incaccwitbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINCACCWITBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINCACCWITBK() {
            if (incaccwitbk == null) {
                incaccwitbk = new ArrayList<String>();
            }
            return this.incaccwitbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INCBKTBKIN" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "incbktbkin"
    })
    public static class GINCBKTBKIN {

        @XmlElement(name = "INCBKTBKIN")
        protected List<String> incbktbkin;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the incbktbkin property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the incbktbkin property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINCBKTBKIN().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINCBKTBKIN() {
            if (incbktbkin == null) {
                incbktbkin = new ArrayList<String>();
            }
            return this.incbktbkin;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INCINTMEDBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "incintmedbk"
    })
    public static class GINCINTMEDBK {

        @XmlElement(name = "INCINTMEDBK")
        protected List<String> incintmedbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the incintmedbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the incintmedbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINCINTMEDBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINCINTMEDBK() {
            if (incintmedbk == null) {
                incintmedbk = new ArrayList<String>();
            }
            return this.incintmedbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INCORDBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "incordbk"
    })
    public static class GINCORDBK {

        @XmlElement(name = "INCORDBK")
        protected List<String> incordbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the incordbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the incordbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINCORDBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINCORDBK() {
            if (incordbk == null) {
                incordbk = new ArrayList<String>();
            }
            return this.incordbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ININSTRCODE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ininstrcode"
    })
    public static class GININSTRCODE {

        @XmlElement(name = "ININSTRCODE")
        protected List<String> ininstrcode;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the ininstrcode property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the ininstrcode property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getININSTRCODE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getININSTRCODE() {
            if (ininstrcode == null) {
                ininstrcode = new ArrayList<String>();
            }
            return this.ininstrcode;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ININTERMEDBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inintermedbk"
    })
    public static class GININTERMEDBK {

        @XmlElement(name = "ININTERMEDBK")
        protected List<String> inintermedbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inintermedbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inintermedbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getININTERMEDBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getININTERMEDBK() {
            if (inintermedbk == null) {
                inintermedbk = new ArrayList<String>();
            }
            return this.inintermedbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ININTMEDBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inintmedbank"
    })
    public static class GININTMEDBANK {

        @XmlElement(name = "ININTMEDBANK")
        protected List<String> inintmedbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inintmedbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inintmedbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getININTMEDBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getININTMEDBANK() {
            if (inintmedbank == null) {
                inintmedbank = new ArrayList<String>();
            }
            return this.inintmedbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INORDERINGBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inorderingbk"
    })
    public static class GINORDERINGBK {

        @XmlElement(name = "INORDERINGBK")
        protected List<String> inorderingbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inorderingbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inorderingbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINORDERINGBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINORDERINGBK() {
            if (inorderingbk == null) {
                inorderingbk = new ArrayList<String>();
            }
            return this.inorderingbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INORDERINGCUS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inorderingcus"
    })
    public static class GINORDERINGCUS {

        @XmlElement(name = "INORDERINGCUS")
        protected List<String> inorderingcus;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inorderingcus property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inorderingcus property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINORDERINGCUS().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINORDERINGCUS() {
            if (inorderingcus == null) {
                inorderingcus = new ArrayList<String>();
            }
            return this.inorderingcus;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INPAYDETAILS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inpaydetails"
    })
    public static class GINPAYDETAILS {

        @XmlElement(name = "INPAYDETAILS")
        protected List<String> inpaydetails;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inpaydetails property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inpaydetails property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINPAYDETAILS().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINPAYDETAILS() {
            if (inpaydetails == null) {
                inpaydetails = new ArrayList<String>();
            }
            return this.inpaydetails;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INPROCESSERR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inprocesserr"
    })
    public static class GINPROCESSERR {

        @XmlElement(name = "INPROCESSERR")
        protected List<String> inprocesserr;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inprocesserr property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inprocesserr property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINPROCESSERR().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINPROCESSERR() {
            if (inprocesserr == null) {
                inprocesserr = new ArrayList<String>();
            }
            return this.inprocesserr;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INPUTTER" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inputter"
    })
    public static class GINPUTTER {

        @XmlElement(name = "INPUTTER")
        protected List<String> inputter;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inputter property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inputter property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINPUTTER().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINPUTTER() {
            if (inputter == null) {
                inputter = new ArrayList<String>();
            }
            return this.inputter;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INREASONOVE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inreasonove"
    })
    public static class GINREASONOVE {

        @XmlElement(name = "INREASONOVE")
        protected List<String> inreasonove;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inreasonove property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inreasonove property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINREASONOVE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINREASONOVE() {
            if (inreasonove == null) {
                inreasonove = new ArrayList<String>();
            }
            return this.inreasonove;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INRECCORRBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inreccorrbk"
    })
    public static class GINRECCORRBK {

        @XmlElement(name = "INRECCORRBK")
        protected List<String> inreccorrbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inreccorrbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inreccorrbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINRECCORRBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINRECCORRBK() {
            if (inreccorrbk == null) {
                inreccorrbk = new ArrayList<String>();
            }
            return this.inreccorrbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INSENDCHG" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "insendchg"
    })
    public static class GINSENDCHG {

        @XmlElement(name = "INSENDCHG")
        protected List<String> insendchg;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the insendchg property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the insendchg property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINSENDCHG().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINSENDCHG() {
            if (insendchg == null) {
                insendchg = new ArrayList<String>();
            }
            return this.insendchg;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INSENDCORRBK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "insendcorrbk"
    })
    public static class GINSENDCORRBK {

        @XmlElement(name = "INSENDCORRBK")
        protected List<String> insendcorrbk;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the insendcorrbk property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the insendcorrbk property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINSENDCORRBK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINSENDCORRBK() {
            if (insendcorrbk == null) {
                insendcorrbk = new ArrayList<String>();
            }
            return this.insendcorrbk;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INSTRCTNCODE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "instrctncode"
    })
    public static class GINSTRCTNCODE {

        @XmlElement(name = "INSTRCTNCODE")
        protected List<String> instrctncode;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the instrctncode property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the instrctncode property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINSTRCTNCODE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINSTRCTNCODE() {
            if (instrctncode == null) {
                instrctncode = new ArrayList<String>();
            }
            return this.instrctncode;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INSWIFTMSG" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inswiftmsg"
    })
    public static class GINSWIFTMSG {

        @XmlElement(name = "INSWIFTMSG")
        protected List<String> inswiftmsg;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the inswiftmsg property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the inswiftmsg property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINSWIFTMSG().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINSWIFTMSG() {
            if (inswiftmsg == null) {
                inswiftmsg = new ArrayList<String>();
            }
            return this.inswiftmsg;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INTERMEDBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "intermedbank"
    })
    public static class GINTERMEDBANK {

        @XmlElement(name = "INTERMEDBANK")
        protected List<String> intermedbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the intermedbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the intermedbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINTERMEDBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINTERMEDBANK() {
            if (intermedbank == null) {
                intermedbank = new ArrayList<String>();
            }
            return this.intermedbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="INTIMEIND" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "intimeind"
    })
    public static class GINTIMEIND {

        @XmlElement(name = "INTIMEIND")
        protected List<String> intimeind;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the intimeind property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the intimeind property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getINTIMEIND().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getINTIMEIND() {
            if (intimeind == null) {
                intimeind = new ArrayList<String>();
            }
            return this.intimeind;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="MESSAGE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "message"
    })
    public static class GMESSAGE {

        @XmlElement(name = "MESSAGE")
        protected List<String> message;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the message property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the message property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMESSAGE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getMESSAGE() {
            if (message == null) {
                message = new ArrayList<String>();
            }
            return this.message;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mMSGTYPE" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="MSGTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="MSGDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "mmsgtype"
    })
    public static class GMSGTYPE {

        @XmlElement(name = "mMSGTYPE")
        protected List<FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE> mmsgtype;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the mmsgtype property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the mmsgtype property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMMSGTYPE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE> getMMSGTYPE() {
            if (mmsgtype == null) {
                mmsgtype = new ArrayList<FUNDSTRANSFERType.GMSGTYPE.MMSGTYPE>();
            }
            return this.mmsgtype;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="MSGTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="MSGDATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msgtype",
            "msgdate"
        })
        public static class MMSGTYPE {

            @XmlElement(name = "MSGTYPE")
            protected String msgtype;
            @XmlElement(name = "MSGDATE")
            protected String msgdate;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the msgtype property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMSGTYPE() {
                return msgtype;
            }

            /**
             * Sets the value of the msgtype property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMSGTYPE(String value) {
                this.msgtype = value;
            }

            /**
             * Gets the value of the msgdate property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMSGDATE() {
                return msgdate;
            }

            /**
             * Sets the value of the msgdate property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMSGDATE(String value) {
                this.msgdate = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ORDCUSTAR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ordcustar"
    })
    public static class GORDCUSTAR {

        @XmlElement(name = "ORDCUSTAR")
        protected List<String> ordcustar;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the ordcustar property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the ordcustar property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getORDCUSTAR().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getORDCUSTAR() {
            if (ordcustar == null) {
                ordcustar = new ArrayList<String>();
            }
            return this.ordcustar;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ORDERINGBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "orderingbank"
    })
    public static class GORDERINGBANK {

        @XmlElement(name = "ORDERINGBANK")
        protected List<String> orderingbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the orderingbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the orderingbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getORDERINGBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getORDERINGBANK() {
            if (orderingbank == null) {
                orderingbank = new ArrayList<String>();
            }
            return this.orderingbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ORDERINGCUST" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "orderingcust"
    })
    public static class GORDERINGCUST {

        @XmlElement(name = "ORDERINGCUST")
        protected List<String> orderingcust;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the orderingcust property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the orderingcust property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getORDERINGCUST().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getORDERINGCUST() {
            if (orderingcust == null) {
                orderingcust = new ArrayList<String>();
            }
            return this.orderingcust;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="OVERRIDE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "override"
    })
    public static class GOVERRIDE {

        @XmlElement(name = "OVERRIDE")
        protected List<String> override;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the override property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the override property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getOVERRIDE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getOVERRIDE() {
            if (override == null) {
                override = new ArrayList<String>();
            }
            return this.override;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PAYDETSAR" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "paydetsar"
    })
    public static class GPAYDETSAR {

        @XmlElement(name = "PAYDETSAR")
        protected List<String> paydetsar;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the paydetsar property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the paydetsar property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPAYDETSAR().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPAYDETSAR() {
            if (paydetsar == null) {
                paydetsar = new ArrayList<String>();
            }
            return this.paydetsar;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="PAYMENTDETAILS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "paymentdetails"
    })
    public static class GPAYMENTDETAILS {

        @XmlElement(name = "PAYMENTDETAILS")
        protected List<String> paymentdetails;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the paymentdetails property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the paymentdetails property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPAYMENTDETAILS().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getPAYMENTDETAILS() {
            if (paymentdetails == null) {
                paymentdetails = new ArrayList<String>();
            }
            return this.paymentdetails;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="RECCORRBANK" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "reccorrbank"
    })
    public static class GRECCORRBANK {

        @XmlElement(name = "RECCORRBANK")
        protected List<String> reccorrbank;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the reccorrbank property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the reccorrbank property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getRECCORRBANK().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getRECCORRBANK() {
            if (reccorrbank == null) {
                reccorrbank = new ArrayList<String>();
            }
            return this.reccorrbank;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mRELATEDMSG" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="RELATEDMSG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="sgTIMEIND" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="TIMEIND" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *                           &lt;/sequence>
     *                           &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "mrelatedmsg"
    })
    public static class GRELATEDMSG {

        @XmlElement(name = "mRELATEDMSG")
        protected List<FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG> mrelatedmsg;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the mrelatedmsg property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the mrelatedmsg property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMRELATEDMSG().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG> getMRELATEDMSG() {
            if (mrelatedmsg == null) {
                mrelatedmsg = new ArrayList<FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG>();
            }
            return this.mrelatedmsg;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="RELATEDMSG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="sgTIMEIND" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="TIMEIND" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
         *                 &lt;/sequence>
         *                 &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "relatedmsg",
            "sgTIMEIND"
        })
        public static class MRELATEDMSG {

            @XmlElement(name = "RELATEDMSG")
            protected String relatedmsg;
            protected FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND sgTIMEIND;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the relatedmsg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getRELATEDMSG() {
                return relatedmsg;
            }

            /**
             * Sets the value of the relatedmsg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setRELATEDMSG(String value) {
                this.relatedmsg = value;
            }

            /**
             * Gets the value of the sgTIMEIND property.
             * 
             * @return
             *     possible object is
             *     {@link FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND }
             *     
             */
            public FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND getSgTIMEIND() {
                return sgTIMEIND;
            }

            /**
             * Sets the value of the sgTIMEIND property.
             * 
             * @param value
             *     allowed object is
             *     {@link FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND }
             *     
             */
            public void setSgTIMEIND(FUNDSTRANSFERType.GRELATEDMSG.MRELATEDMSG.SgTIMEIND value) {
                this.sgTIMEIND = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="TIMEIND" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
             *       &lt;/sequence>
             *       &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "timeind"
            })
            public static class SgTIMEIND {

                @XmlElement(name = "TIMEIND")
                protected List<String> timeind;
                @XmlAttribute(name = "sg")
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger sg;

                /**
                 * Gets the value of the timeind property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the timeind property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getTIMEIND().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link String }
                 * 
                 * 
                 */
                public List<String> getTIMEIND() {
                    if (timeind == null) {
                        timeind = new ArrayList<String>();
                    }
                    return this.timeind;
                }

                /**
                 * Gets the value of the sg property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getSg() {
                    return sg;
                }

                /**
                 * Sets the value of the sg property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setSg(BigInteger value) {
                    this.sg = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mSENDTOPARTY" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="SENDTOPARTY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="sgBKTOBKOUT" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="BKTOBKOUT" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *                           &lt;/sequence>
     *                           &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="MESSAGETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "msendtoparty"
    })
    public static class GSENDTOPARTY {

        @XmlElement(name = "mSENDTOPARTY")
        protected List<FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY> msendtoparty;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the msendtoparty property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the msendtoparty property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMSENDTOPARTY().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY> getMSENDTOPARTY() {
            if (msendtoparty == null) {
                msendtoparty = new ArrayList<FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY>();
            }
            return this.msendtoparty;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="SENDTOPARTY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="sgBKTOBKOUT" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="BKTOBKOUT" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
         *                 &lt;/sequence>
         *                 &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="MESSAGETYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "sendtoparty",
            "sgBKTOBKOUT",
            "messagetype"
        })
        public static class MSENDTOPARTY {

            @XmlElement(name = "SENDTOPARTY")
            protected String sendtoparty;
            protected FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT sgBKTOBKOUT;
            @XmlElement(name = "MESSAGETYPE")
            protected String messagetype;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the sendtoparty property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSENDTOPARTY() {
                return sendtoparty;
            }

            /**
             * Sets the value of the sendtoparty property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSENDTOPARTY(String value) {
                this.sendtoparty = value;
            }

            /**
             * Gets the value of the sgBKTOBKOUT property.
             * 
             * @return
             *     possible object is
             *     {@link FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT }
             *     
             */
            public FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT getSgBKTOBKOUT() {
                return sgBKTOBKOUT;
            }

            /**
             * Sets the value of the sgBKTOBKOUT property.
             * 
             * @param value
             *     allowed object is
             *     {@link FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT }
             *     
             */
            public void setSgBKTOBKOUT(FUNDSTRANSFERType.GSENDTOPARTY.MSENDTOPARTY.SgBKTOBKOUT value) {
                this.sgBKTOBKOUT = value;
            }

            /**
             * Gets the value of the messagetype property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMESSAGETYPE() {
                return messagetype;
            }

            /**
             * Sets the value of the messagetype property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMESSAGETYPE(String value) {
                this.messagetype = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="BKTOBKOUT" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
             *       &lt;/sequence>
             *       &lt;attribute name="sg" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "bktobkout"
            })
            public static class SgBKTOBKOUT {

                @XmlElement(name = "BKTOBKOUT")
                protected List<String> bktobkout;
                @XmlAttribute(name = "sg")
                @XmlSchemaType(name = "positiveInteger")
                protected BigInteger sg;

                /**
                 * Gets the value of the bktobkout property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the bktobkout property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getBKTOBKOUT().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link String }
                 * 
                 * 
                 */
                public List<String> getBKTOBKOUT() {
                    if (bktobkout == null) {
                        bktobkout = new ArrayList<String>();
                    }
                    return this.bktobkout;
                }

                /**
                 * Gets the value of the sg property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BigInteger }
                 *     
                 */
                public BigInteger getSg() {
                    return sg;
                }

                /**
                 * Sets the value of the sg property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BigInteger }
                 *     
                 */
                public void setSg(BigInteger value) {
                    this.sg = value;
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="SIGNATORY" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "signatory"
    })
    public static class GSIGNATORY {

        @XmlElement(name = "SIGNATORY")
        protected List<String> signatory;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the signatory property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the signatory property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSIGNATORY().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getSIGNATORY() {
            if (signatory == null) {
                signatory = new ArrayList<String>();
            }
            return this.signatory;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="SIMESSAGE" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "simessage"
    })
    public static class GSIMESSAGE {

        @XmlElement(name = "SIMESSAGE")
        protected List<String> simessage;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the simessage property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the simessage property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSIMESSAGE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getSIMESSAGE() {
            if (simessage == null) {
                simessage = new ArrayList<String>();
            }
            return this.simessage;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mSND.TO.PAR.AR" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="SNDTOPARAR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="BKTOBKAR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "msndtoparar"
    })
    public static class GSNDTOPARAR {

        @XmlElement(name = "mSND.TO.PAR.AR")
        protected List<FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR> msndtoparar;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the msndtoparar property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the msndtoparar property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMSNDTOPARAR().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR> getMSNDTOPARAR() {
            if (msndtoparar == null) {
                msndtoparar = new ArrayList<FUNDSTRANSFERType.GSNDTOPARAR.MSNDTOPARAR>();
            }
            return this.msndtoparar;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="SNDTOPARAR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="BKTOBKAR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "sndtoparar",
            "bktobkar"
        })
        public static class MSNDTOPARAR {

            @XmlElement(name = "SNDTOPARAR")
            protected String sndtoparar;
            @XmlElement(name = "BKTOBKAR")
            protected String bktobkar;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the sndtoparar property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSNDTOPARAR() {
                return sndtoparar;
            }

            /**
             * Sets the value of the sndtoparar property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSNDTOPARAR(String value) {
                this.sndtoparar = value;
            }

            /**
             * Gets the value of the bktobkar property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getBKTOBKAR() {
                return bktobkar;
            }

            /**
             * Sets the value of the bktobkar property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setBKTOBKAR(String value) {
                this.bktobkar = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="STMTNOS" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "stmtnos"
    })
    public static class GSTMTNOS {

        @XmlElement(name = "STMTNOS")
        protected List<String> stmtnos;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the stmtnos property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the stmtnos property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getSTMTNOS().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getSTMTNOS() {
            if (stmtnos == null) {
                stmtnos = new ArrayList<String>();
            }
            return this.stmtnos;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="mTAXTYPE" maxOccurs="unbounded" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="TAXTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                   &lt;element name="TAXAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                 &lt;/sequence>
     *                 &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *       &lt;attribute name="g" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "mtaxtype"
    })
    public static class GTAXTYPE {

        @XmlElement(name = "mTAXTYPE")
        protected List<FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE> mtaxtype;
        @XmlAttribute(name = "g")
        @XmlSchemaType(name = "positiveInteger")
        protected BigInteger g;

        /**
         * Gets the value of the mtaxtype property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the mtaxtype property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getMTAXTYPE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE }
         * 
         * 
         */
        public List<FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE> getMTAXTYPE() {
            if (mtaxtype == null) {
                mtaxtype = new ArrayList<FUNDSTRANSFERType.GTAXTYPE.MTAXTYPE>();
            }
            return this.mtaxtype;
        }

        /**
         * Gets the value of the g property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getG() {
            return g;
        }

        /**
         * Sets the value of the g property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setG(BigInteger value) {
            this.g = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="TAXTYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *         &lt;element name="TAXAMT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *       &lt;/sequence>
         *       &lt;attribute name="m" type="{http://www.w3.org/2001/XMLSchema}positiveInteger" />
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "taxtype",
            "taxamt"
        })
        public static class MTAXTYPE {

            @XmlElement(name = "TAXTYPE")
            protected String taxtype;
            @XmlElement(name = "TAXAMT")
            protected String taxamt;
            @XmlAttribute(name = "m")
            @XmlSchemaType(name = "positiveInteger")
            protected BigInteger m;

            /**
             * Gets the value of the taxtype property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getTAXTYPE() {
                return taxtype;
            }

            /**
             * Sets the value of the taxtype property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setTAXTYPE(String value) {
                this.taxtype = value;
            }

            /**
             * Gets the value of the taxamt property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getTAXAMT() {
                return taxamt;
            }

            /**
             * Sets the value of the taxamt property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setTAXAMT(String value) {
                this.taxamt = value;
            }

            /**
             * Gets the value of the m property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getM() {
                return m;
            }

            /**
             * Sets the value of the m property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setM(BigInteger value) {
                this.m = value;
            }

        }

    }

}
