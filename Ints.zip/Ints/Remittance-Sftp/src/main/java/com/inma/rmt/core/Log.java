/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.core;

import java.util.Date;
import lombok.Data;
import org.beanio.annotation.Field;
import org.beanio.annotation.Record;

/**
 *
 * @author nmrehman
 */
@Data
@Record(minOccurs = 0, maxOccurs = -1, name = "log")
public class Log {

    @Field
    private String bank;
    @Field
    private String fileName;
    @Field(format = "ddMMyyyy")//HH:mm:ss
    private Date date;
    @Field(format = "HH:mm:ss")//HH:mm:ss
    private Date time;
    @Field
    private String system;
    @Field
    private String type;
    @Field
    private String status;
    @Field
    private String errorMsg;

    public Log() {
    }

    public Log(String bank, String fileName, Date date, String status, String type, String errorMsg, String system) {
        this.bank = bank;
        this.fileName = fileName;
        this.date = date;
        this.time = date;
        this.status = status;
        this.type = type;
        this.errorMsg = errorMsg;
        this.system = system;
    }

}
