/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.core;

import com.inma.rmt.config.AppProperties;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.commons.vfs2.FileExtensionSelector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemManager;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.VFS;
import org.beanio.BeanWriter;
import org.beanio.StreamFactory;
import org.beanio.builder.DelimitedParserBuilder;
import org.beanio.builder.StreamBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
public abstract class AbstractProvider implements Provider {

    protected final static Logger log = LoggerFactory.getLogger(AbstractProvider.class);
    protected AppProperties properties = AppProperties.getInstance();
    protected FileSystemManager fsManager;
    protected BouncyCastleGnuPGEncryption gpgEncryption = new BouncyCastleGnuPGEncryption();
    protected ZipEncryption zipEncryption = new ZipEncryption();
    private static final DateFormat dateFormat = new SimpleDateFormat("ddMMyyy");

    public AbstractProvider() {
        try {
            fsManager = VFS.getManager();
        } catch (FileSystemException ex) {
            log.error("Not able initiate VFS manger");
        }
    }

    @Override
    public void pull() {
        if (!properties.getRPULL_COMM_TYPE().equals("JAVA")) {
            System.out.println("Invalid Communction Channel. Kindly check the properties file!");
            return;
        }

        List<Log> logs = new ArrayList<Log>();
        Type pull = Type.PULL;
        String fileName = "Connectivity";
        try {
            FileObject fileObjectRemote = fsManager.resolveFile(connection(pull), options(pull));
            FileObject fileObjectClient = fsManager.resolveFile(properties.getRPULL_LCL_DIR());
            for (FileObject file : fileObjectRemote.findFiles(new FileExtensionSelector(properties.getRPULL_MFILE_EXT()))) {
                fileName = file.getName().getBaseName();
                log.info("Downloading the remittance file " + fileName);

                FileObject clientFile = fileObjectClient.resolveFile(fileName);
                clientFile.copyFrom(file, Selectors.SELECT_SELF);

                if (properties.isRPULL_GNUPG_DECRYPT_FLAG()) {
                    try {
                        log.info("Decrypting the GnuPG file " + fileName);
                        gpgEncryption.decryptFile(clientFile.getURL().toURI().getPath(), properties.getRPULL_LCL_DIR(),
                                properties.getGNUPG_DEC_PRIVATE_KEY(), properties.getGNUPG_ENC_PUBLIC_KEY(), properties.getGNUPG_DEC_PASSPHARASE());
                    } catch (URISyntaxException ex) {
                        log.error("Exception on GnuPG file name : " + ex);
                    }
                } else if (properties.isRPULL_ZIP_DCYPT_FLAG()) {
                    try {
                        log.info("Decrypting the ZIP file " + fileName);
                        zipEncryption.decrypt(clientFile.getURL().toURI().getPath(), properties.getZIP_ENC_PASSWORD(), properties.getRPULL_LCL_DIR());
                    } catch (URISyntaxException ex) {
                        log.error("Exception on ZIP file name : " + ex);
                    }
                }

                if (properties.isRPULL_DEL_REMOTE()) {
                    /*if (!properties.getRPULL_BKP_DIR().isEmpty()) { //InFuture We will add this feature
                     FileObject fileObjectBkp = fsManager.resolveFile(properties.getRPULL_BKP_DIR() + "/" + file.getName().getBaseName() + "_SENT");
                     fileObjectBkp.copyFrom(file, Selectors.SELECT_SELF);
                     }*/
                    file.delete();
                    String cFileName = fileName.replace("." + file.getName().getExtension(), properties.getRPULL_CFILE_EXT());
                    FileObject cFile = fileObjectRemote.resolveFile(cFileName);
                    if (cFile.exists()) {
                        cFile.delete();
                    }
                }
                if (properties.isRPULL_CFILE_ON_COMPL()) {
                    FileObject tochFile = fileObjectClient.resolveFile(file.getName().getBaseName() + properties.getRPULL_CFILE_EXT());
                    tochFile.createFile();
                }
                logs.add(new Log(properties.getBankName(), fileName, new Date(), TxnStatus.SENT.name(), pull.name(), "", properties.getFROM_SYSTEM()));
            }
        } catch (FileSystemException ex) {
            logs.add(new Log(properties.getBankName(), fileName, new Date(), TxnStatus.FAILURE.name(), pull.name(), ex.getMessage(), properties.getFROM_SYSTEM()));
            log.error("Exception while pulling the file : " + ex.getMessage());
        } finally {
            writeLog(logs);
        }
    }

    @Override
    public void push() {
        List<Log> logs = new ArrayList<Log>();
        Type push = Type.PUSH;
        String fileName = "Connectivity";
        try {
            if (!properties.getRPUSH_COMM_TYPE().equals("JAVA")) {
                System.out.println("Invalid Communction Channel. Kindly check the properties file!");
                return;
            }

            FileObject fileObjectRemote = fsManager.resolveFile(connection(push), options(push));
            FileObject fileObjectClient = fsManager.resolveFile(properties.getRPUSH_LCL_DIR());
            for (FileObject file : fileObjectClient.findFiles(new FileExtensionSelector(properties.getRPUSH_MFILE_EXT()))) {
                fileName = file.getName().getBaseName();
                log.info("Uploading the File --> " + fileName);

                if (properties.isRPUSH_GNUPG_ENC_FLAG()) {
                    try {
                        log.info("Encrypting the GnuPG file " + fileName);
                        gpgEncryption.encryptFile(file.getURL().toURI().getPath(), file.getURL().toURI().getPath() + properties.getGNUPG_ENC_EXT(), properties.getGNUPG_ENC_PUBLIC_KEY());

                        String encFileName = fileName + properties.getGNUPG_ENC_EXT();
                        FileObject encFileObject = fileObjectClient.resolveFile(encFileName);
                        FileObject remoteFile = fileObjectRemote.resolveFile(encFileName);
                        remoteFile.copyFrom(encFileObject, Selectors.SELECT_SELF);
                        if (properties.isRPUSH_DEL_LOCAL()) {
                            encFileObject.delete();
                        }
                    } catch (URISyntaxException ex) {
                        log.error("Exception on GnuPG file name : " + ex);
                    }
                } else if (properties.isRPUSH_ZIP_ENC_FLAG()) {
                    try {
                        log.info("Encrypting the ZIP file " + file.getName().getBaseName());
                        String zipFileName = fileName + properties.getZIP_FILE_EXT();
                        zipEncryption.encrypt(properties.getRPUSH_LCL_DIR() + zipFileName, properties.getZIP_ENC_PASSWORD(), file.getURL().toURI().getPath());

                        FileObject zipFileObject = fileObjectClient.resolveFile(zipFileName); //Copy Zip File                        
                        FileObject remoteFile = fileObjectRemote.resolveFile(zipFileName);
                        remoteFile.copyFrom(zipFileObject, Selectors.SELECT_SELF);
                        if (properties.isRPUSH_DEL_LOCAL()) {
                            zipFileObject.delete();
                        }
                    } catch (URISyntaxException ex) {
                        log.error("Exception on ZIP file name : " + ex);
                    }
                } else {
                    FileObject remoteFile = fileObjectRemote.resolveFile(file.getName().getBaseName());
                    remoteFile.copyFrom(file, Selectors.SELECT_SELF);
                }

                if (properties.isRPUSH_DEL_LOCAL()) {
                    if (!properties.getRPUSH_BKP_DIR().isEmpty()) {
                        FileObject fileObjectBkp = fsManager.resolveFile(properties.getRPUSH_BKP_DIR() + "/" + fileName + "_SENT");
                        fileObjectBkp.copyFrom(file, Selectors.SELECT_SELF);
                    }
                    file.delete();
                }

                if (properties.isRPUSH_CFILE_ON_COMPL()) {
                    FileObject tochFile = fileObjectRemote.resolveFile(fileName + properties.getRPUSH_CFILE_EXT());
                    tochFile.createFile();
                }
                logs.add(new Log(properties.getBankName(), fileName, new Date(), TxnStatus.SENT.name(), push.name(), "", properties.getFROM_SYSTEM()));
            }
        } catch (FileSystemException ex) {
            logs.add(new Log(properties.getBankName(), fileName, new Date(), TxnStatus.FAILURE.name(), push.name(), ex.getMessage(), properties.getFROM_SYSTEM()));
            log.error("Exception while pushing the file : " + ex.getMessage());
        } finally {
            writeLog(logs);
        }
    }

    @Override
    public void ls() {
        try {
            Type pull = Type.PULL;
            FileObject fileObjectRemote = fsManager.resolveFile(connection(pull), options(pull));
            for (FileObject file : fileObjectRemote.getChildren()) {
                System.out.println("File LS --> " + file.getName().getBaseName());
            }
        } catch (FileSystemException ex) {
            log.error("Exception while listing the file: " + ex);
        }
    }

    public void writeLog(Log log) {
        writeLog(Arrays.asList(log));
    }

    public void writeLog(List<Log> logs) {
        StreamFactory factory = StreamFactory.newInstance();
        StreamBuilder builder = new StreamBuilder("mapping")
                .format("csv")
                .parser(new DelimitedParserBuilder(properties.getLOG_WRITE_DLM().charAt(0)))
                .addRecord(Log.class);
        factory.define(builder);
        try {
            //BeanWriter out = factory.createWriter("mapping", new PrintWriter(System.out));
            String fileName = properties.getBankName() + "_" + dateFormat.format(new Date()) + ".txt";
            FileWriter fout = new FileWriter(properties.getLOG_WRITE_PATH() + fileName, true);
            BeanWriter out = factory.createWriter("mapping", fout);
            for (Log lg : logs) {
                out.write(lg);
            }
            out.flush();
            out.close();
        } catch (IOException ex) {
            log.error("Error while Saving Log file " + ex);
        }
    }
}
