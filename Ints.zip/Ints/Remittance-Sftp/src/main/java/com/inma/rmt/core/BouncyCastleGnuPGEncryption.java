/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Iterator;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPCompressedData;
import org.bouncycastle.openpgp.PGPCompressedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPEncryptedDataList;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPObjectFactory;
import org.bouncycastle.openpgp.PGPPrivateKey;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyEncryptedData;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.bouncycastle.openpgp.PGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.jcajce.JcaPGPObjectFactory;
import org.bouncycastle.openpgp.operator.bc.BcKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.bc.BcPBESecretKeyDecryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.bc.BcPGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyDataDecryptorFactory;
import org.bouncycastle.openpgp.operator.bc.BcPublicKeyKeyEncryptionMethodGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
public class BouncyCastleGnuPGEncryption {

    protected final static Logger log = LoggerFactory.getLogger(BouncyCastleGnuPGEncryption.class);

    /**
     *
     * The below method will read and import your secret key from .asc file:
     *
     * @param in
     * @param keyId
     * @return
     *
     */
    public PGPSecretKey readSecretKeyFromCol(InputStream in, long keyId) {
        try {
            in = PGPUtil.getDecoderStream(in);
            PGPSecretKeyRingCollection pgpSec = new PGPSecretKeyRingCollection(in, new BcKeyFingerprintCalculator());
            PGPSecretKey key = pgpSec.getSecretKey(keyId);
            if (key == null) {
                throw new IllegalArgumentException("Can't find encryption key in key ring.");
            }
            return key;
        } catch (IOException ex) {
            log.error("Exception in Loading Private File : " + ex);
        } catch (PGPException ex) {
            log.error("Exception in Loading Private File : " + ex);
        }
        return null;
    }

    /**
     *
     * The below method will read and import your public key from .asc file:
     *
     * @param in
     * @return
     *
     */
    @SuppressWarnings("rawtypes")
    public PGPPublicKey readPublicKeyFromCol(InputStream in) {
        PGPPublicKey key = null;
        try {
            in = PGPUtil.getDecoderStream(in);
            PGPPublicKeyRingCollection pgpPub = new PGPPublicKeyRingCollection(in, new BcKeyFingerprintCalculator());

            Iterator rIt = pgpPub.getKeyRings();
            while (key == null && rIt.hasNext()) {
                PGPPublicKeyRing kRing = (PGPPublicKeyRing) rIt.next();
                Iterator kIt = kRing.getPublicKeys();
                while (key == null && kIt.hasNext()) {
                    PGPPublicKey k = (PGPPublicKey) kIt.next();
                    if (k.isEncryptionKey()) {
                        key = k;
                    }
                }
            }
            if (key == null) {
                throw new IllegalArgumentException("Can't find encryption key in key ring.");
            }
        } catch (IOException ex) {
            log.error("Exception in Loading Public File : " + ex);
        } catch (PGPException ex) {
            log.error("Exception in  Loading Public File : " + ex);
        }
        return key;
    }

    public void decryptFile(String sourceFile, String outDirPath, String privateKey, String publicKey, String password) {
        try {
            InputStream file = new FileInputStream(sourceFile);
            InputStream secKeyIn = new FileInputStream(privateKey);
            InputStream pubKeyIn = new FileInputStream(publicKey);
            char[] pass = password.toCharArray();
            Security.addProvider(new BouncyCastleProvider());
            //PGPPublicKey pubKey = readPublicKeyFromCol(pubKeyIn);
            //PGPSecretKey secKey;//= readSecretKeyFromCol(secKeyIn, pubKey.getKeyID());
            file = PGPUtil.getDecoderStream(file);
            JcaPGPObjectFactory pgpFact;
            PGPObjectFactory pgpF = new PGPObjectFactory(file, new BcKeyFingerprintCalculator());
            Object o = pgpF.nextObject();
            PGPEncryptedDataList encList;

            if (o instanceof PGPEncryptedDataList) {
                encList = (PGPEncryptedDataList) o;
            } else {
                encList = (PGPEncryptedDataList) pgpF.nextObject();
            }

            Iterator<PGPPublicKeyEncryptedData> itt = encList.getEncryptedDataObjects();
            PGPPrivateKey sKey = null;
            PGPPublicKeyEncryptedData encP = null;
            PGPSecretKey secKey;

            while (sKey == null && itt.hasNext()) {
                encP = itt.next();
                secKey = readSecretKeyFromCol(secKeyIn, encP.getKeyID());
                sKey = secKey.extractPrivateKey(new BcPBESecretKeyDecryptorBuilder(new BcPGPDigestCalculatorProvider()).build(pass));
            }
            if (sKey == null) {
                throw new IllegalArgumentException("Secret key for message not found.");
            }

            InputStream clear = encP.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));
            pgpFact = new JcaPGPObjectFactory(clear);
            PGPCompressedData c1 = (PGPCompressedData) pgpFact.nextObject();
            pgpFact = new JcaPGPObjectFactory(c1.getDataStream());
            PGPLiteralData ld = (PGPLiteralData) pgpFact.nextObject();
            ByteArrayOutputStream bOut = new ByteArrayOutputStream();

            InputStream inLd = ld.getDataStream();
            int ch;
            while ((ch = inLd.read()) >= 0) {
                bOut.write(ch);
            }

            bOut.writeTo(new FileOutputStream(new File(outDirPath + "/" + ld.getFileName()))); //ld.getFileName();
            //return bOut;
        } catch (IOException ex) {
            log.error("Exception in Creating GnuPG Decrypting File : " + ex);
        } catch (PGPException ex) {
            log.error("Exception in Creating GnuPG Decrypting File : " + ex);
        }
    }

    public void encryptFile(String fileName, String encryptedOutFile, String publicKey) {
        try {
            FileInputStream fileInputStream = new FileInputStream(publicKey);
            PGPPublicKey encKey = readPublicKeyFromCol(new FileInputStream(publicKey));
            OutputStream out = new FileOutputStream(encryptedOutFile);
            Security.addProvider(new BouncyCastleProvider());
            ByteArrayOutputStream bOut = new ByteArrayOutputStream();
            PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZIP);
            PGPUtil.writeFileToLiteralData(comData.open(bOut), PGPLiteralData.BINARY, new File(fileName));
            comData.close();
            PGPEncryptedDataGenerator cPk = new PGPEncryptedDataGenerator(new BcPGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.TRIPLE_DES).setSecureRandom(new SecureRandom()));
            cPk.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));
            byte[] bytes = bOut.toByteArray();
            OutputStream cOut = cPk.open(out, bytes.length);
            cOut.write(bytes);
            cOut.close();
            out.close();
        } catch (IOException ex) {
            log.error("Exception in Loading Public Key File : " + ex);
        } catch (PGPException ex) {
            log.error("Exception in Creating GnuPG Encrypting File : " + ex);
        }
    }

}
