/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.core;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
import org.slf4j.LoggerFactory;

/**
 *
 * @author nmrehman
 */
public class ZipEncryption {

    protected final static org.slf4j.Logger log = LoggerFactory.getLogger(ZipEncryption.class);

    public void encrypt(String zipFileName, String password, String... files) {
        try {
            ZipFile zipFile = new ZipFile(zipFileName);
            for (String file : files) {
                zipFile.addFile(new File(file), zipParameters(password));
            }
        } catch (ZipException ex) {
            log.error("Exception in Encrypting Zip File " + zipFileName + ". " + ex);
        }
    }

    public void decrypt(String zipFileName, String password, String extractPath) {
        try {
            ZipFile zipFile = new ZipFile(zipFileName);
            if (zipFile.isEncrypted()) {
                zipFile.setPassword(password);
            }
            zipFile.extractAll(extractPath);
        } catch (ZipException ex) {
            log.error("Exception in Decrypted Zip File " + zipFileName + ". " + ex);
        }
    }

    public ZipParameters zipParameters(String password) {
        ZipParameters parameters = new ZipParameters();
        //DEFLATE_LEVEL_FASTEST     - Lowest compression level but higher speed of compression
        //DEFLATE_LEVEL_FAST        - Low compression level but higher speed of compression
        //DEFLATE_LEVEL_NORMAL  - Optimal balance between compression level/speed
        //DEFLATE_LEVEL_MAXIMUM     - High compression level with a compromise of speed
        //DEFLATE_LEVEL_ULTRA       - Highest compression level but low speed
        parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
        parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to deflate compression
        parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_STANDARD);//ENC_METHOD_AES
        parameters.setEncryptFiles(true);
        //AES_STRENGTH_128 - For both encryption and decryption
        //AES_STRENGTH_256 - For both encryption and decryption
        //parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
        parameters.setPassword(password);
        return parameters;
    }

}
