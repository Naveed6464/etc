/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt.sftp;

import com.jcraft.jsch.UserInfo;

/**
 *
 * @author nmrehman
 */
public class SftpPassphraseUserInfo implements UserInfo {

    private String passphrase = null;

    public SftpPassphraseUserInfo(final String pp) {
        passphrase = pp;
    }

    @Override
    public String getPassphrase() {
        return passphrase;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public boolean promptPassword(String string) {
        return true;
    }

    @Override
    public boolean promptPassphrase(String string) {
        return false;
    }

    @Override
    public boolean promptYesNo(String string) {
        return true;
    }

    @Override
    public void showMessage(String string) {

    }

}
