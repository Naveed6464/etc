package com.inma.rmt;

import java.io.*;
import com.linuxense.javadbf.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class InmaDBFReader {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    public static void main(String args[]) {
        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.Main <FileName or FileName with Full Path>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }

        try {
            // create a DBFReader object            
            InputStream inputStream = new FileInputStream(args[0]); // take dbf file as program argument
            DBFReader reader = new DBFReader(inputStream);

            FileOutputStream outputStream = new FileOutputStream(args[1]);
            OutputStreamWriter osw = new OutputStreamWriter(outputStream);
            BufferedWriter bw = new BufferedWriter(osw);

            String delim = args[2];
            // get the field count if you want for some reasons like the following            
            int numberOfFields = reader.getFieldCount();

            // use this count to fetch all field information if required            
            for (int i = 0; i < numberOfFields; i++) {
                DBFField field = reader.getField(i);
                // do something with it if you want
                // refer the JavaDoc API reference for more details
                //
                //System.out.print( "\"" + field.getName() + "\"|");
                //bw.write("\"" + field.getName() + "\"|");
                bw.write(field.getName() + delim);
            }
            // Now, lets us start reading the rows                       
            bw.write("\n");
            Object[] rowObjects;
            String Str1;

            while ((rowObjects = reader.nextRecord()) != null) {
                for (int i = 0; i < rowObjects.length; i++) {
                    try {
                        Str1 = rowObjects[i].toString();
                    } catch (Exception e) {
                        Str1 = "";
                    }
                    //Str1 = rowObjects[i].toString();
                    bw.write(Str1.trim() + delim);
                }
                //System.out.println("");
                bw.write("\n");
            }

            bw.close();
            // By now, we have itereated through all of the rows
            inputStream.close();
        } catch (DBFException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
