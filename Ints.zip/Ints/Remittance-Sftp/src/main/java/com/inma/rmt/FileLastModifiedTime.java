/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inma.rmt;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * <h1> FileLastModifiedTime </h1>
 *
 * FileLastModifiedTime implements an application that simply prints the last
 * modified time of the file.
 *
 * @author nmrehman@alinma.com
 * @version 1.0
 * @since 2015-03-31
 */
public class FileLastModifiedTime {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            String message = "Usage: java -cp <jar files path> com.inma.rmt.Main <FileName or FileName with Full Path>";
            System.out.println(dateFormat.format(cal.getTime()) + " : " + message);
            System.exit(1);
        }
        File file = new File(args[0]);
        System.out.println(file.lastModified());
    }

}
