#sftp -o IdentityFile=/home/rmftpprd/.ssh/id_rsa alinma01@103.5.228.6
#PASSWD=alinma
############################
RUNDIR=/rmtsftp/rmtprd/remittance/bin
BankName=mbt
cd $RUNDIR
LOGFILEPATH=$RUNDIR/../log
LOGFILE=$BankName2Sftp2.log`date +%y%m%d`
#
#User=pinm0001
User=pin20001
HOST=222.127.150.108
DestDir=../mbt/inward
#SrcDir=/Metrobank/RPD/Tie-up/Principal/INMASARI/FEEDBACK/
SrcDir=/Metrobank/RPD/Tie-up/Principal/INMASAR2/FEEDBACK
mfile=*.PRC
cd $DestDir
#
sftp $User@$HOST <<EOF  | tee -a $LOGFILEPATH/$LOGFILE
        cd $SrcDir
	prom
        mget $mfile
        rm $mfile
#        mdelete $mfile
        quit
EOF
