####################################################
##                                                ##
##  Remittance-SFTP start up script for metro     ##
##                                                ## 
####################################################
#### Naveed 
#### 16th March 2016
RUNDIR=/rmtsftp/rmtprd/remittance/bin
cd $RUNDIR
sh Remittance-Sftp.sh /rmtsftp/rmtprd/remittance/conf/MBT.properties