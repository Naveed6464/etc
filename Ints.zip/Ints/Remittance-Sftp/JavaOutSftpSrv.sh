#################################################################
RUNDIR=/rmtsftp/rmtprd/remittance/bin
#
cd $RUNDIR
stat=`cat JavaServcie.Status`
if [ $stat = "RUNNING" ]
then
    echo "Java Out Service Already Running Exiting..."
    exit
fi
echo "RUNNING" > JavaServcie.Status
LOGFILEPATH=$RUNDIR/../log
################################################################
for file in `ls ../conf/???.properties`
do 
# Safe Exist if flag is set to STOPPED
######################################
    file1=../conf/$file
    BankName=`ParseProp.sh $file1 BankName`
    LOGFILE=Stp2CorrSrv_$BankName.log`date +%y%m%d`
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"  >> $LOGFILEPATH/$LOGFILE
    echo "Sftp Outward service started @ `date +%A\ %Y%m%d_%H:%M:%S`"  >> $LOGFILEPATH/$LOGFILE
#
    stat=`cat JavaServcie.Status`
    if [ $stat = "STOPPED" ]
    then
        echo "(1)Stopped Singnal Received Exiting..."  >> $LOGFILEPATH/$LOGFILE
        exit
    fi
#
    echo "Starting Processing for "$BankName  >> $LOGFILEPATH/$LOGFILE
#
    $RUNDIR/Remittance-Sftp.sh $file
#
    cd $lpwd
done
echo "STOPED" > JavaServcie.Status
