package com.naveed.demo;

import java.util.Map;
import javax.crypto.Mac;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.debug.EvalExprEvent;
import org.stringtemplate.v4.debug.InterpEvent;

public class STDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ST hello = new ST("Hello, {name}", '{', '}');
        hello.add("name", "World");
        System.out.println(hello.render());
        System.out.println("Events " + hello.getEvents());

        for (InterpEvent event : hello.getEvents()) {
            if (event instanceof EvalExprEvent) {
                EvalExprEvent exprEvent = (EvalExprEvent) event;
                System.out.println("Found " + exprEvent.expr);
            }
        }

    }
}
