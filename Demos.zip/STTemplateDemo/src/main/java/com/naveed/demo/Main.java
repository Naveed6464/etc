package com.naveed.demo;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.crypto.Mac;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.debug.EvalExprEvent;
import org.stringtemplate.v4.debug.InterpEvent;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String currentPath = "/user/123";
        String path = "/user/{id}";
        List<String> pathList = Lists.newArrayList(Splitter.on('/').trimResults()
                .omitEmptyStrings().split(path));
        List<String> currentPathList = Lists.newArrayList(Splitter.on('/').trimResults()
                .omitEmptyStrings().split(currentPath));

        List<String> pathVariables = getPathVariables(path);
        List<Integer> pathHolders = getPathHolders(pathVariables, pathList);

        if (currentPathList.size() == pathList.size()) {
            for (int i = 0; i < currentPathList.size(); i++) {
                if (!pathHolders.contains(i)) {
                    if (currentPathList.get(i).equals(pathList.get(i))) {
                        System.out.println("TRUE");
                    }
                }
            }
        }
        //List<Object> resolveParameters = resolveParameters(pathVariables, null);
        

        /*ST st = new ST(path, '{', '}');
        st.add("id", "123");
        System.out.println(st.render());
        System.out.println("Events " + st.getEvents());
        int indexOf = pathList.indexOf("{ide}");
        System.out.println("Contains " + indexOf);*/
    }

    public static List<String> getPathVariables(String path) {
        ST st = new ST(path, '{', '}');
        List<String> pathVariabls = new ArrayList<>();
        for (InterpEvent event : st.getEvents()) {
            if (event instanceof EvalExprEvent) {
                EvalExprEvent exprEvent = (EvalExprEvent) event;
                if (path.contains("{") && path.contains("}")) {
                    pathVariabls.add(exprEvent.expr);
                }
            }
        }
        return pathVariabls;
    }

    public static List<Integer> getPathHolders(List<String> pathVariables, List<String> pathList) {
        List<Integer> pathHolders = new ArrayList<>();
        for (String pathVariable : pathVariables) {
            pathHolders.add(pathList.indexOf(pathVariable));
        }
        return pathHolders;
    }

    public static List<Object> resolveParameters(List<String> pathVariables, List<Class> parameters) {
        List<Object> args = new ArrayList<>();
        for (int i = 0; i < parameters.size(); i++) {
            args.add(parameters.get(i).cast(pathVariables.get(i)));
        }
        return args;
    }
}
