package com.naveed.itm.enc;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Naveedur Rahman
 * @version 1.0
 * @since Apr 3, 2019
 */
public class GenerateKeyFile {

    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    private static final Calendar cal = Calendar.getInstance();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        File file = new File(System.getProperty("user.dir"));

//        if (args.length != 1) {
//            String message = "Usage: java -cp <jar files path> <FileName";
//            System.out.println(dateFormat.format(cal.getTime()) + " : " + message + " : Args Length = " + args.length);
//            System.exit(1);
//        }
        String[] mainArgs = {"generateKey", "AES", "128", file.getAbsolutePath() + File.separator + "itmbis.key"};
        com.github.ncredinburgh.tomcat.Main.main(mainArgs);
    }
}
