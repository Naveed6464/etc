package com.naveed.itm.enc.config;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import lombok.Data;

/**
 *
 * @author Naveedur Rahman
 * @version 1.0
 * @since Mar 14, 2019
 */
@Data
public class AppProperties {

    private String privateKeyPath;
    private String publicKeyPath;
    private String keystorePassword, keyPassword, keyAliasName;

    Properties prop = new Properties();

    private static final AppProperties INSTANCE = new AppProperties();

    private AppProperties() {
    }

    public static AppProperties getInstance() {
        return INSTANCE;
    }

    public void loadProperties(String fileName) {
        InputStream input = null;
        try {
            input = new FileInputStream(fileName);
            prop.load(input);
            privateKeyPath = prop.getProperty("PRIVATE.KEY.PATH", "KeyPair/id_rsa");
            publicKeyPath = prop.getProperty("PUBLIC.KEY.PATH", "KeyPair/id_rsa2.pub");
            keystorePassword = prop.getProperty("KEY.STORE.PHRASE", "Alinma123");
            keyPassword = prop.getProperty("KEY.PHRASE", "Alinma123");
            keyAliasName = prop.getProperty("KEY.ALIAS.NAME", "remittancepki");
        } catch (IOException ex) {
            System.out.println("Property File not found " + ex);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    System.out.println("Property File closing error :" + e);
                }
            }
        }
    }

    public void storeProperties(String fileName) {
        try (FileOutputStream out = new FileOutputStream(fileName)) {
            prop.setProperty("PUBLIC.KEY.PATH", publicKeyPath);
            prop.store(out, null);
        } catch (IOException ex) {
            System.out.println("Exception " + ex);
        }
    }

}
