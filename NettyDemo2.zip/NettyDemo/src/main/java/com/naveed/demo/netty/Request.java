package com.naveed.demo.netty;

import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.QueryStringDecoder;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import lombok.Data;

/**
 *
 * @author Naveedur Rahman
 * @email nmarahman@alinma.com
 * @version 1.0
 * @since May 27, 2019
 */
@Data
public class Request {

    private HttpRequest request;
    String uri;
    String method;

    String content;

    public Request() {
    }

    public Request(HttpRequest request, String content) {
        this.request = request;
        this.uri = request.uri();
        this.method = request.method().name();
        this.content = content;
    }

    public Map<String, List<String>> getParams() {
        QueryStringDecoder queryStringDecoder = new QueryStringDecoder(request.uri());
        Map<String, List<String>> params = queryStringDecoder.parameters();
//        if (!params.isEmpty()) {
//            for (Entry<String, List<String>> param : params.entrySet()) {
//            }
//        }
        return params;
    }

    public HttpHeaders getHeaders() {
        HttpHeaders headers = request.headers();
//        if (!headers.isEmpty()) {
//            for (Map.Entry<String, String> header : headers) {
//            }
//        }
        return headers;//Map
    }

}
