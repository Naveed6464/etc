package com.naveed.demo.netty;

/**
 *
 * @author Naveedur Rahman 
 * @email nmarahman@alinma.com
 * @version 1.0
 * @since May 27, 2019
 */
public class RouterHandler {
    
    public String handle(Request request) {
        System.out.println(">>>>>>>>>>>>>>>>> " +request.getMethod());
        System.out.println(">>>>>>>>>>>>>>>>> " +request.getContent());
        System.out.println(">>>>>>>>>>>>>>>>> " +request.getUri());
        return  "Hello Router";
    }
    

}
