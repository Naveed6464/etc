/*global require*/
'use strict';

define(['app'], function (app) {

    return app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
            $urlRouterProvider.otherwise("login");
            $stateProvider
                    .state('home', {
                        url: '/home',
                        templateUrl: 'views/home.html',
                        controller: 'HomeController',
                        saladin: {
                            authenticate: true
                        },
                        resolve: {
                            /*'Apps': ['ApplicationService', '$stateParams', '$q', function (ApplicationService, $stateParams, $q) {
                             var defer = $q.defer();
                             ApplicationService.query(function (entity) {
                             defer.resolve(entity);
                             });
                             return defer.promise;
                             }],*/
                            'Menus': ['MenuService', 'SubMenuService', '$stateParams', '$q', function (MenuService, SubMenuService, $stateParams, $q) {
                                    var defer = $q.defer();
                                    SubMenuService.getAllMenus(function (menus) {
                                        defer.resolve(menus);
                                    });
                                    return defer.promise;
                                }]
                        }
                    })
                    .state('login', {
                        url: '/login',
                        templateUrl: 'views/login.html',
                        controller: 'LoginController',
                        saladin: {
                            authenticate: false
                        }
                    })
                    .state('app', {
                        url: '/app/:entity/',
                        controller: 'AppController',
                        templateUrl: 'views/app/app.html',
                        saladin: {
                            authenticate: true
                        },
                        resolve: {
                            /*'Fields': ['FieldsService', '$stateParams', '$q', function (FieldsService, $stateParams, $q) {
                                    var defer = $q.defer();
                                    FieldsService.getByEntityName({entity: $stateParams.entity}, function (entity) {
                                        defer.resolve(entity);
                                    });
                                    return defer.promise;
                                }],*/
                            'App': ['ApplicationService', '$stateParams', '$q', function (ApplicationService, $stateParams, $q) {
                                    var defer = $q.defer();
                                    ApplicationService.getByEntityName({entity: $stateParams.entity}, function (entity) {
                                        defer.resolve(entity);
                                    });
                                    return defer.promise;
                                }]
                        }
                    });
        }
    ]).constant('REST_HOST', '/api/');
});