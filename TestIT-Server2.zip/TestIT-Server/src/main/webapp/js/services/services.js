/*global require*/
'use strict';

define(['angular'], function(ng) {
    return ng.module('services', ['ngResource']);
});