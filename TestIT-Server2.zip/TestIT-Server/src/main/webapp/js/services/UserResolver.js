/*global require*/
'use strict';

define(['./services'], function(services) {

    services.factory('UserResolver', ['$q', '$route', 'UserService', function($q, $route, UserService) {
            return function() {
                var delay = $q.defer();
                var params = $route.current.params;
                if (params.uid != 0) {
                    UserService.get({id: params.uid}, function(data) {
                        //UserHistoryService.get(data, function(entity) {
                        delay.resolve(data);
                        //});
                    });
                } else {
                    delay.resolve();
                }
                return delay.promise;
            };
        }
    ]);
});