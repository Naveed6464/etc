/*global require*/
'use strict';

define(['./services'], function (services) {

    services.factory('MenuService', ['$resource', 'REST_HOST', function ($resource, REST_HOST) {
            return $resource(REST_HOST + 'menu/:id', {id: '@id'}, 
            {
                'getByEntityName': {method: 'GET', url :  REST_HOST +'menu/ByMenuName/:entity'}
            });
        }
    ]);
});



