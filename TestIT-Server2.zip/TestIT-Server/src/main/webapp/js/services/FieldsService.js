/*global require*/
'use strict';

define(['./services'], function (services) {

    services.factory('FieldsService', ['$resource', 'REST_HOST', function ($resource, REST_HOST) {
            return $resource(REST_HOST + 'formfield/:id', {id: '@id'}, 
            {
                'getByEntityName': {method: 'GET', url :  REST_HOST +'formfield/ByAppName/:entity', isArray: true}
            });
        }
    ]);
});



