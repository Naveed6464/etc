/*global require*/
'use strict';

define(['./controllers'], function (controllers) {
    controllers.controller('LoginController', ['$rootScope', '$scope', '$http', '$state', 'localStorageService', 'REST_HOST',
        function ($rootScope, $scope, $http, $state, localStorageService, REST_HOST) {

            $scope.user = {username: '', password: ''};
            $scope.login = function () {
                $http.post(REST_HOST + 'login', $scope.user).success(function (data, status, headers, config) {
                    $scope.errorMsg = "";
                    localStorageService.set("token", data.token);
                    $scope.user.password = '';
                    $rootScope.currentUser = $scope.user;
                    $rootScope.currentUserName = $scope.user.username;
                    $rootScope.currentUserFirstName = data.name;
                    
                    /*$rootScope.authorizerInfo = data;
                    var PART_DIVIDER_TOKEN = ':';
                    var apps = [];
                    for (var i = 0; i < data.permissions.length; i++) {
                        var tokens = data.permissions[i].split(PART_DIVIDER_TOKEN);
                        apps.push(tokens[0]);
                    }
                    $rootScope.authorizerInfo.apps = apps;*/
                    $state.go("home");
                }).error(function (data, status, headers, config) {
                    $scope.user.password = '';
                    $scope.errorMsg = "Invalid Username or passwrod!";
                });
            };
        }
    ]);
});