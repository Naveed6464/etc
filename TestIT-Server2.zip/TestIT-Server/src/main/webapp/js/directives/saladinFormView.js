/*global require*/
'use strict';

define(['./directives'], function (directives) {

    directives.directive('saladinFormView', ['$rootScope', function ($rootScope) {
            return {
                scope: {
                    app: '=',
                    entity: '='
                },                
                templateUrl: 'views/templates/saladinFormView.html',
                replace: true,
                controller: ['$scope', function ($scope) {                        
                    }],
                link: function (scope, element, attrs) {

                }
            };
        }]);
});