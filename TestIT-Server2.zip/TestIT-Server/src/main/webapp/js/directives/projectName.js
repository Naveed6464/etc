/*global require*/
'use strict';

define(['./directives'], function (directives) {

    directives.directive('projectName', ['$rootScope', 'PROJECT_NAME', function ($rootScope, PROJECT_NAME) {
            return {
                template:  PROJECT_NAME
            };
        }]);
});