/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.controller;

import com.google.gson.JsonObject;
import com.ncr.itm.middleware.web.enitites.LoginUser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.SecureRandom;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nmrehman
 */
@RestController
public class LoginController {

    protected final String TOKEN = "token";
    protected final String MESSAGE = "message";
    protected final String CODE = "code";

    protected final int HTTP_STATUS_OK = 200;
    protected final int HTTP_STATUS_NOT_FOUND = 404;
    protected final int HTTP_STATUS_FORBIDDEN = 403;
    protected final int HTTP_STATUS_INTERNAL_SERVER_ERROR = 500;
    public static byte[] key = new byte[64];
    public static boolean keyInitialize = false;

    public static byte[] getKey() {
        if (!keyInitialize) {
            new SecureRandom().nextBytes(key);
            keyInitialize = true;
        }
        return key;
    }

    private String generateKey(String username) {
        return Jwts.builder().setSubject(username).signWith(SignatureAlgorithm.HS256, getKey()).compact();
    }

    protected String issueJson(int status, String... args) {
        //Preconditions.checkArgument(args.length % 2 == 0, "There must be an even number of strings");
        //JSONObject obj = new JSONObject();
        JsonObject json = new JsonObject();
        for (int i = 0; i < args.length; i += 2) {
            json.addProperty(args[i], args[i + 1]);
            //obj.put(args[i], args[i + 1]);
        }
        return json.toString();
    }

    @RequestMapping(path = "/login", method = RequestMethod.POST)
    public String login(@RequestBody LoginUser loginUser) {
        if (loginUser.getUsername().equals("root") && loginUser.getPassword().equals("root")) {
            return issueJson(HTTP_STATUS_OK, MESSAGE, "ok", TOKEN, generateKey(loginUser.getUsername()), "name", "ROOT");
        } else {
            return issueJson(HTTP_STATUS_NOT_FOUND, MESSAGE, "user not found.");
        }
    }

    @RequestMapping("/logout")
    public void logout() {
        //Subject subject = SecurityUtils.getSubject();
        //subject.logout();
    }

}
