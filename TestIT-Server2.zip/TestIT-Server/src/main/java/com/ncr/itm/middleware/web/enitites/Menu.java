/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.enitites;

import java.util.List;
import lombok.Data;

/**
 *
 * @author nmrehman
 */
@Data
public class Menu {

    String name;
    String title;

    List<Menu> subMenus;

    public Menu(String name, String title, List<Menu> subMenus) {
        this.name = name;
        this.title = title;
        this.subMenus = subMenus;
    }

}
