/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.domain.repositories;

import com.ncr.itm.middleware.web.domain.entities.Report;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author nmrehman
 */
public interface ReportRepository extends CrudRepository<Report, Long> {

}
