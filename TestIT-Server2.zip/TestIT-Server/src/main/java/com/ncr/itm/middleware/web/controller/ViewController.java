/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.controller;

import com.ncr.itm.middleware.web.enitites.Application;
import com.ncr.itm.middleware.web.enitites.FormField;
import com.ncr.itm.middleware.web.enitites.Menu;
import com.ncr.itm.middleware.web.enitites.Tab;
import java.util.Arrays;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nmrehman
 */
@RestController
public class ViewController {

    @RequestMapping("/submenu/allMenus")
    public List<Menu> menus() {
        Menu coremenu = new Menu("coreapplication", "Core Applicatoin", Arrays.asList(new Menu("core", "Core", null)));
        Menu appsMenu = new Menu("application", "Applicatoin", Arrays.asList(new Menu("user", "User", null)));
        Menu reports = new Menu("reports", "Reports", Arrays.asList(new Menu("report", "Reports", null)));
        Menu logmenu = new Menu("logs", "Logs", Arrays.asList(new Menu("log", "Log", null)));
        return Arrays.asList(coremenu, appsMenu, reports, logmenu);
    }

    @RequestMapping("/application/ByAppName/{appName}")
    public Application app(@PathVariable("appName") String appName) {
        switch (appName) {
            case "user":
                List<FormField> formFields = Arrays.asList(new FormField("firstName"), new FormField("lastName"), new FormField("username"), new FormField("password"));
                return new Application("user", "User", Arrays.asList(new Tab("User", formFields)));
        }
        return null;
    }
}
