/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.enitites;

import java.util.List;
import lombok.Data;

/**
 *
 * @author nmrehman
 */
@Data
public class Tab {

    private String title;
    private boolean active;
    private boolean disabled;
    private List<FormField> formFields;

    public Tab() {
    }

    public Tab(String title, List<FormField> formFields) {
        this.title = title;
        this.active = true;
        this.disabled = true;
        this.formFields = formFields;
    }
}
