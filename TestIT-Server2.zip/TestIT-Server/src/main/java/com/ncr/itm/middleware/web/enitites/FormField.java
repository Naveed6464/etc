/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.enitites;

import lombok.Data;

/**
 *
 * @author nmrehman
 */
@Data
public class FormField {

    private String model;
    private String label;
    private String widget;
    private boolean visible;
    private String placeHolder;
    private int max;
    private int min;

    public FormField() {
    }

    public FormField(String model, String label, String widget, boolean visible, String placeHolder, int max, int min) {
        this.model = model;
        this.label = label;
        this.widget = widget;
        this.visible = visible;
        this.placeHolder = placeHolder;
        this.max = max;
        this.min = min;
    }

    public FormField(String model) {
        this(model, model.substring(0, 1).toUpperCase() + model.substring(1));
    }

    public FormField(String model, String label) {
        this(model, label, "text");
    }

    public FormField(String model, String label, String widget) {
        this(model, label, widget, true, "", 0, 0);
    }

}
