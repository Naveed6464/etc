/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.domain.entities;

import com.google.gson.annotations.Expose;
import java.util.ArrayList;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *
 * @author Administrator
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = false)
public class User extends AbstractEntity {

    @Expose
    private String firstName;
    @Expose
    private String lastName;

    //@NotNull
    @Expose
    private String username;

    //@NotNull
    @Expose
    @Column(length = 64)
    private String password;

    //@NotNull 
    @Expose
    @Column(length = 80)
    private String salt;

    @Expose
    //@ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    private ArrayList<String> roles;
    @Expose
    //@OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
    private ArrayList<String> permissions;
    @Expose
    private String role;
    //@Expose
    @Temporal(TemporalType.TIMESTAMP)
    Date signupDate;

    @Expose
    boolean active;
}
