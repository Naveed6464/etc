/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.naveed.fursan.pdf.extract.config;

import com.google.inject.AbstractModule;

/**
 *
 * @author naveed
 */
public class AppModule extends AbstractModule {

    @Override
    protected void configure() {
        //bind(AppProperties.class);
        //UIUtils
        //NettyBootstrap
        //RequestHandler
        //CaptureImage
        //ATTUtils
        //RestTemplate
    }
}
