package com.naveed.pdf.demo;

import com.itextpdf.text.io.RandomAccessSourceFactory;
import com.itextpdf.text.pdf.PRTokeniser;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.RandomAccessFileOrArray;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author nmrehman
 */
public class ItextDemo {

    public static void main(String[] args) throws IOException {
        PdfReader reader = new PdfReader("sample.pdf");
        int n = reader.getNumberOfPages();
        System.out.println(PdfTextExtractor.getTextFromPage(reader, 2));
        
        byte[] streamBytes = reader.getPageContent(2);
        PRTokeniser tokenizer = new PRTokeniser(new RandomAccessFileOrArray(new RandomAccessSourceFactory().createSource(streamBytes)));
        
        while (tokenizer.nextToken()) {
            if (tokenizer.getTokenType() == PRTokeniser.TokenType.STRING) {
                System.out.println("\n\n>>>>> " + tokenizer.getStringValue());
            }
        }
    }

}