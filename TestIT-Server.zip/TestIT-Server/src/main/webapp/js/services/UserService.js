/*global require*/
'use strict';

define(['./services'], function(services) {

    services.factory('UserService', ['$resource', 'REST_HOST', function($resource, REST_HOST) {
            /*return $resource(REST_HOST + 'user/:id', {id: '@id'},
            {
                'login': {method: 'POST', url :  REST_HOST +'user/login/auth'},
                'checkUserName': {method: 'POST', url :  REST_HOST +'user/login/checkUserName'}
            });*/
            return {
                posts: [{
                        id: 1,                        
                        username: 'test1',
                        firstName: 'test',
                        lastName: 'test'                        
                    }, {
                        username: 'test2',
                        firstName: 'test',
                        lastName: 'test'
                    }, {
                        id: 3,
                        username: 'test3',
                        firstName: 'test',
                        lastName: 'test'
                    }, {
                        id: 4,
                        username: 'test4',
                        firstName: 'test',
                        lastName: 'test'
                    }]
            };
        }
    ]);
});



