/*global require*/
'use strict';

define(['./services'], function (services) {

    services.factory('CRUDService', ['$http', 'REST_HOST', '$state', '$q', function ($http, REST_HOST, $state, $q) {
            var reportsModel = [];
            var formModel;
            var entities;
            var viewService = {};
            var entityName;

            var reportsFieldsURL = REST_HOST + 'reportfield/ByAppName/';
            var formFieldsURL = REST_HOST + 'formfield/ByAppName/';

            viewService.myPageResolve = function (name) {
                entityName = name;
                var defer = $q.defer();

                //$http.get(reportsFieldsURL + entityName).success(function (data) {
                //reportsModel = data;

                //$http.get(REST_HOST + entityName).success(function (data) {//+ '/all'
                //entities = data;

                $http.get(formFieldsURL + entityName).success(function (data) {
                    formModel = data;
                    defer.resolve();
                });

                //});

                //});

                return defer.promise;
            };

            viewService.getEntities = function () {
                return entities;
            };

            viewService.getFormModel = function () {
                return formModel;
            };

            viewService.getReportsTblColmns = function () {
                var tblColumns = [];
                for (var i in reportsModel) {
                    tblColumns[i] = {"sTitle": reportsModel[i].label};
                }
                tblColumns[reportsModel.length] = {
                    "sTitle": "Action",
                    "bSearchable": false,
                    "sDefaultContent": "",
                    "fnRender": function (oObj) {
                        return "<a class='tiny button secondary' href=\"#/" + entityName + '/'
                                + oObj.aData["id"]
                                + "/edit\"><i class='icon-edit'></i></a>  "
                                + "<a class='tiny button secondary' href=\"#/" + entityName + '/'
                                + oObj.aData["id"]
                                + "/view\"><i class='icon-th-list'></i></a>";
                    }
                };
                return tblColumns;
            };

            viewService.getReportsColumnDefs = function () {
                var columnDefs = [];
                for (var i in reportsModel) {
                    columnDefs[i] = {"mDataProp": reportsModel[i].model, "aTargets": [reportsModel[i].position]};
                }
                columnDefs[reportsModel.length] = {"mDataProp": null, "sDefaultContent": "", "bSearchable": false, "aTargets": [-1]};
                return columnDefs;
            };

            return viewService;
        }
    ]);
});
