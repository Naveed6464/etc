/*global require*/
'use strict';

define(['./services'], function (services) {

    services.factory('SubMenuService', ['$resource', 'REST_HOST', function ($resource, REST_HOST) {
            return $resource(REST_HOST + 'submenu/:id', {id: '@id'},
                    {
                        'getByParentMenu': {method: 'GET', url: REST_HOST + 'submenu/ByParentMenu/:menuName', isArray: true},
                        'getAllMenus': {method: 'GET', url: REST_HOST + 'submenu/allMenus', isArray: true}
                    });
        }
    ]);
});



