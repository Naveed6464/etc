/*global require*/
'use strict';

define(['./services'], function (services) {

    services.factory('LookupOptionService', ['$resource', 'REST_HOST', function ($resource, REST_HOST) {
            return $resource(REST_HOST + 'lookupoption/:id', {id: '@id'},
                    {
                        'getByLookupName': {method: 'GET', url: REST_HOST + 'lookupoption/ByLookupName/:entity', isArray: true},
                        'getByEntityName': {method: 'GET', url: REST_HOST + 'lookupoption/ByEntityName/:entity/:entityFieldName', isArray: true},
                    });
        }
    ]);
});



