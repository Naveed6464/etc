/*global require*/
'use strict';

define(['./directives'], function (directives) {

    directives.directive('saladinFormAuthorize', ['$rootScope', function ($rootScope) {
            return {
                scope: {
                    app: '=',
                    entity: '='
                },
                templateUrl: 'views/templates/saladinFormAuthorize.html',
                replace: true,
                controller: ['$rootScope', '$scope', '$http', 'REST_HOST', '$uibModal', function ($rootScope, $scope, $http, REST_HOST, $uibModal) {
                        $scope.authorize = function () {

                            var editSameUser = false;

                            if ($scope.entity.audit.lastUpdate) {
                                var last = $scope.entity.audit.lastUpdate.length - 1;
                                if ($scope.entity.audit.lastUpdate[last].lastUpdatedUser === $rootScope.currentUserName) {
                                    editSameUser = true;
                                }
                            }

                            if ($scope.entity.audit.recordInputter === $rootScope.currentUserName || editSameUser) {
                                $uibModal.open({
                                    animation: true,
                                    templateUrl: 'okContent.html',
                                    controller: ['$scope', '$uibModalInstance', function ($scope, $uibModalInstance) {
                                            $scope.title = "Same User!";
                                            $scope.msg = "Same User can't able to authorize.";
                                            $scope.ok = function () {
                                                $uibModalInstance.close();
                                            };

                                            $scope.cancel = function () {
                                                $uibModalInstance.dismiss('cancel');
                                            };
                                        }]
                                });
                            } else {
                                //$scope.entity.audit.recordAthorizer = $rootScope.currentUserName;
                                //$scope.entity.audit.recordApprovedTime = new Date();

                                if (!$scope.entity.audit.authorizers) {
                                    $scope.entity.audit.authorizers = [{}];
                                }
                                if ($scope.app.noOfAuthorizers === 0 || $scope.app.noOfAuthorizers === 1) {
                                    $scope.entity.audit.authorizers[0].recordAthorizer = $rootScope.currentUserName;
                                    $scope.entity.audit.authorizers[0].recordApprovedTime = new Date();
                                    $scope.entity.audit.recordStatus = "L";
                                    $scope.authMthd();
                                } else if ($scope.entity.audit.authorizers.length < $scope.app.noOfAuthorizers) {
                                    var userFound = false;
                                    for (var i = 0; i < $scope.entity.audit.authorizers.length; i++) {
                                        if ($scope.entity.audit.authorizers[i].recordAthorizer === $rootScope.currentUserName) {
                                            userFound = true;
                                        }
                                    }
                                    if (userFound) {
                                        $uibModal.open({
                                            animation: true,
                                            templateUrl: 'okContent.html',
                                            controller: ['$scope', '$uibModalInstance', function ($scope, $uibModalInstance) {
                                                    $scope.title = "Same User!";
                                                    $scope.msg = "Two Same Authroizers can't able to authorize.";
                                                    $scope.ok = function () {
                                                        $uibModalInstance.close();
                                                    };

                                                    $scope.cancel = function () {
                                                        $uibModalInstance.dismiss('cancel');
                                                    };
                                                }]
                                        });
                                    } else {
                                        var lng = $scope.entity.audit.authorizers.length;
                                        if (!$scope.entity.audit.authorizers[lng - 1 ].recordAthorizer) {
                                            lng = lng - 1;
                                        }
                                        if (!$scope.entity.audit.authorizers[lng]) {
                                            $scope.entity.audit.authorizers[lng] = {};
                                        }
                                        $scope.entity.audit.authorizers[lng].recordAthorizer = $rootScope.currentUserName;
                                        $scope.entity.audit.authorizers[lng].recordApprovedTime = new Date();

                                        if ($scope.entity.audit.authorizers.length === $scope.app.noOfAuthorizers) {
                                            $scope.entity.audit.recordStatus = "L";
                                            $scope.authMthd();
                                        } else {
                                            var url = REST_HOST + $scope.app.entity + "_pnd";
                                            $http.post(url, $scope.entity)
                                                    .success(function (response) {
                                                        $scope.app.current.type = 'authorizeSuccess';
                                                        $scope.app.current.id = response.id;
                                                    }).error(function (data, status) {
                                                $scope.app.current.type = 'error';
                                                $scope.app.current.errormessage = data.message;
                                            });
                                        }
                                    }
                                } else {
                                    var lng = $scope.entity.audit.authorizers.length;
                                    if (!$scope.entity.audit.authorizers[lng]) {
                                        $scope.entity.audit.authorizers[lng] = {};
                                    }
                                    $scope.entity.audit.authorizers[lng].recordAthorizer = $rootScope.currentUserName;
                                    $scope.entity.audit.authorizers[lng].recordApprovedTime = new Date();
                                    $scope.entity.audit.recordStatus = "L";
                                    $scope.authMthd();
                                }
                            }
                        };

                        $scope.authMthd = function () {
                            $http.post(REST_HOST + $scope.app.entity + "/authorize/pnd", $scope.entity)
                                    .success(function (response) {
                                        $scope.app.current.type = 'authorizeSuccess';
                                        $scope.app.current.id = response.id;
                                        /*$http.delete(REST_HOST + $scope.app.entity + "_pnd/" + $scope.entity.id, $scope.entity).success(function (response) {
                                         //$scope.entity.hid = $scope.entity.id + ";" + $scope.entity.audit.curNo;
                                            $http.post(REST_HOST + $scope.app.entity + "/update/his", $scope.entity);
                                         });*/                                        
                                    }).error(function (data, status) {
                                $scope.app.current.type = 'error';
                                $scope.app.current.errormessage = data.message;
                                console.error('Repos error', status, data);
                            });
                        };

                        $scope.delete = function () {
                            $http.delete(REST_HOST + $scope.app.entity + "_pnd/" + $scope.entity.id, $scope.entity)
                                    .success(function (response) {
                                        $scope.app.current.type = 'deleted';
                                        $scope.app.current.id = response.id;
                                    }).error(function (data, status) {
                                $scope.app.current.type = 'error';
                                $scope.app.current.errormessage = data.message;
                                console.error('Repos error', status, data);
                            });
                        };
                    }
                ],
                link: function (scope, element, attrs) {

                }
            };
        }]);
});