/*global require*/
'use strict';

define(['./directives'], function (directives) {

    directives.directive('tagLine', ['$rootScope', 'TAG_LINE', function ($rootScope, TAG_LINE) {
            return {
                template:  TAG_LINE
            };
        }]);
});