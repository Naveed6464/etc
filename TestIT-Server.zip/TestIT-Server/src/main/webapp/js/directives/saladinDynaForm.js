
/*global require*/
'use strict';

define(['angular', './directives'], function (angular, directives) {

    directives.directive('saladinDynaForm', ['$rootScope', function ($rootScope) {
            return {
                restrict: 'A',
                scope: {
                    app: '=',
                    entity: '='
                },
                templateUrl: 'views/templates/saladinDynaForm.html',
                replace: true,
                controller: ['$rootScope', '$scope', '$http', 'REST_HOST', '$stateParams', '$state', '$timeout', function ($rootScope, $scope, $http, REST_HOST, $stateParams, $state, $timeout) {
                        $scope.alerts = [];

                        //Hot Field
                        $scope.onEnter = function (field) {
                            $http.post(REST_HOST + $scope.app.entity + "/dynamic/field", field + "####" + angular.toJson($scope.entity) + "####" + angular.toJson($scope.app)).success(function (data) {
                                if (data && data.entity && data.app) {
                                    $scope.entity = data.entity;
                                    var current = $scope.app.current;
                                    $scope.app = data.app;
                                    $scope.app.current = current;
                                }
                            });
                        };

                        $scope.focus = function (field) {                            
                            if (field) {
                                angular.element("#" + field).focus();
                            }
                        };

                        $scope.onChange = function (field) {
                            $http.post(REST_HOST + $scope.app.entity + "/dynamic/field", field + "####" + angular.toJson($scope.entity) + "####" + angular.toJson($scope.app)).success(function (data) {
                                if (data && data.entity && data.app) {
                                    $scope.entity = data.entity;
                                    var current = $scope.app.current;
                                    $scope.app = app;
                                    $scope.app.current = current;
                                }
                            });
                        };
                        $scope.save = function () {
                            var url = REST_HOST + $scope.app.entity;
                            if ($scope.app.type === "H") {
                                url = REST_HOST + $scope.app.entity + "_pnd";
                                if ($scope.app.current.type === 'new') {
                                    $scope.entity.audit = {};
                                    $scope.entity.audit.recordInputter = $rootScope.currentUserName;
                                    $scope.entity.audit.recordCreatedTime = new Date();
                                    $scope.entity.audit.recordStatus = "PND";
                                    $scope.entity.audit.curNo = 1;
                                } else {
                                    if (!$scope.entity.audit.lastUpdate) {
                                        $scope.entity.audit.lastUpdate = [{}];
                                        $scope.entity.audit.lastUpdate[0].lastUpdatedUser = $rootScope.currentUserName;
                                        $scope.entity.audit.lastUpdate[0].lastUpdatedTime = new Date();
                                    } else {
                                        var last = $scope.entity.audit.lastUpdate.length;
                                        $scope.entity.audit.lastUpdate[last].lastUpdatedUser = $rootScope.currentUserName;
                                        $scope.entity.audit.lastUpdate[last].lastUpdatedTime = new Date();
                                    }
                                    $scope.entity.audit.recordStatus = "PND";
                                    $scope.entity.audit.curNo = $scope.entity.audit.curNo + 1;
                                }
                            } else if ($scope.app.type === "L") {
                                if ($scope.app.current.type === 'new') {
                                    $scope.entity.audit = {};
                                    $scope.entity.audit.recordInputter = $rootScope.currentUserName;
                                    $scope.entity.audit.recordCreatedTime = new Date();
                                    $scope.entity.audit.recordStatus = "L";
                                    $scope.entity.audit.curNo = 1;
                                } else {
                                    if (!$scope.entity.audit.lastUpdate) {
                                        $scope.entity.audit.lastUpdate = [{}];
                                        $scope.entity.audit.lastUpdate[0].lastUpdatedUser = $rootScope.currentUserName;
                                        $scope.entity.audit.lastUpdate[0].lastUpdatedTime = new Date();
                                    } else {
                                        var last = $scope.entity.audit.lastUpdate.length;
                                        $scope.entity.audit.lastUpdate[last].lastUpdatedUser = $rootScope.currentUserName;
                                        $scope.entity.audit.lastUpdate[last].lastUpdatedTime = new Date();
                                    }
                                    $scope.entity.audit.curNo = $scope.entity.audit.curNo + 1;
                                }
                            }
                            $scope.entity.screenName = $scope.app.name;

                            if ($scope.app.type === "L" && $scope.entity.audit.curNo !== 1) {
                                $http.put(REST_HOST + $scope.app.name + "/" + $scope.app.current.id, $scope.entity)
                                        .success(function (response) {
                                            $scope.app.current.type = 'completed';
                                            $scope.app.current.id = response.id;
                                        }).error(function (data, status) {
                                    $scope.app.current.type = 'error';
                                    $scope.app.current.errormessage = data.message;
                                    console.error('Repos error', status, data);
                                });
                            } else {
                                $http.post(url, $scope.entity)
                                        .success(function (response) {
                                            $scope.alerts = [];
                                            $scope.app.current.type = 'completed';
                                            $scope.app.current.id = response.id;
                                        }).error(function (data, status) {
                                    if (status === 422) {
                                        for (var i = 0; i < data.errors.length; i++) {
                                            for (var j = 0; j < data.errors[i].messages.length; j++) {
                                                $scope.alerts.push({type: data.errors[i].type, field: data.errors[i].model, msg: data.errors[i].messages[j]});
                                            }
                                        }
                                    } else {
                                        $scope.app.current.type = 'error';
                                        $scope.app.current.errormessage = data.message;
                                        console.error('Repos error', status, data);
                                    }
                                });
                            }
                        };
                        $scope.delete = function () {
                            $http.delete(REST_HOST + $scope.app.entity + "/" + $scope.app.current.id, $scope.entity)
                                    .success(function (response) {
                                        $scope.app.current.type = 'deleted';
                                        $scope.app.current.id = response.id;
                                    }).error(function (data, status) {
                                $scope.app.current.type = 'error';
                                $scope.app.current.errormessage = data.message;
                                console.error('Repos error', status, data);
                            });
                        };

                        //add MultiValue
                        $scope.add = function (model) {
                            $scope.entity[model].push('');
                            //$scope.apply();
                        };
                        //remove Multivalue
                        $scope.remove = function (model, index) {
                            $scope.entity[model].splice(index, 1);
                        };

                        $scope.addMultiAso = function (model, idx, ctrl) {
                            $scope.entity[model][idx][ctrl].push('');
                            //$scope.apply();
                        };
                        //remove Multivalue
                        $scope.removeMultiAso = function (model, idx, ctrl, index) {
                            $scope.entity[model][idx][ctrl].splice(index, 1);
                        };
                        $scope.addMultiAsoAno = function (model, idx, ctrl, idx2, c) {
                            $scope.entity[model][idx][ctrl][idx2][c].push('');
                            //$scope.apply();
                        };
                        $scope.removeMultiAsoAno = function (model, idx, ctrl, idx2, c, index) {
                            $scope.entity[model][idx][ctrl][idx2][c].splice(index, 1);
                        };

                        $scope.addAso = function (model) {
                            var len = $scope.entity[model].length;
                            $scope.entity[model].push({});

                            var fieldModel;
                            for (var t = 0; t < $scope.app.tabs.length; t++) {
                                for (var i = 0; i < $scope.app.tabs[t].formFields.length; i++) {
                                    if ($scope.app.tabs[t].formFields[i].widget === 'asociated') {
                                        if ($scope.app.tabs[t].formFields[i].model === model) {
                                            fieldModel = $scope.app.tabs[t].formFields[i];
                                        }
                                    }
                                }
                            }
                            if (fieldModel) {
                                for (var i = 0; i < fieldModel.multiFields.length; i++) {
                                    if (fieldModel.multiFields[i].widget === 'asociated') {
                                        var field = fieldModel.multiFields[i].model;
                                        $scope.entity[model][len][field] = [{}];
                                        for (var j = 0; j < fieldModel.multiFields[i].multiFields.length; j++) {
                                            if (fieldModel.multiFields[i].multiFields[j] !== null && fieldModel.multiFields[i].multiFields[j].widget === 'multi') {
                                                var field2 = fieldModel.multiFields[i].multiFields[j].model;
                                                $scope.entity[model][len][field][0][field2] = [''];
                                            } else if (fieldModel.multiFields[i].multiFields[j] !== null && fieldModel.multiFields[i].multiFields[j].widget === 'lookup') {

                                            }
                                        }
                                    }
                                }
                            }

                            //this dont need as we already use track by
                            /*$timeout(function () {
                             if (!$scope.$$phase) {
                             $scope.$apply();
                             }
                             });*/
                        };

                        $scope.removeAso = function (model, index) {
                            $scope.entity[model].splice(index, 1);
                        };

                        $scope.addAsoAno = function (model, idx, ctrl) {
                            var len = $scope.entity[model][idx][ctrl].length;
                            $scope.entity[model][idx][ctrl].push({});
                            var fieldModel;
                            for (var t = 0; t < $scope.app.tabs.length; t++) {
                                for (var i = 0; i < $scope.app.tabs[t].formFields.length; i++) {
                                    if ($scope.app.tabs[t].formFields[i].widget === 'asociated') {
                                        if ($scope.app.tabs[t].formFields[i].model === model) {
                                            for (var j = 0; j < $scope.app.tabs[t].formFields[i].multiFields.length; j++) {
                                                if ($scope.app.tabs[t].formFields[i].multiFields[j].model === ctrl) {
                                                    fieldModel = $scope.app.tabs[t].formFields[i].multiFields[j];
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                            if (fieldModel) {
                                for (var i = 0; i < fieldModel.multiFields.length; i++) {
                                    if (fieldModel.multiFields[i] !== null && fieldModel.multiFields[i].widget === 'multi') {
                                        var field2 = fieldModel.multiFields[i].model;
                                        $scope.entity[model][idx][ctrl][len][field2] = [''];
                                    }
                                }
                            }
                            /*$timeout(function () {
                             if (!$scope.$$phase) {
                             $scope.$apply();
                             }
                             });*/
                        };
                        $scope.removeAsoAno = function (model, idx, ctrl, index) {
                            $scope.entity[model][idx][ctrl].splice(index, 1);
                        };

                    }],
                link: function (scope, element, attrs) {
                }
            };
        }]);
});