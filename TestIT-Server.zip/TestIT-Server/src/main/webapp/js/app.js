/*global require*/
'use strict';

define(['angular', 'angularResource', 'angularUIRoute', 'angularUIBootstrap',
    'services/loader',
    'directives/loader',
    'filters/loader',
    'controllers/loader'
], function (angular) {
    return angular.module('app', [
        'ngResource',
        'ngTouch',
        'ngAnimate',
        'ngSanitize',
        'angular-loading-bar',
        'ui.router',
        'ui.bootstrap',
        'LocalStorageModule',
        'datatables',
        'datatables.bootstrap',
        'datatables.buttons',
        'datatables.colvis',
        'datatables.scroller',
        'datatables.columnfilter',
        'datatables.light-columnfilter',
        'ngFileSaver',
        //'ngTable',
        'ui.tinymce',
        'saladinAuth',
        'services',
        'directives',
        //'filters',
        'controllers'
    ]);
});