/*global require*/
'use strict';

define(['app'], function (app) {

    return app.config(['localStorageServiceProvider', '$httpProvider', function (
                localStorageServiceProvider, $httpProvider) {
            localStorageServiceProvider.setPrefix('demoApp');

            $httpProvider.interceptors.push(['$q', 'localStorageService', '$location', function ($q, localStorageService, $location) {
                    return {
                        'request': function (config) {
                            config.headers = config.headers || {};
                            if (localStorageService.get("token")) {
                                config.headers.Authorization = 'Bearer ' + localStorageService.get("token");
                            }
                            return config;
                        },
                        'responseError': function (response) {
                            if (response.status === 401 || response.status === 403) {
                                $location.path('#/login');
                            }
                            return $q.reject(response);
                        }
                    };
                }]);
        }
    ]);
});