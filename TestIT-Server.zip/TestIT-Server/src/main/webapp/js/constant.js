/*global require*/
'use strict';

define(['app'], function (app) {

    return app.constant('REST_HOST', '/api/')
            .constant('PROJECT_NAME', 'Brand')
            .constant('TAG_LINE', 'Tag Line!');
});