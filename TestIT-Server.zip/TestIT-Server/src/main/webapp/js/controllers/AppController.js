/*global require*/
'use strict';
define(['angular', './controllers'], function (angular, controllers) {

    controllers.controller('AppController', ['$scope', '$state', '$stateParams', 'DTOptionsBuilder', 'DTColumnBuilder',
        '$http', 'REST_HOST', 'App', 'LookupOptionService', 'FileSaver', 'Blob', '$uibModal', '$compile',
        function ($scope, $state, $stateParams, DTOptionsBuilder, DTColumnBuilder, $http, REST_HOST, App, LookupOptionService, FileSaver, Blob, $uibModal, $compile) {

            $scope.app = App;
            //$scope.app.fields = Fields;
            $scope.app.current = {id: '', errormessage: '', type: ''};
            $scope.app.popup = {};

            $scope.newDeal = function () {
                $scope.entity = {};
                $scope.app.current.type = 'new';

                $http.get(REST_HOST + $scope.app.entity + "/oncreate").success(function (data) {
                    if (data !== null) {
                        $scope.entity = data;
                    }
                });
                $scope.setUpFields();
            };

            $scope.setUpFields = function () {
                for (var t = 0; t < $scope.app.tabs.length; t++) {
                    for (var i = 0; i < $scope.app.tabs[t].formFields.length; i++) {
                        //console.log($scope.app.tabs[t].formFields[i].model);
                        if ($scope.app.tabs[t].formFields[i].widget === 'multi') {
                            $scope.entity[$scope.app.tabs[t].formFields[i].model] = [''];
                        }
                        if ($scope.app.tabs[t].formFields[i].widget === 'asociated') {
                            $scope.entity[$scope.app.tabs[t].formFields[i].model] = [{}];
                            for (var j = 0; j < $scope.app.tabs[t].formFields[i].multiFields.length; j++) {
                                if ($scope.app.tabs[t].formFields[i].multiFields[j].widget === 'asociated') {
                                    var field = $scope.app.tabs[t].formFields[i].multiFields[j].model;
                                    //var asociated = [{}];
                                    //asociated[0][field] = [{}];                                    
                                    $scope.entity[$scope.app.tabs[t].formFields[i].model][0][field] = [{}];
                                }
                                if ($scope.app.tabs[t].formFields[i].multiFields[j].widget === 'multi') {
                                    var field = $scope.app.tabs[t].formFields[i].multiFields[j].model;
                                    $scope.entity[$scope.app.tabs[t].formFields[i].model][0][field] = [''];

                                }
                                if ($scope.app.tabs[t].formFields[i].multiFields[j].multiFields !== null) {
                                    for (var k = 0; k < $scope.app.tabs[t].formFields[i].multiFields[j].multiFields.length; k++) {
                                        if ($scope.app.tabs[t].formFields[i].multiFields[j].multiFields[k] !== null && $scope.app.tabs[t].formFields[i].multiFields[j].multiFields[k].widget === 'multi') {
                                            var field2 = $scope.app.tabs[t].formFields[i].multiFields[j].multiFields[k].model;
                                            $scope.entity[$scope.app.tabs[t].formFields[i].model][0][field][0][field2] = [''];
                                        }
                                    }
                                }
                            }
                        }
                        if ($scope.app.tabs[t].formFields[i].widget === 'lookup') {
                            $scope.getOptions(t, i);
                        }
                        /*if ($scope.app.tabs[t].formFields[i].widget === 'date') {
                         var field = $scope.app.tabs[t].formFields[i].model;                       
                         $scope.app.popup[field] = {"opened": false};
                         console.log($scope.app.popup);
                         }*/
                    }
                }
            };


            $scope.setUpFieldsEdit = function () {
                /*for (var i = 0; i < Fields.length; i++) {
                 //console.log(Fields[i].widget + " " + Fields[i].model + " " + $scope.entity[Fields[i].model]);                                
                 if (Fields[i].widget === 'multi') {
                 if ($scope.entity[Fields[i].model].length === 0) {
                 $scope.entity[Fields[i].model] = [''];
                 }
                 }
                 if (Fields[i].widget === 'asociated') {
                 if ($scope.entity[Fields[i].model].length === 0) {
                 $scope.entity[Fields[i].model] = [{}];
                 }
                 }
                 
                 if (Fields[i].widget === 'lookup') {
                 $scope.getOptions(i);
                 }
                 }*/

                for (var t = 0; t < $scope.app.tabs.length; t++) {
                    for (var i = 0; i < $scope.app.tabs[t].formFields.length; i++) {
                        if ($scope.app.tabs[t].formFields[i].widget === 'multi') {
                            if ($scope.entity[$scope.app.tabs[t].formFields[i].model].length === 0) {
                                $scope.entity[$scope.app.tabs[t].formFields[i].model] = [''];
                            }
                        }
                        if ($scope.app.tabs[t].formFields[i].widget === 'asociated') {
                            if ($scope.entity[$scope.app.tabs[t].formFields[i].model].length === 0) {
                                $scope.entity[$scope.app.tabs[t].formFields[i].model] = [{}];
                                for (var j = 0; j < $scope.app.tabs[t].formFields[i].multiFields.length; j++) {
                                    if ($scope.app.tabs[t].formFields[i].multiFields[j].widget === 'asociated') {
                                        var field = $scope.app.tabs[t].formFields[i].multiFields[j].model;
                                        if ($scope.entity[$scope.app.tabs[t].formFields[i].model][0][field].length === 0) {
                                            $scope.entity[$scope.app.tabs[t].formFields[i].model][0][field] = [{}];
                                        }
                                    }
                                    if ($scope.app.tabs[t].formFields[i].multiFields[j].widget === 'multi') {
                                        var field = $scope.app.tabs[t].formFields[i].multiFields[j].model;
                                        if ($scope.entity[$scope.app.tabs[t].formFields[i].model][0][field].length === 0) {
                                            $scope.entity[$scope.app.tabs[t].formFields[i].model][0][field] = [''];
                                        }

                                    }
                                    if ($scope.app.tabs[t].formFields[i].multiFields[j].multiFields !== null) {
                                        for (var k = 0; k < $scope.app.tabs[t].formFields[i].multiFields[j].multiFields.length; k++) {
                                            if ($scope.app.tabs[t].formFields[i].multiFields[j].multiFields[k] !== null && $scope.app.tabs[t].formFields[i].multiFields[j].multiFields[k].widget === 'multi') {
                                                var field2 = $scope.app.tabs[t].formFields[i].multiFields[j].multiFields[k].model;
                                                if ($scope.entity[$scope.app.tabs[t].formFields[i].model][0][field][0][field2].length === 0) {
                                                    $scope.entity[$scope.app.tabs[t].formFields[i].model][0][field][0][field2] = [''];
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if ($scope.app.tabs[t].formFields[i].widget === 'lookup') {
                            $scope.getOptions(t, i);
                        }
                        /*if ($scope.app.tabs[t].formFields[i].widget === 'date') {
                         var field = $scope.app.tabs[t].formFields[i].model;                       
                         $scope.app.popup[field] = {"opened": false};
                         console.log($scope.app.popup);
                         }*/
                    }
                }

            };

            $scope.getOptions = function (t, i) {
                var count = i;
                if ($scope.app.tabs[t].formFields[i].lookupType === "LOOKUP_TABLE") {
                    LookupOptionService.getByLookupName({entity: $scope.app.tabs[t].formFields[i].lookupName}, function (options) {
                        //$scope.app.tabs[t].formFields[count].options = options;
                        var opts = [];
                        for (var i = 0; i < options.length; i++) {
                            opts.push(options[i].name);
                        }
                        $scope.app.tabs[t].formFields[count].options = opts;
                    });
                } else if ($scope.app.tabs[t].formFields[i].lookupType === "ENTITY") {
                    LookupOptionService.getByEntityName({entity: $scope.app.tabs[t].formFields[i].lookupName, entityFieldName: $scope.app.tabs[t].formFields[i].lookupEntityFieldName}, function (options) {
                        //$scope.app.tabs[t].formFields[count].options = options;                                                
                        var opts = [];
                        for (var i = 0; i < options.length; i++) {
                            opts.push(options[i].name);
                        }
                        $scope.app.tabs[t].formFields[count].options = opts;
                    });
                }
            };

            $scope.idNotFound = function () {
                $uibModal.open({
                    animation: true,
                    templateUrl: 'okContent.html',
                    controller: ['$scope', '$uibModalInstance', function ($scope, $uibModalInstance) {
                            $scope.title = "ID Should not be Empty!";
                            $scope.msg = "Please Enter the Id Number";
                            $scope.ok = function () {
                                $uibModalInstance.close();
                            };

                            $scope.cancel = function () {
                                $uibModalInstance.dismiss('cancel');
                            };
                        }]
                });
            };

            $scope.RecordNotFound = function () {
                $uibModal.open({
                    animation: true,
                    templateUrl: 'okContent.html',
                    controller: ['$scope', '$uibModalInstance', function ($scope, $uibModalInstance) {
                            $scope.title = "Record Not Found!";
                            $scope.msg = "Application does not contain record with the speciecd ID Number.";
                            $scope.ok = function () {
                                $uibModalInstance.close();
                            };

                            $scope.cancel = function () {
                                $uibModalInstance.dismiss('cancel');
                            };
                        }]
                });
            };

            $scope.edit = function () {
                if (!$scope.app.current.id) {
                    //alert("Please Enter the Id Number");
                    $scope.idNotFound();
                } else {
                    $http.get(REST_HOST + $scope.app.entity + "/" + $scope.app.current.id).success(function (data) {
                        if (data !== null) {
                            $scope.entity = data;
                            $scope.setUpFieldsEdit();
                            //At last
                            $scope.app.current.type = 'edit';
                        } else {
                            $scope.RecordNotFound();
                        }
                    }).error(function (data, status) {
                        $scope.RecordNotFound();
                        console.error('Repos error', status, data);
                    });
                }
            };

            $scope.view = function () {
                if (!$scope.app.current.id) {
                    $scope.idNotFound();
                } else {
                    $http.get(REST_HOST + $scope.app.entity + "/" + $scope.app.current.id).success(function (data) {
                        if (data !== null) {
                            $scope.app.current.type = 'view';
                            $scope.entity = data;
                        } else {
                            $scope.RecordNotFound();
                        }
                    }).error(function (data, status) {
                        $scope.RecordNotFound();
                    });
                }
            };

            $scope.authroize = function () {
                if (!$scope.app.current.id) {
                    $scope.idNotFound();
                } else {
                    $http.get(REST_HOST + $scope.app.entity + "_pnd/" + $scope.app.current.id).success(function (data) {
                        if (data !== null) {
                            $scope.app.current.type = 'authorize';
                            $scope.entity = data;
                        } else {
                            $scope.RecordNotFound();
                        }
                    }).error(function (data, status) {
                        $scope.RecordNotFound();
                    });
                }
            };

            $scope.enquiry = function () {
                $scope.app.current.type = 'enquiry';
                var columFilters = {};
                for (var t = 0; t < $scope.app.tabs.length; t++) {
                    for (var i in $scope.app.tabs[t].formFields) {
                        //console.log($scope.app.tabs[t].formFields[i].model + "  " + $scope.app.tabs[t].formFields[i].label);
                        if ($scope.app.tabs[t].formFields[i].model) {
                            columFilters[i] = {type: 'text'};
                        }
                    }
                }
                $scope.dtOptions = DTOptionsBuilder.fromSource(REST_HOST + $scope.app.entity).withButtons([
                    //'columnsToggle',
                    'colvis',
                    'copy',
                    'print'
                ])
                        .withBootstrap()
                        .withColVis()
                        //.withScroller()
                        .withLightColumnFilter(columFilters)
                        .withOption('responsive', true)
                        .withOption('createdRow', createdRow);


                $scope.dtColumns = [];
                for (var t = 0; t < $scope.app.tabs.length; t++) {
                    for (var i in $scope.app.tabs[t].formFields) {
                        //console.log($scope.app.tabs[t].formFields[i].model + "  " + $scope.app.tabs[t].formFields[i].label);
                        if ($scope.app.tabs[t].formFields[i].model) {
                            $scope.dtColumns[i] = DTColumnBuilder.newColumn($scope.app.tabs[t].formFields[i].model).withTitle($scope.app.tabs[t].formFields[i].label);
                        }
                    }
                }
                $scope.dtColumns.push(DTColumnBuilder.newColumn('action').withTitle('Action').notSortable().renderWith(function (data, type, full) {
                    //return "<div> <a class = \"btn btn-default btn-sm\" onclick=\"MyFunction();return false;\" ng-href = \"#/app/" + $scope.app.name + "/edit/" + full.id + "\"><i class='glyphicon glyphicon-edit'></i></a> \n\
                    //<a class=\"btn btn-default btn-sm\" href=\"#/app/" + $scope.app.name + "/view/" + full.id + "\"><i class='glyphicon glyphicon-th-list'></i></a></div>";
                    return '<button class="btn btn-sm btn-info" ng-click="showEdit(\'' + full.id + '\')">' +
                            '   <i class="glyphicon glyphicon-edit"></i>' +
                            '</button>&nbsp;' +
                            '<button class="btn btn-sm btn-info" ng-click="showView(\'' + full.id + '\')">' +
                            '   <i class="glyphicon glyphicon-th-list"></i>' +
                            '</button>';
                }));
            };


            function createdRow(row, data, dataIndex) {
                // Recompiling so we can bind Angular directive to the DT
                $compile(angular.element(row).contents())($scope);
            }


            $scope.exceptionEnquiry = function () {
                $scope.app.current.type = 'exceptionEnquiry';
                $scope.dtOptions = DTOptionsBuilder.fromSource(REST_HOST + $scope.app.entity + "_pnd");
                $scope.dtColumns = [];
                for (var t = 0; t < $scope.app.tabs.length; t++) {
                    for (var i in $scope.app.tabs[t].formFields) {
                        if ($scope.app.tabs[t].formFields[i].model) {
                            $scope.dtColumns[i] = DTColumnBuilder.newColumn($scope.app.tabs[t].formFields[i].model, $scope.app.tabs[t].formFields[i].label);
                        }
                    }
                }
                $scope.dtColumns.push(DTColumnBuilder.newColumn('action').withTitle('Action').notSortable().renderWith(function (data, type, full) {
                    //return "<div> <a class = \"btn btn-default btn-sm\" href = \"#/app/" + $scope.app.name + "/edit/" + full.id + "\"><i class='glyphicon glyphicon-edit'></i></a> \n\
                    //<a class=\"btn btn-default btn-sm\" href=\"#/app/" + $scope.app.name + "/view/" + full.id + "\"><i class='glyphicon glyphicon-th-list'></i></a></div>";
                    return '<button class="btn btn-sm btn-info" ng-click="showEdit(\'' + full.id + '\')">' +
                            '   <i class="glyphicon glyphicon-edit"></i>' +
                            '</button>&nbsp;' +
                            '<button class="btn btn-sm btn-info" ng-click="showView(\'' + full.id + '\')" "="">' +
                            '   <i class="glyphicon glyphicon-th-list"></i>' +
                            '</button>';
                }));
            };

            $scope.showEdit = function (id) {
                //alert(id);
                $scope.app.current.id = id;
                $scope.app.current.id = id;
                $scope.edit();
            };

            $scope.showView = function (id) {
                $scope.app.current.id = id;
                $http.get(REST_HOST + $scope.app.entity + "/" + id).success(function (data) {
                    if (data !== null) {
                        $scope.app.current.type = 'view';
                        $scope.entity = data;
                    } else {
                        $scope.RecordNotFound();
                    }
                }).error(function (data, status) {
                    $scope.RecordNotFound();
                });
            };


            $scope.gotoHome = function () {
                $state.go("home");
            };


            $scope.pdf = function () {
                $http.get(REST_HOST + $scope.app.entity + '/reports/by/name/pdf', {responseType: 'arraybuffer'}).success(function (data, status, headers, config) {
                    //FileSaver.saveAs(blob, $scope.app.entity + '.pdf');
                    var file = new Blob([data], {type: 'application/pdf'});
                    var fileURL = URL.createObjectURL(file);
                    window.open(fileURL);
                });
            };

            $scope.excel = function () {
                $http.get(REST_HOST + $scope.app.entity + '/reports/by/name/excel', {responseType: 'arraybuffer'}).success(function (data) {
                    var file = new Blob([data], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    //FileSaver.saveAs(blob, $scope.app.entity + '.xlsx');
                    var fileURL = URL.createObjectURL(file);
                    window.open(fileURL);
                });
            };

            $scope.csv = function () {
                $http.get(REST_HOST + $scope.app.entity + '/reports/by/name/csv').success(function (data) {
                    var blob = new Blob([data], {type: 'text/csv;charset=utf-8'});
                    FileSaver.saveAs(blob, $scope.app.entity + '.csv');
                });
            };
        }
    ]);
});