/*global require*/
'use strict';

define(['./controllers'], function (controllers) {

    controllers.controller('HomeController', ['$scope', '$state', 'Menus', function ($scope, $state, Menus) {

            //$scope.apps = Apps;
            $scope.menus = Menus;
            $scope.oneAtATime = true;

            $scope.apps = [];
            $scope.appName = "";

            for (var i = 0; i < Menus.length; i++) {
                for (var j = 0; j < Menus[i].subMenus.length; j++) {
                    $scope.apps.push(Menus[i].subMenus[j].name);
                }
            }

            $scope.gotoApp = function (keyEvent) {
                if (keyEvent.which === 13) {
                    $state.go("app", {"entity": $scope.appName});
                }
            };
        }

    ]);
});