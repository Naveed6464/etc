
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.domain.entities;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Transient;

/**
 *
 * @author Administrator
 */
@Entity
public class Settings extends AbstractEntity {

    String smtpHost;
    String smtpPort;
    String userName;
    String password;
    String msgSubject;
    String msgText;
    String fromEmail;
    String jasperFileName;
    @Transient
    List<Option> availableJasper;

    public Settings(String smtpHost, String smtpPort, String userName, String passWord, String msgSubject, String msgText, String fromEmail, String jasperFileName) {
        this.smtpHost = smtpHost;
        this.smtpPort = smtpPort;
        this.userName = userName;
        this.password = passWord;
        this.msgSubject = msgSubject;
        this.msgText = msgText;
        this.fromEmail = fromEmail;
        this.jasperFileName = jasperFileName;
    }

    public Settings() {
    }

    public String getSmtpHost() {
        return smtpHost;
    }

    public void setSmtpHost(String smtpHost) {
        this.smtpHost = smtpHost;
    }

    public String getSmtpPort() {
        return smtpPort;
    }

    public void setSmtpPort(String smtpPort) {
        this.smtpPort = smtpPort;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMsgSubject() {
        return msgSubject;
    }

    public void setMsgSubject(String msgSubject) {
        this.msgSubject = msgSubject;
    }

    public String getMsgText() {
        return msgText;
    }

    public void setMsgText(String msgText) {
        this.msgText = msgText;
    }

    public void setFromEmail(String fromEmail) {
        this.fromEmail = fromEmail;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public void setJasperFileName(String jasperFileName) {
        this.jasperFileName = jasperFileName;
    }

    public String getJasperFileName() {
        return jasperFileName;
    }

    public void setAvailableJasper(List<Option> availableJasper) {
        this.availableJasper = availableJasper;
    }

    public List<Option> getAvailableJasper() {
        return availableJasper;
    }
    
    

}
