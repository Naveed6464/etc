/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ncr.itm.middleware.web.domain.entities;

import javax.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *
 * @author Administrator
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = false)
public class AuditLog extends AbstractEntity {

    String level;
    String msg;
    String userid;
    String ip;
    String action;

    public AuditLog() {
    }

    public AuditLog(String level, String msg, String userid, String ip, String action) {
        this.level = level;
        this.msg = msg;
        this.userid = userid;
        this.ip = ip;
        this.action = action;
    }

}
